#!/usr/bin/env python3
"""第 1 章教学用最小推理服务：普通/流式请求 + 逐事件请求日志。

设计边界（正文明确声明）：单进程单模型、生成串行（全局锁）、SSE 按 token
增量推送；不含生产级并发、排队与超时管理——那是第 9/15 章的对象。

启动：python experiments/exp_ch1_serving/serve_pi.py [--port 8317]
请求：POST /v1/generate  body={"prompt": str, "max_tokens": int<=256, "stream": bool}
  stream=false → JSON 一次性返回；stream=true → SSE，事件序列
    received → first_token（首 token，含 prefill）→ token×（后续 token）
    → done（结束：eos 或 max_tokens）
日志：request_log.jsonl 逐事件一行（事件类型/请求内相对毫秒/内容），用于
  指出首 token、后续 token 与结束事件。
"""

from __future__ import annotations

import argparse
import json
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from threading import Lock
from typing import Iterator

import torch
from tokenizers.decoders import DecodeStream
from transformers import AutoModelForCausalLM, AutoTokenizer

ROOT = Path(__file__).resolve().parents[2]
MODEL_DIR = ROOT / "models" / "qwen3-0.6b"
LOG_PATH = Path(__file__).resolve().parent / "request_log.jsonl"
MAX_TOKENS_LIMIT = 256
MAX_PROMPT_CHARS = 2000


class Engine:
    """贪心解码引擎：首步 prefill、其后逐 token 增量（use_cache）。

    stream_generate 是事件生成器：每个事件写日志并 yield 给调用方
    （流式请求直接转发给客户端，非流式请求只取最后一个事件）。
    """

    def __init__(self) -> None:
        self.tok = AutoTokenizer.from_pretrained(MODEL_DIR)
        self.model = AutoModelForCausalLM.from_pretrained(MODEL_DIR, dtype=torch.float32)
        self.model.eval()
        self.lock = Lock()
        self.eos = {self.tok.eos_token_id}
        for name in ("im_end", "endoftext"):
            extra = getattr(self.tok, f"{name}_id", None)
            if isinstance(extra, int):
                self.eos.add(extra)
        self.log = LOG_PATH.open("a", encoding="utf-8")

    def _emit(self, request_id: str, event: dict, t0: float) -> None:
        """请求日志：一行一事件，时间为请求内相对毫秒。"""
        row = {"request_id": request_id, "event": event["event"],
               "t_ms": round((time.perf_counter() - t0) * 1e3, 1)}
        row.update({k: v for k, v in event.items() if k != "event"})
        self.log.write(json.dumps(row, ensure_ascii=False) + "\n")
        self.log.flush()

    @torch.no_grad()
    def stream_generate(self, request_id: str, prompt: str, max_tokens: int) -> Iterator[dict]:
        """逐事件产出；首 token 单列事件（含 prefill），done 事件带完整结果。"""
        t0 = time.perf_counter()
        messages = [{"role": "user", "content": prompt}]
        prompt_ids = self.tok.apply_chat_template(messages, add_generation_prompt=True, tokenize=True)["input_ids"]
        event = {"event": "received", "prompt": prompt, "prompt_tokens": len(prompt_ids),
                 "max_tokens": max_tokens}
        self._emit(request_id, event, t0)
        yield event
        with self.lock:
            past = None
            step_input = torch.tensor([prompt_ids])
            decoder = DecodeStream(skip_special_tokens=False)
            text = ""
            token_ids: list[int] = []
            stop_reason = "max_tokens"
            first = True
            for _ in range(max_tokens):
                out = self.model(step_input if past is None else step_input[:, -1:],
                                 past_key_values=past, use_cache=True)
                past = out.past_key_values
                nxt = int(out.logits[0, -1].argmax())
                token_ids.append(nxt)
                if nxt in self.eos or len(token_ids) == max_tokens:
                    # At the limit even an incomplete final character must agree with batch decode.
                    complete = self.tok.decode(token_ids, skip_special_tokens=False, clean_up_tokenization_spaces=False)
                    piece = complete[len(text):]
                else:
                    piece = decoder.step(self.tok.backend_tokenizer, nxt) or ""
                text += piece
                event = {"event": "first_token" if first else "token",
                         "token_id": nxt, "text": piece, "pos": len(token_ids) - 1}
                self._emit(request_id, event, t0)
                yield event
                first = False
                if nxt in self.eos:
                    stop_reason = "eos"
                    break
                step_input = torch.tensor([[nxt]])
        result = {"event": "done", "stop_reason": stop_reason, "new_tokens": len(token_ids),
                  "text": text}
        self._emit(request_id, result, t0)
        yield result


class Handler(BaseHTTPRequestHandler):
    engine: Engine
    counter: list[int] = [0]

    def do_POST(self) -> None:  # noqa: N802（http.server 命名约定）
        if self.path != "/v1/generate":
            self._error(404, "not_found", f"未知路径 {self.path}")
            return
        try:
            length = int(self.headers.get("Content-Length", 0))
            body = json.loads(self.rfile.read(length))
            if not isinstance(body, dict):
                raise ValueError
        except (ValueError, json.JSONDecodeError):
            self._error(400, "bad_request", "请求体必须是 JSON 对象")
            return
        unknown = set(body) - {"prompt", "max_tokens", "stream"}
        if unknown:
            self._error(400, "unknown_param", f"未知参数 {sorted(unknown)}")
            return
        prompt = body.get("prompt")
        if not isinstance(prompt, str) or not prompt:
            self._error(400, "bad_prompt", "prompt 必须是非空字符串")
            return
        if len(prompt) > MAX_PROMPT_CHARS:
            self._error(413, "prompt_too_long", f"prompt 超过 {MAX_PROMPT_CHARS} 字符上限")
            return
        max_tokens = body.get("max_tokens", 32)
        if not isinstance(max_tokens, int) or isinstance(max_tokens, bool) or not 1 <= max_tokens <= MAX_TOKENS_LIMIT:
            self._error(400, "bad_max_tokens", f"max_tokens 必须是 1..{MAX_TOKENS_LIMIT} 整数")
            return
        Handler.counter[0] += 1
        request_id = f"r{Handler.counter[0]:03d}"
        if body.get("stream", False):
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()
            for event in self.engine.stream_generate(request_id, prompt, max_tokens):
                data = json.dumps(event, ensure_ascii=False)
                self.wfile.write(f"data: {data}\n\n".encode("utf-8"))
                self.wfile.flush()
            return
        last: dict = {}
        for last in self.engine.stream_generate(request_id, prompt, max_tokens):
            pass
        self._json(200, {"request_id": request_id, **{k: last[k] for k in ("stop_reason", "new_tokens", "text")}})

    def _json(self, code: int, obj: dict) -> None:
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _error(self, code: int, err: str, message: str) -> None:
        self._json(code, {"error": err, "message": message})

    def log_message(self, fmt: str, *args) -> None:  # 静默默认访问日志
        pass


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8317)
    args = parser.parse_args()
    Handler.engine = Engine()
    server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    print(f"[serve_pi] Qwen3-0.6B 就绪 http://127.0.0.1:{args.port}/v1/generate（日志 {LOG_PATH.name}）", flush=True)
    server.serve_forever()


if __name__ == "__main__":
    main()
