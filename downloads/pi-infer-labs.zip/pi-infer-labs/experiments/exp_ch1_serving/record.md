# exp_ch1_serving 最小服务请求链路 · 实验记录

| 项 | 结果 | 判据 |
|---|---|---|
| E1 普通请求 | PASS | 固定 prompt（中文问答+写代码两条）非流式响应存档 raw.json；32 token 1.97s（含 thinking 段） |
| E2 流式请求 | PASS | 事件序列 received→first_token(162ms 含 prefill)→token×31(≈55ms/token)→done(1859ms)；SSE 增量拼接、生成 ID 整段解码和 E1 完整输出一致，跨两个 token 的「缓」正确还原 |
| E3 错误定位 | PASS | 非法 JSON/未知参数/超长输入/max_tokens 越界四类：HTTP 400/400/413/400 各自错误体；请求日志均无 received（参数校验前置，坏请求不进生成队列） |

- 环境：3.12.10 / torch 2.15.0+cpu / transformers 5.22.1 / CPU（OMP、MKL 各 4 线程）
- 模型：Qwen/Qwen3-0.6B 本地 models/qwen3-0.6b（revision c1899de2）
- 生成口径：默认 chat template（模型默认 thinking）、greedy argmax、EOS 或 max_tokens=32
- 交付物：可重跑命令（单命令脚本封装启动/请求/存档/关停；curl 形式在 raw.json e1/e2.curl 字段）、固定输入输出（raw.json）、请求日志（request_log.jsonl 逐事件一行，first_token/token/done 对应首/后续/结束事件）
- 复跑：`python experiments/exp_ch1_serving/run_ch1_experiment.py`
- 降级说明：请求链路/流式/日志为正确性验收（CPU 签收）；时间戳只作本机相对对照；vLLM 生产引擎启动实测未测（命令按官方文档写入正文，references S3）
