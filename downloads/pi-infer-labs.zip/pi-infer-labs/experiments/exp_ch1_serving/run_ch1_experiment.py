#!/usr/bin/env python3
"""第 1 章实验：最小服务的普通/流式请求、事件标注与错误定位。

单命令复跑：拉起 serve_pi.py 子进程 → 发固定请求 → 存档响应与请求日志
→ 关闭服务。产物：raw.json（响应+事件+错误对照表）、request_log.jsonl。

复跑：python experiments/exp_ch1_serving/run_ch1_experiment.py
"""

from __future__ import annotations

import json
import platform
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

from transformers import AutoTokenizer

OUT_DIR = Path(__file__).resolve().parent
PORT = 8317
BASE = f"http://127.0.0.1:{PORT}"
PROMPT_A = "用一句话解释什么是 KV 缓存。"
PROMPT_B = "写一个 Python 函数，返回两个数中的较大者。"
MAX_TOKENS = 32


def post(body: str, timeout: float = 600.0):
    """发 JSON POST；返回 (status, obj)。非 2xx 时 obj 为错误体。"""
    req = urllib.request.Request(
        BASE + "/v1/generate", data=body.encode("utf-8"),
        headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode("utf-8"))


def post_stream(body: str, timeout: float = 600.0):
    """发 SSE 流式请求；返回逐事件列表（带客户端相对毫秒）。"""
    req = urllib.request.Request(
        BASE + "/v1/generate", data=body.encode("utf-8"),
        headers={"Content-Type": "application/json"}, method="POST")
    events = []
    t0 = time.perf_counter()
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        for raw in resp:
            line = raw.decode("utf-8").strip()
            if not line.startswith("data: "):
                continue
            events.append({
                "t_client_ms": round((time.perf_counter() - t0) * 1e3, 1),
                **json.loads(line[len("data: "):]),
            })
    return events


def _utf8_stdout():
    import sys as _s
    for _st in (_s.stdout, _s.stderr):
        try:
            _st.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


def main() -> None:
    _utf8_stdout()
    record: dict = {"env": {
        "python": platform.python_version(),
        "model": "Qwen/Qwen3-0.6B 本地 models/qwen3-0.6b（revision c1899de2，versions.md）",
        "server": "experiments/exp_ch1_serving/serve_pi.py（标准库 http.server + SSE）",
        "generation_spec": {
            "chat_template": "Qwen3-0.6B 默认 chat template",
            "sampling": "greedy argmax（无采样，确定性）",
            "stop": "eos 或 max_tokens 上限",
        },
    }}
    log_path = OUT_DIR / "request_log.jsonl"
    if log_path.exists():
        log_path.unlink()
    server = subprocess.Popen(
        [sys.executable, "-X", "utf8", str(OUT_DIR / "serve_pi.py"), "--port", str(PORT)],
        cwd=OUT_DIR, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
        encoding="utf-8", errors="replace")   # 服务输出按 UTF-8 读（Windows 默认 GBK 会崩）
    try:
        deadline = time.time() + 300  # 模型加载上限
        while True:
            line = server.stdout.readline()
            if "就绪" in line:
                break
            if time.time() > deadline or server.poll() is not None:
                raise RuntimeError(f"服务未就绪：{line or server.poll()}")
        print("[E1] 普通请求（非流式）")
        t0 = time.perf_counter()
        status, resp_a = post(json.dumps({"prompt": PROMPT_A, "max_tokens": MAX_TOKENS}))
        wall_a = round(time.perf_counter() - t0, 2)
        status_b, resp_b = post(json.dumps({"prompt": PROMPT_B, "max_tokens": MAX_TOKENS}))
        print(f"  [{status}] {resp_a['new_tokens']} tokens, {wall_a}s: {resp_a['text'][:60]}")
        record["e1_blocking"] = {
            "curl": (f'curl -s {BASE}/v1/generate -H "Content-Type: application/json" '
                     f'-d \'{json.dumps({"prompt": PROMPT_A, "max_tokens": MAX_TOKENS}, ensure_ascii=False)}\''),
            "prompt": PROMPT_A, "response": resp_a, "wall_s": wall_a,
            "prompt_b": PROMPT_B, "response_b": resp_b,
        }

        print("[E2] 流式请求（SSE）")
        events = post_stream(json.dumps({"prompt": PROMPT_A, "max_tokens": MAX_TOKENS, "stream": True}))
        kinds = [e["event"] for e in events]
        first_ms = next(e["t_client_ms"] for e in events if e["event"] == "first_token")
        done_ms = events[-1]["t_client_ms"]
        n_token = sum(1 for e in events if e["event"] in ("token", "first_token"))
        print(f"  事件序列: received → first_token → token×{n_token-1} → done")
        print(f"  首 token {first_ms}ms，结束 {done_ms}ms（客户端相对）")
        record["e2_stream"] = {
            "curl": (f'curl -N {BASE}/v1/generate -H "Content-Type: application/json" '
                     f'-d \'{json.dumps({"prompt": PROMPT_A, "max_tokens": MAX_TOKENS, "stream": True}, ensure_ascii=False)}\''),
            "events": events, "kinds": kinds,
            "first_token_ms_client": first_ms, "done_ms_client": done_ms,
            "token_count": n_token,
            "note": "first_token 含 prefill；流式与非流式同 prompt 同 max_tokens，输出文本一致见 check",
        }

        print("[E3] 错误定位（四类，各自的服务端表现）")
        errors = []
        cases = [
            ("非法 JSON", "not-json{{", None),
            ("未知参数", '{"prompt":"hi","temperature":0.7}', None),
            ("超长输入", json.dumps({"prompt": "长" * 3000, "max_tokens": 8}), None),
            ("max_tokens 越界", '{"prompt":"hi","max_tokens":0}', None),
        ]
        for name, payload, _ in cases:
            status, err = post(payload)
            errors.append({"case": name, "payload_head": payload[:40], "http_status": status, "error": err})
            print(f"  {name}: HTTP {status} → {err.get('error')}: {err.get('message')}")
        record["e3_errors"] = errors

        log_rows = [json.loads(l) for l in log_path.read_text(encoding="utf-8").splitlines() if l]
        token_events = [e for e in events if e["event"] in ("first_token", "token")]
        tokenizer = AutoTokenizer.from_pretrained(OUT_DIR.parents[1] / "models/qwen3-0.6b")
        decoded = tokenizer.decode([e["token_id"] for e in token_events],
                                   skip_special_tokens=False, clean_up_tokenization_spaces=False)
        record["checks"] = {
            "stream_and_blocking_text_identical": events[-1]["text"] == resp_a["text"],
            "stream_matches_decoded_ids": "".join(e["text"] for e in token_events) == decoded == events[-1]["text"],
            "log_has_first_token_and_done": any(r["event"] == "first_token" for r in log_rows)
            and any(r["event"] == "done" for r in log_rows),
            "errors_all_rejected": all(e["http_status"] >= 400 for e in errors),
        }
        record["request_log"] = log_rows
        record["degradation_note"] = (
            "本实验为请求链路/流式/日志的正确性验收（CPU 签收）；时间戳只作本机相对对照，"
            "不构成服务性能结论；生产引擎（vLLM）启动与实测标'未测'（5.3）")
        all_ok = all(record["checks"].values())
        (OUT_DIR / "raw.json").write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"\n结论：{'PASS' if all_ok else 'FAIL'}（raw.json + request_log.jsonl）")
    finally:
        server.terminate()
        try:
            server.wait(timeout=10)
        except subprocess.TimeoutExpired:
            server.kill()
    sys.exit(0 if all_ok else 1)


if __name__ == "__main__":
    main()
