# exp_ch10 通信原语小张量进程验证 · 实验记录

复跑基准：git eed7a4d；环境：Python 3.12.10 / torch 2.15.0+cpu / Windows CPU / **gloo 后端**（无 NCCL、无 GPU）。

| 项 | 结果 | 判据 |
|---|---|---|
| 五原语（world=2/4，[16] fp32） | 全部 allclose，**max&#124;Δ&#124; = 0** | 分布式执行 vs 单进程手算参考 |
| TP2 列切分 Linear+all_reduce | allclose 0 误差 | vs 单进程完整 Linear |
| PP2 两阶段接力（tiny 按层拆） | allclose 0 误差 | vs 单进程完整前向 |
| 字节账 | **42 组 ByteLog 与手算一致** | 逻辑载荷口径（逐 rank 应用层发送 numel×4B，Σrank 聚合）；ring 链路公式另列（all_reduce 每 rank ≈2(P−1)/P·N·4B） |
| 报错路径 | reduce_scatter/all_gather 非整除、rank 间参数不一致均显式报错 | 报错行为入测试 |
| 进程清理 | world=2/4 无残留 worker | spawn join + destroy_process_group |

- 小张量计时（相对）：[8] 与 [1024] fp32 的集合通信同为毫秒量级（如 all_reduce world=2 ≈0.76 ms、world=4 ≈2.9 ms；[1024] ≈2.9 ms）——小消息被固定延迟主导；预热≥2+交错重复≥5，样本含首连接触发的高尾（如实保留在 raw）。
- 生成口径：不适用（无生成任务；显式标注）。
- 复跑：`python -m pytest pi_infer/tests/test_comm.py -q`（12 项）；`python experiments/exp_ch10_comm/run_comm_experiment.py`（产物 raw.json）。
- 降级说明：gloo CPU 同机相对对照；NCCL/NVLink/IB、真实多卡吞吐与 TP/PP/DP 设备端对照未测（5.3）；DP 副本未做多进程实跑（10.4 为机制推演）。
