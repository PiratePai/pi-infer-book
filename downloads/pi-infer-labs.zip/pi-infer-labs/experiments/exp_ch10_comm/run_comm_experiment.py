"""第 10 章通信实验：gloo CPU 正确性、应用层载荷账及同机相对计时。

运行：python experiments/exp_ch10_comm/run_comm_experiment.py [--output 路径]
进程启动和模型构造不计时；NCCL、GPU 与设备性能未测。不生成 record.md。
"""

from __future__ import annotations

import argparse
import json
import platform
import statistics
import sys
import traceback
from dataclasses import asdict, is_dataclass
from datetime import datetime, timezone
from pathlib import Path

import torch
import torch.distributed as dist
import torch.multiprocessing as mp

# 支持从仓库根或任意工作目录直接执行脚本。
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from pi_infer.comm import (  # noqa: E402
    aggregate_bytes, all_gather, all_reduce, broadcast, p2p_recv, p2p_send,
    pp2_tiny_forward, reduce_scatter, spawn_workers, time_op, tp2_matmul,
    verify_primitives,
)


WARMUP = 2
REPEATS = 5
SIZES = (8, 64, 1024)
OPS = ("p2p", "broadcast", "all_reduce", "reduce_scatter", "all_gather")


def _timing_case(op, n, world, last_logs, key):
    """构造一次缓冲区，返回所有 rank 顺序一致的阻塞原语调用。"""
    rank = dist.get_rank()
    tensor = torch.arange(n, dtype=torch.float32) + rank
    recv = torch.empty_like(tensor)
    shard = tensor.chunk(world)[rank].clone()

    def operation():
        if op == "p2p":
            # 所有 rank 均有一笔 send；串行环消除阻塞发送的循环等待。
            for src in range(world):
                dst = (src + 1) % world
                if rank == src:
                    log = p2p_send(tensor, dst)
                elif rank == dst:
                    p2p_recv(recv, src)
        elif op == "broadcast":
            _, log = broadcast(tensor)
        elif op == "all_reduce":
            # 复用原地缓冲区，7 轮累计值仍有限；正确性另由独立负载验证。
            _, log = all_reduce(tensor)
        elif op == "reduce_scatter":
            _, log = reduce_scatter(tensor)
        else:
            _, log = all_gather(shard, total_numel=n)
        last_logs[key] = log

    return operation


def _experiment_worker(world):
    """顶层可 pickle 工作负载，每个 world 只 spawn 一轮以摊薄启动成本。"""
    result = {"rank": dist.get_rank(), "primitives": verify_primitives(world)}
    if world == 2:
        result.update(tp2=tp2_matmul(world), pp2=pp2_tiny_forward(world))
    result["shape_checks"] = {}
    for name, operation in (
        ("reduce_scatter_nondivisible", lambda: reduce_scatter(torch.ones(world + 1))),
        ("all_gather_nondivisible", lambda: all_gather(torch.ones(2), total_numel=world + 1)),
        ("all_gather_asymmetric", lambda: all_gather(torch.ones(2 + dist.get_rank()))),
    ):
        try:
            operation()
        except ValueError as error:
            result["shape_checks"][name] = {"pass": True, "error": str(error)}
        else:
            result["shape_checks"][name] = {"pass": False}
    last_logs = {}
    cases = {f"{op}/{n}": _timing_case(op, n, world, last_logs, f"{op}/{n}")
             for n in SIZES for op in OPS}
    dist.barrier()  # 统一开始，barrier 本身不计时。
    result["timings"] = time_op(cases, repeats=REPEATS, warmup=WARMUP)
    result["timing_byte_logs"] = last_logs
    return result


def _expected_bytes(op, world, n):
    """独立手算每 rank 发送元素数；N 是完整向量长度，元素为 float32。"""
    if op == "broadcast":
        return [n * 4] + [0] * (world - 1)
    if op == "all_gather":
        return [n // world * 4] * world
    return [n * 4] * world


def _byte_comparison(label, logs, expected, formula):
    observed = aggregate_bytes(logs)
    passed = (observed["per_rank"] == dict(enumerate(expected))
              and observed["total_bytes"] == sum(expected))
    return {"case": label, "formula": formula, "byte_logs": logs,
            "observed": observed, "expected_per_rank": expected,
            "expected_total_bytes": sum(expected), "pass": passed}


def _summarize(world, ranks):
    """独立核对结果及字节账；计时以每轮各 rank 的最大本地耗时汇总。"""
    formulas = {"p2p": "环中每 rank 一次发送 N×4；Σrank=P×N×4",
                "broadcast": "仅源提交 N×4，其余为 0；Σrank=N×4",
                "all_reduce": "每 rank API 输入 N×4；Σrank=P×N×4",
                "reduce_scatter": "每 rank API 输入 N×4；输出 N/P；Σrank=P×N×4",
                "all_gather": "每 rank API 分片输入 (N/P)×4；Σrank=N×4"}
    comparisons = []
    checks = [check["pass"] for rank in ranks for check in rank["shape_checks"].values()]
    for op in OPS:
        values = [rank["primitives"][op] for rank in ranks]
        checks.extend(bool(passed) and delta <= 1e-6 for passed, _, delta in values)
        comparisons.append(_byte_comparison(
            f"verify/{op}", [value[1] for value in values],
            _expected_bytes(op, world, 8 * world), formulas[op]))
    if world == 2:
        for op, expected, formula in (
            ("tp2", [128, 128], "B=1,T=2,d_out=16；每 rank B×T×d_out×4=128，Σrank=256"),
            ("pp2", [1024, 0], "B=1,T=4,d=64；仅 rank0 发送 B×T×d×4=1024，Σrank=1024"),
        ):
            values = [rank[op] for rank in ranks]
            checks.extend(bool(passed) and delta <= 1e-6 for passed, _, delta in values)
            comparisons.append(_byte_comparison(op, [value[1] for value in values], expected, formula))
    timing_rows = []
    for n in SIZES:
        for op in OPS:
            key = f"{op}/{n}"
            samples = [max(rank["timings"][key]["samples"][i] for rank in ranks)
                       for i in range(REPEATS)]
            row = {"world": world, "op": op, "full_numel": n,
                   "mean_s": statistics.mean(samples), "std_s": statistics.stdev(samples),
                   "samples_max_rank_s": samples}
            timing_rows.append(row)
            comparisons.append(_byte_comparison(
                f"timing/{key}", [rank["timing_byte_logs"][key] for rank in ranks],
                _expected_bytes(op, world, n), formulas[op]))
            checks.append(len(samples) == REPEATS and all(value > 0 for value in samples))
    checks.extend(comparison["pass"] for comparison in comparisons)
    return {"world": world, "ranks": ranks, "byte_comparisons": comparisons,
            "timing_table": timing_rows, "pass": all(checks)}


def _json_default(value):
    if is_dataclass(value):
        return asdict(value)
    raise TypeError(f"不可序列化: {type(value)}")


def _utf8_stdout():
    """Windows 默认 GBK 控制台下非 GBK 字符无法编码——统一按 UTF-8 输出（幂等，静默失败安全）。"""
    import sys as _s
    for _st in (_s.stdout, _s.stderr):
        try:
            _st.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


def main() -> int:
    """落盘环境/判据/原始样本/逐 rank 账，全部自检通过返回 0，否则返回 1。"""
    _utf8_stdout()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("raw.json"))
    args = parser.parse_args()
    record = {
        "env": {"timestamp_utc": datetime.now(timezone.utc).isoformat(),
                "platform": platform.platform(), "python": platform.python_version(),
                "torch": torch.__version__, "backend": "gloo", "device": "cpu",
                "gloo_available": dist.is_gloo_available(), "cuda_available": torch.cuda.is_available(),
                "nccl_available": dist.is_nccl_available(), "threads_per_worker": 1,
                "world_sizes": [2, 4], "seed": 10},
        "criteria": {"allclose_atol": 1e-6, "allclose_rtol": 1e-6,
                     "max_abs_delta_limit": 1e-6, "byte_logs": "逐 rank 与 Σrank 均须等于独立手算",
                     "exit_code": "0=数值、shape 契约与字节账通过；1=失败"},
        "timing_method": {
            "clock": "perf_counter，阻塞 gloo CPU 调用", "warmup": WARMUP, "repeats": REPEATS,
            "order": "按轮交错全部 3 shapes × 5 ops，world=2 后 world=4",
            "summary": "每轮取各 rank 本地耗时最大值，再算 mean/std(n−1)；并非同步端到端时延",
            "included": "Python 封装、集合 shape 元数据交换、返回缓冲区分配、ByteLog 写入",
            "excluded": "spawn、初始化、模型/输入构造、首个 barrier",
            "p2p": "每轮 P 条边串行组成环，每 rank 一次 send/recv；不是单条链路延迟",
        },
        "byte_convention": {
            "definition": "每 rank 应用层发送的张量 numel×element_size；逐 rank + Σrank",
            "excluded": "协议/padding/集合算法内部重复收发/shape 元数据/PP 结果诊断",
            "warning": "逻辑载荷 ≠ 链路传输总量；这里不抓包也不测 gloo 内部流量",
            "broadcast": "根输入只计一次，不因接收者数乘 P−1",
            "all_reduce": "实际传给 dist.all_reduce 的完整输入 N 个 float32，每 rank N×4",
            "ring_formula_assumptions": {
                "description": "假设等分块 ring 算法，N/P 整数，以下仅为内部算法发送量推演，不用于 ByteLog 对表",
                "one_phase_per_rank": "(P−1)/P×N×4（一次 reduce-scatter 或 all-gather 阶段）",
                "all_reduce_two_phases_per_rank": "2×(P−1)/P×N×4",
                "all_reduce_two_phases_sum_ranks": "2×(P−1)×N×4",
                "note": "P=2 时两阶段公式恰等于 N×4，但口径不同；不声称 gloo 实际使用 ring",
            },
        },
        "degradation": "gloo CPU 同机小张量相对对照；NCCL/GPU/设备性能未测",
        "worlds": [],
    }
    try:
        for world in (2, 4):
            before = {process.pid for process in mp.active_children()}
            summary = _summarize(world, spawn_workers(_experiment_worker, world))
            after = {process.pid for process in mp.active_children()}
            summary["worker_cleanup"] = {"pass": before == after, "remaining_worker_pids": sorted(after - before)}
            summary["pass"] = summary["pass"] and before == after
            record["worlds"].append(summary)
            print(f"world={world}: {'PASS' if summary['pass'] else 'FAIL'}")
            print(f"{'op':>16} {'N':>6} {'max-rank mean_ms':>18} {'std_ms':>12}")
            for row in summary["timing_table"]:
                print(f"{row['op']:>16} {row['full_numel']:6d} "
                      f"{row['mean_s'] * 1000:18.4f} {row['std_s'] * 1000:12.4f}")
            print("ByteLog 与手算（逐 rank / Σrank）：")
            for row in summary["byte_comparisons"]:
                if not row["case"].startswith("timing/"):
                    print(f"  {row['case']}: {row['observed']['per_rank']} / "
                          f"{row['observed']['total_bytes']} B; {'PASS' if row['pass'] else 'FAIL'}")
        record["pass"] = all(row["pass"] for row in record["worlds"])
    except Exception:
        record["error"] = traceback.format_exc()
        record["pass"] = False
        print(record["error"], file=sys.stderr)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(record, default=_json_default, ensure_ascii=False, indent=2),
                           encoding="utf-8")
    print("口径：每 rank 应用层输入载荷；all_reduce 每 rank N×4。ring 内部公式另列于 JSON。")
    print(record["degradation"])
    print(f"原始记录：{args.output}")
    return 0 if record["pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
