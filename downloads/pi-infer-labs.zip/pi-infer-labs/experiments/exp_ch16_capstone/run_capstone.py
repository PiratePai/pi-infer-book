#!/usr/bin/env python3
"""第 16 章综合实战：一次可解释的优化（CPU 可完成的受控闭环，全部本机实测）。

负载：Qwen3-0.6B 教学服务同栈（transformers，CPU 进程内）多轮问答——8 个会话（沿用第 5 章
8 条固定样例）× 3 轮（原问题 → 一句话总结 → 再举例）。

会话构造（token 级增量，所有变体共用同一 token 序列，保证公平可比）：
  第 1 轮 prompt = apply_chat_template(u1, add_generation_prompt=True, enable_thinking=False)；
  第 k 轮新喂 = 上轮采样出但未入缓存的尾部 token（≤1 个）+ 后缀
  （若上轮以 max_tokens 截断则补 <|im_end|>，再接 "\\n<|im_start|>user\\n…<|im_end|>\\n<|im_start|>assistant\\n<think>\\n\\n</think>\\n\\n"）。
  实测事实（模板直查，本机 tokenizer）：Qwen3 直答模式把空 <think> 块放进生成头、但历史重渲染
  **不含它**——逐轮重渲染的对话与本轮实际消费的 token 序列必然分叉，前缀复用会 100% 落空；
  故采用 token 级增量构造（与引擎按 token 前缀做前缀缓存同一语义），该模板行为作为结论写入正文。

固定目标（16.1，先于基线锁定）：
  资源：本机 CPU 单进程；fp32 权重 ≈1.4GB / int8 ≈0.37GB（第 5 章口径）；
  质量：第 1 轮答案任务预算 ≥7/8（第 5 章同判据：样例关键词全部出现）；
        复用路径与非复用路径**逐 token 一致**（贪心，正确性判据）；
  服务：轮次 TTFT（=本轮首个前向时间）p95 相对基线改善 ≥20%（v2 或组合达成即通过）；
        v1 预期无吞吐收益——如实报告，按 16.3"无稳定收益时解释并撤回"。

改动（16.2/16.3，均为已学机制）：
  v1：int8 动态量化（第 5 章机制：字节 3.84×、内核收益另论）；
  v2：会话内前缀 KV 复用（第 4 章机制）——契约：精确 token 前缀衔接校验（断言缓存长度 ==
      已消费 token 数，不匹配则整段重算并计 cache_miss）、末 token 覆盖约定（上轮缓存落后
      最后一个采样 token，本轮从尾部续喂）、会话间零共享（每会话独立缓存对象）；
  v1+v2：组合。

运行：python experiments/exp_ch16_capstone/run_capstone.py [--model-dir models/qwen3-0.6b]
产物：experiments/exp_ch16_capstone/raw.json
"""

from __future__ import annotations

import argparse
import copy
import json
import platform
import statistics
import sys
import time
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")

OUT = Path(__file__).resolve().parent / "raw.json"
MAX_NEW_TOKENS = 24          # 每轮生成上限（三轮同值；护栏，非调优对象；先于基线锁定）
TURN_USERS = [None, "请用一句话总结你刚才的回答。", "再补充一个简短的例子。"]
SLO = dict(quality_budget=7 / 8, ttft_improve_pct=20.0)

EXAMPLES = [
    {"id": "zh_qa_1", "prompt": "中国的首都是哪里？请简短回答。", "expected": ["北京"]},
    {"id": "zh_qa_2", "prompt": "为什么白天的天空通常是蓝色的？请用一句话解释。", "expected": ["散射"]},
    {"id": "zh_qa_3", "prompt": "什么是大语言模型的 KV Cache？请简短说明它的作用。", "expected": ["cache"]},
    {"id": "en_qa_1", "prompt": "What is the capital of France? Answer in one sentence.", "expected": ["paris"]},
    {"id": "en_qa_2", "prompt": "Why do we use a cache in a computer? Give a brief answer.", "expected": ["store"]},
    {"id": "code_1", "prompt": "Write a Python function add(a, b) that returns their sum. Output only code.",
     "expected": ["def add", "return a + b"]},
    {"id": "code_2", "prompt": "用 Python 写函数 is_even(n)，判断整数是否为偶数。只输出代码。",
     "expected": ["def is_even", "== 0"]},
    {"id": "translate_1", "prompt": "Translate into English: 量化可以减少模型权重占用的内存。",
     "expected": ["quantiz", "reduce"]},
]


def task_check(text: str, expected: list[str]) -> bool:
    lowered = text.lower()
    return all(kw.lower() in lowered for kw in expected)


def main() -> int:
    import torch
    from torch import ao
    from torch.nn import Linear as _Linear
    from transformers import AutoModelForCausalLM, AutoTokenizer

    ap = argparse.ArgumentParser()
    ap.add_argument("--model-dir", default="models/qwen3-0.6b")
    args = ap.parse_args()

    torch.manual_seed(0)
    tok = AutoTokenizer.from_pretrained(args.model_dir)
    model = AutoModelForCausalLM.from_pretrained(args.model_dir, dtype=torch.float32).eval()
    eos_ids = {tok.eos_token_id}
    ge = model.generation_config.eos_token_id
    for e in (ge if isinstance(ge, list) else [ge]):
        if e is not None:
            eos_ids.add(e)

    def suffix_ids(user_content: str, close_assistant: bool) -> list[int]:
        s = "<|im_end|>" if close_assistant else ""
        s += f"\n<|im_start|>user\n{user_content}<|im_end|>\n<|im_start|>assistant\n<think>\n\n</think>\n\n"
        return tok(s, add_special_tokens=False)["input_ids"]

    @torch.inference_mode()
    def run_session(model, sess, use_reuse: bool) -> list[dict]:
        consumed: list[int] = []       # 已入缓存的全部 token（契约跟踪，不含未入缓存尾部）
        pending: list[int] = []        # 上轮采样出但未入缓存的尾部（≤1 个，不属于 consumed）
        closed_by_max = False
        cache = None
        turns = []
        for turn_i in range(len(TURN_USERS)):
            if turn_i == 0:
                first = tok.apply_chat_template(
                    [{"role": "user", "content": sess["prompt"]}], tokenize=True,
                    add_generation_prompt=True, enable_thinking=False)
                if not isinstance(first, list):          # 5.22.1 返回 BatchEncoding
                    first = first["input_ids"]
                if first and isinstance(first[0], list):
                    first = first[0]
                new_part = first
            else:
                new_part = pending + suffix_ids(TURN_USERS[turn_i], close_assistant=closed_by_max)
            # 本轮完整输入 = 已消费前缀 + 新喂（新喂已含上轮尾部 pending——token 级增量、无重复计数）
            if use_reuse and cache is not None:
                # 契约断言：缓存长度 == 已消费会话长度（consumed 不含 pending，避免尾部 token 重复计数）
                if cache.get_seq_length() == len(consumed):
                    fed, state = new_part, f"hit(cached={len(consumed)},feed={len(new_part)})"
                else:  # 防御分支：契约破坏时整段重算（教学口径如实计数）
                    cache, fed, state = None, consumed + new_part, "cache_miss(整段重算)"
            else:
                # 非复用路径：每轮重发完整会话、全新缓存（第 1 章服务每请求重发全部历史的语义）
                cache, fed, state = None, consumed + new_part, "no_cache"
            t0 = time.perf_counter()
            out = model(input_ids=torch.tensor([fed], dtype=torch.long),
                        past_key_values=cache, use_cache=True)
            prefill_s = time.perf_counter() - t0
            past = out.past_key_values
            gen, itl = [], []
            cur = out.logits[:, -1:].argmax(dim=-1)
            nid = int(cur[0, 0])
            if nid not in eos_ids:
                gen.append(nid)
            # 首 token 即 EOS：本轮立即结束（不进 decode 循环，避免越过 EOS 继续生成）
            for _ in (range(MAX_NEW_TOKENS - len(gen)) if nid not in eos_ids else []):
                t1 = time.perf_counter()
                o2 = model(input_ids=cur, past_key_values=past, use_cache=True)
                itl.append(time.perf_counter() - t1)
                past = o2.past_key_values
                cur = o2.logits[:, -1:].argmax(dim=-1)
                nid = int(cur[0, 0])
                if nid in eos_ids:
                    break
                gen.append(nid)
            stopped_by_eos = nid in eos_ids
            closed_by_max = (not stopped_by_eos) and len(gen) == MAX_NEW_TOKENS
            # 会话逻辑历史按 new_part 推进（两条路径同一会话）；缓存覆盖按实际喂入推导：
            # eos 停止时全部 gen 已入缓存、尾部=eos；max 截断时最后采样 token 未入缓存。
            consumed = consumed + new_part + (gen if stopped_by_eos else gen[:-1])
            pending = [nid] if stopped_by_eos else gen[-1:]
            cache = past
            turns.append(dict(turn=turn_i, conversation_len=len(consumed) + len(pending),
                              fed_tokens=len(fed), cache=state, ttft_ms=prefill_s * 1000,
                              decode_n=len(gen), decode_s=sum(itl),
                              itl_mean_ms=(statistics.mean(itl) * 1000 if itl else None),
                              answer=tok.decode(gen, skip_special_tokens=True)))
        return turns

    def run_variant(model, name, use_reuse):
        sessions = [dict(id=s["id"], turns=run_session(model, s, use_reuse)) for s in EXAMPLES]
        ttfts = [t["ttft_ms"] for s in sessions for t in s["turns"]]
        t1_pass = sum(task_check(s["turns"][0]["answer"], EXAMPLES[i]["expected"])
                      for i, s in enumerate(sessions))
        return dict(variant=name, sessions=sessions,
                    total_s=sum(t["ttft_ms"] / 1000 + t["decode_s"] for s in sessions for t in s["turns"]),
                    ttft_p50_ms=statistics.median(ttfts),
                    ttft_p95_ms=sorted(ttfts)[max(0, int(round(0.95 * len(ttfts))) - 1)],
                    ttft_mean_ms=statistics.mean(ttfts),
                    fed_tokens=sum(t["fed_tokens"] for s in sessions for t in s["turns"]),
                    conversation_tokens=sum(t["conversation_len"] for s in sessions for t in s["turns"]),
                    cache_miss=sum(1 for s in sessions for t in s["turns"] if t["cache"].startswith("cache_miss")),
                    quality_turn1=f"{t1_pass}/{len(EXAMPLES)}")

    results = {}
    print("== baseline（fp32，每轮全新缓存）==")
    results["baseline"] = run_variant(model, "baseline", use_reuse=False)
    print("== v2：会话内前缀 KV 复用（fp32）==")
    results["v2_reuse"] = run_variant(model, "v2_reuse", use_reuse=True)
    # 正确性判据分两层（第 5 章三层验收的运用）：
    #  ① 结构契约（断言）：cache_miss==0——token 前缀衔接与缓存长度一致（可判定）；
    #  ② 轨迹层（观察，不作判定）：复用与全量重算的浮点批形状不同（单次 [1,L] 前向 vs 累计 [1,S]），
    #     贪心输出偶发分叉是已知现象——逐轮记 identical 标志、分叉轮双文本存档供人工检视；
    #     判定层 = 任务预算（第 1 轮 ≥7/8）。
    for sb, sv in zip(results["baseline"]["sessions"], results["v2_reuse"]["sessions"]):
        for tb, tv in zip(sb["turns"], sv["turns"]):
            tv["identical_to_baseline"] = (tb["answer"] == tv["answer"])
    n_turns = len(EXAMPLES) * len(TURN_USERS)
    mismatch = sum(1 for s in results["v2_reuse"]["sessions"] for t in s["turns"]
                   if not t.get("identical_to_baseline", True))
    results["v2_turns_identical"] = f"{n_turns - mismatch}/{n_turns}"
    assert results["v2_reuse"]["cache_miss"] == 0, "复用结构契约被破坏（cache_miss>0）"

    print("== v1：int8 动态量化（每轮全新缓存）==")
    model_int8 = ao.quantization.quantize_dynamic(copy.deepcopy(model), {_Linear}, dtype=torch.qint8)
    results["v1_int8"] = run_variant(model_int8, "v1_int8", use_reuse=False)
    print("== v1+v2：组合 ==")
    results["combo"] = run_variant(model_int8, "combo", use_reuse=True)
    for sb, sv in zip(results["v1_int8"]["sessions"], results["combo"]["sessions"]):
        for tb, tv in zip(sb["turns"], sv["turns"]):
            tv["identical_to_v1_noreuse"] = (tb["answer"] == tv["answer"])
    combo_mismatch = sum(1 for s in results["combo"]["sessions"] for t in s["turns"]
                         if not t.get("identical_to_v1_noreuse", True))
    results["combo_turns_identical"] = f"{n_turns - combo_mismatch}/{n_turns}"
    assert results["combo"]["cache_miss"] == 0, "组合复用结构契约被破坏（cache_miss>0）"

    base_p95 = results["baseline"]["ttft_p95_ms"]
    verdict = {}
    for name in ("v2_reuse", "combo", "v1_int8"):
        imp = (base_p95 - results[name]["ttft_p95_ms"]) / base_p95 * 100
        q = results[name]["quality_turn1"]
        verdict[name] = dict(ttft_p95_improve_pct=round(imp, 1), quality=q,
                             slo_pass=bool(imp >= SLO["ttft_improve_pct"] and q in ("7/8", "8/8")))
    verdict["v1_int8"]["note"] = ("第 5 章口径：压缩格式≠内核收益，预期无吞吐收益；质量预算在本负载"
                                  "（24 token 上限）若 <7/8 一并说明——按 16.3 解释并撤回")

    raw = dict(experiment="exp_ch16 capstone controlled loop (CPU, measured)",
               environment=dict(python=platform.python_version(), torch=torch.__version__,
                                platform=platform.platform(), model=args.model_dir,
                                revision="c1899de2（versions.md 锁定）"),
               fixed=dict(max_new_tokens=MAX_NEW_TOKENS, turns=len(TURN_USERS), slo=SLO,
                          generation=("greedy 逐 token 手写循环 + enable_thinking=False 直答；"
                                      "token 级增量会话构造（实测直查：Qwen3 直答模板历史重渲染不含空 think 块）")),
               results=results, verdict=verdict)

    print("\n==== 汇总 ====")
    for k in ("baseline", "v1_int8", "v2_reuse", "combo"):
        r = results[k]
        print(f"{k:10s}: total {r['total_s']:7.1f}s | TTFT p50/p95 {r['ttft_p50_ms']:7.1f}/{r['ttft_p95_ms']:7.1f}ms | "
              f"fed {r['fed_tokens']}/{r['conversation_tokens']} tok | quality {r['quality_turn1']}")
    print(f"v2 turns identical: {results['v2_turns_identical']}（分叉轮=浮点批形状差异，record 检视）"
          f" | combo turns identical: {results['combo_turns_identical']}")
    for k, v in verdict.items():
        print(f"SLO[{k}]: {v}")
    OUT.write_text(json.dumps(raw, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"OK: {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
