# exp_ch5_quant 量化实跑与质量预算 · 实验记录

## run_quant_experiment.py（机制账 + 真实 int8）

| 项 | 结果 | 判据 |
|---|---|---|
| tiny symmetric/asymmetric 逐层量化 | PASS | 8 token 贪心轨迹对照 + 逐层 .report 权重误差（raw.json） |
| Qwen3-0.6B int8（torch.ao dynamic，真内核） | PASS | 权重 2,383,937,536 → 595,984,384 B（3.84×）；轨迹一致 0.75/0.625；可正常生成 |
| Qwen3.5-0.8B text 主干 int8 | PASS | 权重 3,007,578,112 → 751,894,528 B（4.00×）；轨迹一致 0.167（GDN 循环状态对扰动累积，比全注意力敏感——教学点入正文） |

- 环境：3.12.10 / torch 2.15.0+cpu / transformers 5.22.1 / CPU / 种子 0；模型 revision 见 versions.md
- 生成口径（quant 实验）：默认 chat template（含 thinking）、greedy、24 token 或 EOS；计时=完整 model.generate（含该配置首调，同机相对）
- 内存口径：fp32=去重全参数 numel×4；int8=各 Linear 权重 payload 之和（不含 scale/zp/packed 开销），见 raw.json scope_note

## run_quality_budget.py（三层质量预算，8 样例直答模式）

| 层 | 判据 | fp32 | int8 | 判定 |
|---|---|---|---|---|
| 数值 | 逐层权重误差（.report） | — | 实测入 raw.json | 记录 |
| 轨迹 | 首 token / 逐 token 一致率 | 自对照 8/8 零差异 | 3/8 / 0.120 | **观察不判定**（贪心级联敏感） |
| 任务 | 样例判据满足率（答案要点关键词） | 8/8 | 7/8 | **预算 0.875 边界达标 PASS** |

- 生成口径（quality）：默认模板 + enable_thinking=False（直答）、greedy、48 token 或 EOS；样例=中文问答 3/英文问答 2/代码 2/翻译 1，判据锚定任务事实（北京/paris/def add/散射…）
- **真实退化样例**：zh_qa_2（天空为什么蓝）int8 输出丢失"散射"机制、以"波长"解释替代——任务层失败的正例，正文 5.5 引用
- 判据校准过程（如实记录）：zh_qa_3 判据 'kv'→'cache'（匹配 "K-V Cache" 连字符形式的机械修正，fp32/int8 输出均合格）；en_qa_2 'again'→'store'（措辞依赖修正）；长度 32→48（截断修正）。修正后 fp32 sanity 8/8 重建，int8 用同一判据
- 复跑：`python experiments/exp_ch5_quant/run_quant_experiment.py`；`python experiments/exp_ch5_quant/run_quality_budget.py`
- 降级说明：CPU 正确性/字节账签收；int8 墙钟同机相对（无加速结论，dynamic int8 小 batch 无收益如实记录）；GPU 低精度内核未测（5.3）
