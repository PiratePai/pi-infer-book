#!/usr/bin/env python3
"""第5章质量预算评测：任务质量判定（预算层）+ 生成轨迹观察（记录层）。

三层口径分开验收（基准 5.1：任务指标接近与浮点一致不能混为一谈）：
  层1 任务质量（预算判定）：每条固定样例带任务判据（答案关键词全部出现才算
       满足），int8 满足率 ≥ --budget 才 PASS；fp32 基线满足率作 sanity。
  层2 轨迹观察（只记录不判定）：首 token 一致率、逐 token 一致率——贪心对
       微小扰动敏感、单点分歧会级联，逐 token 一致不是 weight-only int8 的
       合适预算（正文的中心教学点之一）。
生成口径：enable_thinking=False 直答模式（判据锚定答案本身），greedy、
       max_new_tokens=48、模型 EOS。

复跑：python experiments/exp_ch5_quant/run_quality_budget.py [--limit 2 截短冒烟]
"""

from __future__ import annotations

import argparse
import gc
import math
import time
from pathlib import Path

import torch

import sys as _sys
from pathlib import Path as _Path
_sys.path.insert(0, str(_Path(__file__).resolve().parent))   # -I 隔离模式不加脚本目录，显式加（同目录导入）
from run_quant_experiment import (
    ROOT, compare_tokens, dynamic_int8, environment, failure_record,
    load_local, model_revision, write_json,
)

OUT_DIR = Path(__file__).resolve().parent
MAX_NEW_TOKENS = 48  # 生成上限：所有路径与元数据引用同一常量（段末评审 P1-4）
# 任务判据锚定任务事实（答案要点），大小写不敏感；满足 = 全部关键词出现。
# 代码/翻译题用行为字面（return a + b / == 0 / quantiz+reduce）挡住形对实错的输出；
# 关键词命中是代理判据，语义反转类错误仍需人工检视（候选输出全部存档于 raw.json）。
EXAMPLES = [
    {"id": "zh_qa_1", "category": "中文问答", "prompt": "中国的首都是哪里？请简短回答。",
     "expected": ["北京"]},
    {"id": "zh_qa_2", "category": "中文问答", "prompt": "为什么白天的天空通常是蓝色的？请用一句话解释。",
     "expected": ["散射"]},
    {"id": "zh_qa_3", "category": "中文问答", "prompt": "什么是大语言模型的 KV Cache？请简短说明它的作用。",
     "expected": ["cache"]},
    {"id": "en_qa_1", "category": "英文问答", "prompt": "What is the capital of France? Answer in one sentence.",
     "expected": ["paris"]},
    {"id": "en_qa_2", "category": "英文问答", "prompt": "Why do we use a cache in a computer? Give a brief answer.",
     "expected": ["store"]},
    {"id": "code_1", "category": "代码生成", "prompt": "Write a Python function add(a, b) that returns their sum. Output only code.",
     "expected": ["def add", "return a + b"]},
    {"id": "code_2", "category": "代码生成", "prompt": "用 Python 写函数 is_even(n)，判断整数是否为偶数。只输出代码。",
     "expected": ["def is_even", "== 0"]},
    {"id": "translate_1", "category": "翻译", "prompt": "Translate into English: 量化可以减少模型权重占用的内存。",
     "expected": ["quantiz", "reduce"]},
]


def _utf8_stdout():
    """Windows 默认 GBK 控制台下 ✓/✗ 无法编码——统一按 UTF-8 输出（幂等，无 reconfigure 环境静默跳过）。"""
    import sys as _s
    for _st in (_s.stdout, _s.stderr):
        try:
            _st.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


def validate(examples: list[dict], budget: float) -> None:
    """样例必须非空且判据合法，预算为有限的 [0,1] 数值。"""
    if not examples:
        raise ValueError("评测样例集不能为空")
    for example in examples:
        if not example.get("expected"):
            raise ValueError(f"样例 {example['id']} 缺少任务判据 expected")
    if not math.isfinite(budget) or not 0 <= budget <= 1:
        raise ValueError("budget 必须是 [0,1] 内的有限数值")


@torch.inference_mode()
def generate_direct(model, tokenizer, prompt: str, max_new_tokens: int) -> dict:
    """直答模式贪心生成（enable_thinking=False）；返回新 token 与文本。"""
    from transformers import GenerationConfig

    inputs = tokenizer.apply_chat_template(
        [{"role": "user", "content": prompt}], tokenize=True, add_generation_prompt=True,
        return_tensors="pt", return_dict=True, enable_thinking=False,
    )
    eos = model.generation_config.eos_token_id or tokenizer.eos_token_id
    pad = tokenizer.pad_token_id
    if pad is None:
        pad = eos[0] if isinstance(eos, list) else eos
    config = GenerationConfig(do_sample=False, num_beams=1, max_new_tokens=max_new_tokens,
                              eos_token_id=eos, pad_token_id=pad, use_cache=True)
    t0 = time.perf_counter()
    output = model.generate(**inputs, generation_config=config)
    tokens = output[0, inputs["input_ids"].shape[1]:].tolist()
    eos_ids = eos if isinstance(eos, list) else [eos]
    return {"token_ids": tokens, "text": tokenizer.decode(tokens, skip_special_tokens=False),
            "generated_tokens": len(tokens), "wall_s": time.perf_counter() - t0,
            "stop_reason": "eos" if tokens and tokens[-1] in eos_ids else "max_tokens"}


def task_check(text: str, expected: list[str]) -> bool:
    """全部关键词（大小写不敏感）出现才算满足。"""
    lowered = text.lower()
    return all(keyword.lower() in lowered for keyword in expected)


def evaluate(args, record: dict) -> None:
    """fp32 基线（自对照+任务 sanity）→ int8（任务预算 + 轨迹观察）。"""
    record["stage"] = "load"
    model, tokenizer = load_local(ROOT / "models" / "qwen3-0.6b")
    record["model_revision"] = model_revision(ROOT / "models" / "qwen3-0.6b", model)
    record["stage"] = "fp32_baseline"
    baseline = record["baseline"] = []
    for example in record["examples"]:
        output = generate_direct(model, tokenizer, example["prompt"], MAX_NEW_TOKENS)
        satisfied = task_check(output["text"], example["expected"])
        baseline.append({**example, **output, "task_satisfied": satisfied})
        print(f"  fp32 {example['id']}: 判据{'✓' if satisfied else '✗'} "
              f"({output['generated_tokens']} tok, {output['wall_s']:.1f}s)", flush=True)
    fp32_rate = sum(row["task_satisfied"] for row in baseline) / len(baseline)
    record["fp32_task_rate"] = fp32_rate
    write_json(OUT_DIR / "quality_raw.json", record)

    record["stage"] = "fp32_self_check"
    rows = record["self_check"]["rows"] = []
    for reference in baseline:
        candidate = generate_direct(model, tokenizer, reference["prompt"], MAX_NEW_TOKENS)
        comparison = compare_tokens(reference["token_ids"], candidate["token_ids"])
        rows.append({"id": reference["id"], **comparison})
    diff = sum(row["diff_tokens"] for row in rows)
    record["self_check"].update(diff_tokens=diff,
                                status="passed" if diff == 0 else "failed")
    if diff:
        raise AssertionError("fp32 vs fp32 自对照出现差异，评测环境非确定性")
    write_json(OUT_DIR / "quality_raw.json", record)

    record["stage"] = "quantize_dynamic"
    model = dynamic_int8(model)
    record["stage"] = "int8_budget"
    rows = record["int8"]["rows"] = []
    satisfied = 0
    first_agree = 0
    for reference in baseline:
        candidate = generate_direct(model, tokenizer, reference["prompt"], MAX_NEW_TOKENS)
        comparison = compare_tokens(reference["token_ids"], candidate["token_ids"])
        ok = task_check(candidate["text"], reference["expected"])
        satisfied += ok
        first_agree += bool(reference["token_ids"] and candidate["token_ids"]
                            and reference["token_ids"][0] == candidate["token_ids"][0])
        rows.append({"id": reference["id"], "prompt": reference["prompt"],
                     "expected": reference["expected"], "candidate": candidate,
                     "task_satisfied": ok, **comparison})
        print(f"  int8 {reference['id']}: 判据{'✓' if ok else '✗'} "
              f"轨迹一致={comparison['token_agreement']:.2f}", flush=True)
    rate = satisfied / len(rows)
    trajectory = (sum(r["matched_tokens"] for r in rows) / sum(r["compared_tokens"] for r in rows)
                  if rows else 1.0)
    record["int8"].update(task_rate=rate, budget=args.budget,
                          first_token_agreement=first_agree / len(rows),
                          trajectory_token_agreement=trajectory,
                          note="轨迹一致率为观察指标：贪心对扰动级联敏感，不构成预算判定；任务层为关键词代理判据，候选输出已存档供人工检视")
    record["int8"]["status"] = "passed" if rate >= args.budget else "over_budget"
    print(f"  任务满足率 fp32={fp32_rate:.3f} → int8={rate:.3f}（预算 {args.budget}）；"
          f"首token一致 {first_agree}/{len(rows)}，轨迹一致 {trajectory:.3f}", flush=True)
    record.update(stage="complete", status="completed")
    del model
    gc.collect()


def main() -> int:
    _utf8_stdout()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--budget", type=float, default=0.875, help="int8 任务满足率下限（默认 7/8）")
    parser.add_argument("--limit", type=int, default=len(EXAMPLES), help="只评测前 N 条（截短运行不代表完整集验收）")
    parser.add_argument("--threads", type=int, help="显式设置 CPU 线程数")
    args = parser.parse_args()
    try:
        if not 1 <= args.limit <= len(EXAMPLES):
            raise ValueError(f"limit 必须在 1..{len(EXAMPLES)} 内")
        examples = EXAMPLES[:args.limit]
        validate(examples, args.budget)
        if args.threads is not None and args.threads <= 0:
            raise ValueError("threads 必须是正整数")
    except ValueError as error:
        parser.error(str(error))
    if args.threads:
        torch.set_num_threads(args.threads)
    torch.manual_seed(0)
    record = {"env": environment(), "model_dir": "models/qwen3-0.6b",
              "generation_spec": {
                  "chat_template": "apply_chat_template 默认模板 + enable_thinking=False（直答）",
                  "decode": "greedy do_sample=False", "stop": f"EOS 或 {MAX_NEW_TOKENS} token",
                  "task_criteria": "样例内嵌关键词判据，全部出现才满足；与轨迹一致分开报告"},
              "examples": examples, "full_example_count": len(EXAMPLES),
              "evaluated_count": len(examples), "limited_run": len(examples) != len(EXAMPLES),
              "budget": args.budget, "self_check": {}, "int8": {}}
    try:
        evaluate(args, record)
    except Exception as error:
        failure_record(record, error)
        print(f"失败：{record.get('failed_stage')}: {error}", flush=True)
    success = (record.get("status") == "completed"
               and record["int8"].get("status") == "passed"
               and record["fp32_task_rate"] >= args.budget)
    record["passed"] = success
    write_json(OUT_DIR / "quality_raw.json", record)
    print(f"原始数据：{OUT_DIR / 'quality_raw.json'}", flush=True)
    return 0 if success else 1


if __name__ == "__main__":
    raise SystemExit(main())
