#!/usr/bin/env python3
"""第5章：tiny 量化机制账、Qwen3 CPU 动态 int8 实跑、Qwen3.5 降级记录。

复跑：python experiments/exp_ch5_quant/run_quant_experiment.py
"""

from __future__ import annotations

import argparse
import copy
import gc
import json
import platform
import subprocess
import sys
import time
import traceback
from itertools import zip_longest
from pathlib import Path

import torch
from torch import nn

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from pi_infer.bench import sync_device  # noqa: E402
from pi_infer.generate import greedy_decode  # noqa: E402
from pi_infer.model import SimpleKVCache, build_tiny_model  # noqa: E402
from pi_infer.quant import quantize_linear  # noqa: E402

OUT_DIR = Path(__file__).resolve().parent
PROMPTS = ["请用一句话解释什么是大语言模型。", "What is the capital of France? Answer briefly."]


def write_json(path: Path, record: dict) -> None:
    """用 UTF-8 保存原始数据，禁止 NaN/Inf 掩盖数值错误。"""
    path.write_text(json.dumps(record, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")


def environment() -> dict:
    """记录依赖、代码版本与 CPU 同机对照边界。"""
    import transformers

    try:
        git = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
    except (OSError, subprocess.CalledProcessError):
        git = "unavailable"
    return {"git": git, "python": platform.python_version(), "torch": torch.__version__,
            "transformers": transformers.__version__, "device": "cpu",
            "processor": platform.processor(), "threads": torch.get_num_threads(), "seed": 0,
            "cuda_available": torch.cuda.is_available(),
            "quantized_engine": torch.backends.quantized.engine,
            "timing_method": "perf_counter + sync_device，完整 model.generate，不含分词/加载/量化",
            "timing_note": "每条 prompt 每配置一次，无预热；包含该配置首调开销，仅作同机相对记录"}


def generation_spec(max_new_tokens: int) -> dict:
    """固定生成四要素；保留模型 chat template 默认行为（包括 thinking）。"""
    return {"chat_template": "tokenizer.apply_chat_template 默认模板；add_generation_prompt=True；不覆盖 thinking",
            "decode": "greedy，do_sample=False，num_beams=1，无额外 logits 处理器",
            "stop": "模型/分词器 EOS 或 max_new_tokens，包含命中的 EOS",
            "max_new_tokens": max_new_tokens, "use_cache": True,
            "prompts": "prompt 字面量内嵌于脚本及各条记录，user 单轮输入",
            "comparison": "仅比较新生成 token，位置从0起；分母=max(两序列长度)，缺失位置计差异；总率按 token 加权"}


def compare_tokens(baseline: list[int], candidate: list[int]) -> dict:
    """按生成位置比较 Python token ID 列表；EOS 后缺失 token 也计差异。"""
    pairs = list(zip_longest(baseline, candidate, fillvalue=None))
    equal = [left == right for left, right in pairs]
    differences = [{"position": i, "baseline": left, "candidate": right}
                   for i, (left, right) in enumerate(pairs) if left != right]
    count = len(pairs)
    return {"baseline_length": len(baseline), "candidate_length": len(candidate),
            "compared_tokens": count, "matched_tokens": sum(equal),
            "diff_tokens": len(differences), "token_agreement": sum(equal) / count if count else 1.0,
            "per_token_equal": equal, "diff_positions": [row["position"] for row in differences],
            "differences": differences}


def run_tiny() -> dict:
    """同一份 CPU fp32 权重的两种逐层量化；logits 比较各自贪心轨迹。"""
    prompt, new_tokens = [1, 7, 11], 8
    baseline = build_tiny_model(seed=0).eval()
    reference = greedy_decode(baseline, prompt, new_tokens, SimpleKVCache())
    record = {"status": "passed", "prompt_ids": prompt, "max_new_tokens": new_tokens,
              "fp32_tokens": reference.token_ids[len(prompt):], "schemes": {},
              "logits_comparison": "各自自由生成轨迹逐步 max|Δ|；分叉后同时包含上下文变化，非同前缀误差"}
    for scheme in ("symmetric", "asymmetric"):
        model = copy.deepcopy(baseline)
        reports = []
        for name, module in list(model.named_modules()):
            if isinstance(module, nn.Linear):
                quantized = quantize_linear(module, scheme=scheme)
                model.set_submodule(name, quantized)
                report = quantized.report
                reports.append({"name": name, "shape": list(module.weight.shape),
                                "numel": module.weight.numel(), "max_abs": report.max_abs,
                                "mean_abs": report.mean_abs, "scale": report.scale.tolist()})
        output = greedy_decode(model.eval(), prompt, new_tokens, SimpleKVCache())
        deltas = [(a - b).abs().max().item()
                  for a, b in zip(reference.per_step_logits, output.per_step_logits)]
        if output.steps != new_tokens or not all(torch.isfinite(x).all() for x in output.per_step_logits):
            raise RuntimeError(f"tiny {scheme} 生成步数/有限值检查失败")
        comparison = compare_tokens(reference.token_ids[len(prompt):], output.token_ids[len(prompt):])
        record["schemes"][scheme] = {
            "tokens": output.token_ids[len(prompt):], **comparison, "logits_max_abs_delta": deltas,
            "layer_reports": reports,
            "weight_error_summary": {"linear_count": len(reports),
                                     "max_abs": max(row["max_abs"] for row in reports),
                                     "mean_abs": sum(row["mean_abs"] * row["numel"] for row in reports)
                                     / sum(row["numel"] for row in reports)},
        }
        print(f"  tiny {scheme}: token一致率={comparison['token_agreement']:.3f}，max logits Δ={max(deltas):.6f}", flush=True)
    return record


def load_local(model_dir: Path):
    """AutoModelForCausalLM 加载本地 text 主干，CPU fp32/eval，禁止网络回退。"""
    from transformers import AutoModelForCausalLM, AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained(model_dir, local_files_only=True)
    model = AutoModelForCausalLM.from_pretrained(
        model_dir, dtype=torch.float32, local_files_only=True,
    ).cpu().eval()
    return model, tokenizer


def model_revision(model_dir: Path, model: nn.Module) -> str | None:
    """优先读取本地下载元数据的 commit；未提供时如实返回 None。"""
    metadata = model_dir / ".cache" / "huggingface" / "download" / "config.json.metadata"
    if metadata.exists():
        lines = metadata.read_text(encoding="utf-8").splitlines()
        if lines:
            return lines[0]
    return getattr(model.config, "_commit_hash", None)


@torch.inference_mode()
def generate_one(model: nn.Module, tokenizer, prompt: str, max_new_tokens: int) -> dict:
    """CPU 单条 greedy；计时只含完整生成，返回新 token、文本及停止信息。"""
    from transformers import GenerationConfig

    inputs = tokenizer.apply_chat_template(
        [{"role": "user", "content": prompt}], tokenize=True,
        add_generation_prompt=True, return_tensors="pt", return_dict=True,
    )
    eos = model.generation_config.eos_token_id
    if eos is None:
        eos = tokenizer.eos_token_id
    pad = tokenizer.pad_token_id
    if pad is None:
        pad = eos[0] if isinstance(eos, list) else eos
    # 显式固定 greedy；模型自带的 temperature/top_p 等采样参数不会参与选词。
    config = GenerationConfig(do_sample=False, num_beams=1, max_new_tokens=max_new_tokens,
                              eos_token_id=eos, pad_token_id=pad, use_cache=True)
    sync_device()
    start = time.perf_counter()
    output = model.generate(**inputs, generation_config=config)
    sync_device()
    wall_s = time.perf_counter() - start
    tokens = output[0, inputs["input_ids"].shape[1]:].tolist()
    eos_ids = eos if isinstance(eos, list) else [eos]
    if not tokens:
        raise RuntimeError("生成结果为空")
    return {"token_ids": tokens, "text": tokenizer.decode(tokens, skip_special_tokens=False),
            "input_ids": inputs["input_ids"][0].tolist(), "generated_tokens": len(tokens),
            "wall_s": wall_s, "eos_token_id": eos,
            "stop_reason": "eos" if tokens[-1] in eos_ids else "max_new_tokens"}


def linear_memory(model: nn.Module) -> dict:
    """遍历普通/动态量化 Linear；权重 payload 字节，不含 packed 对齐和分配器开销。"""
    from torch.ao.nn.quantized.dynamic import Linear as DynamicLinear

    rows = []
    for name, module in model.named_modules():
        if isinstance(module, (nn.Linear, DynamicLinear)):
            weight = module.weight() if isinstance(module, DynamicLinear) else module.weight
            rows.append({"name": name, "shape": list(weight.shape), "dtype": str(weight.dtype),
                         "numel": weight.numel(), "element_size": weight.element_size(),
                         "weight_bytes": weight.numel() * weight.element_size()})
    return {"linear_weight_bytes": sum(row["weight_bytes"] for row in rows),
            "int8_linear_count": sum(row["dtype"] == "torch.qint8" for row in rows), "layers": rows}


def dynamic_int8(model: nn.Module) -> nn.Module:
    """原地转换 nn.Linear；baseline 必须先生成，减少 CPU 峰值内存。"""
    from torch.ao.quantization import quantize_dynamic

    model = quantize_dynamic(model, {nn.Linear}, dtype=torch.qint8, inplace=True).eval()
    if not linear_memory(model)["int8_linear_count"]:
        raise RuntimeError("没有 Linear 被替换为真实动态 int8 内核")
    return model


def run_real_model(model_dir: Path, prompts: list[str], record: dict) -> None:
    """按阶段更新记录；异常由调用者决定失败退出或作为 Qwen3.5 degradation。"""
    record.update(status="running", stage="load", model_dir=str(model_dir.relative_to(ROOT)),
                  generation_spec=generation_spec(24), prompts=prompts)
    model, tokenizer = load_local(model_dir)
    record["model_revision"] = model_revision(model_dir, model)
    record["model_class"] = type(model).__name__
    fp32_numel = sum(parameter.numel() for parameter in model.parameters())
    record["memory"] = {"fp32_parameter_numel": fp32_numel,
                        "fp32_parameter_bytes": fp32_numel * 4, "fp32": linear_memory(model)}
    record["stage"] = "fp32_generate"
    baseline = record["fp32_outputs"] = []
    for prompt in prompts:
        baseline.append(generate_one(model, tokenizer, prompt, 24))
        print(f"  fp32 prompt {len(baseline)}: {baseline[-1]['wall_s']:.3f}s", flush=True)
    record["stage"] = "quantize_dynamic"
    model = dynamic_int8(model)
    memory = record["memory"]
    memory["int8"] = linear_memory(model)
    memory["remaining_parameter_bytes"] = sum(p.numel() * p.element_size() for p in model.parameters())
    memory["scope_note"] = ("fp32_parameter_bytes 是去重全参数 numel*4；int8.linear_weight_bytes 仅各 Linear 权重 payload，"
                            "另列同范围 fp32 Linear；非 RSS/序列化大小，不含量化 scale/zero_point、packed 开销及量化 Linear bias")
    print(f"  权重字节：fp32全参数={memory['fp32_parameter_bytes']:,}，"
          f"Linear fp32={memory['fp32']['linear_weight_bytes']:,} -> "
          f"int8={memory['int8']['linear_weight_bytes']:,}", flush=True)
    record["stage"] = "int8_generate"
    rows = record["comparisons"] = []
    for prompt, reference in zip(prompts, baseline):
        candidate = generate_one(model, tokenizer, prompt, 24)
        comparison = compare_tokens(reference["token_ids"], candidate["token_ids"])
        rows.append({"prompt": prompt, "fp32": reference, "int8": candidate, **comparison})
        print(f"  int8 prompt {len(rows)}: {candidate['wall_s']:.3f}s，"
              f"token一致率={comparison['token_agreement']:.3f}，差异位置={comparison['diff_positions']}", flush=True)
    record.update(status="passed", stage="complete")
    del model
    gc.collect()


def failure_record(record: dict, error: Exception, *, degradation: bool = False) -> None:
    """保留失败环节、异常类型及 traceback 尾部，部分已完成数据不丢弃。"""
    record.update(status="degraded" if degradation else "failed", failed_stage=record.get("stage"),
                  error_type=type(error).__name__, error=str(error),
                  traceback_summary="".join(traceback.format_exception(error))[-8000:])


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--threads", type=int, help="显式设置 CPU 线程数，默认沿用 torch 配置")
    args = parser.parse_args()
    if args.threads is not None:
        if args.threads <= 0:
            parser.error("threads 必须是正整数")
        torch.set_num_threads(args.threads)
    torch.manual_seed(0)
    record = {"env": environment(), "scope": "full",
              "tiny": {"stage": "tiny"}, "qwen3": {"status": "not_run"}, "qwen35": {"status": "not_run"}}
    try:
        record["tiny"] = run_tiny()
    except Exception as error:
        failure_record(record["tiny"], error)
    for key, directory, prompts in (("qwen3", "qwen3-0.6b", PROMPTS),
                                     ("qwen35", "qwen3.5-0.8b", PROMPTS[:1])):
        print(f"[{directory}]", flush=True)
        try:
            run_real_model(ROOT / "models" / directory, prompts, record[key])
        except Exception as error:
            failure_record(record[key], error, degradation=key == "qwen35")
            print(f"  {record[key]['status']}: {record[key]['failed_stage']}: {error}", flush=True)
        write_json(OUT_DIR / "raw.json", record)
    passed = record["tiny"]["status"] == "passed" and record["qwen3"]["status"] == "passed"
    record["required_parts_passed"] = passed
    write_json(OUT_DIR / "raw.json", record)
    print(f"结果：tiny={record['tiny']['status']}，qwen3={record['qwen3']['status']}，qwen35={record['qwen35']['status']}")
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
