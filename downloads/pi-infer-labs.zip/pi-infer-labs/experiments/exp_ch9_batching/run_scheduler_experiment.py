#!/usr/bin/env python3
"""CPU 调度策略对照：python experiments/exp_ch9_batching/run_scheduler_experiment.py。

启动时实测单位成本，固定目标轨迹比较 static/continuous/chunked{16,32}；
输出 scheduler_raw.json。PASS 必须包含全部请求独立贪心参考逐 token 一致。
所有 TTFT/TPOT/完成时刻均为模拟量；不写 record.md。
"""

from __future__ import annotations

import argparse
import sys
from dataclasses import asdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from experiments.exp_ch9_batching._common import (
    TIMING_SPEC, check_run, checks_pass, environment, make_trace, measure_unit_costs,
    references, request_from, setup_model, write_json,
)
from pi_infer.scheduler import Scheduler, SchedulerConfig


def main() -> int:
    """运行四组配置，自检后保存 raw JSON，失败返回退出码 1。"""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("scheduler_raw.json"))
    parser.add_argument("--requests", type=int, default=32)
    parser.add_argument("--warmup", type=int, default=2)
    parser.add_argument("--repeats", type=int, default=9)
    args = parser.parse_args()
    model = setup_model()
    try:
        trace = make_trace(args.requests)
        costs, measured = measure_unit_costs(model, args.warmup, args.repeats)
    except ValueError as error:
        parser.error(str(error))
    reference = references(model, trace)
    record = {"env": environment(), "timing_spec": TIMING_SPEC, "unit_costs": measured,
              "cost_table_s": asdict(costs), "target_trace": trace, "reference_token_ids": reference,
              "runs": {}}
    for name, policy, chunk in (("static", "static", 32), ("continuous", "continuous", 32),
                                 ("chunked_16", "chunked", 16), ("chunked_32", "chunked", 32)):
        config = SchedulerConfig(policy=policy, chunk_size=chunk, token_budget=128,
                                 max_wait_s=8 * costs.decode_s[8])
        scheduler = Scheduler(model, config, costs)
        for row in trace:
            scheduler.submit(request_from(row))
        metrics = scheduler.run().to_dict()
        checks = check_run(scheduler, trace, reference)
        record["runs"][name] = {"config": asdict(config), "metrics": metrics, "checks": checks,
                                 "iterations": scheduler.iterations,
                                 "queue_depth_samples": scheduler.queue_depth_samples}
        print(f"{name}: 模拟吞吐={metrics['模拟吞吐_token/s']:.1f} token/s, "
              f"p50 模拟 TTFT={metrics['模拟 TTFT_s']['p50']:.6f}s, "
              f"p99 模拟 TPOT={metrics['模拟 TPOT_s']['p99']:.6f}s, "
              f"counts={metrics['counts']}")
    record["checks"] = {"all_runs_pass": all(checks_pass(run["checks"]) for run in record["runs"].values()),
                          "static_slot_waste_visible": record["runs"]["static"]["metrics"]
                          ["static_stranded_slot_seconds"] > 0}
    # 单位成本含实测噪声，任意混合轨迹上的全局 TTFT 不承诺单调；保留两档原始对照。
    record["chunk_comparison"] = {
        name: record["runs"][name]["metrics"][key]
        for name, key in (("chunked_16", "模拟 TTFT_s"), ("chunked_32", "模拟 TTFT_s"))}
    record["chunk_comparison_note"] = (
        "C 减小会缩短单次 prefill 对 decode 的阻塞，同时增多调用、延后长 prompt 首 token；"
        "混合到达队列的全局 p50/p99 不保证单调。确定性方向见 test_scheduler 的受控长短请求测试。")
    record["result"] = "PASS" if checks_pass(record["checks"]) else "FAIL"
    write_json(args.output, record)
    print(f"{record['result']}: {args.output}")
    return 0 if record["result"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
