#!/usr/bin/env python3
"""CPU 发压不足对照：同一 continuous 服务，客户端并发 K=4/32。

复跑：python experiments/exp_ch9_batching/run_underload_experiment.py。
输出 underload_raw.json：目标到达与实际发出分列、客户端积压/服务端排队轨迹、
最后实际发出后排空时长，以及同一窗口的观测峰值模拟吞吐。自检失败退出码 1。
"""

from __future__ import annotations

import argparse
import sys
from dataclasses import asdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from experiments.exp_ch9_batching._common import (
    TIMING_SPEC, check_run, checks_pass, environment, make_trace, measure_unit_costs,
    references, request_from, setup_model, write_json,
)
from pi_infer.scheduler import CostTable, Scheduler, SchedulerConfig, TERMINAL


def peak_throughput(scheduler: Scheduler, window_s: float) -> float:
    """同一固定秒数窗口的最大输出 token/s，含首 token，窗口为 (t-window,t]。"""
    times = sorted(t for r in scheduler.requests.values() for t in r.token_timestamps)
    left, peak = 0, 0
    for right, t in enumerate(times):
        while times[left] <= t - window_s:
            left += 1
        peak = max(peak, right - left + 1)
    return peak / window_s


def run_client(model, config: SchedulerConfig, costs: CostTable, trace: list[dict],
               reference: dict, concurrency: int, window_s: float) -> dict:
    """边界驱动的有限并发客户端；K 只限制已发出未结束请求，不限制服务 batch。

    客户端在模型迭代边界发出到期目标，故实际时刻还包含至多一个迭代的离散
    边界延迟；空闲时跳到下一目标。未来目标不提前发出，客户端积压不进入服务
    队列。K=4/32 共用这一纪律、目标轨迹、服务配置与成本表。
    """
    scheduler = Scheduler(model, config, costs)
    cursor, samples = 0, []

    def sample(phase: str) -> None:
        outstanding = [r for r in scheduler.requests.values() if r.status not in TERMINAL]
        samples.append({"模拟时刻_s": scheduler.now, "phase": phase,
                        "client_backlog": sum(row["target_arrival_time_s"] <= scheduler.now
                                              for row in trace[cursor:]),
                        "client_inflight": len(outstanding),
                        "server_waiting": sum(r.status == "waiting" and r.arrival_time <= scheduler.now
                                              for r in outstanding),
                        "server_running": sum(r.status == "running" for r in outstanding)})

    while cursor < len(trace) or not scheduler.done:
        sample("before_issue")
        inflight = sum(r.status not in TERMINAL for r in scheduler.requests.values())
        while cursor < len(trace) and inflight < concurrency:
            row = trace[cursor]
            target = row["target_arrival_time_s"]
            if target > scheduler.now:
                if not scheduler.done:
                    break
                # 空闲服务可预登记下一次到达；iterate 会直接跳到它的实际时刻。
                scheduler.submit(request_from(row, target))
                cursor += 1
                break
            scheduler.submit(request_from(row, scheduler.now))
            cursor += 1
            inflight += 1
        sample("after_issue")
        scheduler.iterate()
    sample("drained")
    last_issue = max(r.arrival_time for r in scheduler.requests.values())
    checks = check_run(scheduler, trace, reference)
    completion = scheduler.metrics().completion_table
    checks.update({"client_cap_respected": max(s["client_inflight"] for s in samples) <= concurrency,
                   "targets_preserved": all(r["target_arrival_time_s"] == row["target_arrival_time_s"]
                                            for r, row in zip(completion, trace, strict=True)),
                   "issues_not_early": all(r["actual_issue_time_s"] >= r["target_arrival_time_s"]
                                           for r in completion)})
    return {"client_max_concurrency": concurrency, "service_config": asdict(config),
            "metrics": scheduler.metrics().to_dict(), "backlog_samples": samples,
            "server_queue_depth_samples": scheduler.queue_depth_samples,
            "iterations": scheduler.iterations, "checks": checks,
            "target_arrivals_stop_s": trace[-1]["target_arrival_time_s"],
            "actual_issue_stop_s": last_issue,
            "模拟排空时长_s": scheduler.now - last_issue,
            "模拟目标到达停止后排空时长_s": scheduler.now - trace[-1]["target_arrival_time_s"],
            "peak_window_s": window_s, "观测峰值模拟吞吐_token/s": peak_throughput(scheduler, window_s),
            "max_client_backlog": max(s["client_backlog"] for s in samples),
            "max_server_waiting": max(s["server_waiting"] for s in samples)}


def main() -> int:
    """实测一次成本后共享给 K=4/32；不满足对照结论时保存 FAIL 并返回 1。"""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("underload_raw.json"))
    parser.add_argument("--requests", type=int, default=32)
    parser.add_argument("--warmup", type=int, default=2)
    parser.add_argument("--repeats", type=int, default=9)
    args = parser.parse_args()
    model = setup_model()
    try:
        trace = make_trace(args.requests)
        costs, measured = measure_unit_costs(model, args.warmup, args.repeats)
    except ValueError as error:
        parser.error(str(error))
    reference = references(model, trace)
    config = SchedulerConfig(policy="continuous", token_budget=128, max_batch=8)
    window_s = 32 * costs.decode_s[8]
    runs = {str(k): run_client(model, config, costs, trace, reference, k, window_s) for k in (4, 32)}
    low, high = runs["4"], runs["32"]
    checks = {
        "all_runs_pass": all(checks_pass(run["checks"]) for run in runs.values()),
        "same_service_config": low["service_config"] == high["service_config"],
        "k4_has_delayed_issues": any(r["actual_issue_time_s"] > r["target_arrival_time_s"]
                                     for r in low["metrics"]["completion_table"]),
        "k32_higher_observed_peak": high["观测峰值模拟吞吐_token/s"] > low["观测峰值模拟吞吐_token/s"],
        "k32_higher_total_throughput": high["metrics"]["模拟吞吐_token/s"] > low["metrics"]["模拟吞吐_token/s"],
        "k32_service_backlog_visible": high["max_server_waiting"] > 0,
    }
    record = {"env": environment(), "timing_spec": TIMING_SPEC, "unit_costs": measured,
              "cost_table_s": asdict(costs), "target_trace": trace, "reference_token_ids": reference,
              "client_method": "目标到达固定，客户端在迭代边界发出到期请求；K 限制已发未结束请求，见 run_client docstring",
              "drain_definition": "停止发压=最后一次客户端实际发出；排空=模拟结束-最后实际发出；另列目标到达停止后的时长",
              "peak_definition": "固定窗口 (t-window,t] 的最大输出 token/s；两组窗口均为 32*实测 decode(B=8) 秒",
              "runs": runs, "checks": checks, "result": "PASS" if checks_pass(checks) else "FAIL"}
    record["conclusion"] = (
        f"同一服务下，K=4 观测峰值模拟吞吐 {low['观测峰值模拟吞吐_token/s']:.1f}，"
        f"K=32 为 {high['观测峰值模拟吞吐_token/s']:.1f} token/s。"
        "把 K=4 的负载受限吞吐当成服务上限会低估可达吞吐；客户端并发不是服务容量。"
        if checks["k32_higher_observed_peak"] else
        "当前实测成本/轨迹没有显示预期峰值差异，不能签收发压不足结论；保留原始数据为 FAIL。")
    write_json(args.output, record)
    for k, run in runs.items():
        print(f"K={k}: 观测峰值模拟吞吐={run['观测峰值模拟吞吐_token/s']:.1f} token/s, "
              f"模拟吞吐={run['metrics']['模拟吞吐_token/s']:.1f} token/s, "
              f"最大客户端积压={run['max_client_backlog']}, 最大服务等待={run['max_server_waiting']}, "
              f"模拟排空={run['模拟排空时长_s']:.6f}s, counts={run['metrics']['counts']}")
    print(record["conclusion"])
    print(f"{record['result']}: {args.output}")
    return 0 if record["result"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
