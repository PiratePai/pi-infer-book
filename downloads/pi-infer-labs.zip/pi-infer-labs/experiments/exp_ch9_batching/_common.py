"""第 9 章共用的 CPU 单位成本实测、固定轨迹及逐 token 参考。"""

from __future__ import annotations

import json
import platform
import random
import statistics
import time
from pathlib import Path

import torch

from pi_infer.bench import sync_device
from pi_infer.generate import greedy_decode
from pi_infer.model import SimpleKVCache, TinyTransformer, build_tiny_model
from pi_infer.scheduler import CostTable, Request, Scheduler

SEED = 20261103
TIMING_SPEC = {
    "kind": "实测单位成本驱动的离散事件模拟；非设备/生产服务实测延迟",
    "mixed_iteration": "逐块 prefill 成本之和 + decode batch 成本，串行相加，无重叠假设",
    "lookup": "非实测尺寸向上取档；prefill 超过 64 拆段；活动 batch <= 8，禁止外推",
    "kv": "简化 token 容量 kv_num_blocks*block_size；入批预留 prompt+生成数-1，不取整到块",
    "模拟 TTFT": "首 token 模拟时刻 - 客户端实际发出时刻；另列目标到达时刻",
    "模拟 TPOT": "每请求 (末 token - 首 token) / (生成 token 数 - 1)，分位数跨完成请求",
    "模拟吞吐": "所有输出 token / (模拟结束 - 最早实际发出)，含启动和排空段",
    "scope": "固定 tiny CPU 教学模型；真实逐请求独立缓存用于正确性，非真实融合 batch；生产引擎/GPU 未测",
}


def setup_model() -> TinyTransformer:
    """固定种子 build_tiny_model，CPU 单线程；模型构造与参考不参与单位计时。"""
    torch.set_num_threads(1)
    return build_tiny_model(seed=SEED).eval()


@torch.inference_mode()
def measure_unit_costs(model: TinyTransformer, warmup: int = 2, repeats: int = 9) -> tuple[CostTable, dict]:
    """实测 [B,1] decode、[1,C] prefill，预热>=2、交错重复>=5，两端同步。

    decode 在 32-token 历史上前向，预填充与缓存重置不计时，每样本从同一
    历史长度开始；prefill 从空缓存开始。仅测模型前向，不含输入构造和 argmax。
    这张固定历史成本表不建模注意力随历史长度增长的变化，属于简化近似。
    返回 CostTable 与含全部原始秒制样本/均值/样本标准差的 JSON 兼容记录。
    """
    if type(warmup) is not int or warmup < 2 or type(repeats) is not int or repeats < 5:
        raise ValueError("warmup>=2、repeats>=5 且必须是整数")
    device = model.embedding.weight.device
    cases = []
    for batch in (1, 2, 4, 8):
        base = SimpleKVCache()
        model(torch.full((batch, 32), 7, dtype=torch.long, device=device), kv_cache=base)
        cases.append(("decode", batch, torch.full((batch, 1), 7, dtype=torch.long, device=device), base))
    for chunk in (8, 16, 32, 64):
        cases.append(("prefill", chunk, torch.full((1, chunk), 7, dtype=torch.long, device=device), None))
    samples = [[] for _ in cases]
    order = []
    for repetition in range(warmup + repeats):
        # 每轮交错全部 shape，轮换起点，保留执行顺序供复核。
        indices = [(i + repetition) % len(cases) for i in range(len(cases))]
        for index in indices:
            kind, size, inputs, base = cases[index]
            cache = SimpleKVCache()
            if base is not None:
                cache.k_cache = dict(base.k_cache)
                cache.v_cache = dict(base.v_cache)
            sync_device(device)
            start = time.perf_counter()
            model(inputs, start_pos=32 if base is not None else 0, kv_cache=cache)
            sync_device(device)
            elapsed = time.perf_counter() - start
            if repetition >= warmup:
                samples[index].append(elapsed)
                order.append(f"{kind}:{size}")
    rows = [{"kind": kind, "size": size,
             "shape": [size, 1] if kind == "decode" else [1, size],
             "mean_s": statistics.mean(times), "std_s": statistics.stdev(times), "samples_s": times}
            for (kind, size, _, _), times in zip(cases, samples, strict=True)]
    table = CostTable({r["size"]: r["mean_s"] for r in rows if r["kind"] == "decode"},
                      {r["size"]: r["mean_s"] for r in rows if r["kind"] == "prefill"})
    return table, {"warmup": warmup, "repeats": repeats, "rows": rows, "sample_order": order,
                   "method": "perf_counter + pi_infer.bench.sync_device 两端同步；按轮交错",
                   "decode_history_tokens": 32, "prefill_history_tokens": 0,
                   "excludes": "输入构造、初始历史构造、缓存重置、argmax、调度循环"}


def make_trace(count: int = 32) -> list[dict]:
    """返回固定目标到达轨迹；prompt 8–64 / 生成 8–48，默认 32 条。

    到达间隔固定 0.1ms，与成本实测结果无关。seed 只控制 token 和长度排列；
    每六条覆盖长短端点，既定轨迹在所有策略/客户端配置之间完全相同。
    """
    if type(count) is not int or count < 12:
        raise ValueError("轨迹至少包含 12 条请求")
    rng = random.Random(SEED)
    lengths = [(8, 8), (64, 48), (16, 16), (48, 32), (32, 24), (24, 12)]
    trace = []
    for i in range(count):
        if i % 6 == 0:
            rng.shuffle(lengths)
        prompt_len, new = lengths[i % 6]
        trace.append({"request_id": f"r{i:03d}", "target_arrival_time_s": i * .0001,
                      "prompt_ids": [rng.randrange(1, 256) for _ in range(prompt_len)],
                      "max_new_tokens": new})
    return trace


def request_from(row: dict, issued_at: float | None = None) -> Request:
    """从轨迹复制全新 Request，防止跨策略共享状态或缓存。"""
    return Request(row["request_id"], row["target_arrival_time_s"] if issued_at is None else issued_at,
                   row["prompt_ids"], row["max_new_tokens"], row["target_arrival_time_s"])


def references(model: TinyTransformer, trace: list[dict]) -> dict[str, list[int]]:
    """逐请求独立 greedy_decode(SimpleKVCache) 参考，返回含 prompt 的 token。"""
    return {row["request_id"]: greedy_decode(model, row["prompt_ids"], row["max_new_tokens"],
                                            SimpleKVCache()).token_ids for row in trace}


def check_run(scheduler: Scheduler, trace: list[dict], reference: dict[str, list[int]]) -> dict:
    """全量逐 token 比较及结束/预算/KV/计费自检，不隐藏失败或取消请求。"""
    per_request = {row["request_id"]: (row["request_id"] in scheduler.requests
                   and scheduler.requests[row["request_id"]].status == "finished"
                   and scheduler.requests[row["request_id"]].token_ids == reference[row["request_id"]])
                   for row in trace}
    metrics = scheduler.metrics()
    return {"per_request_token_match": per_request,
            "all_tokens_identical": all(per_request.values()),
            "all_requests_accounted": len(scheduler.requests) == len(trace)
            == metrics.finished + metrics.failed + metrics.cancelled,
            "all_finished": metrics.finished == len(trace),
            "kv_fully_returned": scheduler.kv_used_tokens == 0,
            "budget_respected": all(r["input_tokens"] <= scheduler.config.token_budget
                                    for r in scheduler.iterations),
            "batch_measured_range": all(len(r["active_ids"]) <= scheduler.config.max_batch <= 8
                                        for r in scheduler.iterations),
            "chunk_cap_respected": all(scheduler.config.policy != "chunked"
                                       or sum(c["tokens"] for c in r["prefill_chunks"]) <= scheduler.config.chunk_size
                                       for r in scheduler.iterations),
            "serial_cost_accounted": all(abs(r["模拟完成时刻_s"] - r["模拟起始时刻_s"]
                                            - r["prefill_cost_s"] - r["decode_cost_s"]) < 1e-9
                                         for r in scheduler.iterations)}


def checks_pass(checks: dict) -> bool:
    """逐项布尔断言归约；per_request 字典也必须全部通过。"""
    return all(all(value.values()) if isinstance(value, dict) else value for value in checks.values())


def environment() -> dict:
    """用于复现实验的 Python/torch/CPU/模型配置。"""
    return {"python": platform.python_version(), "torch": torch.__version__,
            "platform": platform.platform(), "device": "cpu", "threads": torch.get_num_threads(),
            "seed": SEED, "model": "build_tiny_model(seed)，默认 tiny preset，固定生成长度，无 EOS"}


def write_json(path: Path, record: dict) -> None:
    """创建输出目录并写 UTF-8 原始数据，不省略逐请求输出或失败计数。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
