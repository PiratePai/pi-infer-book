# exp_ch9 批处理与调度 · 实验记录

复跑基准：段末评审修复后复跑（零生成槽位统计修复会小幅改变 static 数字；单位成本逐次实测、模拟数字随运行小幅波动，以 raw.json 为准）；环境：Python 3.12.10 / torch 2.15.0+cpu / Windows CPU。计时层口径：**实测单位成本的离散事件模拟**——decode 步（batch∈{1,2,4,8} 的 `[B,1]` 前向）与 prefill 块（`[1,C]`、C∈{8,16,32,64}）成本在脚本启动时实测（预热+交错重复），混合迭代按串行相加计费；活动 batch 上限 8（不外推）；全部延迟指标为**模拟 TTFT/TPOT**。

## 三策略对照（run_scheduler_experiment.py）

| 策略 | 模拟吞吐 tok/s | p50 模拟 TTFT | p99 模拟 TPOT |
|---|---|---|---|
| static | 8,253 | 35.5 ms | 0.75 ms |
| continuous | 12,317 | 18.5 ms | 0.79 ms |
| chunked C=16 | 9,591 | 28.4 ms | 0.88 ms |
| chunked C=32 | 11,497 | 21.1 ms | 0.80 ms |

- 代际说明：上表为段末评审复跑代；终验复跑（2026-11-04，干净 venv，已覆盖 scheduler_raw.json）为 static 8,434 / continuous 12,577 / chunked C=32 11,737 / C=16 9,952——正文（9.1/9.3）统一引用终验值，同机各代相差百分之几、跨环境可达两成量级，以 raw.json 为准。
- 判据：32/32 请求输出与逐请求独立 `greedy_decode(SimpleKVCache)` 受控参考**逐 token 一致**（不丢请求/不串状态）——三种策略全部 PASS；counts 全列（finished 32/cancelled 0/failed 0），无隐藏。
- 负载：固定种子到达轨迹 32 条（prompt 8–64、生成 8–48，长短混合；字面量在 scheduler_raw.json）。
- baseline/candidate：static vs continuous（9.1）；C∈{16,32}（9.3 分块取舍）。

## 发压不足误用（run_underload_experiment.py）

| 客户端并发 K | 观测峰值模拟吞吐 | 最大服务端等待 | 模拟排空 |
|---|---|---|---|
| 4 | 8,057 tok/s | 3 条 | 0.013 s |
| 32 | 13,092 tok/s | 24 条 | 0.073 s |

- 代际说明：上表为早跑代；终验复跑（2026-11-04，已覆盖 underload_raw.json）观测峰值 9,984/16,848 tok/s、排空 0.010/0.056 s（K=4/32），"K=4 低估可达吞吐约四成"的结论不变——正文（9.4）统一引用终验值，以 raw.json 为准。
- 判据：目标到达轨迹固定、实际发出时刻因 K 推迟（两列分别记录）；K=4 把客户端上限冒充服务容量（低估 38%）的实证；积压深度轨迹与停压排空段入 raw。
- vLLM：启动/压测命令按官方文档登记（S3），本机未装未测。

- 生成口径：tiny 模型 greedy argmax、固定 max_new_tokens（无 EOS 触发路径）；固定种子 0。
- 复跑：`python experiments/exp_ch9_batching/run_scheduler_experiment.py`；`python experiments/exp_ch9_batching/run_underload_experiment.py`（产物 scheduler_raw.json / underload_raw.json）。
- 降级说明：时间轴为离散事件模拟（单位成本实测），模拟延迟不外推为服务/设备实测（5.3）；单机单进程，不含网络与真实并发开销。

## 漂移补记

versions.md 曾记"vLLM 启动命令与负载脚本保留在 experiments/exp_ch9_batching/"（stage-1 时期）——该目录当时不存在，本段创建并收录调度器对照与发压实验；vLLM 命令登记于本章 record 与正文 S3 引用，实测仍未做。
