"""第 12 章：CPU 小 MoE 实跑与 DeepSeek-V3 公式账（不实跑大模型）。

运行 python experiments/exp_ch12_moe/run_moe_experiment.py [--output raw.json]
不报告墙钟/加速比，因而不做性能计时；只报告数值、负载与资源账。
无 GPU、无大 MoE 实跑、不做引擎横评；EP 是公式推演，不是 gloo 实测。
"""

from __future__ import annotations

import argparse
import json
import math
import platform
import sys
import traceback
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path

import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from pi_infer.moe import MoEConfig, MoEFFN, controlled_routing  # noqa: E402


SEED = 12
BATCHES = (1, 4, 16, 64)
DISTRIBUTIONS = (("uniform", .5), ("peak", .5), ("peak", .8))
FACTORS = (1., 1.25, 2.)
DEGRADATION = "CPU tiny 正确性实跑；EP/DeepSeek-V3 为公式推演，非实测；无 GPU、无大 MoE 实跑、不做引擎横评"


def _require(checks: dict, name: str, condition: bool) -> None:
    """先保存判据再抛错，失败时 raw 保留具体断言与已有实验行。"""
    checks[name] = bool(condition)
    if not condition:
        raise AssertionError(name)


def _reference_output(model: MoEFFN, x: torch.Tensor, routing: tuple,
                      overflow_indices: list[int]) -> torch.Tensor:
    """按独立接纳账逐 token 求 Σ gate×expert(x)，不复用分派或合并实现。"""
    expected = x.clone()
    for token in range(len(x)):
        if token not in overflow_indices:
            expected[token] = sum(
                routing[1][token, slot] * model.experts[expert](x[token])
                for slot, expert in enumerate(routing[0][token].tolist()))
    return expected


@torch.inference_mode()
def distribution_scan(record: dict) -> None:
    """18 个固定分布/k/cf 点；同一分布、k 跨 cf 复用同一路由。"""
    generator = torch.Generator().manual_seed(SEED)
    x = torch.randn(64, 64, generator=generator)
    rows = record["distribution_scan"]
    checks = record["checks"]
    for dist, p in DISTRIBUTIONS:
        for k in (1, 2):
            routing = controlled_routing(8, k, dist, tokens=64, p=p, seed=SEED)
            for cf in FACTORS:
                # seed 相同，所有点专家权重一致；构造不参与任何性能计时。
                cfg = MoEConfig(k=k, capacity_factor=cf, seed=SEED)
                model = MoEFFN(cfg).eval()
                output, stats = model(x, routing)
                label = f"{dist}(p={p})/k={k}/cf={cf}"
                # 独立 Python 逐 token 容量账，不调用模块统计逻辑。
                hand_counts = [0] * 8
                overflow_indices = []
                for token, chosen in enumerate(routing[0].tolist()):
                    if any(hand_counts[e] + 1 > math.floor(math.ceil(64 / 8) * cf)
                           for e in chosen):
                        overflow_indices.append(token)
                    else:
                        for expert in chosen:
                            hand_counts[expert] += 1
                hand_ep = 2 * sum(hand_counts) * 64 * 4
                # 独立逐 token、逐专家求和，验证接纳输出而非复用分派/合并代码。
                expected = _reference_output(model, x, routing, overflow_indices)
                accepted = [token for token in range(len(x)) if token not in overflow_indices]
                output_matches = torch.allclose(output[accepted], expected[accepted], atol=1e-6, rtol=1e-5)
                row = {"dist": dist, "p": p if dist == "peak" else None,
                       "k": k, "capacity_factor": cf, "stats": asdict(stats),
                       "routing_indices": routing[0].tolist(), "gates": routing[1].tolist(),
                       "overflow_indices": overflow_indices,
                       "hand_expert_token_counts": hand_counts,
                       "hand_ep_total_bytes": hand_ep,
                       "accepted_output_matches": output_matches,
                       "accepted_output_max_abs_error": float((output[accepted] - expected[accepted]).abs().max())
                       if accepted else 0., "pass": False}
                rows.append(row)
                _require(checks, label, bool(torch.isfinite(output).all())
                         and output_matches
                         and stats.expert_token_counts == hand_counts
                         and stats.overflow_tokens == len(overflow_indices)
                         and stats.expert_token_assignments == (64 - len(overflow_indices)) * k
                         and stats.ep_total_bytes == hand_ep
                         and stats.executed_flops == 2 * (3 * 64 * 176) * sum(hand_counts)
                         and torch.equal(output[overflow_indices], x[overflow_indices]))
                row["pass"] = True
                print(f"{label}: load={stats.expert_token_counts} "
                      f"overflow={stats.overflow_rate:.3f} active={stats.activated_param_ratio:.3f} "
                      f"FLOPs/dense={stats.flops_ratio_vs_dense:.3f} EP={stats.ep_total_bytes}B")
    # 3 distributions * 2 k * 3 cf = 18。
    _require(checks, "scan_complete_no_hidden_failures", len(rows) == 18 and all(r["pass"] for r in rows))
    for k in (1, 2):
        for p in (.5, .8):
            rates = [r["stats"]["overflow_rate"] for r in rows
                     if r["dist"] == "peak" and r["p"] == p and r["k"] == k]
            # top-k 原子接纳的单调性不是任意路由的定理；此处是固定样本判据。
            _require(checks, f"peak_capacity_direction/p={p}/k={k}",
                     all(a >= b for a, b in zip(rates, rates[1:])) and rates[0] > rates[-1])
    _require(checks, "uniform_sufficient_capacity_no_overflow", all(
        r["stats"]["overflow_tokens"] == 0 for r in rows
        if r["dist"] == "uniform" and r["capacity_factor"] >= r["k"]))


@torch.inference_mode()
def batch_scan(record: dict) -> None:
    """k=1，cf=N 消除丢弃干扰；同一路由的前缀用于比较 batch 并集。"""
    checks = record["checks"]
    model = MoEFFN(MoEConfig(k=1, capacity_factor=8., seed=SEED)).eval()
    x = torch.randn(64, 64, generator=torch.Generator().manual_seed(SEED))
    for dist in ("uniform", "peak"):
        routing = controlled_routing(8, 1, dist, tokens=64, p=.8, seed=SEED)
        rows = []
        for tokens in BATCHES:
            prefix_routing = tuple(t[:tokens] for t in routing)
            output, stats = model(x[:tokens], prefix_routing)
            expected = _reference_output(model, x[:tokens], prefix_routing, [])
            output_matches = torch.allclose(output, expected, atol=1e-6, rtol=1e-5)
            union = len(set(routing[0][:tokens].flatten().tolist()))
            # 每个活跃专家本批只读取一次全部权重的理想缓存假设；不是实测。
            weight_bytes = union * stats.expert_params * 4
            expected_union = (min(tokens, 8) if dist == "uniform"
                              else (1 - (1 - .8)**tokens) + 7 * (1 - (1 - .2 / 7)**tokens))
            row = {"dist": dist, "p": .8 if dist == "peak" else None,
                   "T": tokens, "k": 1, "capacity_factor": 8.,
                   "routing_indices": routing[0][:tokens].tolist(),
                   "stats": asdict(stats), "active_expert_union": union,
                   "union_per_token": union / tokens,
                   "expected_union": expected_union,
                   "expected_union_per_token": expected_union / tokens,
                   "weight_read_bytes_if_once_per_expert_per_batch": weight_bytes,
                   "weight_read_bytes_per_token": weight_bytes / tokens,
                   "executed_flops_per_token": stats.executed_flops / tokens,
                   "ep_bytes_per_token": stats.ep_bytes_per_token,
                   "accepted_output_matches": output_matches,
                   "accepted_output_max_abs_error": float((output - expected).abs().max())}
            record["batch_scan"].append(row)
            rows.append(row)
            _require(checks, f"batch/{dist}/T={tokens}", output_matches and stats.overflow_tokens == 0
                     and stats.active_experts == union
                     and stats.ep_bytes_per_token == 2 * 1 * 64 * 4
                     and stats.executed_flops / tokens == 2 * (3 * 64 * 176))
            print(f"batch {dist}/T={tokens}: union={union} union/T={union / tokens:.3f} "
                  f"weight/T={weight_bytes / tokens:.0f}B EP/T={stats.ep_bytes_per_token:.0f}B")
        _require(checks, f"batch/{dist}/union_nondecreasing",
                 all(a["active_expert_union"] <= b["active_expert_union"] for a, b in zip(rows, rows[1:])))
        _require(checks, f"batch/{dist}/amortized_weight_nonincreasing",
                 all(a["weight_read_bytes_per_token"] >= b["weight_read_bytes_per_token"]
                     for a, b in zip(rows, rows[1:]))
                 and rows[0]["weight_read_bytes_per_token"] > rows[-1]["weight_read_bytes_per_token"])
        _require(checks, f"batch/{dist}/expected_union_per_token_nonincreasing",
                 all(a["expected_union_per_token"] >= b["expected_union_per_token"]
                     for a, b in zip(rows, rows[1:])))
    record["batch_convention"] = {
        "distribution": "uniform 为分层均衡循环；peak 为 iid token、单 token 内无放回抽样",
        "capacity": "固定 k=1, cf=N=8，全部接纳，避免用丢 token 冒充通信节省",
        "weight": "假设本批每专家权重只读一次，工作集=U(T)*P*4，摊到每 token 除 T",
        "direction": "并集 U(T) 随前缀 T 非递减；U(T)/T 的单样本非递增仅是此固定种子回归判据",
        "expectation": "peak: E[U(T)]=Σ_e (1-(1-p_e)^T)，E[U]/T 非递增；均衡 uniform 为 min(T,N)",
        "ep": "两次激活派发/回收每 token=2*k*d*4，不因专家权重复用摊薄，扫描要求恒定",
        "flops": "无溢出时每 token=2*P*k，亦恒定",
    }


def deepseek_v3_ledger(bandwidths: list[float]) -> dict:
    """仅整数/浮点公式，不构建 DeepSeek 模型；GB/s 使用十进制 10**9。"""
    d, f, n, k, layers, dense_layers, element_bytes = 7168, 2048, 256, 8, 61, 3, 2
    moe_layers = layers - dense_layers
    p = 3 * d * f
    # 官方配置补全 dense FFN 和 MLA 维度；主模型账不含 MTP 与量化元数据。
    attention_terms = {
        "q_down": {"formula": "7168*1536", "params": d * 1536},
        "q_up": {"formula": "1536*128*(128+64)", "params": 1536 * 128 * 192},
        "kv_down_with_rope": {"formula": "7168*(512+64)", "params": d * 576},
        "kv_up": {"formula": "512*128*(128+128)", "params": 512 * 128 * 256},
        "out": {"formula": "(128*128)*7168", "params": 128 * 128 * d},
    }
    attn_per_layer = sum(t["params"] for t in attention_terms.values())
    components = [
        ("routed_experts", "58*256*(3*7168*2048)", moe_layers * n * p, moe_layers * k * p),
        ("shared_experts", "58*1*(3*7168*2048)", moe_layers * p, moe_layers * p),
        ("first_3_dense_ffn", "3*(3*7168*18432)", 3 * 3 * d * 18432, 3 * 3 * d * 18432),
        ("mla_projections", "61*sum(MLA terms)", layers * attn_per_layer, layers * attn_per_layer),
        ("routers", "58*7168*256", moe_layers * d * n, moe_layers * d * n),
        ("norms", "61*(2*7168+1536+512)+7168", layers * (2 * d + 1536 + 512) + d,
         layers * (2 * d + 1536 + 512) + d),
        ("input_embedding", "129280*7168 resident; 1*7168 active lookup", 129280 * d, d),
        ("output_head", "129280*7168 (untied)", 129280 * d, 129280 * d),
    ]
    breakdown = [{"component": name, "resident_formula": formula, "resident_params": total,
                  "active_params_per_token": active}
                 for name, formula, total, active in components]
    total_params = sum(row["resident_params"] for row in breakdown)
    active_params = sum(row["active_params_per_token"] for row in breakdown)
    single_layer_read = k * p * element_bytes
    dispatch = k * d * element_bytes
    batch_rows = []
    for tokens in BATCHES:
        # token 间独立，token 内均匀无放回选择 k；忽略分组/节点限制。
        union = n * (1 - (1 - k / n)**tokens)
        per_token_read = union * p * element_bytes / tokens
        batch_rows.append({
            "T": tokens, "expected_union_formula": "256*(1-(1-8/256)^T)",
            "expected_union": union, "min_union": k, "max_union": min(n, tokens * k),
            "expected_routed_read_bytes_per_layer_per_batch": union * p * element_bytes,
            "expected_routed_read_bytes_per_layer_per_token": per_token_read,
            "expected_routed_read_bytes_all_58_layers_per_token": moe_layers * per_token_read,
            "shared_read_bytes_per_layer_per_token": p * element_bytes / tokens,
            "ep_total_bytes_per_layer_per_batch": tokens * 2 * dispatch,
            "ep_total_bytes_per_layer_per_token": 2 * dispatch,
            "ep_total_bytes_all_58_layers_per_token": moe_layers * 2 * dispatch,
        })
    scenarios = []
    for bandwidth in bandwidths:
        byte_rate = bandwidth * 10**9
        scenarios.append({
            "effective_bandwidth_GB_s": bandwidth,
            "routed_single_layer_min_seconds_per_token": single_layer_read / byte_rate,
            "routed_single_layer_max_tokens_per_second": byte_rate / single_layer_read,
            "routed_all_58_layers_min_seconds_per_token": moe_layers * single_layer_read / byte_rate,
            "routed_all_58_layers_max_tokens_per_second": byte_rate / (moe_layers * single_layer_read),
            "batch_routed_all_layers": [
                {"T": row["T"],
                 "min_amortized_seconds_per_token": row["expected_routed_read_bytes_all_58_layers_per_token"] / byte_rate,
                 "max_tokens_per_second": byte_rate / row["expected_routed_read_bytes_all_58_layers_per_token"]}
                for row in batch_rows],
        })
    checks = {
        "expert_params_hand": p == 44040192,
        "single_layer_read_hand": single_layer_read == 704643072,
        "dispatch_hand": dispatch == 114688,
        "rounds_to_671B": round(total_params / 1e9) == 671,
        "rounds_to_37B": round(active_params / 1e9) == 37,
        "batch_union_nondecreasing": all(a["expected_union"] <= b["expected_union"]
                                         for a, b in zip(batch_rows, batch_rows[1:])),
        "batch_weight_per_token_nonincreasing": all(
            a["expected_routed_read_bytes_per_layer_per_token"] >= b["expected_routed_read_bytes_per_layer_per_token"]
            for a, b in zip(batch_rows, batch_rows[1:])),
        "ep_per_token_constant": all(row["ep_total_bytes_per_layer_per_token"] == 229376 for row in batch_rows),
    }
    return {
        "scope": "配置账本推演，非实测；主模型，不含 MTP/量化 scale/非学习路由校正 bias；bf16 假设不代表 FP8 发布权重大小",
        "sources": {"S17": "https://arxiv.org/html/2412.19437v2#S4.SS2",
                    "official_config": "https://huggingface.co/deepseek-ai/DeepSeek-V3/blob/main/config.json",
                    "official_model": "https://github.com/deepseek-ai/DeepSeek-V3/blob/main/inference/model.py",
                    "verified_date": "2026-11-03"},
        "config": {"layers": layers, "dense_layers": dense_layers, "moe_layers": moe_layers,
                   "hidden": d, "expert_intermediate": f, "routed_experts": n,
                   "active_routed_experts": k, "shared_experts": 1, "dtype": "bf16", "element_bytes": element_bytes},
        "expert_formula": "P=gate(d*f)+up(d*f)+down(f*d)=3*7168*2048=44,040,192",
        "expert_params": p, "mla_per_layer_terms": attention_terms,
        "parameter_breakdown": breakdown,
        "active_routed_formula": "58*8*P；共享专家另计58*P；前三层 dense、MLA、router、norm、head 全部激活",
        "total_params": total_params, "active_params_per_token": active_params,
        "total_B": total_params / 1e9, "active_B": active_params / 1e9,
        "rounding": "671B/37B 是论文约数；输入 embedding 激活计一行，output head 计完整矩阵，不能将完整 embedding 表算成每 token 全读",
        "placement": {
            "resident_routed_bytes_per_layer": n * p * element_bytes,
            "resident_shared_bytes_per_layer": p * element_bytes,
            "resident_routed_bytes_all_layers": moe_layers * n * p * element_bytes,
            "resident_model_bf16_bytes": total_params * element_bytes,
            "gpu_routed_working_set_bytes_single_token_per_layer": single_layer_read,
            "cpu_gpu_offload": "假设路由专家在 CPU 内存，逐层选中专家全量传至 GPU；共享/dense/MLA/head 常驻 GPU；无跨 batch 缓存命中、无预取重叠",
            "contrast": "全部常驻 GPU 时没有这笔 CPU→GPU 卸载字节，但仍有 HBM 权重读取；两种带宽域不能直接混用",
        },
        "single_token": {
            "routed_weight_read_formula": "8*(3*7168*2048)*2=704,643,072 B/层（672 MiB）",
            "routed_weight_read_bytes_per_layer": single_layer_read,
            "routed_weight_read_bytes_all_58_layers": moe_layers * single_layer_read,
            "shared_weight_read_bytes_per_layer": p * element_bytes,
            "ep_formula": "Σ_e sent_e=256*(8/256)=8；每程8*7168*2=114,688 B；两程229,376 B（224 KiB）",
            "ep_dispatch_bytes_per_layer": dispatch, "ep_return_bytes_per_layer": dispatch,
            "ep_total_bytes_per_layer": 2 * dispatch,
            "ep_total_bytes_all_58_layers": moe_layers * 2 * dispatch,
            "ep_scope": "8/256 是专家命中比例，不再乘一次通信字节；每专家一份向量、全部视为发送，未按节点聚合/本地命中扣减；共享专家假设本地不派发",
        },
        "batch_assumptions": "独立 token 均匀 top-8，无丢弃/分组限制；每批每活跃专家读一次；只预测均值，不保证任意实路由遵循该曲线",
        "batch": batch_rows,
        "bandwidth_convention": {
            "formula": "t_min=需读字节/有效带宽；tokens/s_max=有效带宽/每 token 需读字节",
            "direction": "下界是耗时，带宽/字节是吞吐上界，不能称 tokens/s 下界",
            "assumptions": "50/200/900 GB/s 为假设有效带宽参数；单一聚合瓶颈、串行层、batch权重复用，不额外叠加并行链路带宽",
            "excluded": "只计路由专家权重；忽略计算/KV/激活/EP/调度等；非整模型性能预测，不是任何设备可达吞吐",
        },
        "bandwidth_scenarios": scenarios, "checks": checks, "pass": all(checks.values()),
    }


def main() -> int:
    """始终落盘已有结果与失败 traceback；全部扫描及账本判据通过才退出 0。"""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("raw.json"))
    parser.add_argument("--bandwidths-gb-s", default="50,200,900", help="假设有效带宽，逗号分隔，十进制 GB/s")
    args = parser.parse_args()
    record = {
        "env": {"timestamp_utc": datetime.now(timezone.utc).isoformat(),
                "platform": platform.platform(), "python": platform.python_version(),
                "torch": torch.__version__, "device": "cpu", "threads": 1, "seed": SEED},
        "degradation": DEGRADATION,
        "timing": "不做性能计时；构造/前向只用于正确性、统计与公式双算，无墙钟或速度结论",
        "overflow_semantics": "任一命中专家满位→整 token 残差直通、不占其他槽；教学简化，另有按专家粒度丢弃变体，不冒充 Switch 原文语义",
        "capacity": "floor(ceil(T/N)*cf) 整数槽位，不乘 k；均衡 k=2,cf=1 仍会溢出",
        "activation": "本次专家并集参数 U*P 与逐 token 执行量 2*P*Σ_e count_e 分列；P=3*d*d_ff",
        "dense_reference": "相同专家总参数的 SwiGLU，dense_d_ff=N*d_ff；另报单专家宽度 dense 参考，均不计 router/SiLU/合并",
        "ep_convention": "公式推演，非实测：两次 all-to-all，每次 Σ_e sent_e*d*4B；gloo 路径无 all-to-all；不含 metadata/协议/算法内部流量",
        "criteria": "18/18 分布点、8/8 batch 点，无隐藏失败；逐 token 手算与 stats 一致；权重每 token 摊薄、EP 每 token 恒定；V3 账本手算与公式一致",
        "distribution_scan": [], "batch_scan": [], "checks": {}, "pass": False,
    }
    previous_threads = torch.get_num_threads()
    try:
        bandwidths = [float(value) for value in args.bandwidths_gb_s.split(",")]
        if not bandwidths or any(not math.isfinite(b) or b <= 0 for b in bandwidths):
            raise ValueError("带宽必须是有限正数")
        torch.set_num_threads(1)
        distribution_scan(record)
        batch_scan(record)
        _require(record["checks"], "batch_scan_complete", len(record["batch_scan"]) == 8)
        ledger = deepseek_v3_ledger(bandwidths)
        record["deepseek_v3"] = ledger
        _require(record["checks"], "deepseek_ledger", ledger["pass"])
        record["pass"] = all(record["checks"].values())
    except Exception:
        record["error"] = traceback.format_exc()
        print(record["error"], file=sys.stderr)
    finally:
        torch.set_num_threads(previous_threads)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"{'PASS' if record['pass'] else 'FAIL'}; raw: {args.output}")
    print(DEGRADATION)
    return 0 if record["pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
