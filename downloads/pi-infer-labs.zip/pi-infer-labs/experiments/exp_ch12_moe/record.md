# exp_ch12 MoE top-k 路由与资源账 · 实验记录

复跑基准：git eed7a4d；环境：Python 3.12.10 / torch 2.15.0+cpu / Windows CPU。tiny MoE：d=64、d_ff=176、N=8 专家、固定种子；dense 参照=相同专家总参数的 SwiGLU（dense_d_ff=N×d_ff）。

| 项 | 结果 | 判据 |
|---|---|---|
| 分布×k×容量因子（18 点） | 全 PASS | uniform 近零溢出；peak(0.8) k=1 溢出 70.3%/67.2%/57.8%（cf=1.0/1.25/2.0）、k=2 84.4%/81.2%/71.9%——方向断言 |
| 溢出语义 | 整 token 残差直通（输出==输入，有断言）；容量=floor(ceil(T/N)×cf) 不乘 k——k=2 均衡 cf=1 也溢出（如实记录） | 教学简化口径，docstring 声明不冒充 Switch 原文 |
| batch 并集（T∈{1,4,16,64}） | uniform union/T 1.0→0.125；weight/T 135,168→16,896 B（8×摊薄）；**EP/T 恒 512 B**（=2×k×d×4B，无溢出时） | 摊薄方向断言（通信不摊薄 vs 权重摊薄） |
| EP 字节 | 每次溢出后按实际派发 token 计（如 peak/1.0/1.0：9,728 B = 2×19 token×64×4B） | 公式推演口径（gloo 无 all-to-all，非实测） |
| DeepSeek-V3 账本 | 逐项闭合：单专家 44,040,192 参数；总 671,026,404,352 ≈671B；激活 36,625,610,752 ≈37B；单层路由读 704,643,072 B；EP 每层 229,376 B；带宽三档 50/200/900 GB/s → 58 层单 token 吞吐上界 1.22/4.89/22.05 tok/s | 四项手工核对（checks 全 true）；账本推演非实测 |

- 生成口径：不适用（FFN 层实验无生成任务；路由确定性由固定种子 logits 单测覆盖）。
- 固定输入：可控分布 controlled_routing（uniform / peak(p) / temperature，同种子确定性）；DSV3 账本数字来自 S17 + HF config 直查（sources 在 raw.json，访问 2026-11-03）。
- 带宽约定：tokens/s 为**上界**（带宽÷每 token 需读字节），不可称"下界"；假设单一聚合瓶颈、忽略计算/KV/激活/EP。
- 复跑：`python -m pytest pi_infer/tests/test_moe.py -q`（50 项）；`python experiments/exp_ch12_moe/run_moe_experiment.py`（产物 raw.json）。
- 降级说明：无 GPU、无大 MoE 实跑、不做引擎横评（5.3/1.2）；EP 与 DSV3 全部为公式/账本推演，假设在 raw.json 逐项声明（bf16 假设不代表 FP8 发布权重）。
