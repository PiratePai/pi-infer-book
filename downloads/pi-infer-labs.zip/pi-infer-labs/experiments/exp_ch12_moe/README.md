# 第 12 章 MoE CPU 实验

```powershell
python -m pytest pi_infer/tests/test_moe.py -q -p no:cacheprovider
python experiments/exp_ch12_moe/run_moe_experiment.py
# 可选：指定假设有效带宽（十进制 GB/s），不访问设备或网络
python experiments/exp_ch12_moe/run_moe_experiment.py --bandwidths-gb-s 50,200,900 --output experiments/exp_ch12_moe/raw.json
```

脚本成功返回 0，失败返回 1；`raw.json` 保存环境、每个扫描点的路由/门控、完整 MoEStats、独立逐 token 容量账、判据及失败 traceback。18 个分布点和 8 个 batch 点必须全部完成，不隐藏失败。只实跑 CPU tiny，不报告计时或加速比。EP 与 DeepSeek-V3 部分均为公式推演，无 GPU、无大 MoE 实跑、不做引擎横评。

## 路由和溢出语义

`MoEFFN(MoEConfig(...))(x, routing=None)` 返回 `(output, stats)`。x 为 CPU 浮点 `[T,d]`，默认 float32；Router 返回 `[T,k]` 的专家 id 与原 softmax 概率，top-k 不再次归一化。外部注入路由使用传入 gates 的原值；受控路由生成器则按要求把选中专家概率归一化。

本实现按 token 顺序接纳：**任一命中专家满位，就把该 token 整体经残差直通，输出等于输入，且不占用任何专家槽位**。这是教学简化语义；文献中还有按专家粒度丢弃的变体，不冒充 Switch 原文语义。未溢出时只输出 `Σ_j gate_j*Expert_j(x)`。这里也不模拟 DeepSeek-V3 的生产路由算法。

容量上限为 `ceil(T/N)*capacity_factor`，可用整数槽位取 floor，**不乘 k**。因此 T=64、N=8 时每专家基础容量为 8，均衡 k=2、cf=1 也会有一半 token 溢出；cf=2 才能接纳全部均衡 top-2 路由。`uniform` 是固定种子随机排列循环的分层均衡分布，各专家边际等概率，完整周期精确均衡，不是 iid 随机负载。`peak` 的 p 是无放回抽样底分布的专家 0 概率，k>1 时不能把 p 当作最终命中率。

## 激活、执行、通信三笔账

每专家 SwiGLU 有 `P=3*d*d_ff` 个参数。统计中专家并集激活参数是 `U*P`，总专家参数是 `N*P`，router 参数另列，模型总参数包含 router。激活比的分母是专家总参数，所以单 token、k=1 的专家激活比恰为 1/N；整批 k=1 也可能激活所有专家。

矩阵乘 FLOPs 按 FMA=2 估计：`2*P*Σ_e processed_tokens_e`，不把专家并集参数错误地再乘整个 T；不含 router、SiLU、门控合并和残差。等价 dense FFN 取相同专家总参数，即 `dense_d_ff=N*d_ff`，其 FLOPs 为 `2*N*P*T`。另报单专家宽度 dense 参考，便于区分参数规模与每 token 算量。

EP 派发和回收各记一次 all-to-all，每次 `Σ_e sent_tokens_e*d*4 B`，只数接纳的专家 token 对。4 B 是此 CPU 实验的固定 float32 逻辑载荷假设；模型转 dtype 不会自动改变这项公式。项目 gloo 路径无 all-to-all，这里没有实际通信调用，也不测链路流量；不含元数据、padding、协议、内部重复收发或专家本地放置优化。

## Batch 扫描的方向

固定 k=1、cf=N=8，避免溢出干扰，T∈{1,4,16,64} 使用同一条路由轨迹的前缀。**专家并集 U(T) 的绝对大小随 T 非递减**。假设每批每个活跃专家的权重只读一次，则每 token 权重读取字节为 `U(T)*P*4/T`，可以摊薄。固定种子的实跑检查该摊薄方向；单样本 `U/T` 非递增并不是任意随机前缀的定理。另记录期望并集，peak 的 k=1 公式为 `Σ_e[1-(1-p_e)^T]`，其期望并集/T 非递增。

**无溢出时，每 token EP 激活载荷恒为 `2*k*d*4`，每 token 专家矩阵乘 FLOPs 恒为 `2*k*P`**。它们不因权重批内复用而减少。扫描明确断言 EP/T 恒定为 512 B；不能把丢 token 导致的字节减少当成摊薄收益。

## DeepSeek-V3 手算（推演）

主干配置依据 [S17 §4.2](https://arxiv.org/html/2412.19437v2#S4.SS2)；dense 中间维、词表和 MLA 维度补自 [官方配置](https://huggingface.co/deepseek-ai/DeepSeek-V3/blob/main/config.json)，矩阵分解参照 [官方实现](https://github.com/deepseek-ai/DeepSeek-V3/blob/main/inference/model.py)。只做主模型参数账，不含 MTP、量化 scale、非学习路由校正 bias；字节假设 bf16，不代表 FP8 发布权重的文件大小。

`P=3*7168*2048=44,040,192`。下表给出配置推算值；论文的 671B/37B 是约数，不能当作精确参数计数。

| 部分 | 驻留参数 | 单 token 激活参数 |
|---|---:|---:|
| 58 层路由专家 | 58×256×P = 653,908,770,816 | 58×8×P = 20,434,649,088 |
| 58 层共享专家 | 58×P = 2,554,331,136 | 2,554,331,136 |
| 首 3 层 dense FFN | 3×3×7168×18432 = 1,189,085,184 | 1,189,085,184 |
| 61 层 MLA 投影 | 11,413,422,080 | 11,413,422,080 |
| MoE routers | 106,430,464 | 106,430,464 |
| 各 RMSNorm | 1,006,592 | 1,006,592 |
| 输入 embedding | 926,679,040 | 单行 7,168 |
| 独立输出 head | 926,679,040 | 926,679,040 |
| 合计 | **671,026,404,352 ≈ 671B** | **36,625,610,752 ≈ 37B** |

MLA 每层分项为 `7168*1536 + 1536*128*(128+64) + 7168*(512+64) + 512*128*(128+128) + (128*128)*7168 = 187,105,280`，完整手算项与结果保存于 raw。输入 embedding 按一次查表只读一行计激活，输出 head 则计完整矩阵；这是一套明确的推算口径。

单 token、单 MoE 层，8 个路由专家权重读取为 `8*P*2 = 704,643,072 B = 672 MiB`，共享专家另加 `P*2 = 88,080,384 B`。58 层路由专家合计 `40,869,298,176 B`。EP 每程 `8*7168*2 = 114,688 B`，两程 `229,376 B = 224 KiB`；58 层共 `13,303,808 B`。`8/256` 是专家命中比例，求出发送数 8 后不能再乘一次该比例。

卸载场景假设路由专家在 CPU、其余常驻 GPU，每层只把所选专家传入 GPU，无跨 batch 缓存命中和预取重叠；全驻留场景没有这笔 CPU→GPU 流量，仍需考虑 HBM 读取。CPU→GPU 和 HBM 的有效带宽是不同参数，不可混用。

假设 50/200/900 GB/s 有效带宽，`耗时下界=字节/带宽`，`吞吐上界=带宽/每 token 字节`。后者不能称为 token/s 下界。raw 同时报单层、58 层和 batch 摊薄后的值，只计路由专家，不预测整模型性能。

V3 batch 账假设每 token 均匀无放回命中 8 专家，token 之间独立，则 `E[U(T)]=256*[1-(1-8/256)^T]`。每 token 路由专家权重字节为 `E[U]*P*2/T`；共享权重为 `P*2/T`。该模型忽略真实分组/节点限制，EP 每 token 仍为 229,376 B，不随专家权重摊薄而降低。
