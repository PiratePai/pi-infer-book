"""第 11 章 P/D：spawn gloo CPU 交接、错误路径与 KV 长度扫描。

运行：python experiments/exp_ch11_pd/run_pd_experiment.py [--output raw.json]
gloo 不可用/运行异常时保留原因并降级到线程共享 InProcessChannel。
仅使用标准库与 torch；输出 raw JSON 和独立 SVG 曲线，不生成 record.md。
"""

from __future__ import annotations

import argparse
import json
import pickle
import platform
import queue
import socket
import statistics
import sys
import threading
import time
import traceback
from datetime import datetime, timedelta, timezone
from pathlib import Path

import torch
import torch.distributed as dist
import torch.multiprocessing as mp

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from pi_infer.generate import greedy_decode  # noqa: E402
from pi_infer.kv import DoubleFreeError  # noqa: E402
from pi_infer.model import SimpleKVCache, build_tiny_model  # noqa: E402
from pi_infer.pd import (  # noqa: E402
    ACK_TOPIC, PD_TOPIC, Ack, Cancel, Channel, Data, DecodeWorker,
    GlooChannel, InProcessChannel, PdCancelled, PdRequest,
    PrefillWorker, message_bytes,
)


SEED = 11
LENGTHS = (16, 32, 64, 128)
WARMUP = 2
REPEATS = 5


def _wait(predicate, timeout=5.):
    deadline = time.monotonic() + timeout
    while not predicate():
        if time.monotonic() >= deadline:
            raise TimeoutError("实验协议条件未满足")
        time.sleep(0.001)


class _FaultChannel(Channel):
    """只对命名故障用例注入丢 Ack/暂停 Data/丢 Cancel；扫描不注入故障。"""

    def __init__(self, base, role):
        self.base, self.role = base, role
        self.data_entered, self.resume = threading.Event(), threading.Event()
        self.dropped_ack = 0

    def send(self, topic, message):
        if self.role == "d" and type(message) is Ack and message.request_id == "retry" and not self.dropped_ack:
            self.dropped_ack += 1
            return
        if self.role == "p" and isinstance(message, Data) and message.request_id == "cancel-data":
            self.data_entered.set()
            if not self.resume.wait(5):
                raise TimeoutError("Data 故障注入未恢复")
            return
        if self.role == "p" and isinstance(message, Cancel) and message.request_id == "cancel-data":
            return  # 故意丢取消通知，由 D 的 Prepare 超时回收。
        self.base.send(topic, message)

    def recv(self, topic, timeout=None):
        return self.base.recv(topic, timeout)

    def close(self):
        self.base.close()


def _snapshot(model, rid, kv_len=16, prefill_tokens=1):
    prompt = [(i * 7 + 1) % model.config.vocab_size for i in range(kv_len - prefill_tokens + 1)]
    cache = SimpleKVCache()
    generated = greedy_decode(model, prompt, prefill_tokens, cache)
    return PdRequest.from_cache(rid, generated.token_ids, cache), prompt


def _decode_session(base, model=None):
    """D 接收线程处理协议；本线程仅响应实验控制与生成请求。"""
    model = build_tiny_model(SEED) if model is None else model
    channel = _FaultChannel(base, "d")
    d = DecodeWorker(model, channel, data_timeout=0.15)
    stop = threading.Event()
    failures = []

    def receive():
        try:
            d.run(stop)
        except Exception:
            failures.append(traceback.format_exc())

    thread = threading.Thread(target=receive, name="pd-experiment-d")
    thread.start()
    try:
        while True:
            command = channel.recv("command", timeout=15.)
            op, rid = command["op"], command.get("rid")
            if op in ("inspect", "decode"):
                _wait(lambda: rid in d.states and d.states[rid].committed)
                tokens = d.decode(rid, command.get("tokens", 0))
                state = d.states[rid]
                result = {"token_ids": tokens, "steps": state.steps,
                          "kv_len": state.cache.get(0)[0].shape[2],
                          "epoch": state.prepare.epoch}
            elif op == "pending":
                _wait(lambda: rid in d.pending)
                result = {"pending": True}
            elif op == "released":
                _wait(lambda: rid not in d.states and rid not in d.pending)
                result = {"state_count": d.state_count, "expired_prepares": d.expired_prepares}
            elif op == "errors":
                _wait(lambda: len(d.errors) >= command["count"])
                result = {"errors": [{"type": type(e).__name__, "message": str(e)} for e in d.errors]}
            elif op == "finish":
                _wait(lambda: d.state_count == 0)
                result = {"state_count": d.state_count, "pending_messages": base.pending_count,
                          "expired_prepares": d.expired_prepares,
                          "dropped_ack": channel.dropped_ack, "receiver_failures": failures,
                          "errors": [{"type": type(e).__name__, "message": str(e)} for e in d.errors]}
            else:
                raise ValueError(f"未知实验控制: {op}")
            channel.send("result", result)
            if op == "finish":
                return result
    finally:
        stop.set()
        thread.join(2)
        if thread.is_alive():
            raise RuntimeError("D 接收线程未退出")


def _prefill_session(base, model=None):
    """P 驱动一致性、三时机取消、重试去重/epoch 及交错长度扫描。"""
    model = build_tiny_model(SEED) if model is None else model
    channel = _FaultChannel(base, "p")
    p = PrefillWorker(channel, ack_timeout=2.)

    def command(op, rid=None, **kwargs):
        channel.send("command", {"op": op, "rid": rid, **kwargs})
        return channel.recv("result", timeout=10.)

    def release(rid, cancel=False):
        if cancel:
            p.cancel(rid)
        else:
            p.release(rid)
        remote = command("released", rid)
        return {"p_held": p.owned_count, "p_routes": len(p.transferred),
                "d_states": remote["state_count"], "queued_messages": base.pending_count,
                "expired_prepares": remote["expired_prepares"]}

    def clean(row):
        return all(row[key] == 0 for key in ("p_held", "p_routes", "d_states", "queued_messages"))

    result = {"checks": {}, "cancellations": {}, "scan": []}
    req, prompt = _snapshot(model, "agreement", prefill_tokens=3)
    epoch = p.hold(req)
    payload = Data(req.request_id, epoch, req.token_ids, req.kv)
    p.handoff(req.request_id)
    remote = command("decode", req.request_id, tokens=6)
    reference = greedy_decode(model, prompt, 9).token_ids
    result["agreement"] = {"prompt": prompt, "p_generated": 3, "d_generated": 6,
                           "actual": remote["token_ids"], "reference": reference,
                           "bytes": message_bytes(payload), "pass": remote["token_ids"] == reference}
    result["checks"]["token_for_token"] = result["agreement"]["pass"]

    # 在已续解码的缓存上重发最初 Data，不能重建/倒退或重复生成。
    channel.send(PD_TOPIC, payload.prepare())
    channel.send(PD_TOPIC, payload)
    duplicate_ack = channel.recv(ACK_TOPIC, timeout=2.)
    after_duplicate = command("inspect", req.request_id)
    result["checks"]["duplicate_data"] = duplicate_ack == Ack(req.request_id, epoch) and after_duplicate == remote
    result["checks"]["agreement_cleanup"] = clean(release(req.request_id))

    req, _ = _snapshot(model, "cancel-before")
    p.hold(req)
    before = release(req.request_id, cancel=True)
    before["pass"] = clean(before)
    result["cancellations"]["before_prepare"] = before

    req, _ = _snapshot(model, "cancel-data")
    p.hold(req)
    failures = []

    def handoff():
        try:
            p.handoff(req.request_id)
        except Exception as error:
            failures.append(error)

    thread = threading.Thread(target=handoff)
    thread.start()
    try:
        if not channel.data_entered.wait(5):
            raise TimeoutError("未进入 Data 阶段")
        command("pending", req.request_id)
        during = release(req.request_id, cancel=True)
    finally:
        channel.resume.set()
        thread.join(5)
    during["handoff_exception"] = type(failures[0]).__name__ if failures else None
    during["injection"] = "暂停并丢弃 Data，同时丢弃 Cancel；D 依靠 Prepare 超时清理"
    during["pass"] = (not thread.is_alive() and clean(during) and during["expired_prepares"] == 1
                      and len(failures) == 1 and isinstance(failures[0], PdCancelled))
    result["cancellations"]["during_data"] = during

    req, _ = _snapshot(model, "cancel-after")
    p.hold(req)
    p.handoff(req.request_id)
    command("inspect", req.request_id)
    after = release(req.request_id, cancel=True)
    after["pass"] = clean(after)
    result["cancellations"]["after_ack"] = after

    req, _ = _snapshot(model, "retry")
    epoch = p.hold(req)
    p.ack_timeout = 0.1
    try:
        p.handoff(req.request_id)
    except TimeoutError:
        retained = p.owned_count == 1 and p.held[req.request_id].data.epoch == epoch
    else:
        retained = False
    p.ack_timeout = 2.
    retried_epoch = p.handoff(req.request_id)
    remote = command("inspect", req.request_id)
    result["checks"]["ack_timeout_retry"] = retained and retried_epoch == epoch == remote["epoch"]
    result["checks"]["retry_cleanup"] = clean(release(req.request_id))
    try:
        p.release(req.request_id)
    except DoubleFreeError:
        result["checks"]["double_release"] = True
    else:
        result["checks"]["double_release"] = False

    # released epoch=0，复用相同 request_id 得到 epoch=1；旧消息不能损伤新缓存。
    req, prompt = _snapshot(model, "reuse")
    old_epoch = p.hold(req)
    old = Data(req.request_id, old_epoch, req.token_ids, req.kv)
    p.handoff(req.request_id)
    release(req.request_id)
    new_epoch = p.hold(req)
    p.handoff(req.request_id)
    channel.send(PD_TOPIC, old.prepare())
    channel.send(PD_TOPIC, old)
    channel.send(PD_TOPIC, Cancel(req.request_id, old_epoch))
    errors = command("errors", count=3)["errors"]
    remote = command("decode", req.request_id, tokens=2)
    result["checks"]["stale_epoch_isolation"] = (
        new_epoch == old_epoch + 1 and remote["epoch"] == new_epoch
        and remote["token_ids"] == greedy_decode(model, prompt, 3).token_ids
        and len(errors) == 3 and all(e["type"] == "PdStaleMessage" for e in errors))
    result["checks"]["reuse_cleanup"] = clean(release(req.request_id))

    snapshots = {length: _snapshot(model, f"scan-{length}", kv_len=length)[0] for length in LENGTHS}
    samples = {length: [] for length in LENGTHS}
    byte_samples = {length: [] for length in LENGTHS}
    for iteration in range(WARMUP + REPEATS):
        for length in LENGTHS:
            original = snapshots[length]
            rid = f"scan-{length}-{iteration}"
            req = PdRequest(rid, original.token_ids, original.kv)
            p.hold(req)  # 模型计算与 P 快照复制不计时。
            bytes_before = p.sent_bytes
            start = time.perf_counter()
            p.handoff(rid)
            elapsed = time.perf_counter() - start
            remote = command("inspect", rid)
            if remote["kv_len"] != length or remote["token_ids"] != req.token_ids:
                raise AssertionError("扫描交接后的载荷与发送侧不符")
            if not clean(release(rid)):
                raise AssertionError("扫描回收有残留")
            if iteration >= WARMUP:
                samples[length].append(elapsed)
                byte_samples[length].append(p.sent_bytes - bytes_before)
    for length in LENGTHS:
        # 独立手算：2(K/V)*2层*2KV heads*T*16 head_dim*4(float32) + (T+1)*8。
        expected = 2 * 2 * 2 * length * 16 * 4 + (length + 1) * 8
        values = samples[length]
        row = {"kv_len": length, "token_count": length + 1,
               "message_bytes": message_bytes(snapshots[length]), "expected_bytes": expected,
               "sent_bytes_each_handoff": byte_samples[length], "samples_s": values,
               "mean_s": statistics.mean(values), "std_s": statistics.stdev(values),
               "logical_mib_per_s": expected / statistics.mean(values) / 1024**2,
               "pass": all(b == expected for b in byte_samples[length]) and all(t > 0 for t in values)}
        result["scan"].append(row)
    result["d_cleanup"] = command("finish")
    result["p_cleanup"] = {"held": p.owned_count, "routes": len(p.transferred),
                           "queued_messages": base.pending_count}
    result["checks"]["cleanup"] = (
        all(value == 0 for value in result["p_cleanup"].values())
        and result["d_cleanup"]["state_count"] == result["d_cleanup"]["pending_messages"] == 0
        and not result["d_cleanup"]["receiver_failures"] and result["d_cleanup"]["dropped_ack"] == 1)
    result["pass"] = (all(result["checks"].values()) and all(r["pass"] for r in result["cancellations"].values())
                      and all(r["pass"] for r in result["scan"]))
    return result


def _gloo_entry(rank, port, results):
    """spawn 顶层入口；两 rank 分别运行 P/D，各自持有一个模型和通道端点。"""
    torch.set_num_threads(1)
    channel = None
    try:
        dist.init_process_group("gloo", init_method=f"tcp://127.0.0.1:{port}",
                                rank=rank, world_size=2, timeout=timedelta(seconds=20))
        channel = GlooChannel(1 - rank)
        result = _prefill_session(channel) if rank == 0 else _decode_session(channel)
        channel.close()
        channel = None
        results.put((rank, pickle.dumps(result, protocol=pickle.HIGHEST_PROTOCOL)))
    finally:
        try:
            if channel is not None:
                channel.close()
        finally:
            if dist.is_initialized():
                dist.destroy_process_group()


def _run_gloo():
    if not dist.is_available() or not dist.is_gloo_available():
        raise RuntimeError("当前 torch 无 gloo 后端")
    with socket.socket() as probe:
        probe.bind(("127.0.0.1", 0))
        port = probe.getsockname()[1]
    results = mp.get_context("spawn").Queue()
    context = None
    ranks = {}
    deadline = time.monotonic() + 90
    before = {p.pid for p in mp.active_children()}
    try:
        context = mp.spawn(_gloo_entry, args=(port, results), nprocs=2, join=False)
        finished = False
        while not finished:
            if time.monotonic() >= deadline:
                raise TimeoutError("gloo 实验超时")
            try:
                rank, payload = results.get(timeout=0.05)
                ranks[rank] = pickle.loads(payload)
            except queue.Empty:
                pass
            finished = context.join(timeout=0.05)
        while len(ranks) < 2:
            rank, payload = results.get(timeout=1.)
            ranks[rank] = pickle.loads(payload)
    finally:
        if context is not None:
            for process in context.processes:
                if process.is_alive():
                    process.terminate()
            for process in context.processes:
                process.join()
        results.close()
        results.join_thread()
    result = ranks[0]
    result["worker_cleanup"] = {"remaining_pids": sorted({p.pid for p in mp.active_children()} - before)}
    result["pass"] = result["pass"] and not result["worker_cleanup"]["remaining_pids"]
    return result


def _run_inprocess():
    channel = InProcessChannel()
    failures = []
    # build_tiny_model 设置全局 RNG；同进程必须串行初始化两份模型。
    p_model, d_model = build_tiny_model(SEED), build_tiny_model(SEED)

    def decode():
        try:
            _decode_session(channel, d_model)
        except Exception:
            failures.append(traceback.format_exc())

    thread = threading.Thread(target=decode, name="pd-fallback")
    thread.start()
    try:
        result = _prefill_session(channel, p_model)
        thread.join(2)
        result["worker_cleanup"] = {"thread_alive": thread.is_alive(), "failures": failures}
        result["pass"] = result["pass"] and not thread.is_alive() and not failures
        return result
    finally:
        channel.close()
        thread.join(2)


def _write_curve(path, rows, backend):
    """用标准库输出两幅共享 T 轴的 SVG，原始数值完整保留于 JSON。"""
    width, height = 960, 370
    chunks = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
              '<rect width="100%" height="100%" fill="white"/>',
              f'<text x="30" y="28" font-family="sans-serif" font-size="17">P/D handoff - {backend} CPU relative (mean +/- sample std)</text>']
    for panel, (field, scale, label, color) in enumerate((
        ("mean_s", 1000, "Handoff latency (ms)", "#2563eb"),
        ("message_bytes", 1 / 1024, "Logical payload (KiB)", "#059669"),
    )):
        left, top, plot_w, plot_h = 65 + panel * 465, 75, 370, 230
        ymax = max((r[field] + (r["std_s"] if field == "mean_s" else 0)) * scale for r in rows) * 1.15

        def x(value):
            return left + (value - 16) / (128 - 16) * plot_w

        def y(value):
            return top + plot_h * (1 - value / ymax)

        chunks.append(f'<text x="{left}" y="55" font-family="sans-serif" font-size="14">{label}</text>')
        for tick in range(5):
            value = ymax * tick / 4
            yy = y(value)
            chunks.append(f'<path d="M {left} {yy} h {plot_w}" stroke="#ddd"/>')
            chunks.append(f'<text x="{left-8}" y="{yy+4}" text-anchor="end" font-size="11">{value:.2f}</text>')
        chunks.append(f'<path d="M {left} {top} v {plot_h} h {plot_w}" stroke="#555" fill="none"/>')
        points = " ".join(f'{x(r["kv_len"]):.2f},{y(r[field]*scale):.2f}' for r in rows)
        chunks.append(f'<polyline points="{points}" fill="none" stroke="{color}" stroke-width="2"/>')
        for row in rows:
            xx, yy = x(row["kv_len"]), y(row[field] * scale)
            chunks.append(f'<circle cx="{xx}" cy="{yy}" r="4" fill="{color}"/>')
            if field == "mean_s":
                low, high = y((row[field] - row["std_s"]) * scale), y((row[field] + row["std_s"]) * scale)
                chunks.append(f'<path d="M {xx} {low} V {high} M {xx-4} {low} h 8 M {xx-4} {high} h 8" stroke="{color}"/>')
            chunks.append(f'<text x="{xx}" y="{top+plot_h+19}" text-anchor="middle" font-size="12">{row["kv_len"]}</text>')
        chunks.append(f'<text x="{left+plot_w/2}" y="350" text-anchor="middle" font-family="sans-serif" font-size="13">KV length T</text>')
    chunks.append("</svg>")
    path.write_text("\n".join(chunks), encoding="utf-8")


def main():
    """落盘口径、判据与原始样本；所有自检通过退出 0，否则退出 1。"""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("raw.json"))
    parser.add_argument("--inprocess", action="store_true", help="显式验证降级路径，不尝试 gloo")
    parser.add_argument("--allow-fallback", action="store_true", help="允许 gloo 失败后以进程内验证成功退出")
    args = parser.parse_args()
    torch.set_num_threads(1)
    record = {
        "environment": {"timestamp_utc": datetime.now(timezone.utc).isoformat(),
                        "platform": platform.platform(), "python": platform.python_version(),
                        "torch": torch.__version__, "device": "cpu", "gloo_available": dist.is_gloo_available(),
                        "seed": SEED, "threads_per_worker": 1, "world_size_requested": 2,
                        "start_method": "spawn"},
        "criteria": {"agreement": "相同种子 tiny、相同 prompt、相同总生成长度，逐 token 完全一致",
                     "cancellation": "三时机 P held/routes、D pending/states 与通道未消费消息均为零",
                     "bytes": "每次交接 message_bytes 等于独立 shape 手算；每次重发单独计数",
                     "errors": "Ack 超时保留所有权且同 epoch 重试、重复 Data 幂等、旧 epoch 隔离、重复 release 报错",
                     "exit_code": "默认 gloo 失败退出 1；仅 --allow-fallback 或 --inprocess 允许降级验证成功退出 0"},
        "contract": "KV 长度=len(token_ids)-1；D 首步重喂最后一个 token；Commit 前不得解码",
        "timing_method": {"clock": "P perf_counter，prepare 发送前至 Ack 收到并完成 Commit 发送",
                          "included": "控制消息、Data 序列化/传输、D 缓存重建、P 清理与 Commit 发送",
                          "excluded": "spawn、进程组、模型构造、prefill、P hold 快照复制、D 续解码、回收/实验控制",
                          "warmup_per_length": WARMUP, "repeats_per_length": REPEATS,
                          "order": "每轮交错 T=16,32,64,128，先预热后记录；mean/std(n-1)",
                          "scan": "T 为 KV 长度，token_ids 长度 T+1；T=128 只交接、不继续解码，遵守 tiny 的位置上限",
                          "bandwidth": "logical_mib_per_s=逻辑载荷/交接耗时，只作 CPU 相对敏感性，不代表链路带宽"},
        "byte_convention": "len(token_ids)*8 + Σ层(K.numel*K.element_size + V.numel*V.element_size)；不含协议头/pickle/控制消息/内部重传",
        "declaration": "gloo CPU 相对；真实引擎 P/D 实测未测；GPU/NCCL/设备性能未测。混合模型 Qwen3.5 GDN 交接对象账在正文层面，不属本脚本。",
        "fallback": {"used": False, "reason": None},
        "allow_fallback": args.allow_fallback,
    }
    try:
        if args.inprocess:
            record["fallback"] = {"used": True, "reason": "命令行 --inprocess 显式选择"}
            record["backend"] = "InProcessChannel (single process, two threads)"
            result = _run_inprocess()
        else:
            try:
                result = _run_gloo()
                record["backend"] = "GlooChannel (two spawned processes)"
            except Exception:
                record["fallback"] = {"used": True, "reason": traceback.format_exc()}
                print("gloo 运行失败，降级为 InProcessChannel；具体原因保留于 JSON。", file=sys.stderr)
                record["backend"] = "InProcessChannel (single process, two threads)"
                result = _run_inprocess()
        record["result"] = result
        record["pass"] = result["pass"]
        if record["fallback"]["used"] and not (args.inprocess or args.allow_fallback):
            record["pass"] = False
        record["gloo_two_process_pass"] = not record["fallback"]["used"] and result["pass"]
        curve = args.output.with_suffix(".svg")
        curve.parent.mkdir(parents=True, exist_ok=True)
        _write_curve(curve, result["scan"], "InProcess" if record["fallback"]["used"] else "gloo spawn")
        record["curve"] = curve.name
        for row in result["scan"]:
            print(f'T={row["kv_len"]:3d}  bytes={row["message_bytes"]:6d}  mean_ms={row["mean_s"]*1000:.3f}  std_ms={row["std_s"]*1000:.3f}')
    except Exception:
        record["pass"] = False
        record["gloo_two_process_pass"] = False
        record["error"] = traceback.format_exc()
        print(record["error"], file=sys.stderr)
    record["status"] = "PASS" if record["pass"] else "FAIL"
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f'{record["status"]}: {record.get("backend", "未运行")}；fallback={record["fallback"]["used"]}')
    print(record["declaration"])
    print(f"原始记录：{args.output}")
    return 0 if record["pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
