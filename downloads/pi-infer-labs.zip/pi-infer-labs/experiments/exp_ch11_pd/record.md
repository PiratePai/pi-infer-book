# exp_ch11 P/D 双进程状态交接 · 实验记录

复跑基准：git eed7a4d；环境：Python 3.12.10 / torch 2.15.0+cpu / Windows CPU / **GlooChannel 双进程（spawn）实跑，未降级**（InProcessChannel 降级路径另行单测）。

| 项 | 结果 | 判据 |
|---|---|---|
| 交接后逐 token 一致 | PASS | 固定种子 tiny、同 prompt、同总生成长度，D 端续生成与单进程 greedy 参考**逐 token 全等**（受控确定性基线） |
| 取消三时机（交接前/Data 中/Ack 后） | 全 PASS | 双侧登记清零、通道无残留、无泄漏计数 |
| Ack 超时重试 | PASS | P 保留所有权、同 epoch 重发 Data 成功；重复 Data 幂等（仅重发 Ack 不重复解码） |
| 释放后复用 | PASS | 释放后旧 epoch 消息命中 tombstone 被拒，不影响新请求 |
| 重复释放 | PASS（报错） | 双重复用 kv.DoubleFreeError 语义 |
| 约定校验 | PASS | kv_len == len(token_ids)−1 不符即 ValueError（D 端首步重喂最后 token 取 logits） |
| 传输扫描 | T=16/32/64/128 → 8,328/16,648/33,288/66,568 B，耗时 1.9–4.8 ms（段末代早跑；终验复跑见下注，以 raw.json 为准） | 字节随 T 线性；小消息被固定延迟主导（字节×8 耗时几乎不动） |

- 消息协议：prepare/data/ack/commit-release 四阶段；幂等键 (request_id, epoch)。
- 代际说明：传输扫描耗时上行为段末代（git eed7a4d）；终验复跑（2026-11-04，干净 venv，已覆盖 raw.json）各档均值 T=16/32/64/128 → 5.83/2.59/4.93/8.91 ms（2.59–8.91 ms，样本 std 与档间差同量级）——绝对墙钟随机器波动，以 raw.json 为准；字节随 T 线性的账与"小消息固定延迟主导"的结构结论不变。
- 生成口径：tiny 模型 greedy argmax、固定种子、固定生成长度（token 字面量在 raw.json）。
- 字节账：message_bytes 与 shape 手算逐次一致（判据之一）；每次重发单独计数。
- 混合模型（Qwen3.5 GDN）交接对象账：正文 11.2 层面（KV 12,288 B/token + 每请求固定 conv 1.8 MB + recurrent 18.9 MB，S0/S4），本脚本不含——6.4 边界。
- 复跑：`python -m pytest pi_infer/tests/test_pd.py -q`（15 项）；`python experiments/exp_ch11_pd/run_pd_experiment.py`（产物 raw.json、raw.svg）。
- 降级说明：gloo CPU 相对；真实引擎 P/D 分离、NVLink/IB 传输带宽、GPU/NCCL 未测（5.3）；带宽敏感性为扫描曲线+账本推演（T=40,960 ≈503 MB @假设 50 GB/s → ≈10 ms）。
