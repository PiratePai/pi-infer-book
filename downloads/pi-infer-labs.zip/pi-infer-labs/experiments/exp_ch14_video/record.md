# exp_ch14 DiT 视频生成成本账与执行侧优化对照 · 实验记录

复跑基准：git 136c053 → 评审修订后复跑；环境：Python 3.12.10 / Windows CPU（纯账本推演，无 GPU/无 Wan 环境，driver 不适用；官方仓库主线按访问日）。对象：Wan-AI/Wan2.2-TI2V-5B（S32 仓库 + S33 config/文件大小直查；未下载权重、未运行生成）。生成口径：脚本固定 size 1280*704 / 121 帧 / shift 5.0 / unipc / 50 step / guide 5.0 / **seed=0（实验固定值；官方默认 -1 随机）**；batch=1 单卡主线。

| 项 | 结果 | 判据 |
|---|---|---|
| 潜在形状与 token 账 | 121 帧 → 潜在 48×31×44×80（(F-1)/4+1、H/16、W/16，实现直查公式断言；整数除法：120 帧会静默得 30 片/117 帧）；patchify (1,2,2) → **DiT token 27,280**；文本条件 512 token | 公式双算断言 |
| DiT 参数账 | 公式 **4.93B 为简化下界**（self/cross 各 4×3072²、FFN 两矩阵、text/time/patch embed；未含 bias/norm/modulation 小项 <0.5%）；fp32 存储（20.01GB/4）5.00B 为含全部小项口径——"5B"落在两者之间，**差 1.4%**；T5 encoder 5.68B（11.36GB bf16/2）；VAE 估 0.70B（2.82GB 按 fp32 假设，dtype 未直查已标注） | 下界 vs 存储双口径（差距如实报告） |
| FLOPs 账 | 每去噪前向：线性 269T + 自注意力二次 274T + 跨注意力 5.1T = **549T**；每 step CFG×2 = 1,097T；50 step **54.9 PFLOPs**；T5 每段生成编码 **2 次**（条件+无条件，实现直查）共 11.6T | 账本推演（bf16） |
| 官方口径闭合 | 54.9 PFLOPs ÷ 4090 峰值 165 TF/s = 5.5 分钟（100% 下界）；官方"<9 分钟" ⟺ **有效利用率 > 61.6%**——参数化闭合，非实测 | 双向核对 |
| 显存账 | 全常驻（80GB 卡场景）22.6GB + 激活超 24GB 卡；官方开关语义（实现直查）：offload_model = **每段生成前后各整体搬运 DiT 一次**（非逐 step）；t5_cpu = T5 常驻 CPU（每段 2 次编码）；convert_model_dtype = fp32→bf16；24GB 默认路径 GPU 峰值 ≈ 9.9GB + 激活；**无 FA 分数矩阵 35.7GB**（27,280²×24×2B）单次物化即爆——flash-attn 是硬约束 | 公式推演（假设与放置场景在 raw.json note） |
| VAE 粗估 | raw.json 中 vae_est（≈9.6 PFLOPs）为**量级参考**（每 16 输出像素过一次参数的粗估公式），不作成本结论，正文未引用 | 声明边界 |
| 执行侧优化 A/B（run_wan_generation.py） | **未测**。`--self-check` 已验证：三种计时挂接（属性式/nn.Module forward/类 `__call__`——T5EncoderModel 为普通类、每段生成 2 次调用）、固定参数（帧数 4n+1 断言）、盲化材料生成（匿名 X/Y 复制 + scoring_template.csv + blind_key.json）；构造参数与官方一致（t5_cpu/convert_model_dtype，offload 为 generate() 参数）；save_video(tensor=video[None]) 且校验产物非空 | 脚本逻辑签收；生成实测待复现条件 |

- 固定输入：PROMPTS 3 条（官方示例风格 + 场运镜 + 航拍）；A=--no-offload（显存装得下时）/ B=--offload（官方默认），同 seed 同采样参数只差执行开关。
- 盲化对照（复现时执行）：脚本产出匿名 X/Y 视频与打分模板；每字段 0/1/2 分档（0=缺失/错误，1=部分成立，2=明确成立）；黑帧=连续 ≥8 帧亮度均值 <5；四条失败条件任一命中判负；多数 prompt 分差 ≤2 视为质量等价比时间。不引入 FVD（D10）。
- 跨步缓存实验：未纳入（14.4——近似缓存的检查方法正文讲授，未核验的实现不作必做依赖）。
- 降级说明（5.3）：本机无 GPU、无 Wan2.2 运行环境——生成、阶段计时、A/B 对照**全部未测**；成本账为 config 直查推演，逐项断言与假设在 raw.json。
