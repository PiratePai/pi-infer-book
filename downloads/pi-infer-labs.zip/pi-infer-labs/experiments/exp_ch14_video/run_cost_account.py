#!/usr/bin/env python3
"""第 14 章实验（本机可跑部分）：Wan2.2-TI2V-5B 一次视频生成的成本账（config 直查推演）。

全部输入为 S32/S33 登记事实（仓库 config 代码直查 + HF 文件大小直查），本脚本把账算出来并
与手算常数双算断言——不加载模型、不跑生成（本机无 GPU/无 Wan 环境，5.3）。

账本结构（对应正文 14.2 的四阶段）：
  ① 文本编码（umT5-xxl encoder，一次）：参数 5.68B（bf16 checkpoint 11.36GB/2）× prompt 512 token
  ② 去噪循环（50 step × CFG 双前向 × DiT 5B × 27,280 token）——含线性项与自注意力二次项分开报
  ③ VAE 解码（高压缩 VAE，31 帧潜在 → 121 帧 1280×704 像素）
  ④ 输出/封装（121 帧像素 → mp4 写盘）
外加显存账（权重放置与三个官方工程开关 offload_model/convert_model_dtype/t5_cpu 的含义）。

运行：python experiments/exp_ch14_video/run_cost_account.py
产物：experiments/exp_ch14_video/raw.json
"""

from __future__ import annotations

import json
import platform
import sys
from pathlib import Path

OUT = Path(__file__).resolve().parent / "raw.json"

# ---------------- S33 登记事实（wan/configs/wan_ti2v_5B.py + HF config.json 直查） ----------------
CFG = dict(
    dim=3072, num_layers=30, num_heads=24, ffn_dim=14_336,
    in_dim=48, out_dim=48, freq_dim=256,
    patch=(1, 2, 2), vae_stride=(4, 16, 16),     # VAE 4×16×16 压缩 + patchify 2×2
    text_dim=2560, text_len=512,                 # umt5-xxl 输出维度 × 上下文长度
    sample_fps=24, sample_shift=5.0, sample_steps=50, sample_guide_scale=5.0,
    frame_num=121, size=(1280, 704),             # 720P 官方档（SUPPORTED_SIZES 仅 704*1280/1280*704）
    # HF 文件大小直查（2026-11-03）
    dit_fp32_bytes=20_010_000_000,               # 3 个 safetensors 分片合计 20.01 GB（fp32 存储）
    t5_bf16_bytes=11_360_000_000,                # models_t5_umt5-xxl-enc-bf16.pth
    vae_bytes=2_820_000_000,                     # Wan2.2_VAE.pth（dtype 未直查，按 fp32 估）
)


def dit_params_formula() -> dict:
    """DiT 参数公式侧（结构按官方 model.py：self/cross 各 4 投影 dim×dim、FFN 两矩阵、qk_norm/modulation）。"""
    d, L = CFG["dim"], CFG["num_layers"]
    self_attn = 4 * d * d
    cross_attn = 4 * d * d            # k/v 输入已被 text_embed 投到 dim（实现直查）
    ffn = 2 * d * CFG["ffn_dim"]
    per_layer = self_attn + cross_attn + ffn
    blocks = L * per_layer
    patch_embed = CFG["in_dim"] * d * CFG["patch"][0] * CFG["patch"][1] * CFG["patch"][2]
    text_embed = 2 * CFG["text_dim"] * d        # Sequential(Linear(text_dim,d), GELU, Linear(d,d))
    time_head = CFG["freq_dim"] * d + d * d     # sinusoidal→MLP
    head = d * CFG["out_dim"]
    return dict(per_layer=per_layer, blocks=blocks, patch_embed=patch_embed,
                text_embed=text_embed, time_head=time_head, head=head,
                total=blocks + patch_embed + text_embed + time_head + head)


def main() -> int:
    W, H = CFG["size"]
    F = CFG["frame_num"]
    st, sh, sw = CFG["vae_stride"]
    p_t, p_h, p_w = CFG["patch"]

    # ---------------- 潜在形状与 token 账（实现直查公式：target_shape） ----------------
    lat_t = (F - 1) // st + 1          # (121-1)//4+1 = 31
    lat_h = H // sh                    # 704//16 = 44
    lat_w = W // sw                    # 1280//16 = 80
    tokens = lat_t * (lat_h // p_h) * (lat_w // p_w)      # 31×22×40 = 27,280
    assert (lat_t, lat_h, lat_w, tokens) == (31, 44, 80, 27_280), "潜在/token 公式与手算不符"

    # ---------------- 参数账（公式 vs 文件大小双口径） ----------------
    p = dit_params_formula()
    dit_from_fp32 = CFG["dit_fp32_bytes"] / 4      # fp32 存储 → 参数 ≈ 5.00B（官方名"5B"）
    t5_params = CFG["t5_bf16_bytes"] / 2           # bf16 checkpoint → ≈5.68B
    vae_params_est = CFG["vae_bytes"] / 4          # dtype 未直查，按 fp32 估 ≈0.71B（声明假设）

    # ---------------- ② 去噪循环 FLOPs 账 ----------------
    d, L, heads = CFG["dim"], CFG["num_layers"], CFG["num_heads"]
    lin_per_token = 2 * p["total"]                                     # 线性项（投影+FFN）
    lin = lin_per_token * tokens                                       # 269.5 TFLOPs
    self_quad = 4 * d * tokens * tokens * L                            # 自注意力 QK^T+PV（FA 省 IO 不省 FLOPs）
    cross = 4 * d * tokens * CFG["text_len"] * L                       # 跨注意力（512 文本 token）
    per_pass = lin + self_quad + cross
    per_step = 2 * per_pass                                            # CFG：条件 + 无条件双前向
    total_dit = per_step * CFG["sample_steps"]

    # ---------------- ① 文本编码 & ③ VAE & ④ 输出（粗估，标注口径） ----------------
    t5_encodes = 2   # CFG：每段生成编码条件与无条件 prompt 各一次（实现直查）
    t5_flops = t5_encodes * 2 * t5_params * CFG["text_len"]            # ≈11.7 TFLOPs（每段生成）
    vae_flops_est = 2 * vae_params_est * F * W * H // 16               # 仅量级参考：每 16 输出像素过一次 VAE 参数的粗估，不作成本结论
    raw_frames_bytes = F * W * H * 3

    # ---------------- 显存账（bf16；放置场景分列，官方开关语义按实现直查） ----------------
    bf16 = 2
    mem = dict(
        dit_bf16=p["total"] * bf16 / 1e9,           # ≈9.9 GB
        t5_bf16=t5_params * bf16 / 1e9,             # ≈11.4 GB
        vae_bf16_est=vae_params_est * bf16 / 1e9,   # ≈1.4 GB
        full_resident_gb=(p["total"] + t5_params + vae_params_est) * bf16 / 1e9,  # ≈22.6 GB（全常驻场景）
        latent_bf16_mb=lat_t * CFG["in_dim"] * lat_h * lat_w * bf16 / 1e6,
        no_fa_scores_gb=tokens * tokens * heads * bf16 / 1e9,  # 不用 FA 需物化的分数矩阵 ≈35.7 GB
        note=("全常驻（≈22.6 GB，如 80GB 卡关 offload、T5 也在 GPU）加激活超出 24GB 卡。官方默认开关即解："
              "offload_model=True 的语义是【每段生成前后】各整体搬运 DiT 一次（循环前上卡、循环后下卡，实现直查），"
              "非逐 step 搬运；t5_cpu 把 T5 放 CPU（每段生成调用 2 次编码，频次低故代价小）；"
              "convert_model_dtype 即 fp32→bf16。24GB 默认路径 GPU 峰值 ≈ DiT 9.9 GB + 激活/latent"),
    )

    # ---------------- 与官方口径的闭合检验（参数化呈现，不冒充实测） ----------------
    # 模型卡："约 5 秒 720P 视频在单张消费级 GPU（RTX 4090）上不足 9 分钟"
    flops_4090_peak = 165e12          # 4090 bf16 dense 峰值（公开规格，正文标注）
    implied_min = total_dit / flops_4090_peak / 60
    mfu_if_9min = total_dit / (540 * flops_4090_peak)   # 若官方 9 分钟成立 → 反解有效利用率

    raw = dict(
        experiment="exp_ch14_video cost account (config-derived, no model run)",
        environment=dict(python=platform.python_version(), platform=platform.platform(),
                         note="纯账本推演，无 GPU/无 Wan 环境"),
        latent=dict(frames=F, latent=[CFG["in_dim"], lat_t, lat_h, lat_w],
                    patch=CFG["patch"], tokens=tokens,
                    formula="lat_t=(F-1)//4+1; lat_h=H//16; lat_w=W//16; tokens=lat_t×(lat_h/2)×(lat_w/2)"),
        params=dict(dit_formula=p, dit_from_fp32_storage=dit_from_fp32,
                    dit_closure="公式 4.93B 为简化下界（未含 bias/norm/modulation 等小项，合计 <0.5%）；fp32 存储 5.00B 为含全部小项口径——官方名 5B 落在两者之间，差 1.4%",
                    t5_from_bf16=t5_params, vae_est_fp32_assumed=vae_params_est),
        flops=dict(
            text_encode=t5_flops,
            dit=dict(linear=lin, self_attn_quad=self_quad, cross_attn=cross,
                     per_pass=per_pass, per_step_cfg2=per_step,
                     steps=CFG["sample_steps"], total=total_dit),
            vae_est=vae_flops_est,
            notes=("自注意力二次项与线性项同量级（27,280 token）；CFG 双前向；50 step;"
                   "FA 降低的是 IO 不是 FLOPs（第 6 章）；去噪循环占端到端 90%+ 为推演预期（T5/VAE/封装合计秒级），未测"),
            units="FLOPs（非 TFLOPs 字段为原始值）",
        ),
        memory=mem,
        output_stage=dict(raw_frames_bytes=raw_frames_bytes,
                          note="121 帧 RGB ≈325 MB 原始像素 → mp4 编码写盘（I/O 段，秒级）"),
        closure=dict(
            official_claim="模型卡：RTX 4090 单卡 5 秒 720P 不足 9 分钟（S32/S33）",
            peak_only_minutes=implied_min,
            mfu_threshold_pct=mfu_if_9min * 100,
            statement=(f"去噪循环合计 {total_dit/1e15:.1f} PFLOPs；按 4090 峰值 165 TF/s 需 "
                       f"{implied_min:.1f} 分钟（100% 利用率下界）。官方 <9 分钟 等价于 "
                       f"有效利用率高于 {mfu_if_9min*100:.1f}%（参数化推演，非实测；快于 9 分钟意味着更高利用率）"),
        ),
    )

    print(f"潜在: {CFG['in_dim']}×{lat_t}×{lat_h}×{lat_w} -> DiT tokens {tokens:,}")
    print(f"DiT 参数: 公式（下界）{p['total']/1e9:.2f}B，fp32 存储 {dit_from_fp32/1e9:.2f}B——'5B' 落在两者之间（差 1.4%）；"
          f"T5 enc {t5_params/1e9:.2f}B；VAE 估 {vae_params_est/1e9:.2f}B")
    print(f"每 pass: 线性 {lin/1e12:.0f}T + 自注意力二次 {self_quad/1e12:.0f}T + 跨注意力 {cross/1e12:.1f}T"
          f" = {per_pass/1e12:.0f} TFLOPs")
    print(f"每 step (CFG×2): {per_step/1e12:.0f}T × 50 step = {total_dit/1e15:.1f} PFLOPs；"
          f"T5 编码 {t5_flops/1e12:.1f}T（每段生成 2 次）")
    print(f"显存: DiT {mem['dit_bf16']:.1f}GB + T5 {mem['t5_bf16']:.1f}GB + VAE {mem['vae_bf16_est']:.1f}GB"
          f" 全常驻合计 {mem['full_resident_gb']:.1f}GB（24GB 卡默认走 offload/t5_cpu/bf16 路径）；"
          f"无 FA 的分数矩阵 {mem['no_fa_scores_gb']:.1f}GB")
    print(f"闭合: 峰值需 {implied_min:.1f} 分钟；官方 <9 分钟 等价于 有效利用率 >{mfu_if_9min*100:.1f}%")
    OUT.write_text(json.dumps(raw, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"OK: {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
