#!/usr/bin/env python3
"""第 14 章实验（可执行包，需 GPU/Wan2.2 环境；本机未测）：

Wan2.2-TI2V-5B 全链路生成 + 一项执行侧优化开关的 A/B 对照，固定采样参数与 seed；
逐阶段计时（文本编码 / 去噪前向 / VAE 解码 / 输出封装）并产出盲化对照材料。

固定参数（S33 官方默认；seed=0 为本实验固定值——官方默认 seed=-1 随机）：
  size=1280*704, frame_num=121, shift=5.0, solver=unipc, steps=50, guide_scale=5.0, seed=0

执行侧优化开关（不改变采样语义；bf16 与 fp32 在固定 seed 下输出有数值差异，
按任务质量盲化对照裁决，不做逐位比较）：
  --offload/--no-offload   整段生成前后 DiT 权重 CPU↔GPU 换入换出（官方 offload_model 语义：
                            循环前整体上卡、循环后整体下卡——每次生成各搬运一次，非逐 step）
  --dtype bf16|fp32        对应官方 convert_model_dtype

用法（官方仓库根目录或已就绪环境，需 ≥24GB VRAM GPU；batch=1，主线单卡路径）：
  python run_wan_generation.py --ckpt_dir ./Wan2.2-TI2V-5B --tag A --no-offload --append
  python run_wan_generation.py --ckpt_dir ./Wan2.2-TI2V-5B --tag B --offload --append
本机自检（不 import wan、不测推理）：
  python run_wan_generation.py --self-check

盲化对照规则（14 章验收，不引入 FVD）：
  1) 3–5 个固定 prompt（PROMPTS）；A/B 各生成一遍（同 seed 同采样参数，只差执行开关）；
  2) A/B 齐备后脚本把两版复制为 blind/X_*.mp4 与 blind/Y_*.mp4（随机映射，key 写 blind_key.json，
     评审前不可看）；并生成 scoring_template.csv（逐 prompt × 检查单字段）；
  3) 打分档位：每字段 0/1/2（0=缺失或错误，1=部分成立，2=明确成立）；黑帧=连续 ≥8 帧亮度均值 <5；
     首尾帧崩坏=首/末帧与中段主体明显不一致或不可辨；
  4) 失败条件（任一命中该配置判负）：整段或大段黑帧、首帧或尾帧崩坏、>30% 帧明显 artifact、
     主体与 prompt 无关；
  5) 汇总判读：逐 prompt 记 A/B 总分与失败条件触发；多数 prompt 分差 ≤2 视为"质量等价，比时间"，
     某版触发失败条件则该配置判负。
"""

from __future__ import annotations

import argparse
import json
import random
import shutil
import sys
import time
from pathlib import Path

OUT = Path(__file__).resolve().parent / "generation_raw.json"
BLIND_DIR = Path(__file__).resolve().parent / "blind"
BLIND_KEY = BLIND_DIR / "blind_key.json"

# 固定 prompt 集（官方示例风格；3 条起步，可按需加到 5）
PROMPTS = [
    "Two anthropomorphic cats in comfy boxing gear and bright gloves fight intensely on a spotlighted stage.",
    "A calm river flows through a spring meadow, camera slowly pans right, petals drifting in the breeze.",
    "A red sports car drives along a coastal highway at sunset, aerial view, waves crashing on the shore.",
]
CHECKLIST = ["主体出现", "动作与镜头方向", "风格一致性", "色彩与清晰度", "整体可用"]  # 各 0-2 分
FAIL_CONDITIONS = ["整段或大段黑帧", "首帧或尾帧崩坏", ">30% 帧明显 artifact", "主体与 prompt 无关"]

FIXED = dict(size=(1280, 704), frame_num=121, shift=5.0, solver="unipc",
             steps=50, guide_scale=5.0, seed=0, fps_out=24)   # S33 官方默认 + seed=0（实验固定值，官方默认 -1 随机）


def _sync(torch):
    if torch.cuda.is_available():
        torch.cuda.synchronize()


class CallTimer:
    """把计时包在调用路径外（不修改 wan 包源码）。

    三种挂接模式（--self-check 各验一例）：
      wrap_method(obj, "decode")   属性式调用 self.vae.decode(...)：实例属性即可拦截
      wrap_forward(obj)            调用式 self.model(...)：nn.Module 经 _call_impl 调 self.forward，
                                   实例 forward 可拦截
      wrap_class_call(obj)         调用式 self.text_encoder(...)：普通类在类上定义 __call__，
                                   须包类方法（T5EncoderModel 即此形态；每段生成调用 2 次——
                                   条件与无条件 prompt 各编码一次）
    """

    def __init__(self):
        self.calls = 0
        self.total_s = 0.0

    def _around(self, fn):
        timer = self

        def timed(*a, **k):
            t0 = time.perf_counter()
            r = fn(*a, **k)
            import torch
            _sync(torch)
            timer.total_s += time.perf_counter() - t0
            timer.calls += 1
            return r

        return timed

    def wrap_method(self, obj, name):
        setattr(obj, name, self._around(getattr(obj, name)))

    def wrap_forward(self, obj):
        self.wrap_method(obj, "forward")

    def wrap_class_call(self, obj):
        cls = type(obj)
        cls.__call__ = self._around(cls.__call__.__func__ if hasattr(cls.__call__, "__func__") else cls.__call__)


def self_check() -> int:
    import types

    # 模式 1：属性式方法
    t1 = CallTimer()
    fake = types.SimpleNamespace(decode=lambda x: x * 2)
    t1.wrap_method(fake, "decode")
    assert fake.decode(3) == 6 and t1.calls == 1

    # 模式 2：nn.Module 式 forward（调用式 __call__ 走 forward）
    import torch.nn as nn

    class Mod(nn.Module):
        def forward(self, x):  # noqa: D102
            return x + 1

    t2 = CallTimer()
    m = Mod()
    t2.wrap_forward(m)
    assert m(1) == 2 and t2.calls == 1, "nn.Module 调用式须经实例 forward 拦截"

    # 模式 3：普通类 __call__（T5EncoderModel 形态）
    class T5Like:
        def __call__(self, texts, device):  # noqa: D102
            return len(texts)

    t3 = CallTimer()
    enc = T5Like()
    t3.wrap_class_call(enc)
    assert enc(["a"], "cpu") == 1 and t3.calls == 1, "类 __call__ 须在类上包装"

    assert FIXED["frame_num"] == 4 * 30 + 1
    assert len(PROMPTS) >= 3 and len(CHECKLIST) == 5 and len(FAIL_CONDITIONS) == 4
    print("[self-check] 三种计时挂接/固定参数/盲化检查单结构通过（生成部分未测，需 GPU + Wan2.2 环境）")
    return 0


def make_blind(data: dict) -> None:
    """A/B 齐备时：复制为匿名 X/Y 视频 + 写 key + 生成打分模板。"""
    rng = random.Random(FIXED["seed"] + 1)
    a_is_x = rng.random() < 0.5
    BLIND_DIR.mkdir(exist_ok=True)
    rows = ["prompt_i,judge,field,score,comment"]
    for i in range(len(PROMPTS)):
        for tag, label in (("A", "X" if a_is_x else "Y"), ("B", "Y" if a_is_x else "X")):
            src = data[tag]["records"][i]["video"]
            dst = BLIND_DIR / f"{label}_p{i}.mp4"
            if Path(src).exists():
                shutil.copyfile(src, dst)
        for field in CHECKLIST + [";".join(FAIL_CONDITIONS)]:
            rows.append(f"{i},,<填>,{field if field in CHECKLIST else '失败条件:' + field},,")
    (BLIND_DIR / "scoring_template.csv").write_text("\n".join(rows), encoding="utf-8")
    BLIND_KEY.write_text(json.dumps(
        dict(a_is_x=a_is_x, note="X/Y 与 A/B 的映射；评审完成后方可查看"),
        ensure_ascii=False), encoding="utf-8")
    print(f"OK: {BLIND_DIR}（匿名 X/Y + 打分模板 + key）")


def run(args) -> int:
    import torch
    if args.wan_repo:
        sys.path.insert(0, str(Path(args.wan_repo).resolve()))
    import wan
    from wan.configs import SIZE_CONFIGS, WAN_CONFIGS

    wan_t2v = wan.WanTI2V(
        config=WAN_CONFIGS["ti2v-5B"], checkpoint_dir=args.ckpt_dir,
        device_id=0, rank=0, t5_cpu=args.t5_cpu,
        convert_model_dtype=(args.dtype == "bf16"),
    )

    t5_timer, dit_timer, vae_timer = CallTimer(), CallTimer(), CallTimer()
    t5_timer.wrap_class_call(wan_t2v.text_encoder)   # 每段生成 2 次调用（条件 + 无条件）
    dit_timer.wrap_forward(wan_t2v.model)            # 每次去噪前向（CFG 双前向 → 约 2×steps 次）
    vae_timer.wrap_method(wan_t2v.vae, "decode")     # VAE 解码（一次）

    from wan.utils.utils import save_video

    records = []
    t_all = time.perf_counter()
    for i, prompt in enumerate(PROMPTS):
        t0 = time.perf_counter()
        video = wan_t2v.generate(
            input_prompt=prompt, size=SIZE_CONFIGS["1280*704"],
            frame_num=FIXED["frame_num"], shift=FIXED["shift"],
            sample_solver=FIXED["solver"], sampling_steps=FIXED["steps"],
            guide_scale=FIXED["guide_scale"], seed=FIXED["seed"],
            offload_model=args.offload)
        _sync(torch)
        gen_s = time.perf_counter() - t0
        out_mp4 = Path(args.out_dir).resolve() / f"{args.tag}_p{i}.mp4"
        out_mp4.parent.mkdir(parents=True, exist_ok=True)
        t1 = time.perf_counter()
        save_video(tensor=video[None], save_file=str(out_mp4), fps=FIXED["fps_out"])
        save_s = time.perf_counter() - t1
        if not out_mp4.exists() or out_mp4.stat().st_size == 0:
            print(f"FAIL: {out_mp4} 未生成或为空（save_video 可能吞异常，见官方 utils）")
            return 3
        frames = int(video.shape[1]) if video.ndim >= 3 else None   # (C, N, H, W)
        records.append(dict(prompt_i=i, prompt=prompt, gen_s=round(gen_s, 2),
                            save_s=round(save_s, 2), video=str(out_mp4), frames=frames))
        print(f"[{args.tag}] p{i}: 生成 {gen_s:.1f}s + 封装 {save_s:.1f}s ({frames} 帧) -> {out_mp4.name}")

    total_s = time.perf_counter() - t_all
    summary = dict(
        tag=args.tag, offload=args.offload, dtype=args.dtype, t5_cpu=args.t5_cpu,
        convert_model_dtype=(args.dtype == "bf16"), batch=1,
        fixed=FIXED, prompts=len(PROMPTS), total_s=round(total_s, 2),
        stages=dict(t5_encode_s=round(t5_timer.total_s, 2), t5_encode_calls=t5_timer.calls,
                    dit_forward_calls=dit_timer.calls,
                    dit_total_s=round(dit_timer.total_s, 2),
                    dit_per_call_s=round(dit_timer.total_s / max(1, dit_timer.calls), 3),
                    vae_decode_s=round(vae_timer.total_s, 2)),
        output_stage_s=round(sum(r["save_s"] for r in records), 2),
        records=records,
        blind_rules=dict(checklist=CHECKLIST, fail_conditions=FAIL_CONDITIONS,
                         scoring="每字段 0/1/2；黑帧=连续≥8 帧亮度均值<5；首尾帧崩坏=首/末帧主体不可辨;"
                                 "多数 prompt 分差≤2 视为质量等价比时间，触发失败条件判负"),
    )
    mode = "a" if args.append and OUT.exists() else "w"
    data = json.loads(OUT.read_text(encoding="utf-8")) if (mode == "a" and OUT.exists()) else {}
    data[args.tag] = summary
    OUT.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    if "A" in data and "B" in data:
        make_blind(data)
    print(f"OK: {OUT}")
    return 0


def _utf8_stdout():
    """Windows 默认 GBK 控制台下非 GBK 字符无法编码——统一按 UTF-8 输出（幂等，静默失败安全）。"""
    import sys as _s
    for _st in (_s.stdout, _s.stderr):
        try:
            _st.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


def main() -> int:
    _utf8_stdout()
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt_dir", default="./Wan2.2-TI2V-5B")
    ap.add_argument("--wan_repo", default=None, help="官方仓库根目录（未 pip 安装时）")
    ap.add_argument("--out_dir", default="./ch14_outputs")
    ap.add_argument("--tag", default="A", help="A/B 对照标签；A/B 齐备时自动产盲化材料")
    ap.add_argument("--offload", dest="offload", action="store_true", default=True)
    ap.add_argument("--no-offload", dest="offload", action="store_false")
    ap.add_argument("--dtype", choices=["bf16", "fp32"], default="bf16")
    ap.add_argument("--t5_cpu", action="store_true", default=True)
    ap.add_argument("--append", action="store_true", help="多配置写入同一 raw 文件")
    ap.add_argument("--self-check", action="store_true")
    args = ap.parse_args()
    if args.self_check:
        return self_check()
    return run(args)


if __name__ == "__main__":
    sys.exit(main())
