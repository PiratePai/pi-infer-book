# exp_ch14_video · 第 14 章 DiT 与视频生成：成本账与执行侧优化对照

## 组成

| 文件 | 内容 | 本机状态 |
|---|---|---|
| `run_cost_account.py` | 一次生成的四阶段成本账（潜在/token 公式、DiT 参数公式 vs 存储双口径闭合、FLOPs 线性+二次分开、显存账与三工程开关、与官方"9 分钟"口径的参数化闭合） | **已跑（config 直查推演，含双算断言）** |
| `run_wan_generation.py` | 全链路生成 + 执行侧优化 A/B（offload 开关、bf16/fp32）+ 逐阶段计时（T5×2 次调用/去噪前向/VAE/封装）+ 盲化材料（匿名 X/Y + 打分模板 + key） | **未测**（`--self-check` 已验证三种计时挂接/固定参数/盲化结构） |
| `raw.json` | 成本账产物 | 已跑产物 |

## 运行

```bash
# 本机可跑（秒级）
python experiments/exp_ch14_video/run_cost_account.py
python experiments/exp_ch14_video/run_wan_generation.py --self-check

# GPU 环境（未测项复现；官方仓库环境 + ≥24GB VRAM）
git clone https://github.com/Wan-Video/Wan2.2 && cd Wan2.2
pip install -r requirements.txt
huggingface-cli download Wan-AI/Wan2.2-TI2V-5B --local-dir ./Wan2.2-TI2V-5B
python /path/to/pi-infer-labs/experiments/exp_ch14_video/run_wan_generation.py --wan_repo . --ckpt_dir ./Wan2.2-TI2V-5B --tag A --no-offload --dtype bf16 --append   # 在 Wan2.2 仓库根目录执行；脚本用绝对路径指向本书仓库
python /path/to/pi-infer-labs/experiments/exp_ch14_video/run_wan_generation.py --wan_repo . --ckpt_dir ./Wan2.2-TI2V-5B --tag B --offload --dtype bf16 --append
```

## 复现条件与预期输出（未测项）

- **环境**：Linux/CUDA ≥24GB VRAM（RTX 4090 级），官方 Wan2.2 仓库依赖（torch、flash-attn 等；以官方主线 README 的安装步骤为准），权重约 34GB（DiT 20GB fp32 + T5 11.4GB bf16 + VAE 2.8GB）；batch=1 单卡主线；
- **预期输出**：每 prompt 一行 `[Tag] pN: 生成 X.Xs + 封装 X.Xs (121 帧)`；`generation_raw.json` 含 `stages`（t5_encode_s×2 次调用 / dit_forward_calls≈100 / dit_total_s / vae_decode_s）与逐条记录（含 mp4 路径与帧数）；A/B 齐备后自动产出 `blind/`（匿名 X/Y 视频 + scoring_template.csv + blind_key.json）；
- **量级预期**（由成本账推演，供核对）：去噪循环占总时间 90%+（推演）；每前向 ≈549 TFLOPs（27,280 token）；A（no-offload，需显存装得下）预期快于 B（offload 每段生成前后各整体搬运 9.9GB×2，约 1.2s/段）；T5 每段生成编码 2 次（t5_cpu 下在 CPU，秒级）；VAE 解码秒级；
- **盲化对照**：打分档位 0/1/2（0=缺失或错误，1=部分成立，2=明确成立）；黑帧=连续 ≥8 帧亮度均值<5；首尾帧崩坏=首/末帧主体不可辨；四条失败条件任一命中该配置判负；多数 prompt 分差 ≤2 视为质量等价比时间——不引入 FVD（D10 口径）。评分用 scoring_template.csv 逐条填写。

## 口径注意

- 固定采样参数 = 官方默认 + seed 0（实验固定值，官方默认 -1 随机）；改这些是"改变采样设置"（14.3 边界），须另行声明，不作执行侧优化。
- bf16 与 fp32 在固定 seed 下输出有数值差异——执行侧对照按任务质量盲化裁决，不做逐位比较。
- 成本账全部数字为 config 直查推演（S32/S33），DiT 公式为简化下界（与 fp32 存储口径差 1.4%），VAE 参数按 fp32 假设估（dtype 未直查，已标注）；无任何本机生成实测。
