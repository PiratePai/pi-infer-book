#!/usr/bin/env python3
"""第 8 章：CUDA Graph 捕获/重放的"代码就绪"封装（按 PyTorch 官方约束实现）。

本机无 NVIDIA GPU：本模块在 CUDA 可用时走真实捕获/重放；CPU 上显式拒绝
捕获并给出可观测的状态（graph_status=unavailable），绝不伪造"图已测"。
正文据此按官方文档（references S26）核对约束清单；设备行为标"未测"（5.3）。

复跑：随 run_exec_experiment.py 一起调用；亦可单独
python experiments/exp_ch8_exec/cuda_graph_ready.py --self-check
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from typing import Any, Callable

import torch


@dataclass
class GraphRunnerStatus:
    """捕获/回退的可观测状态；never_ok=False 时 graphed 为真。"""

    graphed: bool = False
    reason: str = "未捕获"
    captures: int = 0
    replays: int = 0
    eager_fallbacks: int = 0
    static_buffer_bytes: int = 0
    recaptures_shape_change: int = 0


class CudaGraphRunner:
    """按官方工作流封装：side-stream 预热 → 捕获 → 静态输入喂入 → replay。

    约束（S26，违反会在 CUDA 上报错，本模块提前校验能校验的部分）：
    - 捕获须在非默认流：torch.cuda.graph 上下文自动切 side stream；
    - 预热在 side stream 上执行（_warmup_on_side_stream）；
    - 动态 shape 禁止：每次调用比对输入 shape/dtype/device，变化则
      显式重捕获（recapture），不静默出错；
    - 每次重放读写同一静态缓冲：输入经 static_input.copy_(x) 喂入，
      输出从 static_output 读出（拷贝返回，避免外部持有图内缓冲）；
    - 额外内存 = 静态输入/输出缓冲字节数（本模块记账；GPU 私有内存池
      行为按文档登记，本机未测）。
    CPU 上：capture() 抛 RuntimeError（信息中说明原因），call() 走 eager
    回退并计数——回退路径显式可观测，不冒充图执行。
    """

    def __init__(self, fn: Callable[..., torch.Tensor], example_input: torch.Tensor) -> None:
        if not callable(fn):
            raise TypeError("fn 必须可调用")
        if not isinstance(example_input, torch.Tensor):
            raise TypeError("example_input 必须是 torch.Tensor")
        self.fn = fn
        self._signature = (tuple(example_input.shape), example_input.dtype, str(example_input.device))
        self.status = GraphRunnerStatus()
        self._graph: torch.cuda.CUDAGraph | None = None
        self._static_input: torch.Tensor | None = None
        self._static_output: torch.Tensor | None = None
        if torch.cuda.is_available() and example_input.is_cuda:
            self._capture(example_input)

    # -- 捕获与重放 ---------------------------------------------------

    def _warmup_on_side_stream(self, example_input: torch.Tensor, iterations: int = 3) -> None:
        """官方要求：捕获前在 side stream 预热（线程池/惰性初始化进预热）。"""
        stream = torch.cuda.Stream(device=example_input.device)
        stream.wait_stream(torch.cuda.current_stream(example_input.device))
        with torch.cuda.stream(stream):
            for _ in range(iterations):
                self.fn(example_input)
        torch.cuda.synchronize(example_input.device)

    def _capture(self, example_input: torch.Tensor) -> None:
        """真实捕获路径；仅 CUDA 输入可达。"""
        if not (torch.cuda.is_available() and example_input.is_cuda):
            raise RuntimeError(
                "CUDA Graph 捕获需要 CUDA 张量与可用 CUDA 设备；本机无 NVIDIA GPU（5.3：设备行为未测）")
        self._warmup_on_side_stream(example_input)
        static_input = example_input.clone()
        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            static_output = self.fn(static_input)
        buffer_bytes = static_buffer_account([static_input, static_output])
        # 捕获及输出校验全部成功后提交，异常时保留原图、缓冲与签名。
        self._graph, self._static_input, self._static_output = graph, static_input, static_output
        self._signature = (tuple(example_input.shape), example_input.dtype, str(example_input.device))
        self.status.graphed = True
        self.status.reason = "已捕获"
        self.status.captures += 1
        self.status.static_buffer_bytes = buffer_bytes

    def call(self, x: torch.Tensor) -> torch.Tensor:
        """shape/dtype/device 与捕获签名一致则 replay，变化则显式重捕获。"""
        signature = (tuple(x.shape), x.dtype, str(x.device))
        if signature != self._signature:
            if not (torch.cuda.is_available() and x.is_cuda):
                raise ValueError(
                    f"输入签名变化 {self._signature} → {signature}，且当前设备不可捕获；"
                    "CPU 路径请保持输入签名一致")
            self._capture(x)
            self.status.recaptures_shape_change += 1
        if self._graph is None:  # CPU：显式 eager 回退（可观测，不冒充图）
            self.status.eager_fallbacks += 1
            return self.fn(x)
        self._static_input.copy_(x)  # 喂新数据：重放读写同一地址
        self._graph.replay()
        self.status.replays += 1
        return self._static_output.clone()


def _utf8_stdout():
    """Windows 默认 GBK 控制台下 ✓/✗ 无法编码——统一按 UTF-8 输出（幂等，无 reconfigure 环境静默跳过）。"""
    import sys as _s
    for _st in (_s.stdout, _s.stderr):
        try:
            _st.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


def static_buffer_account(tensors: list[torch.Tensor]) -> int:
    """静态输入/输出缓冲的额外内存记账（字节）；GPU 图私有池另计、本机未测。"""
    return sum(t.numel() * t.element_size() for t in tensors)


def _self_check() -> int:
    """CPU 自检：签名校验/回退计数/重捕获拒绝路径；捕获本身标不可用。"""
    weight = torch.eye(16)
    fn = lambda x: torch.nn.functional.linear(x, weight)  # noqa: E731
    runner = CudaGraphRunner(fn, torch.zeros(4, 16))
    assert not runner.status.graphed and "未捕获" in runner.status.reason
    out = runner.call(torch.ones(4, 16))
    assert torch.allclose(out, torch.ones(4, 16))
    assert runner.status.eager_fallbacks == 1 and runner.status.replays == 0
    try:
        runner.call(torch.ones(8, 16))  # 动态 shape：CPU 不可重捕获 → 显式报错
    except ValueError:
        print("动态 shape 变化被显式拒绝 ✓")
    else:
        raise AssertionError("shape 变化应报错")
    print(f"自检通过：graphed={runner.status.graphed}（本机无 CUDA，捕获未测），"
          f"回退 {runner.status.eager_fallbacks} 次，静态缓冲记账函数可用")
    return 0


if __name__ == "__main__":
    _utf8_stdout()
    import sys
    sys.exit(_self_check())
