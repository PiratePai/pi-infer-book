# exp_ch8 执行优化（融合/CUDA Graph/传输与同步）· 实验记录

复跑基准：段末评审修复后复跑（评审 P1/P2 修复含计时改成对交错，数字以本次 raw.json 为准；正文同步引用本次值）；环境：Python 3.12.10 / torch 2.15.0+cpu / Windows CPU（无 NVIDIA GPU，torch.cuda.is_available()=False）。

| 项 | 结果 | 判据 |
|---|---|---|
| X1 trace 证据 | 元数据/分发类算子 self 时间占比 3.3–4.3%（top-8 表存档 x1_profiler_top8.txt） | 优化对象由 trace 指向，先采后改 |
| X2 每算子提交开销 | ≈2.13 µs（1000 算子链 vs 塌缩单算子；双方预热 + 成对交错 7 轮） | 差值/N 的稳定量级 |
| X3 融合代理 | out-of-place 0.091 ms vs in-place 0.080 ms（成对交错，in-place 快 ≈12%）；中间字节 45,056→22,528 B；torch.equal 逐位一致；torch.compile 环境不可用（InvalidCxxCompiler: cl 未找到；与探测代码错误已区分） | 数值一致 + 字节账 2:1；CPU 时间无收益如实记录 |
| X4 CUDA Graph | graphed=False（本机无 CUDA）；CPU 自检（守卫/回退计数/动态 shape 显式拒绝/完整设备签名/静态缓冲记账 512 B）通过 | 代码就绪交付；设备行为未测 |
| X5 传输与同步 | 计算生产者 1.14×（收益有限，线程池竞争）；I/O 生产者 1.33×（重叠成立） | 一正一负两组对照，机制归因 |

- 生成口径：不适用（纯算子实验，无生成任务；显式标注）。
- 固定输入：X3 固定种子 0 的 gate/up/down（d=64, d_ff=176）与 x[32,64]；X2 `torch.zeros(64)`；X5 固定 24/8 批与 512×512 负载。
- baseline/candidate：X2 链 vs 塌缩；X3 out-of-place vs in-place（+融合理想界 0 B 为账面参照）；X5 串行交接 vs 深度 2/4 预取。
- 内存数据：中间物化字节按 numel×4 实算；X4 静态缓冲 512 B 为记账函数输出；GPU 私有池未测。
- 复跑：`python experiments/exp_ch8_exec/cuda_graph_ready.py --self-check`；`python experiments/exp_ch8_exec/run_exec_experiment.py`（产物 raw.json、x1_profiler_top8.txt）。
- 降级说明：CUDA Graph 真实捕获/重放、H2D/pin_memory/non_blocking、torch.compile 内核、GPU 私有内存池均未测（5.3）；X2/X3/X5 同机相对对照，只支撑机制与量级结论（数字随机器状态小幅波动，复跑以 raw.json 为准）。
