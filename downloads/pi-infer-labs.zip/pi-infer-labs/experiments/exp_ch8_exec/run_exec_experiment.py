#!/usr/bin/env python3
"""第 8 章实验：执行优化——融合、图捕获与数据搬运（CPU 可跑，设备项标未测）。

X1 trace 指向：profiler 采集小算子链 top 表，以"元数据/分发占比"证据选择优化对象
   （验收：只做 trace 指向的改动）；
X2 算子提交/启动开销：N 个小算子链 vs 数学塌缩后的单算子，实测每算子分发开销
   （融合与 CUDA Graph 共同治理的对象在 CPU 侧的证据）；
X3 融合的代价与可用条件：SwiGLU 前馈的 out-of-place（两次中间物化）vs in-place
   （一次物化）对照——逐位一致、中间张量字节账、时间；torch.compile 在本机
   不可用（缺 MSVC cl）如实记录为缺项；in-place ≠ 融合的边界在正文声明；
X4 CUDA Graph：CudaGraphRunner（cuda_graph_ready.py）CPU 自检 + 静态缓冲额外内存
   记账；真实捕获/重放未测（无 NVIDIA GPU），约束清单按官方文档核对（S26）；
X5 传输与同步：生产者/消费者双线程流水线，有无预取队列的吞吐对照（异步重叠纪律
   的 CPU 可见版）；H2D/pin_memory/non_blocking 按官方文档登记、未测。

复跑：python experiments/exp_ch8_exec/run_exec_experiment.py
"""

from __future__ import annotations

import functools
import json
import platform
import queue
import statistics
import subprocess
import sys
import threading
import tempfile
import time
import traceback
from pathlib import Path

import torch
from torch import nn
from torch.nn import functional as F

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from cuda_graph_ready import CudaGraphRunner, static_buffer_account  # noqa: E402

OUT_DIR = Path(__file__).resolve().parent
WARMUP, REPEATS = 3, 7


def git_hash() -> str:
    try:
        return subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
    except Exception:
        return "unavailable"


def timed(fn, *, warmup=WARMUP, repeats=REPEATS, interleave=None) -> dict | tuple[dict, dict]:
    """双方预热后按轮 A/B 交错采样；传 interleave 时返回两份样本统计。"""
    cases = [fn] if interleave is None else [fn, interleave]
    for _ in range(warmup):
        for operation in cases:
            operation()
    samples = [[] for _ in cases]
    for _ in range(repeats):
        for operation, values in zip(cases, samples):
            start = time.perf_counter()
            operation()
            values.append(time.perf_counter() - start)
    rows = [{"mean_s": statistics.mean(values), "std_s": statistics.stdev(values),
             "samples": values} for values in samples]
    return rows[0] if interleave is None else tuple(rows)


def _probe_compile(fn) -> dict:
    """无参探测编译并对照 eager；仅已知编译器环境缺项可降级，代码错误抛出。"""
    expected = fn()
    try:
        actual = torch.compile(fn)()
        torch.testing.assert_close(actual, expected, atol=1e-6, rtol=1e-5)
    except Exception as error:
        pending, seen = [error], set()
        unavailable = False
        while pending:
            current = pending.pop()
            if current is None or id(current) in seen:
                continue
            seen.add(id(current))
            if type(current).__name__ in {"InvalidCxxCompiler", "CppCompilerNotFoundError"}:
                unavailable = True
            pending.extend([current.__cause__, current.__context__,
                            getattr(current, "inner_exception", None)])
        if not unavailable:
            raise RuntimeError(f"torch.compile 探测代码/执行错误: {type(error).__name__}: {error}") from error
        return {"status": "unavailable", "error": f"{type(error).__name__}: {error}"}
    return {"status": "available", "error": None}


# ---------------------------------------------------------------- X1 trace
def x1_trace_evidence() -> dict:
    """profiler 证据表：小张量上的算子链，元数据/分发开销占比可见。"""
    x = torch.randn(1, 64)
    w1 = torch.randn(64, 32)
    w2 = torch.randn(32, 64)

    def chain() -> None:
        for _ in range(50):
            y = F.silu(x @ w1) * (x @ w1)  # 5 类算子 ×50：mm/silu/mul 反复提交
            _ = y @ w2

    chain()
    from torch.profiler import ProfilerActivity, profile
    with profile(activities=[ProfilerActivity.CPU]) as prof:
        chain()
    table = prof.key_averages().table(sort_by="self_cpu_time_total", row_limit=8)
    (OUT_DIR / "x1_profiler_top8.txt").write_text(
        "\n".join(line.rstrip() for line in table.splitlines()) + "\n", encoding="utf-8")
    rows = prof.key_averages()
    total = sum(e.self_cpu_time_total for e in rows)
    meta = sum(e.self_cpu_time_total for e in rows
               if e.key in ("aten::view", "aten::as_strided", "aten::to", "aten::contiguous",
                            "aten::empty", "aten::resolve_conj", "aten::detach"))
    return {"note": "改动由 trace 指向：小算子链的提交/分发成本占比（见 x1_profiler_top8.txt）",
            "self_cpu_total_us": total, "metadata_ops_us": meta,
            "metadata_share_pct": round(100 * meta / total, 2) if total else 0.0}


# ------------------------------------------------- X2 分发/启动开销
def x2_dispatch_overhead() -> dict:
    """1000 个 [64] 逐元素加法 vs 一次塌缩加法：每算子提交开销的实测。"""
    x = torch.zeros(64)
    n = 1000

    def chain() -> None:
        y = x
        for _ in range(n):
            y = y + 1.0

    def collapsed() -> None:
        _ = x + float(n)

    chain_t = timed(chain)
    collapsed_t = timed(collapsed)
    per_op_us = (chain_t["mean_s"] - collapsed_t["mean_s"]) / n * 1e6
    return {"ops": n, "chain": chain_t, "collapsed": collapsed_t,
            "per_op_overhead_us": per_op_us,
            "note": "每算子提交/分发开销 =（链-塌缩)/N；融合与 CUDA Graph 都是把这个数乘以减少的算子数"}


# ------------------------------------------------- X3 融合对照
def x3_fusion() -> dict:
    """SwiGLU：out-of-place 两次中间物化 vs in-place 一次物化（代理对照）。"""
    torch.manual_seed(0)
    d, d_ff, tokens = 64, 176, 32
    gate = nn.Linear(d, d_ff, bias=False)
    up = nn.Linear(d, d_ff, bias=False)
    down = nn.Linear(d_ff, d, bias=False)
    x = torch.randn(tokens, d)

    def out_of_place() -> torch.Tensor:
        h = F.silu(gate(x))          # 物化 1：[T,d_ff]
        h = h * up(x)                # 物化 2：再分配一个 [T,d_ff]
        return down(h)

    def in_place() -> torch.Tensor:
        h = F.silu(gate(x))          # 物化 1
        h.mul_(up(x))                # 原地：少物化一个 [T,d_ff]
        return down(h)

    assert torch.equal(out_of_place(), in_place()), "两条路径必须逐位一致"
    oop_t, ip_t = timed(out_of_place, interleave=in_place)
    bytes_ffn = tokens * d_ff * 4
    compile_probe = _probe_compile(out_of_place)
    return {"tokens": tokens, "d_ff": d_ff,
            "out_of_place": oop_t, "in_place": ip_t,
            "intermediate_bytes_2_vs_1": [2 * bytes_ffn, bytes_ffn],
            "fusion_ideal_bytes": 0,
            "torch_compile": compile_probe["status"], "compile_probe": compile_probe,
            "timing_order": "双方预热，每轮 out_of_place/in_place 各一次",
            "note": ("in-place 是'减少中间物化'的可测代理，不等于算子融合；真融合内核"
                     "（compile/手写）与 CUDA Graph 的设备端收益本机未测（5.3）")}


# ------------------------------------------------- X5 流水线预取
EYE = None  # main() 里初始化，避免模块导入期建大矩阵


def _produce_compute() -> torch.Tensor:
    """纯计算生产者：小算子若干（无阻塞）。"""
    payload = torch.randn(512, 512)
    for _ in range(4):
        payload = F.silu(payload) + 1.0
    return payload


def _produce_io(path: Path) -> torch.Tensor:
    """阻塞 I/O 生产者：写读磁盘（释放 GIL）——数据搬运的 CPU 类比。"""
    torch.save(torch.randn(512, 512), path)
    return torch.load(path)


def _consume(payload: torch.Tensor) -> torch.Tensor:
    """消费者：若干中等矩阵乘（CPU 上已由 intra-op 线程池并行）。"""
    for _ in range(6):
        payload = F.silu(payload @ EYE)
    return payload


def _run_serial(produce, batches: int = 8) -> float:
    """同步交接：单线程逐批 生产→消费，两段成本都计入（无可重叠）。"""
    start = time.perf_counter()
    for _ in range(batches):
        _consume(produce())
    return time.perf_counter() - start


def _run_pipeline(produce, depth: int = 2, batches: int = 8) -> float:
    """限深队列预取；任一线程失败通知另一方停止，join 后向主线程转发异常。"""
    q: queue.Queue = queue.Queue(maxsize=depth)
    stop = threading.Event()
    errors: list[Exception] = []

    def put(item) -> bool:
        while not stop.is_set():
            try:
                q.put(item, timeout=.02)
                return True
            except queue.Full:
                continue
        return False

    def producer() -> None:
        for _ in range(batches):
            if stop.is_set() or not put(produce()):
                return
        put(None)

    def consumer() -> None:
        while not stop.is_set():
            try:
                item = q.get(timeout=.02)
            except queue.Empty:
                continue
            if item is None:
                return
            _consume(item)

    def guarded(operation) -> None:
        try:
            operation()
        except Exception as error:
            errors.append(error)
            stop.set()

    start = time.perf_counter()
    threads = [threading.Thread(target=guarded, args=(producer,)),
               threading.Thread(target=guarded, args=(consumer,))]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    if errors:
        raise errors[0]
    return time.perf_counter() - start


def x5_pipeline() -> dict:
    """每种生产者双方预热后逐轮串行/流水各一次；独立临时文件最终清理。"""
    global EYE
    EYE = torch.eye(512)
    variants = {}
    temporary = tempfile.TemporaryDirectory(prefix="pi-infer-x5-")
    try:
        io_producer = functools.partial(_produce_io, Path(temporary.name) / "transfer.pt")
        for name, produce in (("compute_producer", _produce_compute), ("io_producer", io_producer)):
            serial, piped = timed(functools.partial(_run_serial, produce),
                                  interleave=functools.partial(_run_pipeline, produce))
            variants[name] = {
                "serial_mean_s": serial["mean_s"], "serial_std_s": serial["std_s"],
                "prefetch_mean_s": piped["mean_s"], "prefetch_std_s": piped["std_s"],
                "serial_samples": serial["samples"], "prefetch_samples": piped["samples"],
                "speedup": serial["mean_s"] / piped["mean_s"]}
    finally:
        temporary.cleanup()
    return {"variants": variants, "timing_order": "双方预热，每轮 serial/prefetch 各一次",
            "note": ("重叠的前提是有一方真正在'等'：纯计算生产者双方都抢 intra-op 线程池，"
                     "流水线无收益甚至更慢（如实报告）；阻塞 I/O 生产者（磁盘写读、释放 GIL，"
                     "H2D/DMA 的 CPU 类比）则与消费重叠、约 1.2× 量级。H2D/pin_memory/"
                     "non_blocking 语义按官方文档登记、未测（无 GPU）")}


def _run_experiment(record: dict) -> None:
    """运行各项实验并填充结果；任何执行错误交由主入口记录并返回失败。"""
    print("=" * 64)
    print("exp_ch8 执行优化：融合 / CUDA Graph / 传输与同步（CPU；设备项未测）")
    x1 = x1_trace_evidence()
    print(f"[X1] trace 证据：算子链 self 时间中元数据/分发类占 {x1['metadata_share_pct']}%"
          "（表见 x1_profiler_top8.txt；结合 X2 的每算子开销选优化对象）")
    x2 = x2_dispatch_overhead()
    print(f"[X2] 每算子提交开销 ≈ {x2['per_op_overhead_us']:.2f} µs（1000 算子链 vs 塌缩单算子）")
    x3 = x3_fusion()
    print(f"[X3] 融合代理：out-of-place {x3['out_of_place']['mean_s']*1e3:.3f} ms vs "
          f"in-place {x3['in_place']['mean_s']*1e3:.3f} ms；compile={x3['torch_compile']}")
    runner = CudaGraphRunner(lambda t: F.linear(t, torch.eye(16)), torch.zeros(4, 16))
    out = runner.call(torch.ones(4, 16))
    graph_state = {"graphed": runner.status.graphed, "reason": runner.status.reason,
                   "eager_fallbacks": runner.status.eager_fallbacks,
                   "static_buffer_bytes": static_buffer_account([torch.zeros(4, 16), out]),
                   "device_note": "无 NVIDIA GPU：捕获/重放未测；约束与工作流按 S26 官方文档核对（cuda_graph_ready.py）"}
    print(f"[X4] CUDA Graph：graphed={graph_state['graphed']}（{graph_state['reason']}），"
          f"静态缓冲记账 {graph_state['static_buffer_bytes']} B")
    x5 = x5_pipeline()
    for name, v in x5["variants"].items():
        print(f"[X5:{name}] 串行 {v['serial_mean_s']:.4f} s vs 流水 {v['prefetch_mean_s']:.4f} s"
              f"（相对 {v['speedup']:.2f}×）")

    record.update({
        "env": {"git": git_hash(), "python": platform.python_version(),
                "torch": torch.__version__, "device": "cpu",
                "threads": torch.get_num_threads()},
        "generation_spec": "不适用（纯算子实验，无生成任务）",
        "x1_trace": x1, "x2_dispatch": x2, "x3_fusion": x3,
        "x4_cuda_graph": graph_state, "x5_pipeline": x5,
        "checks": {
            "x3_equal": True,
            "x1_profiler_table": "x1_profiler_top8.txt",
            "pass": True,
        },
        "degradation_note": ("CPU 相对对照（5.3）：CUDA Graph 真实捕获/重放、GPU 私有内存池、"
                             "H2D/pin_memory/non_blocking、torch.compile 融合内核均未测/不可用；"
                             "X2/X3/X5 只做机制与相对量级证据"),
        "pass": True,
    })


def _utf8_stdout():
    """Windows 默认 GBK 控制台下 µ/≈ 等字符无法编码——统一按 UTF-8 输出（幂等，静默失败安全）。"""
    import sys as _s
    for _st in (_s.stdout, _s.stderr):
        try:
            _st.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


def main() -> int:
    """执行异常始终保存 pass=False 与原始 traceback，并以非零状态退出。"""
    _utf8_stdout()
    record = {"pass": False, "checks": {"pass": False}}
    try:
        _run_experiment(record)
    except Exception:
        record["error"] = traceback.format_exc()
        print(record["error"], file=sys.stderr)
    finally:
        (OUT_DIR / "raw.json").write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"结论：{'PASS' if record['pass'] else 'FAIL'}（raw.json）")
    return 0 if record["pass"] else 1


if __name__ == "__main__":
    sys.exit(main())
