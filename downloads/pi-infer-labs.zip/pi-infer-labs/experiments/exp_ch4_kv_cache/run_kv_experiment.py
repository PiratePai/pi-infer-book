#!/usr/bin/env python3
"""第 4 章样章实验：KV 块分配器与前缀复用——正确性、行为与容量账。

E1 四组合逐 token 一致性（无缓存/连续缓存/分页缓存/前缀复用）
E2 分配器行为时间线：命中/未命中/尾块、取消/失败回收、重复释放、共享引用计数
E3 token 容量 vs 实际张量字节
E4 前缀复用的收益边界（不同命中长度下 prefill 计算量对照——解释"命中快"≠"全部负载快"）

复跑：python experiments/exp_ch4_kv_cache/run_kv_experiment.py
"""

from __future__ import annotations

import json
import platform
import subprocess
import sys
import time
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from pi_infer import build_tiny_model, greedy_decode  # noqa: E402
from pi_infer.model import SimpleKVCache, TinyTransformer  # noqa: E402
from pi_infer.kv import BlockAllocator, CapacityError, DoubleFreeError, PagedKVCache  # noqa: E402

OUT_DIR = Path(__file__).resolve().parent
BLOCK_SIZE = 4
PROMPT = [1, 11, 21, 31, 41, 51]
SUFFIX = [61, 71]
NEW_TOKENS = 6
N_BLOCKS = 32


def _utf8_stdout():
    """Windows 默认 GBK 控制台下 ✓/✗ 无法编码——统一按 UTF-8 输出（幂等，无 reconfigure 环境静默跳过）。"""
    import sys as _s
    for _st in (_s.stdout, _s.stderr):
        try:
            _st.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


def git_hash() -> str:
    try:
        return subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
    except Exception:
        return "unavailable"


def make_pool(model: TinyTransformer) -> PagedKVCache:
    return PagedKVCache(
        num_blocks=N_BLOCKS,
        block_shape=(model.config.n_kv_heads, BLOCK_SIZE, model.config.d_model // model.config.n_heads),
        n_layers=model.config.n_layers,
    )


def prefill(model: TinyTransformer, req, token_ids: list[int]) -> None:
    with torch.no_grad():
        model(torch.tensor([token_ids]), start_pos=req.num_matched, kv_cache=req)


def main() -> None:
    _utf8_stdout()
    model = build_tiny_model(seed=0)
    record: dict = {"env": {
        "git": git_hash(), "python": platform.python_version(),
        "torch": torch.__version__, "device": "cpu",
        "block_size": BLOCK_SIZE, "num_blocks": N_BLOCKS,
        "prompt": PROMPT, "suffix": SUFFIX, "new_tokens": NEW_TOKENS,
        "generation_spec": {"decode": "greedy", "stop": "max_new_tokens=6"},
    }}
    print("=" * 64)
    print("exp_ch4 KV 块分配器与前缀复用")
    results: dict[str, bool] = {}

    # ---- E1 四组合一致性 ----
    print("\n[E1] 四组合逐 token 一致性")
    full_prompt = PROMPT + SUFFIX
    baseline = greedy_decode(model, full_prompt, NEW_TOKENS)                      # 组合1 无缓存
    simple = greedy_decode(model, full_prompt, NEW_TOKENS, SimpleKVCache())      # 组合2 连续缓存
    pool = make_pool(model)
    req = pool.request("m", "independent", full_prompt)
    paged = greedy_decode(model, full_prompt, NEW_TOKENS, req)                   # 组合3 分页缓存独立
    req.release("finished")
    warmup = make_pool(model)                                                     # 组合4 前缀复用
    w = warmup.request("m", "warmup", PROMPT)
    prefill(model, w, PROMPT)
    w.release("finished")
    pool2 = make_pool(model)
    hit = pool2.request("m", "reuse", full_prompt)
    reuse = greedy_decode(model, full_prompt, NEW_TOKENS, hit)
    hit.release("finished")
    tol = 1e-5
    combos = {"无缓存": baseline, "连续缓存": simple, "分页缓存": paged, "前缀复用": reuse}
    e1 = {}
    for name, r in combos.items():
        tokens_ok = r.token_ids == baseline.token_ids
        logits_err = max(float((a - b).abs().max()) for a, b in zip(r.per_step_logits, baseline.per_step_logits))
        e1[name] = {"tokens_equal": tokens_ok, "max_abs_err": logits_err}
        print(f"  {name}: tokens_equal={tokens_ok}, max|Δlogits|={logits_err:.2e}")
        results[f"E1_{name}"] = tokens_ok and logits_err <= tol
    e1["reuse_num_matched"] = hit.num_matched  # 复用命中的 token 数（整块对齐）
    record["e1_four_combos"] = e1

    # ---- E2 分配器行为时间线 ----
    print("\n[E2] 分配器行为时间线")
    log: list[str] = []
    pool3 = make_pool(model)
    a = pool3.request("m", "A", PROMPT)
    prefill(model, a, PROMPT)
    log.append(f"A prefill 后: 持有 {pool3.allocator.used_blocks} 块（PROMPT={len(PROMPT)} token = {len(PROMPT)//BLOCK_SIZE} 整块 + 尾块 {len(PROMPT)%BLOCK_SIZE}）")
    b = pool3.request("m", "B", PROMPT + [999])   # B 与 A 前缀共享
    log.append(f"B 命中 A 的前缀: num_matched={b.num_matched}（尾块不共享 → 部分命中不计入）")
    shared_after = pool3.allocator.used_blocks
    a.release("finished")
    log.append(f"A 释放后: {shared_after} → {pool3.allocator.used_blocks} 块（共享块被 B 引用，不归还）")
    b.release("cancelled")
    log.append(f"B 取消释放后: → {pool3.allocator.used_blocks} 块（引用归零，全部归还）")
    c = pool3.request("m", "C", PROMPT)
    prefill(model, c, PROMPT)
    c.release("failed")
    log.append(f"C 失败释放后: 块池恢复 {pool3.allocator.free_blocks}/{N_BLOCKS}（failed 与 finished/cancelled 同一回收路径）")
    try:
        c.release("finished")
        log.append("重复释放：未报错（异常！）")
        results["E2_double_free"] = False
    except DoubleFreeError:
        log.append("重复释放：DoubleFreeError ✓")
        results["E2_double_free"] = True
    record["e2_timeline"] = log
    for line in log:
        print(f"  {line}")

    # ---- E3 容量对照 ----
    print("\n[E3] token 容量 vs 实际张量字节")
    pool4 = make_pool(model)
    theory_tokens = pool4.token_capacity
    actual_bytes = pool4.allocated_bytes
    per_token_theory = 2 * model.config.n_layers * model.config.n_kv_heads * (model.config.d_model // model.config.n_heads) * 4
    e3 = {
        "token_capacity_theory": theory_tokens,
        "theortetical_bytes": theory_tokens * per_token_theory,
        "actual_tensor_bytes": actual_bytes,
        "match": theory_tokens * per_token_theory == actual_bytes,
    }
    record["e3_capacity"] = e3
    print(f"  容量 {theory_tokens} token × {per_token_theory} B/token = {theory_tokens*per_token_theory/1024:.1f} KB（理论）")
    print(f"  块池张量实际 {actual_bytes/1024:.1f} KB（numel×4B）→ {'一致' if e3['match'] else '不一致'}")
    results["E3_capacity_match"] = e3["match"]

    # ---- E4 复用收益边界 ----
    print("\n[E4] 前缀复用的收益边界（prefill 计算量随命中长度的变化）")
    e4 = []

    def timed_prefill_reuse(hit_len: int) -> tuple[float, float, int]:
        """返回（复用 prefill 秒, 全量 prefill 秒, 首次命中的 token 数），各 3 次独立建池取中位。

        每次采样都用全新块池重新 warmup——否则同一池内重复 request 会命中
        上一轮已释放请求登记的完整前缀（弱索引复用），变量失控。
        """
        prompt = [7] * 40
        reuse_samples, full_samples, matched = [], [], 0
        for _ in range(3):
            pool5 = make_pool(model)
            if hit_len:
                wreq = pool5.request("m", "w", prompt[:hit_len])
                prefill(model, wreq, prompt[:hit_len])
                wreq.release("finished")
            req2 = pool5.request("m", "r", prompt)
            matched = req2.num_matched
            t0 = time.perf_counter()
            prefill(model, req2, prompt)
            reuse_samples.append(time.perf_counter() - t0)
            req2.release("finished")
        for _ in range(3):
            pool6 = make_pool(model)                  # 全新池且无同名前缀 → 必然未命中
            req3 = pool6.request("m2", "r", prompt)
            assert req3.num_matched == 0
            t0 = time.perf_counter()
            prefill(model, req3, prompt)
            full_samples.append(time.perf_counter() - t0)
            req3.release("finished")
        reuse_samples.sort(); full_samples.sort()
        return reuse_samples[1], full_samples[1], matched

    with torch.no_grad():
        for hit_len in (0, 8, 24):
            t_reuse, t_full, matched = timed_prefill_reuse(hit_len)
            e4.append({"hit_len": hit_len, "num_matched": matched,
                       "reuse_prefill_ms": t_reuse * 1e3, "full_prefill_ms": t_full * 1e3})
            print(f"  命中 {hit_len:2d} token（复用 {matched//BLOCK_SIZE} 块）: 复用 prefill {t_reuse*1e3:6.2f} ms vs 全量 {t_full*1e3:6.2f} ms")
    record["e4_reuse_boundary"] = e4
    record["e4_note"] = ("命中越长省得越多；但生成阶段（decode）完全不受前缀复用影响——"
                        "『命中快』只作用于 prefill 段，不等于全部负载都快（验收条款）")

    record["all_pass"] = all(results.values())
    record["checks"] = results
    record["degradation_note"] = "CPU 正确性与行为验收；E4 为同机相对对照，无绝对性能结论（5.3）"
    (OUT_DIR / "raw.json").write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    print("\n结论：", "全部通过" if record["all_pass"] else "存在失败项", "（raw.json）")
    sys.exit(0 if record["all_pass"] else 1)


if __name__ == "__main__":
    main()
