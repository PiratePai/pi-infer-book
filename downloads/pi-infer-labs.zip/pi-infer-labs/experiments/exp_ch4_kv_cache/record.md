# exp_ch4 KV Cache 分页与复用 · 实验记录

| 项 | 结果 | 判据 |
|---|---|---|
| E1 四组合逐 token 一致 | PASS | 无缓存/连续缓存/分页独立/前缀复用 token 序列一致，逐步 logits max&#124;Δ&#124;≤4.2e-7 |
| E2 行为时间线 | PASS | 命中/尾块部分匹配不计入/取消与失败统一回收/重复释放 DoubleFreeError/共享块引用计数 |
| E3 容量对照 | PASS | 32 块×4 槽=128 token×512B=65536 B，与块池张量实测 65536 B 逐字节一致 |
| E4 复用收益边界 | 记录 | 命中 0/8/24 token：prefill 3.65–3.97 vs 3.84–4.13 ms，tiny+CPU 上收益淹没在噪声；decode 完全不受益 |

- 环境：3.12.10 / torch 2.15.0+cpu / CPU / git 700994b9；块大小 4、32 块、固定 prompt/suffix、生成 6 token
- 生成口径：greedy argmax，无采样
- 复跑：`python experiments/exp_ch4_kv_cache/run_kv_experiment.py`
- 降级说明：E1–E3 正确性/行为验收（CPU 签收）；E4 同机相对对照，不构成性能结论（5.3）
