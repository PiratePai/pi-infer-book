# exp_ch5_sparse 稀疏 mask 数值验证与计量 · 实验记录

| 项 | 结果 | 判据 |
|---|---|---|
| S1 mask 语义 | PASS | 滑窗(6,3) 位置 4 可见 [2,3,4]；严格因果（上三角全 False）；window≥T 退化全因果；band 块稀疏=块 pattern ∩ token 级因果（36/64） |
| S2 数值对齐 | PASS | blocked_sparse vs masked_dense 同 mask（滑窗 4/8、band 块 4）max&#124;Δ&#124;≤4.8e-07 全 allclose |
| S3 计量 | PASS | 跳过块数/FLOPs 与手算一致；窗口 4/8/16/32 理论计算占比 12%/18%/27%/42% 单调；band 块 8 = 23% |

- 环境：3.12.10 / torch 2.15.0+cpu / CPU / 种子 0 / git 提交时点 HEAD
- 输入：GQA 随机张量（B/Hq/Hkv/T/D 见 raw.json）；无采样（纯前向）
- 复跑：`python experiments/exp_ch5_sparse/run_sparse_experiment.py`
- 降级说明：本机无稀疏内核——**数值验证与计量不等于稀疏加速**（正文明示）；跳过块实现的收益需块稀疏内核，未测（5.3/5.5）
