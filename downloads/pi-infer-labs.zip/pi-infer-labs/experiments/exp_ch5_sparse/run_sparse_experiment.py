#!/usr/bin/env python3
"""第 5 章短作业实验：稀疏 mask 的语义、稠密参考对齐与跳块计量。

演示（CPU，5.5 降级口径：无数值内核加速结论）：
  S1 mask 语义：滑窗与块稀疏的窗口/块/因果边界检查
  S2 数值对齐：blocked_sparse_attention 与 masked_dense_attention 同 mask 输出 allclose
  S3 计量：跳过块数与 FLOPs 节省对照手算；不同 window/块 pattern 的节省曲线
明确定位：本实验证明"两实现数值一致 + 计量正确"，稠密计算后遮罩只用于参考，
不等于稀疏加速（真实收益需要块稀疏内核，本机无此类内核，未测）。

复跑：python experiments/exp_ch5_sparse/run_sparse_experiment.py
"""

from __future__ import annotations

import json
import platform
import subprocess
import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from pi_infer.sparse import (  # noqa: E402
    block_sparse_mask,
    blocked_sparse_attention,
    masked_dense_attention,
    sliding_window_causal_mask,
)

OUT_DIR = Path(__file__).resolve().parent
torch.manual_seed(0)


def git_hash() -> str:
    try:
        return subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
    except Exception:
        return "unavailable"


def random_qkv(B: int, Hq: int, Hkv: int, Tq: int, Tk: int, D: int):
    """固定种子生成 GQA 输入。"""
    q = torch.randn(B, Hq, Tq, D)
    k = torch.randn(B, Hkv, Tk, D)
    v = torch.randn(B, Hkv, Tk, D)
    return q, k, v


def main() -> None:
    record: dict = {"env": {
        "git": git_hash(), "python": platform.python_version(),
        "torch": torch.__version__, "device": "cpu",
        "seed": 0,
        "degradation": "无稀疏内核环境：仅数值验证与计量，不构成加速结论（5.3/5.5）",
    }}
    print("=" * 64)
    print("exp_ch5_sparse mask 语义 / 数值对齐 / 跳块计量（CPU 数值验证）")

    # ---- S1 mask 语义 ----
    print("\n[S1] mask 语义检查")
    m = sliding_window_causal_mask(6, 3)
    # 位置 4 可见 {2,3,4}（i-window < j <= i）
    s1 = {
        "window_see_4": torch.nonzero(m[4]).flatten().tolist(),
        "row0_only_self": torch.nonzero(m[0]).flatten().tolist(),
        "strictly_causal": bool(m.triu(1).sum() == 0),
        "degenerate_full": bool(sliding_window_causal_mask(4, 8).equal(
            sliding_window_causal_mask(4, 4))),
    }
    bm = block_sparse_mask(8, 4, "band")
    s1["band_elements_kept"] = int(bm.sum())  # 2 块网格：对角 2 块经 token 级 tril 各剩 10 + 下邻块 16 = 36
    record["s1_mask_semantics"] = s1
    print(f"  滑窗(6,3) 位置4 可见 {s1['window_see_4']}；严格因果={s1['strictly_causal']}")
    print(f"  band 块稀疏保留元素 {s1['band_elements_kept']}/64（对角块再受 token 级因果裁剪）")

    # ---- S2 数值对齐 ----
    print("\n[S2] blocked_sparse vs masked_dense（同 mask allclose）")
    q, k, v = random_qkv(B=2, Hq=4, Hkv=2, Tq=16, Tk=16, D=8)
    cases = {
        "sliding_w4": sliding_window_causal_mask(16, 4),
        "sliding_w8": sliding_window_causal_mask(16, 8),
        "band_block4": block_sparse_mask(16, 4, "band"),
    }
    s2 = {}
    for name, mask in cases.items():
        ref = masked_dense_attention(q, k, v, mask)
        out, stats = blocked_sparse_attention(q, k, v, mask, block_size=4)
        err = float((out - ref).abs().max())
        s2[name] = {"max_abs_err": err, "allclose_1e_6": bool(torch.allclose(out, ref, atol=1e-6)),
                    "kept": stats.kept_blocks, "skipped": stats.skipped_blocks,
                    "flops_dense": stats.flops_dense, "flops_actual": stats.flops_actual}
        print(f"  {name}: max|Δ|={err:.2e} allclose={s2[name]['allclose_1e_6']} "
              f"块 {stats.kept_blocks} 留/{stats.skipped_blocks} 跳，FLOPs {stats.flops_actual}/{stats.flops_dense} "
              f"({stats.flops_actual/stats.flops_dense:.0%})")
    record["s2_alignment"] = s2

    # ---- S3 节省曲线（计量，非实测加速） ----
    print("\n[S3] 理论 FLOPs 占比 vs 窗口/块参数（T=64，纯计量）")
    _, k64, v64 = random_qkv(1, 4, 2, 64, 64, 8)
    q64 = torch.randn(1, 4, 64, 8)
    rows = []
    for window in (4, 8, 16, 32):
        mask = sliding_window_causal_mask(64, window)
        _, st = blocked_sparse_attention(q64, k64, v64, mask, block_size=4)
        rows.append({"mask": f"sliding_w{window}", "flops_ratio": st.flops_actual / st.flops_dense,
                     "kept": st.kept_blocks, "skipped": st.skipped_blocks})
        print(f"  窗口 {window:>2}: 理论计算占比 {rows[-1]['flops_ratio']:.0%}")
    mask = block_sparse_mask(64, 8, "band")
    _, st = blocked_sparse_attention(q64, k64, v64, mask, block_size=8)
    rows.append({"mask": "band_block8", "flops_ratio": st.flops_actual / st.flops_dense,
                 "kept": st.kept_blocks, "skipped": st.skipped_blocks})
    print(f"  band 块 8: 理论计算占比 {rows[-1]['flops_ratio']:.0%}")
    record["s3_flops_metering"] = rows

    record["checks"] = {
        "s1_semantics": s1["strictly_causal"] and s1["window_see_4"] == [2, 3, 4],
        "s2_all_aligned": all(c["allclose_1e_6"] for c in s2.values()),
        "s3_monotone_window": all(rows[i]["flops_ratio"] <= rows[i + 1]["flops_ratio"] for i in range(3)),
    }
    record["quality_note"] = ("数值对齐只证明实现一致；任务质量与端到端收益需块稀疏内核与固定评测样例，"
                              "本机无此类内核，未测（正文明示稠密遮罩≠稀疏加速）")
    all_ok = all(record["checks"].values())
    (OUT_DIR / "raw.json").write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\n结论：{'PASS' if all_ok else 'FAIL'}（raw.json）")
    sys.exit(0 if all_ok else 1)


if __name__ == "__main__":
    main()
