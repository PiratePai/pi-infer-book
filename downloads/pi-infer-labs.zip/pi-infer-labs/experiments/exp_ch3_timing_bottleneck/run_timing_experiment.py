#!/usr/bin/env python3
"""第 3 章样章实验：错误计时 vs 正确计时、单因素扫描、字节账/Roofline、profiler。

演示（CPU 变体，5.3 降级口径）：
  E1 错误计时对照：无预热含首调 vs 预热后交错重复；计时窗口缺尾 vs 全程
  E2 单因素扫描：输入长度 / 生成长度 / batch（各自单独扫）
  E3 字节账 + Roofline（标称参数，标注未实测）
  E4 torch.profiler 一次规范采集（CPU trace，top 算子表）

复跑：python experiments/exp_ch3_timing_bottleneck/run_timing_experiment.py
"""

from __future__ import annotations

import json
import platform
import statistics
import subprocess
import sys
import time
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from pi_infer import greedy_decode  # noqa: E402
from pi_infer.model import SimpleKVCache, TinyConfig, TinyTransformer  # noqa: E402


def build_model() -> TinyTransformer:
    """与 build_tiny_model(seed=0) 同权重，但扩大 max_seq_len 以容纳最长扫描点。"""
    torch.manual_seed(0)
    return TinyTransformer(TinyConfig(max_seq_len=256, seed=0))

OUT_DIR = Path(__file__).resolve().parent
WARMUP, REPEATS = 3, 5
# 标称参数（示例用，Roofline 结论按"未实测"处理）
NOMINAL_CPU_GFLOPS = 200.0     # AVX2 多核标称上限量级
NOMINAL_CPU_BW_GBPS = 40.0     # 双通道 DDR4 标称量级


def git_hash() -> str:
    try:
        return subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
    except Exception:
        return "unavailable"


def sync_device() -> None:
    """正确同步：CUDA 存在时必须 synchronize 再读表；CPU 上为空操作但保留同一调用点。"""
    if torch.cuda.is_available():
        torch.cuda.synchronize()


def timed_decode(model, prompt_len: int, new_tokens: int, batch: int = 1) -> float:
    """计时窗口=完整解码（含输入构造后、含全部输出 token）；同步后读表。"""
    prompt = [7] * prompt_len
    t0 = time.perf_counter()
    for _ in range(batch):
        greedy_decode(model, prompt, new_tokens, SimpleKVCache())
    sync_device()                      # 计时窗口内同步
    return time.perf_counter() - t0


def main() -> None:
    model = build_model()
    record: dict = {"env": {
        "git": git_hash(), "python": platform.python_version(),
        "torch": torch.__version__, "device": "cpu",
        "processor": platform.processor(),
        "cuda_available": torch.cuda.is_available(),
        "warmup": WARMUP, "repeats": REPEATS,
        "timing_method": "perf_counter + 进程内串行（CPU）；CUDA 分支 sync_device 已内置但本机未测",
        "generation_spec": {"decode": "greedy", "sampling": "无", "stop": "max_new_tokens 固定"},
    }}
    print("=" * 64)
    print("exp_ch3 计时、字节账与 profiler（CPU；性能绝对值未测，只做相对对照）")

    # ---- E1 错误计时 vs 正确计时 ----
    print("\n[E1] 错误计时 vs 正确计时（同一段工作：prompt=32, 生成 16, ×1）")
    # 错误 a：无预热，直接计第一次（含 torch 线程池/首kernel 初始化）
    wrong_a = timed_decode(model, 32, 16)
    # 错误 b：计时窗口缺尾——只测了 prefill+部分 decode（漏掉最后一步收尾）
    prompt = [7] * 32
    t0 = time.perf_counter()
    greedy_decode(model, prompt, 14, SimpleKVCache())   # 声称 16，实际只做 14
    wrong_b = time.perf_counter() - t0
    # 正确：预热 + 交错重复 + 同步
    for _ in range(WARMUP):
        timed_decode(model, 32, 16)
    right = [timed_decode(model, 32, 16) for _ in range(REPEATS)]
    right_mean, right_std = statistics.mean(right), statistics.stdev(right)
    record["e1_timing_discipline"] = {
        "wrong_no_warmup_s": wrong_a,
        "wrong_truncated_window_s": wrong_b,
        "correct_mean_s": right_mean, "correct_std_s": right_std,
        "samples_s": right,
        "warmup": WARMUP, "repeats": REPEATS,
        "note": "错误计时都系统性偏离正确口径；CUDA 上另有异步未同步的假加速变体（脚本含 sync_device 分支，本机未测）",
    }
    print(f"  无预热首调: {wrong_a*1e3:8.2f} ms   （偏差 {(wrong_a/right_mean-1)*100:+.0f}%）")
    print(f"  计时缺尾(14/16): {wrong_b*1e3:8.2f} ms   （偏差 {(wrong_b/right_mean-1)*100:+.0f}%）")
    print(f"  正确口径: {right_mean*1e3:8.2f} ± {right_std*1e3:.2f} ms  （预热{WARMUP}×交错{REPEATS}）")

    # ---- E2 单因素扫描 ----
    print("\n[E2] 单因素扫描（其余条件固定；每点 预热2×重复5，报均值±std）")
    def sweep(name: str, variable: str, values: list, **fixed) -> None:
        rows = []
        for v in values:
            kwargs = {**fixed, variable: v}
            for _ in range(2):
                timed_decode(model, **kwargs)
            samples = [timed_decode(model, **kwargs) for _ in range(REPEATS)]
            rows.append({"value": v, "mean_s": statistics.mean(samples),
                         "std_s": statistics.stdev(samples), "samples": samples})
            print(f"  {name}={v:<4} {statistics.mean(samples)*1e3:8.2f} ± {statistics.stdev(samples)*1e3:6.2f} ms")
        record[f"e2_sweep_{variable}"] = rows

    sweep("input_len", "prompt_len", [8, 32, 128], new_tokens=16, batch=1)
    sweep("new_tokens", "new_tokens", [8, 16, 32], prompt_len=32, batch=1)
    sweep("batch", "batch", [1, 2, 4], prompt_len=32, new_tokens=16)

    # ---- E3 字节账 + Roofline ----
    print("\n[E3] 字节账（公式化，tiny 配置）与 Roofline（标称参数，未实测）")
    cfg = model.config
    d, dff, V = cfg.d_model, cfg.d_ff, cfg.vocab_size
    L, hq, hkv, dh = cfg.n_layers, cfg.n_heads, cfg.n_kv_heads, cfg.d_model // cfg.n_heads
    weight_params = V * d + L * (4 * d * d + 3 * d * dff) + d + d  # 近似：proj×4 + ffn×3 + norms
    weight_bytes = weight_params * 4
    kv_bytes_per_token = 2 * L * hkv * dh * 4
    prefill_flops = 2 * weight_params  # 每 token 前向 ≈ 2×参数量（GQA 尾项忽略）
    decode_flops_per_token = prefill_flops + 2 * L * hq * dh * (16 + 1)  # +注意力分数与加权V
    intensity = prefill_flops / (weight_bytes + kv_bytes_per_token * 32)
    ridge = NOMINAL_CPU_GFLOPS * 1e9 / (NOMINAL_CPU_BW_GBPS * 1e9)
    record["e3_byte_roofline"] = {
        "weight_params": weight_params, "weight_bytes_fp32": weight_bytes,
        "kv_bytes_per_token": kv_bytes_per_token,
        "prefill_flops_per_token": prefill_flops,
        "decode_flops_per_token": decode_flops_per_token,
        "arithmetic_intensity_prefill_T32_flop_per_byte": intensity,
        "nominal_ridge_point_flop_per_byte": ridge,
        "nominal_cpu_gflops": NOMINAL_CPU_GFLOPS, "nominal_bw_gbps": NOMINAL_CPU_BW_GBPS,
        "note": "Roofline 参数为标称量级示例；带宽/算力未实测（5.3），只用于演示判定流程",
    }
    print(f"  权重: {weight_params/1e6:.2f}M 参数 = {weight_bytes/1e6:.2f} MB (fp32)")
    print(f"  KV: {kv_bytes_per_token} B/token（2K/V×{L}层×{hkv}头×{dh}维×4B）")
    print(f"  算术强度(T=32 prefill): {intensity:.1f} FLOP/B vs 脊点 {ridge:.1f} FLOP/B（标称）→ "
          f"{'计算受限' if intensity >= ridge else '带宽受限'}（示例结论，未实测）")

    # ---- E4 profiler ----
    print("\n[E4] torch.profiler 规范采集（CPU，一段 prefill+decode）")
    from torch.profiler import ProfilerActivity, profile
    with profile(activities=[ProfilerActivity.CPU]) as prof:
        for _ in range(3):
            greedy_decode(model, [7] * 32, 8, SimpleKVCache())
    table = prof.key_averages().table(sort_by="self_cpu_time_total", row_limit=10)
    (OUT_DIR / "profiler_top10.txt").write_text(table, encoding="utf-8")
    record["e4_profiler"] = {"file": "profiler_top10.txt",
                             "note": "top-10 CPU 算子表（3 次 decode 循环）"}
    print(table.splitlines()[3])  # 表头行示例
    print("  （完整表见 profiler_top10.txt）")

    record["degradation_note"] = ("本机无 NVIDIA GPU：CPU 相对对照可签收；CUDA 异步假加速变体、"
                                  "显存 allocated/reserved、设备 trace 未测（5.3）")
    (OUT_DIR / "raw.json").write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    print("\n结论：E1–E4 完成，原始数据 raw.json / profiler_top10.txt")


if __name__ == "__main__":
    main()
