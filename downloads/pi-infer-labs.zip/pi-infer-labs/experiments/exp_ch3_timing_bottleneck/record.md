# exp_ch3 计时、字节账与 profiler · 实验记录

| 项 | 结果 | 判据 |
|---|---|---|
| E1a 错误：无预热首调 | 24.04 ms（+46%） | 与正确口径对照，系统性偏高 |
| E1b 错误：窗口缺尾(14/16) | 16.17 ms（−1%） | 窗口漏最后 2 步 decode |
| E1 正确：预热3×交错5 | 16.41 ± 2.59 ms | perf_counter + 同步点保留 |
| E2 单因素扫描 | input_len {8,32,128} / new_tokens {8,16,32} / batch {1,2,4} | 每次只动一个因素，均值±std（raw.json） |
| E3 字节账+Roofline | 权重 0.10M 参数 ≈ 0.40 MB；KV 512 B/token；强度 vs 脊点（标称） | 公式化手算；Roofline 参数标称未实测 |
| E4 profiler | top-10 CPU 算子表 | profiler_top10.txt |

- 环境：3.12.10 / torch 2.15.0+cpu / CPU / git 700994b9
- 生成口径：greedy argmax、max_new_tokens 固定、无采样；计时窗口=完整解码（含输入构造后、含全部输出）
- 复跑：`python experiments/exp_ch3_timing_bottleneck/run_timing_experiment.py`
- 降级说明：CPU 相对对照可签收；CUDA 异步假加速变体、显存 allocated/reserved、设备 trace 未测（5.3）
