#!/usr/bin/env python3
"""第 6 章实验：标准注意力 vs online softmax 分块的数值/内存/时间扫描。

  F1 数值对齐：随机 GQA 输入上 online(block=64..1) 与参考 allclose
  F2 峰值内存：peak_bytes 计量——参考实现随 T² 增长、online 随 T 线性（分块 O(1) 级）
  F3 CPU 时间：少量长度 × batch 扫描（同机相对对照）
  F4 生产内核检查清单：SDPA 路径代码就绪性检查（不实测 GPU，5.3）

复跑：python experiments/exp_ch6_flash/run_flash_experiment.py
"""

from __future__ import annotations

import json
import platform
import statistics
import subprocess
import sys
import time
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from pi_infer.flash import flash_attention_reference, online_softmax_attention  # noqa: E402

OUT_DIR = Path(__file__).resolve().parent
torch.manual_seed(0)
WARMUP, REPEATS = 2, 5


def git_hash() -> str:
    try:
        return subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
    except Exception:
        return "unavailable"


def random_qkv(B, Hq, Hkv, T, D, seed_offset=0):
    g = torch.Generator().manual_seed(seed_offset)
    return (torch.randn(B, Hq, T, D, generator=g), torch.randn(B, Hkv, T, D, generator=g),
            torch.randn(B, Hkv, T, D, generator=g))


def timed(fn) -> float:
    for _ in range(WARMUP):
        fn()
    samples = []
    for _ in range(REPEATS):
        t0 = time.perf_counter()
        fn()
        samples.append(time.perf_counter() - t0)
    return statistics.mean(samples), statistics.stdev(samples)


def _utf8_stdout():
    """Windows 默认 GBK 控制台下非 GBK 字符无法编码——统一按 UTF-8 输出（幂等，静默失败安全）。"""
    import sys as _s
    for _st in (_s.stdout, _s.stderr):
        try:
            _st.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


def main() -> None:
    _utf8_stdout()
    record: dict = {"env": {
        "git": git_hash(), "python": platform.python_version(),
        "torch": torch.__version__, "device": "cpu", "seed": 0,
        "timing": f"perf_counter 预热{WARMUP}×重复{REPEATS}（同机相对对照）",
    }}
    print("=" * 64)
    print("exp_ch6 标准注意力 vs online softmax 分块（CPU）")

    # ---- F1 数值对齐 ----
    print("\n[F1] online vs 参考 allclose（GQA B=2 Hq=4 Hkv=2 T=128 D=16）")
    q, k, v = random_qkv(2, 4, 2, 128, 16)
    ref, ref_stats = flash_attention_reference(q, k, v)
    f1 = {}
    for block in (64, 16, 4, 1):
        out, _ = online_softmax_attention(q, k, v, block_size=block)
        err = float((out - ref).abs().max())
        f1[f"block{block}"] = {"max_abs_err": err, "allclose_1e_5": bool(torch.allclose(out, ref, atol=1e-5))}
        print(f"  block={block:>2}: max|Δ|={err:.2e} allclose={f1[f'block{block}']['allclose_1e_5']}")
    record["f1_alignment"] = f1

    # ---- F2 峰值内存（计量钩子；长度维度 B=1 + batch 维度对照） ----
    print("\n[F2] 中间张量峰值字节（计量口径见 flash.FlashStats）")
    f2 = []
    for T in (256, 512, 1024, 2048):
        q, k, v = random_qkv(1, 2, 1, T, 32)
        _, ref_st = flash_attention_reference(q, k, v)
        _, on_st = online_softmax_attention(q, k, v, block_size=64)
        row = {"T": T, "B": 1, "ref_peak_bytes": ref_st.peak_bytes, "online_peak_bytes": on_st.peak_bytes,
               "ratio": on_st.peak_bytes / ref_st.peak_bytes,
               "ref_writes": ref_st.hbm_writes_approx, "online_writes": on_st.hbm_writes_approx}
        f2.append(row)
        print(f"  T={T:>4} B=1: 参考 {ref_st.peak_bytes/1e3:8.1f} KB | online {on_st.peak_bytes/1e3:7.1f} KB "
              f"（{row['ratio']:.1%}）| 写入 {ref_st.hbm_writes_approx/1e3:.0f}→{on_st.hbm_writes_approx/1e3:.0f} KB")
    for B in (2, 4):
        q, k, v = random_qkv(B, 2, 1, 1024, 32)
        _, ref_st = flash_attention_reference(q, k, v)
        _, on_st = online_softmax_attention(q, k, v, block_size=64)
        row = {"T": 1024, "B": B, "ref_peak_bytes": ref_st.peak_bytes, "online_peak_bytes": on_st.peak_bytes,
               "ratio": on_st.peak_bytes / ref_st.peak_bytes,
               "ref_writes": ref_st.hbm_writes_approx, "online_writes": on_st.hbm_writes_approx}
        f2.append(row)
        print(f"  T=1024 B={B}: 参考 {ref_st.peak_bytes/1e3:8.1f} KB | online {on_st.peak_bytes/1e3:7.1f} KB "
              f"（{row['ratio']:.1%}）—— batch 线性放大两侧峰值，比例不变")
    record["f2_peak_bytes"] = f2

    # ---- F3 时间扫描（长度 × batch，逐点附数值误差与该点峰值） ----
    print("\n[F3] CPU 时间扫描（相对对照，block=64；每点附 max|Δ| 与峰值）")
    f3 = []
    for T, B in ((128, 1), (256, 1), (512, 1), (128, 2), (128, 4)):
        q, k, v = random_qkv(B, 2, 1, T, 32)
        ref, ref_st = flash_attention_reference(q, k, v)
        on, on_st = online_softmax_attention(q, k, v, block_size=64)
        err = float((on - ref).abs().max())
        ref_t, ref_s = timed(lambda: flash_attention_reference(q, k, v))
        on_t, on_s = timed(lambda: online_softmax_attention(q, k, v, block_size=64))
        f3.append({"T": T, "B": B, "max_abs_err": err, "allclose_1e_5": bool(torch.allclose(on, ref, atol=1e-5)),
                   "ref_peak_bytes": ref_st.peak_bytes, "online_peak_bytes": on_st.peak_bytes,
                   "ref_s": ref_t, "ref_std": ref_s, "online_s": on_t, "online_std": on_s})
        print(f"  T={T:>3} B={B}: max|Δ|={err:.1e} 峰值 {ref_st.peak_bytes/1e3:6.1f}→{on_st.peak_bytes/1e3:5.1f} KB | "
              f"参考 {ref_t*1e3:6.2f}±{ref_s*1e3:4.2f} ms | online {on_t*1e3:6.2f}±{on_s*1e3:4.2f} ms")
    record["f3_time_sweep"] = f3

    # ---- F4 生产内核检查清单（代码就绪性，不实测） ----
    print("\n[F4] 生产内核（SDPA）就绪性检查：CPU 分支实跑，CUDA 标未测")
    q, k, v = random_qkv(1, 2, 1, 64, 32)
    k_full = k.repeat_interleave(q.shape[1] // k.shape[1], dim=1)
    v_full = v.repeat_interleave(q.shape[1] // v.shape[1], dim=1)
    sdpa = torch.nn.functional.scaled_dot_product_attention(q, k_full, v_full, is_causal=True)
    ref, _ = flash_attention_reference(q, k, v)
    f4 = {
        "sdpa_cpu_runs": True,
        "sdpa_vs_reference_allclose_1e_5": bool(torch.allclose(sdpa, ref, atol=1e-5)),
        "cuda_flash_available": torch.cuda.is_available(),
        "note": ("清单其余项（dtype 匹配/非连续输入布局/GQA repeat 策略/后端选择的真机行为）"
                 "随生产内核使用节在正文给出，GPU 侧未测（5.3）"),
    }
    record["f4_kernel_readiness"] = f4
    print(f"  SDPA(CPU) 与参考 allclose={f4['sdpa_vs_reference_allclose_1e_5']}；CUDA flash 可用={f4['cuda_flash_available']}")

    record["checks"] = {
        "f1_all_aligned": all(x["allclose_1e_5"] for x in f1.values()),
        "f2_online_sublinear": f2[-1]["ratio"] < 0.5,
        "f3_recorded": len(f3) == 5,
        "f4_sdpa_aligned": f4["sdpa_vs_reference_allclose_1e_5"],
    }
    record["degradation_note"] = ("CPU 数值/内存计量/相对时间签收；绝对性能与 GPU 内核行为未测（5.3）。"
                                  "peak_bytes 为实现内计量口径（不含输入输出与算子内部工作区），正文已声明")
    all_ok = all(record["checks"].values())
    (OUT_DIR / "raw.json").write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\n结论：{'PASS' if all_ok else 'FAIL'}（raw.json）")
    sys.exit(0 if all_ok else 1)


if __name__ == "__main__":
    main()
