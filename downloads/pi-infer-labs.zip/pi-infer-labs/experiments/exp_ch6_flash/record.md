# exp_ch6_flash 分块注意力对照 · 实验记录

| 项 | 结果 | 判据 |
|---|---|---|
| F1 数值对齐 | PASS | online(block=64/16/4/1) vs 参考 max&#124;Δ&#124;≤4.8e-07 全 allclose（GQA B=2 Hq=4 Hkv=2 T=128） |
| F2 峰值内存 | PASS | 长度维（B=1）：T=256/512/1024/2048 参考 1050.6KB→67.1MB 随 T² 增长、online 恒 66.6KB（占比 0.1%@2048）；batch 维（T=1024）：B=2/4 双侧线性放大、占比 0.4% 不变。写入 67.7→27.8MB |
| F3 时间+逐点误差扫描 | PASS | T∈{128,256,512}×B∈{1}∪{128}×B∈{2,4} 每点附误差与峰值：max&#124;Δ&#124;∈[3.0e-07, 5.7e-07] 全过 allclose@1e-05；参考 6.3–22.4ms，online 9.6–81.9ms——CPU 上 online 更慢（分块循环开销），"IO 优化不是计算优化"实证 |
| F4 内核就绪 | PASS | SDPA(CPU) 与参考 allclose(1e-05)；CUDA flash 不可用（无 NVIDIA GPU），GPU 行为未测 |

- 环境：3.12.10 / torch 2.15.0+cpu / CPU / 种子 0
- 计量口径：peak_bytes=实现内显式分配的中间张量存活峰值（_LiveTensors 登记制，不含输入输出与算子内部工作区）；hbm_writes_approx=各内部张量首写字节+输出
- 计时：预热 2×重复 5，perf_counter，同机相对对照
- 复跑：`python experiments/exp_ch6_flash/run_flash_experiment.py`
- 降级说明：CPU 数值/计量/相对时间签收；GPU 端 FlashAttention 收益与内核行为未测（5.3）
