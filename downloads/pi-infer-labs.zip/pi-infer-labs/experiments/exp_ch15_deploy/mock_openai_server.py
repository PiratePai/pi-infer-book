#!/usr/bin/env python3
"""本机 OpenAI 兼容桩；一个空格分隔的词就是一个 mock token。

运行：python mock_openai_server.py --port 8123 --prefill-delay-ms 30 --token-delay-ms 5
自检：python mock_openai_server.py --self-check（不监听、不发请求）。
退出码：0 正常关闭/自检通过；2 参数非法；3 监听失败；1 自检失败。
直方图每个已结束的合法请求各观察一次（含客户端断连），不按 n 重复计数。
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import random
import re
import sys
import threading
import time
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit


@dataclass(frozen=True)
class Config:
    """启动前校验监听参数与模拟延迟，避免启动后才发现配置错误。"""

    host: str = "127.0.0.1"
    port: int = 8123
    prefill_delay_ms: float = 20.0
    token_delay_ms: float = 5.0
    max_running: int = 8

    def __post_init__(self) -> None:
        """校验端口、并行槽和有限非负延迟。"""
        if (not isinstance(self.host, str) or not self.host.strip()
                or type(self.port) is not int or not 1 <= self.port <= 65535):
            raise ValueError("host 不能为空，port 必须在 1..65535")
        if type(self.max_running) is not int or self.max_running < 1:
            raise ValueError("max-running 必须大于 0")
        for value in (self.prefill_delay_ms, self.token_delay_ms):
            if type(value) not in (int, float) or not math.isfinite(value) or value < 0:
                raise ValueError("延迟必须是有限的非负毫秒数")


@dataclass(frozen=True)
class ChatRequest:
    """对单个请求做构造期校验；输出长度按每个 choice 计。"""

    messages: list
    model: str = "mock-model"
    max_tokens: int = 16
    temperature: float = 1.0
    stream: bool = False
    seed: int | None = 0
    n: int = 1

    def __post_init__(self) -> None:
        """只接受非空文本消息，限制请求大小和生成规模。"""
        if not isinstance(self.messages, list) or not self.messages:
            raise ValueError("messages 必须是非空列表")
        for message in self.messages:
            if (not isinstance(message, dict)
                    or message.get("role") not in ("system", "user", "assistant", "tool", "developer")
                    or not isinstance(message.get("content"), str)):
                raise ValueError("每条消息必须有合法 role 和字符串 content")
        if not isinstance(self.model, str) or not self.model.strip():
            raise ValueError("model 必须是非空字符串")
        for key, value, upper in (("max_tokens", self.max_tokens, 65536), ("n", self.n, 16)):
            if type(value) is not int or not 1 <= value <= upper:
                raise ValueError(f"{key} 必须是 1..{upper} 的整数")
        if (type(self.temperature) not in (int, float)
                or not math.isfinite(self.temperature) or not 0 <= self.temperature <= 2):
            raise ValueError("temperature 必须在 0..2")
        if type(self.stream) is not bool or (self.seed is not None and type(self.seed) is not int):
            raise ValueError("stream 必须为布尔值，seed 必须为整数或 null")

    @property
    def prompt(self) -> str:
        """合并所有消息文本，作为确定性词表与 prompt token 账的输入。"""
        return " ".join(message["content"] for message in self.messages)


def derive_tokens(prompt: str, seed: int, count: int) -> list[str]:
    """用 SHA-256 与局部随机数生成器派生词表，不依赖进程随机 hash。"""
    if not isinstance(prompt, str) or type(seed) is not int or type(count) is not int or count < 0:
        raise ValueError("prompt/seed/count 类型非法或 count 为负")
    vocabulary = sorted(set(re.findall(r"\w+|[^\w\s]", prompt))) or ["mock", "token"]
    digest = hashlib.sha256(f"{seed}\0{prompt}".encode("utf-8")).digest()
    random.Random(int.from_bytes(digest, "big")).shuffle(vocabulary)
    return [(" " if index else "") + vocabulary[index % len(vocabulary)] for index in range(count)]


def make_chunk(request_id: str, model: str, created: int, index: int,
               delta: dict, finish_reason: str | None = None) -> dict:
    """组装一个 OpenAI chat.completion.chunk；空 delta 可表示结束。"""
    return {"id": request_id, "object": "chat.completion.chunk", "created": created,
            "model": model, "choices": [{"index": index, "delta": delta,
                                          "finish_reason": finish_reason}]}


def sse_frame(payload: dict | str) -> bytes:
    """编码一个完整 SSE data 帧，保留 UTF-8 文本与双换行边界。"""
    text = payload if isinstance(payload, str) else json.dumps(payload, ensure_ascii=False)
    return f"data: {text}\n\n".encode("utf-8")


class Metrics:
    """用一把锁维护 gauge、counter 和累积直方图，支持并发抓取。"""

    BOUNDS = (0.01, 0.05, 0.1, 0.5, 1.0, 5.0, float("inf"))

    def __init__(self) -> None:
        """初始化请求账与直方图计数。"""
        self.lock = threading.Lock()
        self.running = self.waiting = self.prompt_tokens = self.generation_tokens = 0
        self.finished = 0
        self.buckets = {name: [0] * len(self.BOUNDS) for name in ("ttft", "tpot")}
        self.sums = {"ttft": 0.0, "tpot": 0.0}

    def change(self, **deltas: int) -> None:
        """原子增减正在运行、等待与 token 计数。"""
        with self.lock:
            for name, delta in deltas.items():
                setattr(self, name, getattr(self, name) + delta)

    def finish(self, ttft: float, tpot: float) -> None:
        """每个结束请求对两个直方图各贡献一个观察值。"""
        with self.lock:
            self.running -= 1
            self.finished += 1
            for name, value in (("ttft", ttft), ("tpot", tpot)):
                self.sums[name] += value
                for index, bound in enumerate(self.BOUNDS):
                    self.buckets[name][index] += int(value <= bound)

    def render(self) -> str:
        """输出 Prometheus 文本；+Inf 与 _count 都等于 requests_finished_total。"""
        with self.lock:
            lines = []
            for name, kind, value in (
                ("num_requests_running", "gauge", self.running),
                ("num_requests_waiting", "gauge", self.waiting),
                ("prompt_tokens_total", "counter", self.prompt_tokens),
                ("generation_tokens_total", "counter", self.generation_tokens),
                ("requests_finished_total", "counter", self.finished),
            ):
                lines.extend((f"# TYPE vllm:{name} {kind}", f"vllm:{name} {value}"))
            for key, name in (("ttft", "time_to_first_token_seconds"),
                              ("tpot", "request_time_per_output_token_seconds")):
                lines.append(f"# TYPE vllm:{name} histogram")
                for bound, count in zip(self.BOUNDS, self.buckets[key]):
                    label = "+Inf" if math.isinf(bound) else f"{bound:g}"
                    lines.append(f'vllm:{name}_bucket{{le="{label}"}} {count}')
                lines.extend((f"vllm:{name}_count {self.finished}",
                              f"vllm:{name}_sum {self.sums[key]:.9f}"))
            return "\n".join(lines) + "\n"


def make_handler(config: Config, metrics: Metrics) -> type[BaseHTTPRequestHandler]:
    """把配置、并行槽和指标绑定到独立服务，避免模块级可变服务状态。"""
    slots = threading.BoundedSemaphore(config.max_running)

    class Handler(BaseHTTPRequestHandler):
        """实现 JSON、SSE 与指标端点；一个 HTTP 请求由一个线程处理。"""

        protocol_version = "HTTP/1.1"

        def log_message(self, format: str, *args: object) -> None:
            """保留标准访问日志。"""
            super().log_message(format, *args)

        def respond(self, code: int, payload: bytes, content_type: str) -> None:
            """用明确的长度关闭响应，避免客户端误等连接结束。"""
            self.send_response(code)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(payload)))
            self.send_header("Connection", "close")
            self.end_headers()
            self.close_connection = True
            self.wfile.write(payload)

        def do_GET(self) -> None:
            """抓取线程安全指标快照，其余路径返回 404。"""
            if urlsplit(self.path).path == "/metrics":
                self.respond(200, metrics.render().encode(), "text/plain; version=0.0.4; charset=utf-8")
            else:
                self.respond(404, b'{"error":"not found"}', "application/json")

        def do_POST(self) -> None:
            """先校验请求，再排队、模拟 prefill/decode 并准确记 token 账。"""
            if urlsplit(self.path).path != "/v1/chat/completions":
                self.respond(404, b'{"error":"not found"}', "application/json")
                return
            try:
                self.connection.settimeout(30)
                length = int(self.headers.get("Content-Length", "0"))
                if not 0 < length <= 2 * 1024 * 1024:
                    raise ValueError("Content-Length 必须在 1..2097152")
                payload = json.loads(self.rfile.read(length))
                if not isinstance(payload, dict):
                    raise ValueError("JSON 顶层必须是对象")
                fields = ChatRequest.__dataclass_fields__
                request = ChatRequest(**{key: value for key, value in payload.items() if key in fields})
            except (ValueError, TypeError, OSError) as exc:
                self.respond(400, json.dumps({"error": str(exc)}, ensure_ascii=False).encode("utf-8"),
                             "application/json; charset=utf-8")
                return
            arrived = time.perf_counter()
            metrics.change(waiting=1)
            slots.acquire()
            metrics.change(waiting=-1, running=1, prompt_tokens=len(request.prompt.split()))
            first = last = None
            emitted = 0
            request_id = f"chatcmpl-mock-{time.time_ns()}"
            created = int(time.time())
            tokens = [derive_tokens(request.prompt, (request.seed or 0) + index, request.max_tokens)
                      for index in range(request.n)]
            try:
                if request.stream:
                    self.send_response(200)
                    self.send_header("Content-Type", "text/event-stream; charset=utf-8")
                    self.send_header("Cache-Control", "no-cache")
                    self.send_header("Connection", "close")
                    self.end_headers()
                    self.close_connection = True
                time.sleep(config.prefill_delay_ms / 1000)
                if request.stream:
                    for index in range(request.n):
                        self.wfile.write(sse_frame(make_chunk(request_id, request.model, created, index,
                                                             {"role": "assistant"})))
                    self.wfile.flush()
                for position in range(request.max_tokens):
                    for index in range(request.n):
                        if emitted:
                            time.sleep(config.token_delay_ms / 1000)
                        if request.stream:
                            self.wfile.write(sse_frame(make_chunk(request_id, request.model, created, index,
                                                                 {"content": tokens[index][position]})))
                            self.wfile.flush()
                        now = time.perf_counter()
                        first = now if first is None else first
                        last = now
                        emitted += 1
                        metrics.change(generation_tokens=1)
                usage = {"prompt_tokens": len(request.prompt.split()), "completion_tokens": emitted,
                         "total_tokens": len(request.prompt.split()) + emitted}
                if request.stream:
                    for index in range(request.n):
                        self.wfile.write(sse_frame(make_chunk(request_id, request.model, created, index,
                                                             {}, "length")))
                    self.wfile.write(sse_frame({"id": request_id, "object": "chat.completion.chunk",
                                               "created": created, "model": request.model,
                                               "choices": [], "usage": usage}))
                    self.wfile.write(sse_frame("[DONE]"))
                    self.wfile.flush()
                else:
                    response = {"id": request_id, "object": "chat.completion", "created": created,
                                "model": request.model, "usage": usage, "choices": [
                                    {"index": index, "message": {"role": "assistant",
                                     "content": "".join(tokens[index])}, "finish_reason": "length"}
                                    for index in range(request.n)]}
                    self.respond(200, json.dumps(response, ensure_ascii=False).encode("utf-8"),
                                 "application/json; charset=utf-8")
            except (BrokenPipeError, ConnectionError, TimeoutError):
                pass  # 客户端断连也必须释放并行槽、闭合请求账。
            finally:
                finished = time.perf_counter()
                metrics.finish((first or finished) - arrived,
                               (last - first) / (emitted - 1) if emitted > 1 else 0.0)
                slots.release()

    return Handler


def self_check() -> None:
    """不发网络请求，独立核对确定性词表、帧边界与累计桶账。"""
    expected = derive_tokens("alpha beta gamma", 7, 7)
    assert expected == derive_tokens("alpha beta gamma", 7, 7)
    assert len(expected) == 7 and len(derive_tokens("", 0, 3)) == 3
    assert expected[0].strip() == expected[3].strip()
    frames = [sse_frame(make_chunk("test", "mock", 0, 0, {"content": token})) for token in expected]
    decoded = [json.loads(frame.decode()[6:].strip()) for frame in frames]
    assert "".join(chunk["choices"][0]["delta"]["content"] for chunk in decoded) == "".join(expected)
    assert all(frame.endswith(b"\n\n") for frame in frames)
    assert sse_frame("[DONE]") == b"data: [DONE]\n\n"
    metrics = Metrics()
    metrics.change(running=1, generation_tokens=7)
    metrics.finish(0.04, 0.02)
    assert metrics.buckets["ttft"] == [0, 1, 1, 1, 1, 1, 1]
    assert 'vllm:time_to_first_token_seconds_bucket{le="+Inf"} 1' in metrics.render()
    for kwargs in ({"max_tokens": 0}, {"stream": "true"}, {"n": True}):
        try:
            ChatRequest(messages=[{"role": "user", "content": "test"}], **kwargs)
        except ValueError:
            continue
        raise AssertionError("非法请求未拒绝")


def main(argv: list[str] | None = None) -> int:
    """解析启动参数；Ctrl+C 为正常关闭。"""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8123)
    parser.add_argument("--prefill-delay-ms", type=float, default=20.0)
    parser.add_argument("--token-delay-ms", type=float, default=5.0)
    parser.add_argument("--max-running", type=int, default=8)
    parser.add_argument("--self-check", action="store_true")
    args = parser.parse_args(argv)
    try:
        config = Config(**{key: value for key, value in vars(args).items() if key != "self_check"})
    except ValueError as exc:
        parser.error(str(exc))
    if args.self_check:
        self_check()
        print("OK: mock 确定性词表、SSE、请求校验与直方图自检")
        return 0
    try:
        server = ThreadingHTTPServer((config.host, config.port), make_handler(config, Metrics()))
    except OSError as exc:
        print(f"监听失败：{exc}", file=sys.stderr)
        return 3
    server.daemon_threads = True
    print(f"mock: http://{config.host}:{config.port}（Ctrl+C 关闭）", flush=True)
    try:
        server.serve_forever(poll_interval=0.2)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
