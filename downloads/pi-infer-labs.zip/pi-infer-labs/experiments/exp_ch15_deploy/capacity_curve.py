#!/usr/bin/env python3
"""第 15 章部署包 · 容量曲线生成（纯标准库，零新依赖）。

输入：bench_sweep.py 产出的 results/summary.csv（列：rate, req_s, out_tok_s, ttft_p50_ms,
ttft_p99_ms, tpot_p99_ms, itl_p99_ms, goodput_req_s, failures, cancels 等；兼容 underloaded）。
输出（--out 目录）：
  capacity.csv      逐到达率点 + SLO 达标列
  capacity.md       Markdown 表（正文/报告直接引用）
  capacity.svg      双轴折线：吞吐/goodput 曲线 + p99 延迟曲线 + SLO 线

用法：python capacity_curve.py --summary results/summary.csv --out results/
      SLO 口径：--slo "ttft_p99_ms<=2000,tpot_p99_ms<=200"（分号/逗号分隔的 表达式<=值 列表）
      无需输入文件的回归自检：python capacity_curve.py --self-check
"""

from __future__ import annotations

import argparse
import contextlib
import csv
import io
import math
import re
import sys
import tempfile
from pathlib import Path
from xml.etree import ElementTree
from xml.sax.saxutils import escape


SUMMARY_COLUMNS = ["rate", "req_s", "out_tok_s", "ttft_p50_ms", "ttft_p99_ms", "tpot_p99_ms",
                   "itl_p99_ms", "goodput_req_s", "failures", "cancels", "max_wait", "drain_s", "underloaded"]
# 与 bench_sweep 保持一致；goodput 不能作为自身的 SLO 判据。
SLO_METRICS = frozenset(SUMMARY_COLUMNS) - {"goodput_req_s"}
Rule = tuple[str, str, float]


def _utf8_stdout():
    """Windows 默认 GBK 控制台下非 GBK 字符无法编码——统一按 UTF-8 输出（幂等，静默失败安全）。"""
    import sys as _s
    for _st in (_s.stdout, _s.stderr):
        try:
            _st.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


def parse_slo(text: str) -> list[Rule]:
    """与 bench_sweep 同语义：指标白名单、四种比较运算和有限阈值。"""
    rules = []
    for part in text.replace(";", ",").split(","):
        if not part.strip():
            continue
        match = re.fullmatch(r"\s*([A-Za-z_][\w]*)\s*(<=|>=|<|>)\s*(\S+)\s*", part)
        if not match:
            raise ValueError(f"SLO 规则不认识：{part}（形如 ttft_p99_ms<=2000）")
        key, op, raw_value = match.groups()
        try:
            value = float(raw_value)
        except ValueError as exc:
            raise ValueError(f"SLO 阈值不是数字：{part}") from exc
        if not math.isfinite(value):
            raise ValueError(f"SLO 阈值必须有限：{part}")
        if key == "goodput_req_s":
            raise ValueError("goodput_req_s 不能作为自身的 SLO 判据")
        if key not in SLO_METRICS:
            raise ValueError(f"未知 SLO 指标：{key}（可用：{', '.join(sorted(SLO_METRICS))}）")
        rules.append((key, op, value))
    return rules


def read_summary(path: Path) -> list[dict]:
    with path.open(encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    out = []
    for r in rows:
        item = {}
        for k, v in r.items():
            if k == "underloaded" and str(v).strip().lower() in ("true", "false", "1", "0"):
                item[k] = str(v).strip().lower() in ("true", "1")
                continue
            try:
                value = float(v)
                item[k] = value if math.isfinite(value) else None
            except (TypeError, ValueError):
                item[k] = None
        if item.get("rate") is None:
            raise ValueError("summary 的 rate 必须是有限数值")
        out.append(item)
    return sorted(out, key=lambda x: x["rate"])


def slo_ok(row: dict, rules: list[Rule]) -> bool:
    """缺失、空值或非有限的指标在四种比较下均不达标。"""
    for key, op, limit in rules:
        value = row.get(key)
        if value is None or not math.isfinite(value):
            return False
        if not {"<=": value <= limit, ">=": value >= limit,
                "<": value < limit, ">": value > limit}[op]:
            return False
    return True


def is_underloaded(row: dict) -> bool:
    """兼容 bench 的布尔列及外部 CSV 的数值 1；旧 summary 无该列时不排除。"""
    return row.get("underloaded") in (True, 1.0)


def fmt(v):
    if v is None:
        return ""
    if isinstance(v, float):
        return f"{v:,.1f}"
    return str(v)


def write_svg(rows: list[dict], rules, path: Path, slo_lines=("ttft_p99_ms", "tpot_p99_ms")) -> None:
    """纯标准库 SVG：左轴吞吐（req/s、goodput）、右轴 p99 延迟（ms）+ SLO 水平线。"""
    if not rows:
        raise SystemExit("summary 为空")
    w, h, pad = 860, 480, 60
    rates = [r["rate"] for r in rows]

    def points(key):
        return [r for r in rows if r.get(key) is not None and math.isfinite(r[key])]

    thr_max = max((r[k] for k in ("req_s", "goodput_req_s") for r in points(k)), default=0) * 1.15 or 1.0
    lat_values = [r[k] for k in slo_lines for r in points(k)]
    lat_values.extend(v for k, _, v in rules if k in slo_lines)
    lat_max = max(lat_values, default=0) * 1.15 or 1.0

    def x(v):
        return pad + (v - min(rates)) / (max(rates) - min(rates) + 1e-9) * (w - 2 * pad)

    def y_l(v):  # 左轴（吞吐）
        return h - pad - v / thr_max * (h - 2 * pad)

    def y_r(v):  # 右轴（延迟）
        return h - pad - v / lat_max * (h - 2 * pad)

    parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" font-family="sans-serif" font-size="12">']
    slo_text = ",".join(f"{k}{o}{v}" for k, o, v in rules) or "none"
    parts.append(f'<text x="{pad}" y="24">{escape(f"capacity curve（SLO: {slo_text}）")}</text>')
    # 网格与轴
    for i in range(5):
        yy = pad + i * (h - 2 * pad) / 4
        parts.append(f'<line x1="{pad}" y1="{yy:.1f}" x2="{w-pad}" y2="{yy:.1f}" stroke="#e0e0e0"/>')
        parts.append(f'<text x="4" y="{yy+4:.1f}" fill="#1a7f37">{thr_max*(1-i/4):.1f}</text>')
        parts.append(f'<text x="{w-pad+6}" y="{yy+4:.1f}" fill="#b35900">{lat_max*(1-i/4):.0f}ms</text>')
    for r in rows:
        parts.append(f'<text x="{x(r["rate"])-12:.1f}" y="{h-pad+18}">{r["rate"]:g}</text>')
    parts.append(f'<text x="{w//2-40}" y="{h-8}">{escape("到达率（req/s 目标）")}</text>')
    # 吞吐/goodput 折线（左轴）
    for key, color in (("req_s", "#1a7f37"), ("goodput_req_s", "#666")):
        valid = points(key)
        if not valid:
            continue
        pts = " ".join(f"{x(r['rate']):.1f},{y_l(r[key]):.1f}" for r in valid)
        parts.append(f'<polyline points="{pts}" fill="none" stroke="{color}" stroke-width="2"/>')
        parts.append(f'<text x="{pad+4}" y="{y_l(valid[0][key]) - 6:.1f}" fill="{color}">{escape(key)}</text>')
    # 延迟折线 + SLO 线（右轴）
    for key, color in (("ttft_p99_ms", "#b35900"), ("tpot_p99_ms", "#c2a300")):
        valid = points(key)
        if not valid:
            continue
        pts = " ".join(f"{x(r['rate']):.1f},{y_r(r[key]):.1f}" for r in valid)
        parts.append(f'<polyline points="{pts}" fill="none" stroke="{color}" stroke-width="2" stroke-dasharray="1,0"/>')
        for (rk, op, rv) in rules:
            if rk == key and op == "<=":
                parts.append(f'<line x1="{pad}" y1="{y_r(rv):.1f}" x2="{w-pad}" y2="{y_r(rv):.1f}" '
                             f'stroke="{color}" stroke-dasharray="6,4"/>')
                parts.append(f'<text x="{pad+4}" y="{y_r(rv)-4:.1f}" fill="{color}">{escape(f"SLO {key}{op}{rv:g}")}</text>')
    parts.append("</svg>")
    path.write_text("\n".join(parts), encoding="utf-8")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--summary", help="bench_sweep.py 产出的 summary.csv")
    ap.add_argument("--out", help="输出目录")
    ap.add_argument("--slo", default="ttft_p99_ms<=2000,tpot_p99_ms<=200",
                    help='SLO 规则（goodput 判定）；默认 "ttft_p99_ms<=2000,tpot_p99_ms<=200"')
    ap.add_argument("--self-check", action="store_true")
    args = ap.parse_args(argv)

    try:
        rules = parse_slo(args.slo)
    except ValueError as exc:
        ap.error(str(exc))
    if args.self_check:
        self_check()
        print("OK: SLO 校验、空指标、SVG XML 与发压不足排除自检")
        return 0
    if not args.summary or not args.out:
        ap.error("必须提供 --summary 和 --out")
    try:
        rows = read_summary(Path(args.summary))
    except (OSError, ValueError) as exc:
        ap.error(str(exc))
    if not rows:
        raise SystemExit("summary 为空")
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    cols = ["rate", "req_s", "out_tok_s", "ttft_p50_ms", "ttft_p99_ms", "tpot_p99_ms",
            "itl_p99_ms", "goodput_req_s", "failures", "cancels"]
    has_underloaded = any("underloaded" in r for r in rows)
    if has_underloaded:
        cols.extend(("underloaded", "recommendation_exclusion"))
        for r in rows:
            r["recommendation_exclusion"] = "underloaded（发压不足，排除推荐）" if is_underloaded(r) else ""
    cols.append("slo_ok")
    with (out / "capacity.csv").open("w", encoding="utf-8", newline="") as f:
        wtr = csv.writer(f)
        wtr.writerow(cols)
        for r in rows:
            ok = slo_ok(r, rules)
            wtr.writerow([fmt(r.get(c, "")) for c in cols[:-1]] + ["Y" if ok else "N"])
    lines = ["| " + " | ".join(cols) + " |", "|" + "---|" * len(cols)]
    for r in rows:
        ok = slo_ok(r, rules)
        lines.append("| " + " | ".join(fmt(r.get(c, "")) for c in cols[:-1]) + f" | {'✅' if ok else '❌'} |")
    (out / "capacity.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    write_svg(rows, rules, out / "capacity.svg")

    excluded = [r for r in rows if is_underloaded(r)]
    if excluded:
        print("排除发压不足（underloaded=True）档位的可持续点推荐："
              + ", ".join(f"{r['rate']:g}" for r in excluded) + " req/s；SLO 达标列仍独立保留。")
    ok_rows = [r for r in rows if slo_ok(r, rules) and not is_underloaded(r)]
    if ok_rows:
        cap = max(ok_rows, key=lambda r: r["rate"])
        print(f"可持续配置（SLO 内最大到达率）: {cap['rate']:g} req/s "
              f"(goodput {fmt(cap.get('goodput_req_s'))} req/s, "
              f"ttft_p99 {fmt(cap.get('ttft_p99_ms'))}ms, tpot_p99 {fmt(cap.get('tpot_p99_ms'))}ms)")
        print("余量建议：把运行点定在可持续到达率的 70–80%，留突发与长尾余量（15.3）。")
    else:
        print("无可推荐的可持续点（SLO 未达标或 underloaded 发压不足）——降低到达率或调整旋钮后重扫。")
    print(f"OK: {out}/capacity.csv capacity.md capacity.svg")
    return 0


def self_check() -> None:
    """覆盖真实 CSV 空指标、默认 SLO 的 XML、编码字符转义及新旧 summary。"""
    rules = parse_slo("ttft_p99_ms<=2000;tpot_p99_ms<=200")
    for key in SLO_METRICS:
        assert parse_slo(f"{key}<=2") == [(key, "<=", 2.0)]
    for invalid in ("ttft=2", "tttf_p99_ms<=2000", "ttft_p99_ms<=nan", "ttft_p99_ms<=inf",
                    "ttft_p99_ms>=-inf", "ttft_p99_ms<=1e309", "a<=b", "a<=2<=3", "goodput_req_s>0"):
        try:
            parse_slo(invalid)
        except ValueError:
            continue
        raise AssertionError(f"非法 SLO 未拒绝：{invalid}")
    for op in ("<=", ">=", "<", ">"):
        assert not slo_ok({"tpot_p99_ms": None}, parse_slo(f"tpot_p99_ms{op}200"))
        assert not slo_ok({}, parse_slo(f"tpot_p99_ms{op}200"))
    with tempfile.TemporaryDirectory(prefix="capacity-") as temporary:
        root = Path(temporary)
        summary = root / "summary.csv"
        header = "rate,req_s,goodput_req_s,ttft_p99_ms,tpot_p99_ms,underloaded\n"
        summary.write_text(header + "1,1,1,100,10,False\n2,2,2,100,10,True\n"
                           "3,0,0,,,\n4,1,0,100,not-a-number,0\n", encoding="utf-8")
        rows = read_summary(summary)
        assert rows[2]["tpot_p99_ms"] is rows[3]["tpot_p99_ms"] is None
        assert slo_ok(rows[0], rules) and slo_ok(rows[1], rules)
        assert not slo_ok(rows[2], rules) and not slo_ok(rows[3], rules)
        stream = io.StringIO()
        with contextlib.redirect_stdout(stream):
            assert main(["--summary", str(summary), "--out", str(root)]) == 0
        assert "可持续配置（SLO 内最大到达率）: 1 req/s" in stream.getvalue()
        with (root / "capacity.csv").open(encoding="utf-8", newline="") as handle:
            output = list(csv.DictReader(handle))
        assert output[1]["slo_ok"] == "Y" and "underloaded" in output[1]["recommendation_exclusion"]
        assert output[2]["tpot_p99_ms"] == "" and output[2]["slo_ok"] == "N"
        assert "None" not in (root / "capacity.md").read_text(encoding="utf-8")
        ElementTree.parse(root / "capacity.svg")
        write_svg(rows, [("<&>", "<=", 1)], root / "escaped.svg")
        assert "<&><=1" in "".join(ElementTree.parse(root / "escaped.svg").getroot().itertext())
        # 旧版无 underloaded 列时，仍推荐 SLO 内最大的档位。
        summary.write_text("rate,req_s,goodput_req_s,ttft_p99_ms,tpot_p99_ms\n"
                           "1,1,1,100,10\n2,2,2,100,10\n", encoding="utf-8")
        stream = io.StringIO()
        with contextlib.redirect_stdout(stream):
            assert main(["--summary", str(summary), "--out", str(root)]) == 0
        assert "可持续配置（SLO 内最大到达率）: 2 req/s" in stream.getvalue()


if __name__ == "__main__":
    _utf8_stdout()
    sys.exit(main())
