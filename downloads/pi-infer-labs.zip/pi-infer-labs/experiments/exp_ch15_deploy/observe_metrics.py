#!/usr/bin/env python3
"""以标准库抓取 /metrics，聚合多 worker/模型的累积桶与 token 计数。

python observe_metrics.py --base-url http://127.0.0.1:8123 --interval 1 --duration 60 --out metrics.csv
TTFT/TPOT 分位数使用累积桶内线性插值，落在 +Inf 桶时取最后有限上界。
KV 水位按完整标签去重取最大，整体列为最繁忙 worker 水位，附加 JSON 列保留标签。
缺失指标、空直方图、首个吞吐样本和 counter 重置后的吞吐留空。
退出码：0 完成/自检通过；3 目标不可达或抓取失败；2 参数/输出文件错误；
130 用户中断；1 自检断言失败。
"""

from __future__ import annotations

import argparse
import csv
import http.client
import json
import math
import os
import re
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlsplit


COLUMNS = ["ts", "num_requests_running", "num_requests_waiting", "kv_cache_usage_perc",
           "kv_cache_usage_perc_by_labels", "ttft_p50_est_ms", "ttft_p99_est_ms",
           "tpot_p50_est_ms", "tpot_p99_est_ms", "prompt_tokens_total", "generation_tokens_total", "out_tok_s"]
SAMPLE_RE = re.compile(r"^([a-zA-Z_:][a-zA-Z0-9_:]*)(?:\{(.*?)\})?\s+"
                       r"([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?|[+-]?Inf|NaN)(?:\s.*)?$")
LABEL_RE = re.compile(r'([a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*"((?:\\.|[^"\\])*)"')


@dataclass(frozen=True)
class Sample:
    """一条 Prometheus 样本，可表示 gauge、counter 或 histogram bucket。"""

    name: str
    labels: dict[str, str]
    value: float


def parse_prometheus(text: str) -> list[Sample]:
    """正则解析带标签/可选时间戳的样本；跳过注释和无法识别的行。"""
    result = []
    for line in text.splitlines():
        match = SAMPLE_RE.fullmatch(line.strip())
        if not match:
            continue
        name, raw_labels, raw_value = match.groups()
        try:
            labels = {key: json.loads('"' + value + '"') for key, value in LABEL_RE.findall(raw_labels or "")}
            result.append(Sample(name, labels, float(raw_value)))
        except (ValueError, json.JSONDecodeError):
            continue
    return result


def histogram_quantile(buckets: dict[float, float], q: float) -> float | None:
    """按累积计数插值分位数；无观察值或非单调桶不提供虚假估计。"""
    if not 0 <= q <= 1:
        raise ValueError("q 必须在 0..1")
    if not buckets:
        return None
    ordered = sorted(buckets.items())
    if any(math.isnan(bound) or bound < 0 or not math.isfinite(count) or count < 0
           for bound, count in ordered):
        return None
    if any(a[1] > b[1] for a, b in zip(ordered, ordered[1:])):
        return None
    total = ordered[-1][1]
    if total <= 0:
        return None
    rank = q * total
    lower_bound = lower_count = 0.0
    for upper_bound, upper_count in ordered:
        if rank <= upper_count:
            if math.isinf(upper_bound):
                return lower_bound if any(math.isfinite(bound) for bound in buckets) else None
            if upper_count == lower_count:
                return upper_bound
            return lower_bound + (upper_bound - lower_bound) * (rank - lower_count) / (upper_count - lower_count)
        lower_bound, lower_count = upper_bound, upper_count
    return None


def metric_row(samples: list[Sample], timestamp: float) -> dict:
    """请求数/counter 求和；KV 水位取最大并保留标签；直方图按 le 合桶。"""
    def total(*names: str) -> float | None:
        """按候选名优先级查找，避免别名同时存在时重复计数。"""
        for name in names:
            values = [sample.value for sample in samples if sample.name == name and math.isfinite(sample.value)]
            if values:
                return sum(values)
        return None

    def quantiles(name: str) -> list[float | None]:
        """模型/worker 的累积计数可按 le 相加，再用相同插值口径求分位。"""
        buckets: dict[float, float] = {}
        for sample in samples:
            if sample.name == name and "le" in sample.labels:
                try:
                    bound = float(sample.labels["le"])
                except ValueError:
                    continue
                buckets[bound] = buckets.get(bound, 0.0) + sample.value
        estimates = [histogram_quantile(buckets, q) for q in (0.5, 0.99)]
        return [value * 1000 if value is not None else None for value in estimates]

    cache_by_labels: dict[tuple[tuple[str, str], ...], float] = {}
    # 比例不是可加计数：同一完整标签取最大；跨 worker 的摘要也取最大，避免 60%+60%=120%。
    # 保留全部原始标签，供下游按 engine/worker 观察；无标签时摘要就是原值。
    for name in ("vllm:kv_cache_usage_perc", "vllm:gpu_cache_usage_perc"):
        for sample in samples:
            if sample.name == name and math.isfinite(sample.value):
                labels = tuple(sorted(sample.labels.items()))
                cache_by_labels[labels] = max(cache_by_labels.get(labels, sample.value), sample.value)
        if cache_by_labels:
            break  # 新旧指标名同时出现时优先使用新名，不重复聚合。
    cache_details = (json.dumps([{"labels": dict(labels), "value": value}
                                for labels, value in sorted(cache_by_labels.items())], ensure_ascii=False)
                     if any(cache_by_labels) else None)
    return dict(zip(COLUMNS, [timestamp, total("vllm:num_requests_running"),
        total("vllm:num_requests_waiting"), max(cache_by_labels.values(), default=None), cache_details,
        *quantiles("vllm:time_to_first_token_seconds_bucket"),
        *quantiles("vllm:request_time_per_output_token_seconds_bucket"),
        total("vllm:prompt_tokens_total"), total("vllm:generation_tokens_total"), None]))


def output_rate(previous: tuple[float, float] | None, current: tuple[float, float]) -> float | None:
    """按单调时钟间隔计算 counter 差分，重置后的第一个样本留空。"""
    if previous is None or current[0] <= previous[0] or current[1] < previous[1]:
        return None
    return (current[1] - previous[1]) / (current[0] - previous[0])


@dataclass(frozen=True)
class Config:
    """启动前校验 URL、抓取节奏与总持续时间。"""

    base_url: str = "http://127.0.0.1:8000"
    interval: float = 1.0
    duration: float = 60.0
    out: Path = Path("metrics.csv")
    timeout: float = 5.0

    def __post_init__(self) -> None:
        """拒绝非法 URL 与非正/非有限时间参数。"""
        parsed = urlsplit(self.base_url)
        if (parsed.scheme not in ("http", "https") or not parsed.hostname
                or parsed.username is not None or parsed.password is not None or parsed.query or parsed.fragment):
            raise ValueError("base-url 必须是无凭据、查询串和片段的 http(s) URL")
        if parsed.port is not None and not 1 <= parsed.port <= 65535:
            raise ValueError("base-url 端口必须在 1..65535")
        if any(type(value) not in (int, float) or not math.isfinite(value) or value <= 0
               for value in (self.interval, self.duration, self.timeout)):
            raise ValueError("interval/duration/timeout 必须为有限正数")


def fetch(config: Config) -> str:
    """以独立连接抓取一个快照，可用 OPENAI_API_KEY 访问有认证的服务。"""
    parsed = urlsplit(config.base_url)
    secure = parsed.scheme == "https"
    cls = http.client.HTTPSConnection if secure else http.client.HTTPConnection
    connection = cls(parsed.hostname, parsed.port or (443 if secure else 80), timeout=config.timeout)
    prefix = parsed.path.rstrip("/")
    if prefix.endswith("/v1"):
        prefix = prefix[:-3]
    api_key = os.environ.get("OPENAI_API_KEY", "")
    try:
        connection.request("GET", prefix + "/metrics",
                           headers={"Authorization": f"Bearer {api_key}"} if api_key else {})
        response = connection.getresponse()
        if response.status != 200:
            raise ConnectionError(f"/metrics HTTP {response.status}")
        return response.read().decode("utf-8")
    finally:
        connection.close()


def observe(config: Config) -> int:
    """按目标节奏采样；慢抓取跳过错过的采样点，不补发突发请求。"""
    config.out.parent.mkdir(parents=True, exist_ok=True)
    start = time.perf_counter()
    previous = None
    target = 0.0
    count = 0
    with config.out.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=COLUMNS)
        writer.writeheader()
        while target < config.duration:
            remaining = start + target - time.perf_counter()
            if remaining > 0:
                time.sleep(remaining)
            try:
                samples = parse_prometheus(fetch(config))
            except (OSError, http.client.HTTPException, UnicodeError) as exc:
                print(f"抓取失败：{exc}", file=sys.stderr)
                return 3
            now = time.perf_counter()
            row = metric_row(samples, time.time())
            if row["generation_tokens_total"] is not None:
                current = (now, row["generation_tokens_total"])
                row["out_tok_s"] = output_rate(previous, current)
                previous = current
            else:
                previous = None
            writer.writerow(row)
            handle.flush()
            count += 1
            target = max(target + config.interval,
                         (math.floor((now - start) / config.interval) + 1) * config.interval)
    print(f"OK: {count} 个指标快照 -> {config.out}")
    return 0


def self_check() -> None:
    """手算桶内插值与 counter 差分，覆盖标签、时间戳、空桶及重置。"""
    text = '''# TYPE vllm:num_requests_running gauge
vllm:num_requests_running{model_name="m"} 2
vllm:num_requests_waiting 3
vllm:time_to_first_token_seconds_bucket{model_name="m",le="0.1"} 2
vllm:time_to_first_token_seconds_bucket{le="0.5",model_name="m"} 6
vllm:time_to_first_token_seconds_bucket{le="1"} 10
vllm:time_to_first_token_seconds_bucket{le="+Inf"} 10
vllm:prompt_tokens_total 1.2e2 123456
vllm:generation_tokens_total 40
vllm:request_time_per_output_token_seconds_bucket{engine="0",le="0.01"} 1
vllm:request_time_per_output_token_seconds_bucket{engine="0",le="0.05"} 3
vllm:request_time_per_output_token_seconds_bucket{engine="0",le="0.1"} 5
vllm:request_time_per_output_token_seconds_bucket{engine="0",le="+Inf"} 5
vllm:request_time_per_output_token_seconds_bucket{engine="1",le="0.01"} 1
vllm:request_time_per_output_token_seconds_bucket{engine="1",le="0.05"} 3
vllm:request_time_per_output_token_seconds_bucket{engine="1",le="0.1"} 5
vllm:request_time_per_output_token_seconds_bucket{engine="1",le="+Inf"} 5
'''
    samples = parse_prometheus(text)
    row = metric_row(samples, 1.0)
    assert row["num_requests_running"] == 2 and row["num_requests_waiting"] == 3
    assert row["kv_cache_usage_perc"] is None and row["out_tok_s"] is None
    assert math.isclose(row["ttft_p50_est_ms"], 400.0)
    assert math.isclose(row["ttft_p99_est_ms"], 987.5)
    # TPOT 合桶为 {0.01:2, 0.05:6, 0.1:10, +Inf:10}：
    # p50=.01+(.05-.01)*(5-2)/(6-2)=.04s；p99=.05+.05*(9.9-6)/4=.09875s。
    assert math.isclose(row["tpot_p50_est_ms"], 40.0)
    assert math.isclose(row["tpot_p99_est_ms"], 98.75)
    assert row["prompt_tokens_total"] == 120 and row["generation_tokens_total"] == 40
    assert any(sample.name.endswith("per_output_token_seconds_bucket") for sample in samples)
    assert histogram_quantile({0.1: 0, float("inf"): 0}, 0.5) is None
    assert histogram_quantile({0.1: 2, 0.5: 6, float("inf"): 10}, 0.99) == 0.5
    assert output_rate((10, 40), (12, 50)) == 5 and output_rate((10, 40), (12, 3)) is None
    assert metric_row(samples + samples, 1)["generation_tokens_total"] == 80
    assert math.isclose(metric_row(samples + samples, 1)["tpot_p99_est_ms"], 98.75)
    cache = parse_prometheus('''vllm:kv_cache_usage_perc{engine="0",worker="0"} 0.6
vllm:kv_cache_usage_perc{engine="0",worker="1"} 0.6
vllm:kv_cache_usage_perc{engine="0",worker="0"} 0.5
vllm:gpu_cache_usage_perc 0.9
''')
    cache_row = metric_row(cache, 1)
    assert cache_row["kv_cache_usage_perc"] == 0.6
    assert json.loads(cache_row["kv_cache_usage_perc_by_labels"]) == [
        {"labels": {"engine": "0", "worker": "0"}, "value": 0.6},
        {"labels": {"engine": "0", "worker": "1"}, "value": 0.6}]
    plain_cache = metric_row(parse_prometheus("vllm:gpu_cache_usage_perc 0.7"), 1)
    assert plain_cache["kv_cache_usage_perc"] == 0.7 and plain_cache["kv_cache_usage_perc_by_labels"] is None
    empty = metric_row([], 1)
    assert empty["tpot_p50_est_ms"] is empty["tpot_p99_est_ms"] is None
    assert list(row) == COLUMNS


def main(argv: list[str] | None = None) -> int:
    """解析参数并按明确退出码报告抓取或文件错误。"""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", default="http://127.0.0.1:8000")
    parser.add_argument("--interval", type=float, default=1.0)
    parser.add_argument("--duration", type=float, default=60.0)
    parser.add_argument("--out", type=Path, default=Path("metrics.csv"))
    parser.add_argument("--timeout", type=float, default=5.0)
    parser.add_argument("--self-check", action="store_true")
    args = parser.parse_args(argv)
    try:
        config = Config(**{key: value for key, value in vars(args).items() if key != "self_check"})
    except ValueError as exc:
        parser.error(str(exc))
    if args.self_check:
        self_check()
        print("OK: Prometheus 解析、TTFT/TPOT 手算插值、KV 标签水位与 counter 差分自检")
        return 0
    try:
        return observe(config)
    except KeyboardInterrupt:
        return 130
    except OSError as exc:
        print(f"输出文件错误：{exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
