#!/usr/bin/env python3
"""独立 OpenAI SSE 压测器：asyncio 调度，http.client 在线程中执行阻塞 I/O。

python bench_sweep.py --base-url http://127.0.0.1:8123 --model mock \
    --rates 1,2,4,8 --num-prompts 64 --concurrency 16 --input-len 256 \
    --output-len 64 --slo 'ttft_p99_ms<=2000,tpot_p99_ms<=200' --out results/

时间戳均为每档开始后的 perf_counter 秒数，meta 保存对应 UTC/Unix 起点。
TTFT 从实际发出算起；TPOT=(最后 token-首 token)/(输出 token 数-1)。
单 token 的 TPOT/ITL 没有定义，写空值；需要这些指标的 SLO 判为不达标。
pXX 使用排序后 (N-1)*q 的线性插值。吞吐分母含客户端积压和停压后的排空段。
goodput 对每个请求同时应用全部规则：ttft_pXX 代入该请求 TTFT，tpot_pXX
代入该请求 TPOT，itl_pXX 代入该请求 ITL 分位数；其余汇总列使用该档数值。

SSE 不承诺每个 content delta 恰为一个模型 token。mock 的逐 token 时间精确；
真实端点若合并 token，只能记录 delta 到达时刻，明确标为 chunk 观测，不能还原
帧内 token 的 ITL。输出 token 总数优先取 usage，缺失时以内容帧数作代理并告警。
输入长度同样是合成词数，未声称是任意模型 tokenizer 的精确 token 数。

退出码：0 所有请求成功（SLO 不达标仍为 0）；2 请求失败/取消或参数、文件错误；
3 连接建立失败（优先于 2）；4 SLO 解析错误；1 自检断言失败。
"""

from __future__ import annotations

import argparse
import asyncio
import concurrent.futures
import csv
import http.client
import json
import math
import os
import platform
import random
import re
import socket
import sys
import threading
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit


SUMMARY_COLUMNS = ["rate", "req_s", "out_tok_s", "ttft_p50_ms", "ttft_p99_ms", "tpot_p99_ms",
                   "itl_p99_ms", "goodput_req_s", "failures", "cancels", "max_wait", "drain_s", "underloaded"]
# 与 capacity_curve 保持一致：含当前输出的全部分位字段，排除循环定义的 goodput。
SLO_METRICS = frozenset(SUMMARY_COLUMNS) - {"goodput_req_s"}
Rule = tuple[str, str, float]


def parse_slo(text: str) -> list[Rule]:
    """与 capacity_curve 同语义：指标白名单、四种比较运算和有限阈值。"""
    rules = []
    for part in text.replace(";", ",").split(","):
        if not part.strip():
            continue
        match = re.fullmatch(r"\s*([A-Za-z_][\w]*)\s*(<=|>=|<|>)\s*(\S+)\s*", part)
        if not match:
            raise ValueError(f"SLO 规则不认识：{part}（形如 ttft_p99_ms<=2000）")
        key, op, raw_value = match.groups()
        try:
            value = float(raw_value)
        except ValueError as exc:
            raise ValueError(f"SLO 阈值不是数字：{part}") from exc
        if not math.isfinite(value):
            raise ValueError(f"SLO 阈值必须有限：{part}")
        if key == "goodput_req_s":
            raise ValueError("goodput_req_s 不能作为自身的 SLO 判据")
        if key not in SLO_METRICS:
            raise ValueError(f"未知 SLO 指标：{key}（可用：{', '.join(sorted(SLO_METRICS))}）")
        rules.append((key, op, value))
    return rules


def slo_ok(row: dict, rules: list[Rule]) -> bool:
    """与容量曲线一样合取全部规则，缺失或无定义的指标判为不达标。"""
    for key, op, limit in rules:
        value = row.get(key)
        if value is None or not math.isfinite(value):
            return False
        if not {"<=": value <= limit, ">=": value >= limit,
                "<": value < limit, ">": value > limit}[op]:
            return False
    return True


def percentile(values: list[float], q: float) -> float | None:
    """按 (N-1)*q 插值；空样本不伪造零延迟。"""
    if not 0 <= q <= 1:
        raise ValueError("分位数必须在 0..1")
    if not values:
        return None
    ordered = sorted(values)
    position = (len(ordered) - 1) * q
    lower = math.floor(position)
    upper = math.ceil(position)
    return ordered[lower] + (ordered[upper] - ordered[lower]) * (position - lower)


def arrival_trace(rate: float, count: int, kind: str, seed: int) -> list[float]:
    """首个目标为零，后续使用指数间隔或 1/rate 固定间隔，数量严格为 count。"""
    if not math.isfinite(rate) or rate <= 0 or count < 1 or kind not in ("poisson", "fixed"):
        raise ValueError("到达率/数量/轨迹类型非法")
    rng = random.Random(seed)
    result = [0.0]
    for _ in range(count - 1):
        result.append(result[-1] + (rng.expovariate(rate) if kind == "poisson" else 1 / rate))
    return result


@dataclass(frozen=True)
class Endpoint:
    """解析服务地址；同时接受主机根地址和以 /v1 结尾的 base URL。"""

    base_url: str
    host: str = field(init=False)
    port: int = field(init=False)
    secure: bool = field(init=False)
    chat_path: str = field(init=False)
    metrics_path: str = field(init=False)

    def __post_init__(self) -> None:
        """拒绝凭据、查询串、片段及不支持的 URL scheme。"""
        parsed = urlsplit(self.base_url)
        if (parsed.scheme not in ("http", "https") or not parsed.hostname
                or parsed.username is not None or parsed.password is not None
                or parsed.query or parsed.fragment):
            raise ValueError("base-url 必须是无凭据、查询串和片段的 http(s) 地址")
        secure = parsed.scheme == "https"
        port = parsed.port if parsed.port is not None else (443 if secure else 80)
        if not 1 <= port <= 65535:
            raise ValueError("base-url 端口非法")
        prefix = parsed.path.rstrip("/")
        root = prefix[:-3] if prefix.endswith("/v1") else prefix
        for name, value in (("host", parsed.hostname), ("port", port), ("secure", secure),
                            ("chat_path", root + "/v1/chat/completions"),
                            ("metrics_path", root + "/metrics")):
            object.__setattr__(self, name, value)

    def connection(self, timeout: float) -> http.client.HTTPConnection:
        """每个请求使用独立连接，不跨线程复用 http.client 连接。"""
        cls = http.client.HTTPSConnection if self.secure else http.client.HTTPConnection
        return cls(self.host, self.port, timeout=timeout)


@dataclass(frozen=True)
class Config:
    """在发出任何请求前完成全部压测参数校验。"""

    base_url: str
    model: str
    rates: tuple[float, ...]
    num_prompts: int = 64
    concurrency: int = 16
    input_len: int = 256
    output_len: int = 64
    slo: str = "ttft_p99_ms<=2000,tpot_p99_ms<=200"
    out: Path = Path("results")
    warmup: int = 4
    seed: int = 0
    arrival: str = "poisson"
    prompt_file: Path | None = None
    timeout: float = 60.0
    metrics_interval: float = 0.2

    def __post_init__(self) -> None:
        """拒绝空模型、重复档位、非正规模与无限时间参数。"""
        Endpoint(self.base_url)
        if (not isinstance(self.model, str) or not self.model.strip() or not self.rates
                or len(set(self.rates)) != len(self.rates)):
            raise ValueError("model/rates 不能为空，rates 不可重复")
        if any(type(rate) not in (int, float) or not math.isfinite(rate) or rate <= 0 for rate in self.rates):
            raise ValueError("rates 必须是有限正数")
        if any(type(value) is not int or value < 1
               for value in (self.num_prompts, self.concurrency, self.input_len, self.output_len)):
            raise ValueError("num-prompts/concurrency/input-len/output-len 必须大于零")
        if (type(self.warmup) is not int or self.warmup < 0 or type(self.seed) is not int
                or self.arrival not in ("poisson", "fixed")):
            raise ValueError("warmup 必须非负，arrival 必须是 poisson 或 fixed")
        if any(type(value) not in (int, float) or not math.isfinite(value) or value <= 0
               for value in (self.timeout, self.metrics_interval)):
            raise ValueError("timeout/metrics-interval 必须是有限正数")
        if self.prompt_file is not None and not self.prompt_file.is_file():
            raise ValueError(f"prompt-file 不存在：{self.prompt_file}")


@dataclass
class RequestRecord:
    """逐请求审计记录；四时刻和逐内容 token 帧时间使用相同相对时钟。"""

    id: int
    target_arrival_s: float
    actual_send_s: float | None = None
    first_token_s: float | None = None
    token_times_s: list[float] = field(default_factory=list)
    completed_s: float | None = None
    status: str = "pending"
    error: str | None = None
    connection_error: bool = False
    output_tokens: int = 0
    token_count_source: str = "unavailable"
    timing_granularity: str = "content_delta"
    client_wait_s: float | None = None
    connect_start_s: float | None = None

    def __post_init__(self) -> None:
        """拒绝负请求编号及非法目标时刻。"""
        if self.id < 0 or not math.isfinite(self.target_arrival_s) or self.target_arrival_s < 0:
            raise ValueError("请求编号/目标时刻非法")


def request_latencies(record: RequestRecord) -> tuple[float | None, float | None, list[float]]:
    """返回毫秒 TTFT、TPOT 与各相邻内容 token 帧 ITL，避免请求加权 ITL。"""
    ttft = ((record.first_token_s - record.actual_send_s) * 1000
            if record.first_token_s is not None and record.actual_send_s is not None else None)
    tpot = ((record.token_times_s[-1] - record.token_times_s[0]) * 1000 / (record.output_tokens - 1)
            if len(record.token_times_s) > 1 and record.output_tokens > 1 else None)
    itl = [(right - left) * 1000 for left, right in zip(record.token_times_s, record.token_times_s[1:])]
    return ttft, tpot, itl


def summarize(records: list[RequestRecord], rate: float, rules: list[Rule],
              elapsed: float, stop_s: float, max_wait: int, underloaded: bool = False) -> dict:
    """用成功请求计算延迟与吞吐，失败/取消单列；分母覆盖最后完成时刻。"""
    if elapsed <= 0 or stop_s < 0 or max_wait < 0:
        raise ValueError("汇总计时/等待深度非法")
    successful = [record for record in records if record.status == "success"]
    samples = [request_latencies(record) for record in successful]
    ttfts = [ttft for ttft, _, _ in samples if ttft is not None]
    tpots = [tpot for _, tpot, _ in samples if tpot is not None]
    itls = [value for _, _, values in samples for value in values]
    row = dict(zip(SUMMARY_COLUMNS, [rate, len(successful) / elapsed,
        sum(record.output_tokens for record in successful) / elapsed,
        percentile(ttfts, 0.5), percentile(ttfts, 0.99), percentile(tpots, 0.99),
        percentile(itls, 0.99), 0.0,
        sum(record.status == "failed" for record in records),
        sum(record.status == "cancelled" for record in records), max_wait, max(0.0, elapsed - stop_s), underloaded]))
    good = 0
    for ttft, tpot, itl in samples:
        request_row = {**row, "ttft_p50_ms": ttft, "ttft_p99_ms": ttft,
                       "tpot_p99_ms": tpot, "itl_p99_ms": percentile(itl, 0.99)}
        good += slo_ok(request_row, rules)
    row["goodput_req_s"] = good / elapsed
    return row


def make_prompts(config: Config) -> list[str]:
    """确定性合成单词序列，或循环使用 UTF-8 逐行文本/JSONL prompt 文件。"""
    if config.prompt_file is not None:
        prompts = []
        for number, line in enumerate(config.prompt_file.read_text(encoding="utf-8-sig").splitlines(), 1):
            if not line.strip():
                continue
            if config.prompt_file.suffix.lower() == ".jsonl":
                value = json.loads(line)
                line = value if isinstance(value, str) else value.get("prompt", value.get("text")) if isinstance(value, dict) else None
            if not isinstance(line, str) or not line.strip():
                raise ValueError(f"prompt-file 第 {number} 行不是非空 prompt 字符串")
            prompts.append(line)
        if not prompts:
            raise ValueError("prompt-file 没有有效 prompt")
        return [prompts[index % len(prompts)] for index in range(config.num_prompts)]
    rng = random.Random(config.seed)
    return [" ".join(f"w{rng.randrange(65536):05d}" for _ in range(config.input_len))
            for _ in range(config.num_prompts)]


class Transport:
    """执行 SSE 与指标 HTTP I/O，并允许取消时主动关闭工作线程连接。"""

    def __init__(self, endpoint: Endpoint, config: Config) -> None:
        """保存只读配置与活跃连接表；凭据仅从环境读取，不写 meta。"""
        self.endpoint, self.config = endpoint, config
        self.api_key = os.environ.get("OPENAI_API_KEY", "")
        self.lock = threading.Lock()
        self.active: dict[int, http.client.HTTPConnection] = {}
        self.cancelled = threading.Event()

    def cancel(self) -> None:
        """取消所有已连接的请求，唤醒正在读 SSE 的线程。"""
        self.cancelled.set()
        with self.lock:
            for connection in self.active.values():
                if connection.sock is not None:
                    try:
                        connection.sock.shutdown(socket.SHUT_RDWR)
                    except OSError:
                        pass
                connection.close()

    def send(self, record: RequestRecord, prompt: str, origin: float) -> None:
        """一个内容 delta 记一个到达时刻，usage 只负责输出 token 总数。"""
        connection = self.endpoint.connection(self.config.timeout)
        with self.lock:
            self.active[record.id] = connection
        usage_tokens = None
        connected = False
        try:
            if self.cancelled.is_set():
                record.status = "cancelled"
                return
            record.connect_start_s = time.perf_counter() - origin
            connection.connect()
            connected = True
            if self.cancelled.is_set():
                record.status = "cancelled"
                return
            payload = json.dumps({"model": self.config.model, "messages": [{"role": "user", "content": prompt}],
                "max_tokens": self.config.output_len, "temperature": 0, "stream": True,
                "stream_options": {"include_usage": True}, "seed": self.config.seed + record.id, "n": 1}).encode()
            headers = {"Content-Type": "application/json", "Accept": "text/event-stream"}
            if self.api_key:
                headers["Authorization"] = f"Bearer {self.api_key}"
            record.actual_send_s = time.perf_counter() - origin
            record.client_wait_s = max(0.0, record.actual_send_s - record.target_arrival_s)
            record.status = "running"
            connection.request("POST", self.endpoint.chat_path, payload, headers)
            response = connection.getresponse()
            if response.status != 200:
                raise ValueError(f"HTTP {response.status}: {response.read(1024).decode('utf-8', 'replace')}")
            if "text/event-stream" not in response.getheader("Content-Type", "").lower():
                raise ValueError("服务未返回 SSE；无法测量逐 token 时间")
            event_lines: list[str] = []
            done = False
            while not done:
                if time.perf_counter() - origin - record.actual_send_s > self.config.timeout:
                    raise TimeoutError("请求总时长超过 timeout")
                raw_line = response.readline()
                if not raw_line:
                    raise ValueError("SSE 在 [DONE] 前断开")
                line = raw_line.decode("utf-8").rstrip("\r\n")
                if line.startswith("data:"):
                    event_lines.append(line[5:].lstrip(" "))
                elif not line and event_lines:
                    data = "\n".join(event_lines)
                    event_lines.clear()
                    if data == "[DONE]":
                        done = True
                        continue
                    chunk = json.loads(data)
                    if chunk.get("error"):
                        raise ValueError(f"SSE error: {chunk['error']}")
                    usage = chunk.get("usage") or {}
                    if "completion_tokens" in usage:
                        usage_tokens = usage["completion_tokens"]
                        if type(usage_tokens) is not int or usage_tokens < 0:
                            raise ValueError("usage.completion_tokens 非法")
                    for choice in chunk.get("choices", []):
                        if choice.get("index", 0) != 0:
                            continue
                        delta = choice.get("delta") or {}
                        if any(delta.get(key) for key in ("content", "reasoning_content", "reasoning")):
                            now = time.perf_counter() - origin
                            record.first_token_s = now if record.first_token_s is None else record.first_token_s
                            record.token_times_s.append(now)
            if not record.token_times_s:
                raise ValueError("请求未产生内容 token")
            record.output_tokens = usage_tokens if usage_tokens is not None else len(record.token_times_s)
            if record.output_tokens < 1:
                raise ValueError("有内容的请求 completion_tokens 必须大于 0")
            record.token_count_source = "usage" if usage_tokens is not None else "content_delta_proxy"
            record.timing_granularity = ("one_delta_per_token" if usage_tokens == len(record.token_times_s)
                                         else "content_delta")
            record.status = "success"
        except (OSError, http.client.HTTPException, ValueError, TypeError, KeyError, AttributeError) as exc:
            record.status = "cancelled" if self.cancelled.is_set() else "failed"
            record.connection_error = not connected and not self.cancelled.is_set()
            record.error = f"{type(exc).__name__}: {exc}"
        finally:
            record.completed_s = time.perf_counter() - origin
            with self.lock:
                self.active.pop(record.id, None)
            connection.close()

    def waiting_depth(self) -> int | None:
        """读取所有模型/worker 的等待 gauge；端点缺失时回退到客户端观测。"""
        connection = self.endpoint.connection(min(self.config.timeout, 1.0))
        try:
            headers = {"Authorization": f"Bearer {self.api_key}"} if self.api_key else {}
            connection.request("GET", self.endpoint.metrics_path, headers=headers)
            response = connection.getresponse()
            if response.status != 200:
                return None
            text = response.read().decode("utf-8")
            values = re.findall(r"^vllm:num_requests_waiting(?:\{[^\n]*\})?\s+([\d.eE+\-]+)", text, re.M)
            return int(sum(float(value) for value in values)) if values else None
        except (OSError, http.client.HTTPException, ValueError):
            return None
        finally:
            connection.close()


async def run_rate(config: Config, prompts: list[str], rate: float, rules: list[Rule],
                   warmup: bool = False) -> tuple[dict, list[RequestRecord], dict]:
    """独立调度全部目标到达，Semaphore 只限制实际并发，不推迟目标轨迹。"""
    trace = arrival_trace(rate, config.num_prompts, config.arrival, config.seed)
    records = [RequestRecord(index, target) for index, target in enumerate(trace)]
    transport = Transport(Endpoint(config.base_url), config)
    semaphore = asyncio.Semaphore(config.concurrency)
    origin = time.perf_counter()
    epoch = time.time()
    stopped = asyncio.Event()
    max_client_wait = max_server_wait = 0
    metrics_samples = 0
    cancelled = False

    async def issue(record: RequestRecord) -> None:
        """先等目标时刻，再等并行槽；取消后仍等待线程完成回收。"""
        nonlocal max_client_wait
        worker = None
        try:
            # Windows 的事件循环时钟可能按约 15ms 粒度提前唤醒定时器。
            # 每次唤醒都复核高精度时钟，不能把目标轨迹提前成突发发压。
            while True:
                remaining = record.target_arrival_s - (time.perf_counter() - origin)
                if remaining <= 0:
                    break
                await asyncio.sleep(max(remaining, 0.001))
            record.status = "waiting"
            pending = sum(item.status == "waiting" for item in records)
            max_client_wait = max(max_client_wait, pending if semaphore.locked() else max(0, pending - 1))
            async with semaphore:
                record.status = "connecting"
                worker = asyncio.create_task(asyncio.to_thread(transport.send, record, prompts[record.id], origin))
                await asyncio.shield(worker)
        except asyncio.CancelledError:
            transport.cancel()
            if worker is not None:
                await worker
            record.status = "cancelled"
            record.completed_s = time.perf_counter() - origin

    async def monitor() -> None:
        """定期抓取服务端等待深度；不把抓取失败算作压测请求失败。"""
        nonlocal max_server_wait, metrics_samples
        while not stopped.is_set():
            depth = await asyncio.to_thread(transport.waiting_depth)
            if depth is not None:
                max_server_wait = max(max_server_wait, depth)
                metrics_samples += 1
            try:
                await asyncio.wait_for(stopped.wait(), timeout=config.metrics_interval)
            except TimeoutError:
                pass

    tasks = [asyncio.create_task(issue(record)) for record in records]
    observer = asyncio.create_task(monitor())
    try:
        await asyncio.gather(*tasks)
    except asyncio.CancelledError:
        cancelled = True
        transport.cancel()
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
    finally:
        stopped.set()
        await observer
    elapsed = max((record.completed_s or 0.0 for record in records), default=0.0)
    elapsed = max(elapsed, 1e-9)
    max_wait = max_server_wait if metrics_samples else max_client_wait
    lags = [record.client_wait_s * 1000 for record in records if record.client_wait_s is not None]
    lag_p99 = percentile(lags, 0.99)
    underloaded = lag_p99 is not None and lag_p99 > max(50.0, 100.0 / rate)
    row = summarize(records, rate, rules, elapsed, trace[-1], max_wait, underloaded)
    details = {"rate": rate, "warmup": warmup, "origin_unix_s": epoch,
        "origin_utc": datetime.fromtimestamp(epoch, timezone.utc).isoformat(),
        "elapsed_s": elapsed, "target_stop_s": trace[-1],
        "actual_stop_s": max((record.actual_send_s or 0.0 for record in records), default=0.0),
        "client_send_lag_p99_ms": lag_p99, "max_client_wait": max_client_wait,
        "max_server_wait": max_server_wait if metrics_samples else None,
        "max_wait_source": "server_metrics" if metrics_samples else "client_pending",
        "metrics_samples": metrics_samples,
        "underloaded": underloaded,
        "cancelled": cancelled,
        "token_timing_approximate": any(record.status == "success" and
            record.timing_granularity != "one_delta_per_token" for record in records)}
    return row, records, details


def save_records(path: Path, records: list[RequestRecord]) -> None:
    """按目标到达顺序写 JSONL，失败和取消记录同样保留。"""
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for record in records:
            handle.write(json.dumps(asdict(record), ensure_ascii=False, allow_nan=False) + "\n")


async def run_sweep(config: Config, rules: list[Rule], arguments: dict) -> int:
    """预热一次，逐档扫描、落盘、排空；连接错误具有最高运行期退出优先级。"""
    loop = asyncio.get_running_loop()
    # 避免默认线程池上限把较大的 concurrency 悄悄变成客户端瓶颈。
    loop.set_default_executor(concurrent.futures.ThreadPoolExecutor(max_workers=config.concurrency + 2))
    prompts = make_prompts(config)
    config.out.mkdir(parents=True, exist_ok=True)
    meta = {"arguments": arguments, "config": asdict(config), "slo_rules": rules,
        "environment": {"python": sys.version, "platform": platform.platform(),
                        "cpu_count": os.cpu_count(), "cwd": str(Path.cwd()),
                        "api_key_present": bool(os.environ.get("OPENAI_API_KEY"))},
        "clock": "perf_counter 相对每档起点的秒；origin_unix_s 用于跨文件对时",
        "metric_conventions": {"percentile": "(N-1)*q 线性插值", "ttft_origin": "actual_send_s",
            "throughput_window": "首个目标到达至最后完成，含排空", "input_len_unit": "synthetic_words",
            "token_times": "每个非空内容/推理 delta；帧内 token 的时间不可恢复",
            "max_wait": "优先服务端 gauge；无可用 /metrics 时为客户端待发请求深度"},
        "warmup": None, "rates": []}
    exit_code = 0
    try:
        if config.warmup:
            warm = Config(**{**asdict(config), "num_prompts": config.warmup, "warmup": 0, "arrival": "fixed"})
            _, records, details = await run_rate(warm, [prompts[i % len(prompts)] for i in range(config.warmup)],
                                                  max(config.rates), rules, warmup=True)
            save_records(config.out / "warmup.jsonl", records)
            meta["warmup"] = details
            if any(record.status != "success" for record in records):
                exit_code = 3 if any(record.connection_error for record in records) else 2
            if details["cancelled"]:
                exit_code = exit_code or 2
                return exit_code
        with (config.out / "summary.csv").open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=SUMMARY_COLUMNS)
            writer.writeheader()
            handle.flush()
            for rate in config.rates:
                row, records, details = await run_rate(config, prompts, rate, rules)
                label = str(rate).removesuffix(".0")
                save_records(config.out / f"requests_{label}.jsonl", records)
                writer.writerow(row)
                handle.flush()
                meta["rates"].append(details)
                if any(record.connection_error for record in records):
                    exit_code = 3
                elif any(record.status != "success" for record in records) and exit_code == 0:
                    exit_code = 2
                print(f"rate={rate:g} req/s={row['req_s']:.3f} goodput={row['goodput_req_s']:.3f} "
                      f"failures={row['failures']} cancels={row['cancels']} drain={row['drain_s']:.3f}s", flush=True)
                if details["underloaded"]:
                    print(f"发压不足：实际发出延迟 p99={details['client_send_lag_p99_ms']:.1f}ms；"
                          "目标率不能视为实际到达率，请查看 JSONL 与 meta。", file=sys.stderr)
                if details["token_timing_approximate"]:
                    print("逐 token 计时含内容帧代理：usage 缺失或帧数与 token 数不一致。", file=sys.stderr)
                if details["cancelled"]:
                    break
    finally:
        meta["exit_code"] = exit_code
        (config.out / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2,
            default=str, allow_nan=False) + "\n", encoding="utf-8")
    return exit_code


def self_check() -> None:
    """不用服务，手算三个请求的分位数、吞吐与同时达标 goodput。"""
    assert parse_slo("ttft_p99_ms<=250; tpot_p99_ms>=10") == [
        ("ttft_p99_ms", "<=", 250.0), ("tpot_p99_ms", ">=", 10.0)]
    assert parse_slo("req_s>1,failures<2") == [("req_s", ">", 1.0), ("failures", "<", 2.0)]
    for key in SLO_METRICS:
        assert parse_slo(f"{key}<=2") == [(key, "<=", 2.0)]
    for invalid in ("ttft=2", "tttf_p99_ms<=2000", "ttft_p99_ms<=nan", "ttft_p99_ms<=inf",
                    "ttft_p99_ms>=-inf", "ttft_p99_ms<=1e309", "a<=b", "a<=2<=3", "goodput_req_s>0"):
        try:
            parse_slo(invalid)
        except ValueError:
            continue
        raise AssertionError(f"非法 SLO 未拒绝：{invalid}")
    assert arrival_trace(2, 4, "fixed", 0) == [0, 0.5, 1, 1.5]
    poisson = arrival_trace(2, 20, "poisson", 7)
    assert len(poisson) == 20 and all(a < b for a, b in zip(poisson, poisson[1:]))
    assert poisson == arrival_trace(2, 20, "poisson", 7)
    records = [RequestRecord(index, target, actual_send_s=target, first_token_s=tokens[0],
        token_times_s=tokens, completed_s=done, status="success", output_tokens=3)
        for index, (target, tokens, done) in enumerate([
            (0.0, [0.1, 0.2, 0.3], 0.4), (0.5, [0.7, 1.0, 1.3], 1.4),
            (1.0, [1.4, 1.9, 2.4], 2.5)])]
    row = summarize(records, 2, parse_slo("ttft_p99_ms<=250,tpot_p99_ms<=350"), 2.5, 1, 0)
    for key, expected in {"req_s": 1.2, "out_tok_s": 3.6, "ttft_p50_ms": 200,
                          "ttft_p99_ms": 396, "tpot_p99_ms": 496, "itl_p99_ms": 500,
                          "goodput_req_s": 0.8, "drain_s": 1.5}.items():
        assert math.isclose(row[key], expected, abs_tol=1e-9), (key, row[key], expected)
    assert list(row) == SUMMARY_COLUMNS
    records[0].status = "failed"
    records[1].status = "cancelled"
    row = summarize(records, 2, [], 2.5, 1, 4)
    assert row["failures"] == row["cancels"] == 1 and row["max_wait"] == 4
    assert math.isclose(row["req_s"], 0.4)
    assert not slo_ok({"tpot_p99_ms": None}, parse_slo("tpot_p99_ms<=200"))
    assert not slo_ok({}, parse_slo("tpot_p99_ms>=0"))
    assert summarize(records, 2, [], 2.5, 1, 4, underloaded=True)["underloaded"] is True


def main(argv: list[str] | None = None) -> int:
    """CLI 入口；SLO 错误单独返回 4，其他参数错误由 argparse 返回 2。"""
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--base-url", default="http://127.0.0.1:8000")
    parser.add_argument("--model")
    parser.add_argument("--rates", default="1,2,4,8")
    parser.add_argument("--num-prompts", type=int, default=64)
    parser.add_argument("--concurrency", type=int, default=16)
    parser.add_argument("--input-len", type=int, default=256)
    parser.add_argument("--output-len", type=int, default=64)
    parser.add_argument("--slo", default="ttft_p99_ms<=2000,tpot_p99_ms<=200")
    parser.add_argument("--out", type=Path, default=Path("results"))
    parser.add_argument("--warmup", type=int, default=4)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--arrival", choices=("poisson", "fixed"), default="poisson")
    parser.add_argument("--prompt-file", type=Path)
    parser.add_argument("--timeout", type=float, default=60.0)
    parser.add_argument("--metrics-interval", type=float, default=0.2)
    parser.add_argument("--self-check", action="store_true")
    args = parser.parse_args(argv)
    try:
        rules = parse_slo(args.slo)
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return 4
    if args.self_check:
        self_check()
        print("OK: SLO、到达轨迹、三请求手算指标自检")
        return 0
    try:
        config = Config(**{**{key: value for key, value in vars(args).items() if key != "self_check"},
                           "model": args.model or "", "rates": tuple(float(value) for value in args.rates.split(","))})
    except ValueError as exc:
        parser.error(str(exc))
    try:
        return asyncio.run(run_sweep(config, rules, {key: str(value) if isinstance(value, Path) else value
                                                   for key, value in vars(args).items()}))
    except KeyboardInterrupt:
        return 2
    except (OSError, ValueError) as exc:
        print(f"压测失败：{exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
