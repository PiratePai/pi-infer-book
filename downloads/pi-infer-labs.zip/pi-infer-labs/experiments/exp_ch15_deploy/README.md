# exp_ch15_deploy · 第 15 章 vLLM 部署包（可启动 / 可压测 / 可观测）

## 组成

| 文件 | 内容 | 本机状态 |
|---|---|---|
| `serve.sh` | vLLM 启动脚本：参数化（MODEL/MAX_MODEL_LEN/GPU_MEM_UTIL/MAX_NUM_SEQS/DTYPE/EXTRA_ARGS），含架构支持核查命令与回退边界说明 | 未测（需 Linux/CUDA + vLLM） |
| `bench_sweep.py` | 自包含压测（asyncio + 标准库，打 OpenAI 兼容端点）：到达轨迹（目标/实际发出双记录）、逐请求四时刻 + 逐 token 时间戳、TTFT/TPOT/ITL 分位、goodput（SLO 规则判定）、失败/取消入账、排空计时 | **mock 上实测通过**（`--self-check` 亦过） |
| `observe_metrics.py` | /metrics 周期抓取 → CSV：running/waiting、KV 水位、TTFT/TPOT 直方图分位估计（桶线性插值）、token 计数与差分吞吐 | **mock 上实测通过** |
| `capacity_curve.py` | 容量曲线生成（纯标准库）：capacity.csv/md + 双轴 SVG + 可持续点与余量建议 | **mock 产物上实测通过** |
| `mock_openai_server.py` | 本机自测用 mock（OpenAI 兼容 + SSE 流式 + /metrics 桩，确定性输出、可控 prefill/token 延迟） | 本机实测 |
| `config/` | 配置建议模板（SLO 表 + 旋钮联动） | — |

## 一键流程（GPU 环境，未测项的复现命令）

```bash
# 0) 架构支持核查（先于启动；Qwen3.5=GDN 混合主干，支持随 vLLM 版本变化）
python - <<'PY'
import vllm; print(vllm.__version__)
from vllm.model_executor.models.registry import ModelRegistry
print([n for n in ModelRegistry.get_supported_archs() if "Qwen3" in n])
PY
# 1) 启动（默认锚 Qwen3.5-0.8B；不支持时登记缺项，Qwen3-0.6B 仅作链路自测）
./serve.sh
# 2) 压测扫描（输入/输出分布与 SLO 按你的负载改）
python bench_sweep.py --base-url http://127.0.0.1:8000 --model Qwen3.5-0.8B \
    --rates 1,2,4,8,16 --num-prompts 256 --concurrency 32 \
    --input-len 1024 --output-len 128 --slo "ttft_p99_ms<=2000,tpot_p99_ms<=200" --out results/
# 2b) 可选：官方基准对照（口径见 S34；--goodput 与上面 SLO 同义）
# vllm bench serve --backend vllm --model Qwen3.5-0.8B --base-url http://127.0.0.1:8000 \n#     --max-concurrency 32 --num-prompts 256 --percentile-metrics ttft,tpot,itl \n#     --goodput "ttft:2000 tpot:200"
# 3) 观测（压测期间另开终端）
python observe_metrics.py --base-url http://127.0.0.1:8000 --interval 1 --duration 600 --out metrics.csv
# 4) 容量曲线与可持续配置
python capacity_curve.py --summary results/summary.csv --out results/
```

**回退边界**：若所装 vLLM 不支持 Qwen3.5 架构——按基准 6.4 不换锚，登记缺项（所需 vLLM 版本与核查输出）；
`MODEL=Qwen/Qwen3-0.6B ./serve.sh` 仅用于脚本链路自测（端点/流式/指标通路），**不替代锚定模型的部署验收**。

## 本机自测（无 GPU 也可跑）

```bash
python mock_openai_server.py --port 8123 --token-delay-ms 5 --prefill-delay-ms 50   # 终端 1
python bench_sweep.py --base-url http://127.0.0.1:8123 --model mock --rates 2,4 \
    --num-prompts 16 --concurrency 8 --input-len 64 --output-len 16 --out results_mock/   # 终端 2
python observe_metrics.py --base-url http://127.0.0.1:8123 --duration 5 --out metrics_mock.csv
python capacity_curve.py --summary results_mock/summary.csv --out results_mock/
```

预期输出（本机实测）：`rate=4 req/s=4.2 goodput=4.2 failures=0 drain=0.15s`；metrics CSV 含直方图分位估计；
capacity 三件产物 + `可持续配置: 4 req/s` 与余量建议。**mock 数字只验证脚本逻辑，不构成任何性能结论。**

## 预期输出结构（GPU 环境核对用）

- `results/summary.csv`：rate, req_s, out_tok_s, ttft_p50_ms, ttft_p99_ms, tpot_p99_ms, itl_p99_ms, goodput_req_s, failures, cancels, max_wait, drain_s, underloaded；
- `results/requests_<rate>.jsonl`：逐请求（目标到达/实际发出/首 token/逐 token/完成/状态）——发压不足检测与排空分析的数据面；
- `metrics.csv`：逐采样点服务级与请求级指标；
- `results/capacity.{csv,md,svg}`：曲线与 SLO 达标列；输入含 `underloaded` 时 CSV/MD 另列发压不足及排除推荐的原因。SLO 达标但 `underloaded=True` 的档位不作为可持续点推荐；旧 summary 无此列时沿用原选择口径。

## 观测指标口径

`observe_metrics.py` 将 `time_to_first_token_seconds_bucket` 与
`request_time_per_output_token_seconds_bucket` 各自按 `le` 合并所有模型/worker 的累积桶，
以桶内线性插值输出毫秒列 `ttft_p50_est_ms` / `ttft_p99_est_ms` 与
`tpot_p50_est_ms` / `tpot_p99_est_ms`。这是服务启动以来的累积分位估计；落在 `+Inf`
桶时取最后有限上界，缺失或空直方图留空。`python observe_metrics.py --self-check`
包含 TTFT 与双 engine TPOT 合桶的手算样例。

`kv_cache_usage_perc` 是比例，不能跨 worker 相加。同一完整标签重复出现时取最大值，
摘要列取最繁忙 worker 的水位（两个 0.6 仍为 0.6），
`kv_cache_usage_perc_by_labels` 以 JSON 保留完整的 engine/worker 等标签及各自水位；
无标签指标直接输出原值，标签列留空。优先读取 `vllm:kv_cache_usage_perc`，
缺失时使用旧名 `vllm:gpu_cache_usage_perc`。请求数与 token counter 仍跨 worker 求和。

## 口径注意

- SLO 规则语法（bench 与 curve 同语义）：`k<=v` / `k>=v` / `k<v` / `k>v`（逗号或分号分隔），阈值必须有限。指标白名单为上述 summary 列（含已输出的 TTFT/TPOT/ITL 分位字段），其中 `goodput_req_s` 因循环定义而不可作为判据；未知名称报参数错误（bench 退出 4，curve 非零退出）。空指标判为不达标，在 CSV/MD 中留空；
- goodput 分母包含失败/取消/超时请求（第 15 章 15.3）；
- SSE 的 chunk 不保证逐 token（bench 对 chunk 观测与 token 计数分列，usage 缺失时以内容帧数作代理并告警）；
- 本机 mock 的 token 延迟是模拟值；真实引擎的数字必须以 GPU 环境实测为准（未测如实标注）。
