#!/usr/bin/env bash
# 第 15 章 vLLM 部署包 · 启动脚本（Linux/CUDA 环境；本仓库写作机未测——无 GPU、vLLM 未安装）
#
# 用法（在装有 vLLM 的 Linux GPU 机器上）：
#   ./serve.sh                          # 默认：Qwen3.5-0.8B（6.4 锚定），OpenAI 兼容端点 :8000
#   MODEL=Qwen/Qwen3-0.6B ./serve.sh    # 脚本链路自测/对照（不替代锚定模型的部署验收）
#   MAX_MODEL_LEN=8192 GPU_MEM_UTIL=0.90 MAX_NUM_SEQS=64 ./serve.sh
#
# 架构支持核查（先于启动）：
#   python - <<'PY'
#   import vllm; print(vllm.__version__)
#   from vllm.model_executor.models.registry import ModelRegistry
#   names = ModelRegistry.get_supported_archs()
#   print([n for n in names if "Qwen3" in n])
#   PY
#   若列表不含 Qwen3.5（GDN 混合主干）对应架构：按 6.4 不换锚——登记缺项（所需 vLLM 版本），
#   Qwen3-0.6B 仅用于脚本链路自测（README「回退边界」）。
set -euo pipefail

MODEL="${MODEL:-Qwen/Qwen3.5-0.8B}"          # 6.4 锚定（text 主干）；本地路径亦可
SERVED_NAME="${SERVED_NAME:-$(basename "$MODEL")}"
PORT="${PORT:-8000}"
MAX_MODEL_LEN="${MAX_MODEL_LEN:-8192}"
GPU_MEM_UTIL="${GPU_MEM_UTIL:-0.92}"   # 引擎默认（S36）
MAX_NUM_SEQS="${MAX_NUM_SEQS:-64}"       # 示例预设（官方未列固定默认，随版本核对）
DTYPE="${DTYPE:-bfloat16}"
EXTRA_ARGS="${EXTRA_ARGS:-}"                  # 例：--enable-prefix-caching 已默认开（S36）

# 引擎旋钮依据 S36（官方 CLI 文档登记）；连续批处理/PagedKV 为 vLLM 默认机制（第 9/4 章）
exec vllm serve "$MODEL" \
  --served-model-name "$SERVED_NAME" \
  --port "$PORT" \
  --max-model-len "$MAX_MODEL_LEN" \
  --gpu-memory-utilization "$GPU_MEM_UTIL" \
  --max-num-seqs "$MAX_NUM_SEQS" \
  --dtype "$DTYPE" \
  --enable-prefix-caching \
  $EXTRA_ARGS
