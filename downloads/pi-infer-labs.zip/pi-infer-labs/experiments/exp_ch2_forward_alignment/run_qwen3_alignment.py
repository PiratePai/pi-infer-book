#!/usr/bin/env python3
"""第 2 章样章进阶实验：Qwen3-0.6B 真实权重对齐与差异清单核实。

把 Qwen3-0.6B 权重装入本书最小实现（逐项补齐教学清单外差异：
QK-Norm / 独立 head_dim / tied lm_head / half-split RoPE / rope_theta），
与 transformers 官方前向对照单步 logits。

前置：models/qwen3-0.6b/ 已下载（约 1.4GB）。
复跑：python experiments/exp_ch2_forward_alignment/run_qwen3_alignment.py
"""

from __future__ import annotations

import json
import math
import platform
import subprocess
import sys
import time
from pathlib import Path

import torch
from torch import Tensor, nn
from torch.nn import functional as F

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

MODEL_DIR = ROOT / "models" / "qwen3-0.6b"
OUT_DIR = Path(__file__).resolve().parent
INPUT_IDS = [151644, 872, 198, 108386, 151645, 198]  # "<|im_start|>user\n你好<|im_end|>\n" 的近似片段（固定字面量）
# 以上为演示用固定 token 字面量；对齐实验只要求"两边同输入"，不要求语义正确。


def git_hash() -> str:
    try:
        return subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
    except Exception:
        return "unavailable"


class Qwen3RMSNorm(nn.Module):
    """与 pi_infer.model.RMSNorm 相同公式；Qwen3 中也用于每头 QK-Norm。"""

    def __init__(self, dim: int, eps: float = 1e-6) -> None:
        super().__init__()
        self.weight = nn.Parameter(torch.ones(dim))
        self.eps = eps

    def forward(self, x: Tensor) -> Tensor:
        dtype = x.dtype
        x = x.float()
        x = x * torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + self.eps)
        return (x * self.weight.float()).to(dtype)


def rotate_half(x: Tensor) -> Tensor:
    """Qwen3 的 RoPE 配对方式：前半/后半配对（与 tiny 的 interleave 是同族变体）。"""

    x1, x2 = x[..., : x.shape[-1] // 2], x[..., x.shape[-1] // 2:]
    return torch.cat((-x2, x1), dim=-1)


class MinimalQwen3Attention(nn.Module):
    """差异补齐版：独立 head_dim、每头 q_norm/k_norm、half-split RoPE。"""

    def __init__(self, cfg: dict) -> None:
        super().__init__()
        d, hd = cfg["hidden_size"], cfg["head_dim"]
        self.n_heads, self.n_kv = cfg["num_attention_heads"], cfg["num_key_value_heads"]
        self.head_dim = hd
        self.q_proj = nn.Linear(d, self.n_heads * hd, bias=False)
        self.k_proj = nn.Linear(d, self.n_kv * hd, bias=False)
        self.v_proj = nn.Linear(d, self.n_kv * hd, bias=False)
        self.o_proj = nn.Linear(self.n_heads * hd, d, bias=False)
        self.q_norm = Qwen3RMSNorm(hd, cfg["rms_norm_eps"])   # 差异 #1：QK-Norm
        self.k_norm = Qwen3RMSNorm(hd, cfg["rms_norm_eps"])
        inv = cfg["rope_theta"] ** (-torch.arange(0, hd, 2, dtype=torch.float32) / hd)  # 差异 #4：theta=1e6
        t = torch.arange(cfg["max_position_embeddings"], dtype=torch.float32)
        freqs = torch.cat((torch.outer(t, inv),) * 2, dim=-1)  # half-split：前半/后半同频，表扩到 hd 维
        self.register_buffer("cos", freqs.cos(), persistent=False)
        self.register_buffer("sin", freqs.sin(), persistent=False)

    def forward(self, x: Tensor) -> Tensor:
        B, T, _ = x.shape
        q = self.q_norm(self.q_proj(x).view(B, T, self.n_heads, self.head_dim).transpose(1, 2))
        k = self.k_norm(self.k_proj(x).view(B, T, self.n_kv, self.head_dim).transpose(1, 2))
        v = self.v_proj(x).view(B, T, self.n_kv, self.head_dim).transpose(1, 2)
        cos, sin = self.cos[:T], self.sin[:T]
        q = q * cos + rotate_half(q) * sin
        k = k * cos + rotate_half(k) * sin
        k = k.repeat_interleave(self.n_heads // self.n_kv, dim=1)
        v = v.repeat_interleave(self.n_heads // self.n_kv, dim=1)
        scores = (q @ k.transpose(-2, -1)) / math.sqrt(self.head_dim)
        mask = torch.ones(T, T, dtype=torch.bool, device=x.device).tril()
        scores = scores.masked_fill(~mask, torch.finfo(scores.dtype).min)
        out = torch.softmax(scores, dim=-1) @ v
        return self.o_proj(out.transpose(1, 2).reshape(B, T, -1))


class MinimalQwen3(nn.Module):
    """只覆盖前向所需的最小结构；权重由 safetensors 逐名映射。"""

    def __init__(self, cfg: dict) -> None:
        super().__init__()
        self.embed = nn.Embedding(cfg["vocab_size"], cfg["hidden_size"])
        self.layers = nn.ModuleList(
            nn.ModuleDict({
                "attn_norm": Qwen3RMSNorm(cfg["hidden_size"], cfg["rms_norm_eps"]),
                "attn": MinimalQwen3Attention(cfg),
                "ffn_norm": Qwen3RMSNorm(cfg["hidden_size"], cfg["rms_norm_eps"]),
                "gate_proj": nn.Linear(cfg["hidden_size"], cfg["intermediate_size"], bias=False),
                "up_proj": nn.Linear(cfg["hidden_size"], cfg["intermediate_size"], bias=False),
                "down_proj": nn.Linear(cfg["intermediate_size"], cfg["hidden_size"], bias=False),
            }) for _ in range(cfg["num_hidden_layers"]))
        self.final_norm = Qwen3RMSNorm(cfg["hidden_size"], cfg["rms_norm_eps"])
        self.lm_head = nn.Linear(cfg["hidden_size"], cfg["vocab_size"], bias=False)  # 差异 #3：tied

    def forward(self, ids: Tensor) -> Tensor:
        x = self.embed(ids)
        for layer in self.layers:
            x = x + layer["attn"](layer["attn_norm"](x))
            g = F.silu(layer["gate_proj"](layer["ffn_norm"](x))) * layer["up_proj"](layer["ffn_norm"](x))
            x = x + layer["down_proj"](g)
        return self.lm_head(self.final_norm(x))


def load_weights(model: MinimalQwen3, model_dir: Path) -> None:
    """从 safetensors 读 bf16 权重，映射进最小实现（转 fp32）。

    兼容单文件与分片两种发布形态：Qwen3-0.6B 为单 model.safetensors。
    """
    from safetensors.torch import load_file

    index_path = model_dir / "model.safetensors.index.json"
    if index_path.exists():
        index = json.loads(index_path.read_text())
        tensors: dict[str, Tensor] = {}
        for shard in sorted(set(index["weight_map"].values())):
            tensors.update(load_file(model_dir / shard, device="cpu"))
    else:
        tensors = load_file(model_dir / "model.safetensors", device="cpu")
    mapping_prefix = "model."
    with torch.no_grad():
        model.embed.weight.copy_(tensors[f"{mapping_prefix}embed_tokens.weight"].float())
        for i, layer in enumerate(model.layers):
            src = f"{mapping_prefix}layers.{i}."
            layer["attn_norm"].weight.copy_(tensors[src + "input_layernorm.weight"].float())
            layer["ffn_norm"].weight.copy_(tensors[src + "post_attention_layernorm.weight"].float())
            a = layer["attn"]
            for name in ("q_proj", "k_proj", "v_proj", "o_proj"):
                getattr(a, name).weight.copy_(tensors[src + f"self_attn.{name}.weight"].float())
            a.q_norm.weight.copy_(tensors[src + "self_attn.q_norm.weight"].float())
            a.k_norm.weight.copy_(tensors[src + "self_attn.k_norm.weight"].float())
            for name in ("gate_proj", "up_proj", "down_proj"):
                layer[name].weight.copy_(tensors[src + f"mlp.{name}.weight"].float())
        model.final_norm.weight.copy_(tensors[f"{mapping_prefix}norm.weight"].float())
        # tie_word_embeddings=true：lm_head 复用 embedding
        model.lm_head.weight.copy_(model.embed.weight)


def main() -> None:
    from transformers import AutoModelForCausalLM, AutoTokenizer

    t0 = time.perf_counter()
    cfg_full = json.loads((MODEL_DIR / "config.json").read_text())
    record: dict = {"env": {
        "git": git_hash(), "python": platform.python_version(),
        "torch": torch.__version__, "device": "cpu",
        "model": "Qwen/Qwen3-0.6B（本地 models/qwen3-0.6b）",
        "fixed_input_ids": INPUT_IDS, "dtype": "bf16 权重 → fp32 装载",
    }}
    print("=" * 60)
    print("exp_ch2 进阶：Qwen3-0.6B 真实权重对齐")
    print("=" * 60)

    # 差异清单核实（config 直查，一手来源）
    cfg = {k: cfg_full[k] for k in (
        "hidden_size", "num_attention_heads", "num_key_value_heads", "head_dim",
        "num_hidden_layers", "intermediate_size", "vocab_size", "rope_theta",
        "rms_norm_eps", "max_position_embeddings")}
    diffs = {
        "1_qk_norm": {"qwen3": "q_norm/k_norm 存在（RMSNorm on head_dim）", "tiny": "无", "verified": True},
        "2_head_dim": {"qwen3": f"head_dim={cfg['head_dim']} 独立于 hidden/n_heads（{cfg['num_attention_heads']}×{cfg['head_dim']}≠{cfg['hidden_size']}）", "tiny": "head_dim = d/n_heads", "verified": cfg["num_attention_heads"] * cfg["head_dim"] != cfg["hidden_size"]},
        "3_tied_lm_head": {"qwen3": f"tie_word_embeddings={cfg_full.get('tie_word_embeddings')}", "tiny": "独立权重", "verified": bool(cfg_full.get("tie_word_embeddings"))},
        "4_rope_theta": {"qwen3": f"rope_theta={cfg['rope_theta']}", "tiny": "10000", "verified": cfg["rope_theta"] != 10000},
        "5_precision": {"qwen3": "bf16 checkpoint", "tiny": "fp32", "verified": True},
        "6_rope_pairing": {"qwen3": "half-split 配对（rotate_half）", "tiny": "interleave 配对", "verified": True},
    }
    record["difference_checklist"] = diffs
    for k, v in diffs.items():
        print(f"[diff] {k}: {v['qwen3']} | tiny: {v['tiny']} | 核实={v['verified']}")

    # 官方参考前向
    ref = AutoModelForCausalLM.from_pretrained(MODEL_DIR, torch_dtype=torch.float32)
    ref.eval()
    with torch.no_grad():
        ref_logits = ref(torch.tensor([INPUT_IDS])).logits[0]
    ref_argmax = [int(t.argmax()) for t in ref_logits]

    # 最小实现前向
    mine = MinimalQwen3(cfg)
    load_weights(mine, MODEL_DIR)
    mine.eval()
    with torch.no_grad():
        my_logits = mine(torch.tensor([INPUT_IDS]))[0]
    my_argmax = [int(t.argmax()) for t in my_logits]

    err = float((my_logits - ref_logits).abs().max())
    rel = err / float(ref_logits.abs().max())
    tokens_equal = my_argmax == ref_argmax
    ok = tokens_equal and rel <= 1e-4  # fp32 同路径重排的浮点噪声上限；实测值照实记录

    record["alignment"] = {
        "max_abs_err": err, "max_rel_err": rel,
        "argmax_tokens_equal": tokens_equal,
        "tolerance_rel": 1e-4, "pass": ok,
        "ref_argmax": ref_argmax, "mine_argmax": my_argmax,
    }
    print(f"[align] max|Δ|={err:.3e}, 相对={rel:.3e}, argmax 序列一致={tokens_equal} ({'PASS' if ok else 'FAIL'})")
    record["wall_seconds"] = round(time.perf_counter() - t0, 1)
    record["quality_check"] = "与 transformers 官方前向单步 logits 对照；argmax 序列逐位置一致"
    record["degradation_note"] = "CPU fp32 前向（0.6B 秒级）；对齐为正确性结论，无性能结论（5.3）"

    (OUT_DIR / "qwen3_raw.json").write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"结论：{'对齐通过' if ok else '对齐失败'}（qwen3_raw.json）")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
