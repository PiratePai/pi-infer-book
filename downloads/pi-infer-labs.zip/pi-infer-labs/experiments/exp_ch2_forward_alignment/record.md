# exp_ch2 前向与解码对齐 · 实验记录

| 项 | 结果 | 判据 |
|---|---|---|
| 1 前向 vs 存档参考 | PASS | max{|Δ|}=0.00e+00 ≤ 1e-5 |
| 2 贪心(缓存) vs 逐步重算 | PASS | tokens 一致，max|Δlogits|=7.15e-07 ≤ 1e-5 |
| 3 增量 vs 全量 | PASS | max|Δ|=5.96e-07 ≤ 1e-5 |

- 环境：3.12.10 / torch 2.15.0+cpu / CPU / git 2d74a823
- 生成口径：greedy argmax，max_new_tokens=8，无采样
- 复跑：`python experiments/exp_ch2_forward_alignment/run_alignment.py`（原始数据 raw.json）
- 降级说明：CPU 正确性签收；性能未测（无 CUDA 设备，5.3）
