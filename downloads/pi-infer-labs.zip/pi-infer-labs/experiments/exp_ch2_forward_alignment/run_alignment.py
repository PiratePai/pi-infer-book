#!/usr/bin/env python3
"""第 2 章样章必做实验：合成小模型前向与解码对齐。

按 5.1 实验协议输出 record.md + raw.json：
1. 前向对齐：seed=0 固定输入的 logits 与测试存档参考值对照；
2. 解码对齐：贪心生成 vs 逐步全量重算 argmax 参考；
3. 增量=全量：分块增量前向 vs 一次全量前向。

复跑：python experiments/exp_ch2_forward_alignment/run_alignment.py
"""

from __future__ import annotations

import json
import platform
import subprocess
import sys
import time
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from pi_infer import build_tiny_model, greedy_decode  # noqa: E402
from pi_infer.model import SimpleKVCache  # noqa: E402

OUT_DIR = Path(__file__).resolve().parent

# 测试 test_seed_zero_logits_match_recorded_cpu_reference 中的存档参考（首 6 列）。
REFERENCE_LOGITS6 = [
    [-0.433235884, 0.482292354, 0.310008675, 0.116080061, -0.260784328, -0.213458151],
    [0.298161030, -0.495017290, -0.272267252, -0.412694871, 0.896487474, -0.432440937],
    [0.726913631, -0.284058332, -0.426585585, -0.171945751, 1.258289099, 0.503898025],
]
INPUT_IDS = [1, 7, 11]
PROMPT = [2, 4, 6, 8]
NEW_TOKENS = 8
CHUNKS = (3, 1, 1, 2)


def git_hash() -> str:
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True,
        ).strip()
    except Exception:
        return "unavailable"


def main() -> None:
    record: dict = {}
    print("=" * 60)
    print("exp_ch2 前向与解码对齐（合成小模型，CPU）")
    print("=" * 60)

    # ---- 环境（5.1：代码与模型版本、硬件/依赖）----
    record["env"] = {
        "git": git_hash(),
        "python": platform.python_version(),
        "torch": torch.__version__,
        "device": "cpu",
        "processor": platform.processor(),
        "model": "build_tiny_model(seed=0) 合成小模型（无权重依赖）",
        "fixed_input": {"forward": INPUT_IDS, "prompt": PROMPT,
                        "new_tokens": NEW_TOKENS, "chunks": list(CHUNKS)},
        "generation_spec": {"decode": "greedy（argmax）", "sampling": "无（greedy）",
                            "stop": "max_new_tokens=8（合成模型无 eos）"},
    }
    print(f"[env] {record['env']['torch']} @ {record['env']['device']}, git {record['env']['git'][:8]}")

    # ---- 1. 前向对齐：与存档参考对照 ----
    t0 = time.perf_counter()
    model = build_tiny_model(seed=0)
    with torch.no_grad():
        logits = model(torch.tensor([INPUT_IDS]))
    forward_err = float((logits[0, :, :6] - torch.tensor(REFERENCE_LOGITS6)).abs().max())
    ok1 = forward_err <= 1e-5
    record["forward_alignment"] = {
        "max_abs_err_vs_recorded_reference": forward_err,
        "tolerance": 1e-5, "pass": ok1,
        "shape": list(logits.shape),
    }
    print(f"[1] 前向对齐 vs 存档参考: max|Δ|={forward_err:.2e} ({'PASS' if ok1 else 'FAIL'}), shape={list(logits.shape)}")

    # ---- 2. 解码对齐：贪心 vs 逐步全量重算 argmax ----
    with torch.no_grad():
        cached = greedy_decode(model, PROMPT, NEW_TOKENS, SimpleKVCache())
        naive_ids, naive_logits = list(PROMPT), []
        for _ in range(NEW_TOKENS):
            step = model(torch.tensor([naive_ids]))[0, -1]
            naive_logits.append(step)
            naive_ids.append(int(step.argmax()))
    tokens_equal = cached.token_ids == naive_ids
    logits_err = max(
        float((a - b).abs().max()) for a, b in zip(cached.per_step_logits, naive_logits)
    )
    ok2 = tokens_equal and logits_err <= 1e-5
    record["decode_alignment"] = {
        "cached_tokens": cached.token_ids, "naive_tokens": naive_ids,
        "tokens_equal": tokens_equal, "max_abs_err_step_logits": logits_err,
        "tolerance": 1e-5, "pass": ok2,
    }
    print(f"[2] 解码对齐 贪心(缓存) vs 逐步重算: tokens_equal={tokens_equal}, max|Δlogits|={logits_err:.2e} ({'PASS' if ok2 else 'FAIL'})")

    # ---- 3. 增量 = 全量 ----
    tokens = torch.tensor([[2, 5, 8, 11, 13, 17, 19, 23]])
    with torch.no_grad():
        full = model(tokens)
        cache, pos, parts = SimpleKVCache(), 0, []
        for size in CHUNKS + (1,):  # 3+1+1+2+1 = 8
            parts.append(model(tokens[:, pos:pos + size], start_pos=pos, kv_cache=cache))
            pos += size
    inc_err = float((torch.cat(parts, dim=1) - full).abs().max())
    ok3 = inc_err <= 1e-5
    record["incremental_equals_full"] = {
        "chunks": list(CHUNKS) + [1], "max_abs_err": inc_err,
        "tolerance": 1e-5, "pass": ok3,
    }
    print(f"[3] 增量(3,1,1,2,1) vs 全量: max|Δ|={inc_err:.2e} ({'PASS' if ok3 else 'FAIL'})")

    record["wall_seconds"] = round(time.perf_counter() - t0, 3)
    record["quality_check"] = "三项对照全部通过（正确性验收）；本实验为正确性实验，无性能结论"
    record["degradation_note"] = "CPU 正确性签收；性能未测（无 CUDA 设备，5.3）"

    all_ok = ok1 and ok2 and ok3
    (OUT_DIR / "raw.json").write_text(
        json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")

    lines = [
        "# exp_ch2 前向与解码对齐 · 实验记录",
        "",
        "| 项 | 结果 | 判据 |",
        "|---|---|---|",
        f"| 1 前向 vs 存档参考 | {'PASS' if ok1 else 'FAIL'} | max{{|Δ|}}={forward_err:.2e} ≤ 1e-5 |",
        f"| 2 贪心(缓存) vs 逐步重算 | {'PASS' if ok2 else 'FAIL'} | tokens 一致，max|Δlogits|={logits_err:.2e} ≤ 1e-5 |",
        f"| 3 增量 vs 全量 | {'PASS' if ok3 else 'FAIL'} | max|Δ|={inc_err:.2e} ≤ 1e-5 |",
        "",
        f"- 环境：{record['env']['python']} / torch {record['env']['torch']} / CPU / git {record['env']['git'][:8]}",
        f"- 生成口径：greedy argmax，max_new_tokens={NEW_TOKENS}，无采样",
        f"- 复跑：`python experiments/exp_ch2_forward_alignment/run_alignment.py`（原始数据 raw.json）",
        f"- 降级说明：{record['degradation_note']}",
    ]
    (OUT_DIR / "record.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("=" * 60)
    print(f"结论：{'全部通过' if all_ok else '存在失败项'}（详见 record.md / raw.json）")
    sys.exit(0 if all_ok else 1)


if __name__ == "__main__":
    main()
