#!/usr/bin/env python3
"""第 13 章实验（可执行包，需 GPU/权重环境；本机未测）：

固定样例集的阶段诊断：文本 / 单图 / 多图三类固定请求，逐阶段计时与显存计量，
并带判分规则（文字关键词 + 图中小目标字段）的质量框架；--image-size 提供单变量入口
（同一任务只改图像输入分辨率，供优化对照用）。

阶段划分（13.1 的落地；均为固定样例上的单次诊断或 --repeats 次重复的均值±std）：
  ① 媒体预处理（processor：resize/patch/占位展开）
  ② 视觉编码（vision tower + merger/DeepStack，以 forward hook 事件计时）
  ③ 语言 prefill = prefill 总墙钟 − ① − ②（近似残差：含特征注入、hook 同步与主机开销，按此口径声明）
  ④ decode（逐 token；首 token 直接取 prefill logits，之后增量循环；ITL 样本逐个记录）

用法（有 GPU 的环境）：
  python run_stage_comparison.py --model Qwen/Qwen3-VL-4B-Instruct --max-new-tokens 32 --repeats 3
本机自检（无 GPU 也可跑，只验证样例构造与判分器逻辑，不加载模型、不测推理）：
  python run_stage_comparison.py --self-check

未测声明：本脚本在本仓库写作机（无 NVIDIA GPU）上未做模型推理实测；样例/判分器逻辑经
--self-check 验证。复现条件：transformers>=4.57（或 5.x）、torch+CUDA、约 12GB 显存
（bf16 4B 模型 + KV），--image-size 调大或上下文加长时显存相应增加。
"""

from __future__ import annotations

import argparse
import json
import statistics
import sys
import time
from pathlib import Path

OUT = Path(__file__).resolve().parent / "stage_comparison_raw.json"

# ----------------------------------------------------------------------------
# 固定样例集（合成图自带 ground truth，可复现：小图形画在指定象限，判分看颜色词 + 方位词）
SAMPLES = [
    dict(
        id="text_qa_1", kind="text",
        prompt="用一句话解释什么是 KV 缓存。",
        judge=dict(any_groups=[["缓存"], ["复用", "保存", "留着"], ["避免", "不用", "减少"]]),
        note="文本基线：无视觉 token（任一组命中即过）",
    ),
    dict(
        id="img_small_target_1", kind="image", seed=1, size=(896, 896),
        shapes=[("square", "red", "top-left"), ("circle", "blue", "bottom-right"),
                ("square", "yellow", "center")],
        prompt="图中有哪些颜色的图形？分别位于什么位置？",
        judge=dict(any_groups=[["红"], ["蓝"], ["黄"], ["左上", "左上角"], ["右下", "右下角"], ["中间", "中央", "中心"]]),
        require_all=False,
        note="小目标清点：六组（三色 + 三方位）按'至少五组命中'的宽松版执行——颜色与方位为独立字段，"
             "错配（如'红色在右下'）关键词层面无法区分，输出存档供人工复核（代理判据边界，第 5 章口径）",
        min_groups=5,
    ),
    dict(
        id="img_negation_1", kind="image", seed=2, size=(896, 896),
        shapes=[("square", "green", "top-right"), ("circle", "red", "bottom-left")],
        prompt="右下角有没有图形？如果有，是什么颜色？",
        judge=dict(any_groups=[["没有", "无", "空的", "不放"], ["左下", "左下角"], ["红", "红色"]]),
        require_all=False,
        note="否定/方位陷阱：右下角为空。要求命中'否定词'或指向真实位置（左下/红）任一组即过；"
             "自检含错误答案（'右下角有一个绿色方块'）必须 FAIL",
    ),
    dict(
        id="multi_img_compare_1", kind="multi_image", seeds=(1, 2), size=(896, 896),
        shapes_a=[("square", "red", "top-left"), ("circle", "blue", "bottom-right")],
        shapes_b=[("square", "green", "top-right"), ("circle", "red", "bottom-left")],
        prompt="这两张图中，第一张的左上角与第二张的哪个角颜色不同？",
        judge=dict(any_groups=[["绿", "绿色"], ["右上", "右上角"], ["不同"]]),
        note="跨图比较：命中关键信息任一组即过（弱判据，输出存档人工复核）",
    ),
]
SMALL = 24  # 小目标边长（像素）：896×896 画布上的 24px 方块/圆（约 0.73% 面积）


def draw_shapes(size, shapes, seed=0):
    """按 ground truth 画合成图：纯色背景 + 指定象限的小图形（SMALL 像素）。确定性，可复现。"""
    from PIL import Image, ImageDraw

    w, h = size
    rng = __import__("random").Random(seed)
    bg = (rng.randrange(64), rng.randrange(64), rng.randrange(64))
    im = Image.new("RGB", (w, h), bg)
    dr = ImageDraw.Draw(im)
    colors = dict(red=(220, 40, 40), blue=(40, 80, 220), yellow=(230, 210, 50),
                  green=(50, 180, 70))
    pos_xy = {"top-left": (w // 4, h // 4), "top-right": (3 * w // 4, h // 4),
              "bottom-left": (w // 4, 3 * h // 4), "bottom-right": (3 * w // 4, 3 * h // 4),
              "center": (w // 2, h // 2)}
    for (kind, color, pos) in shapes:
        cx, cy = pos_xy[pos]
        r = SMALL // 2
        if kind == "square":
            dr.rectangle([cx - r, cy - r, cx + r, cy + r], fill=colors[color])
        else:
            dr.ellipse([cx - r, cy - r, cx + r, cy + r], fill=colors[color])
    return im


def score(text: str, judge: dict, require_all: bool = False, min_groups: int | None = None) -> dict:
    """判分规则：any_groups 每组内关键词任一命中即该组通过。

    require_all=True：须全组通过（用于多要点强判据）；min_groups=k：至少 k 组通过（小目标清点）；
    默认：任一组通过。关键词命中是代理判据（第 5 章同口径声明）：能挡住多数退化，
    颜色-方位错配与语义反转仍需人工检视，全部候选输出存档于 raw JSON 供核查。"""
    groups = []
    for g in judge["any_groups"]:
        hit = [kw for kw in g if kw in text]
        groups.append(dict(keywords=g, hit=hit, passed=bool(hit)))
    n_pass = sum(1 for g in groups if g["passed"])
    if require_all:
        passed = n_pass == len(groups)
    elif min_groups is not None:
        passed = n_pass >= min_groups
    else:
        passed = n_pass >= 1
    return dict(groups=groups, groups_passed=n_pass, passed=passed)


def self_check() -> int:
    """本机可跑：验证样例构造与判分器逻辑（含错误答案必须 FAIL 的反例；不加载模型、不测推理）。"""
    im = draw_shapes((896, 896), SAMPLES[1]["shapes"], seed=1)
    assert im.size == (896, 896)
    # 小目标样例：五组命中的正确答案过；只提一种颜色的错误答案不过
    s_ok = score("左上角是红色方块，右下角有蓝色圆形，中间还有一个黄色方块。",
                 SAMPLES[1]["judge"], min_groups=SAMPLES[1]["min_groups"])
    assert s_ok["passed"] and s_ok["groups_passed"] >= 5, s_ok
    s_bad = score("图里有一个红色方块。", SAMPLES[1]["judge"], min_groups=SAMPLES[1]["min_groups"])
    assert not s_bad["passed"], "小目标样例应要求多组命中"
    # 否定陷阱：正确答案过；错误答案（声称右下有绿色方块）必须 FAIL
    s_trap_ok = score("右下角没有图形，圆形在左下角，是红色的。", SAMPLES[2]["judge"])
    assert s_trap_ok["passed"], s_trap_ok
    s_trap_bad = score("右下角有一个绿色方块。", SAMPLES[2]["judge"])
    assert not s_trap_bad["passed"], "错误断言（右下=绿）应被判分器拒绝"
    # 文本基线
    assert score("这是一张图片。", SAMPLES[0]["judge"])["passed"] is False
    print("[self-check] 样例构造与判分器逻辑全部通过（含错误答案反例；模型推理部分未测，需 GPU 环境）")
    return 0


class StageTimer:
    """以 forward hook + CUDA 事件给子模块计时（vision tower 与 language model 分离）。"""

    def __init__(self, module):
        self.t_ms = 0.0
        self.calls = 0
        self._pre = module.register_forward_pre_hook(self._before, with_kwargs=True)
        self._post = module.register_forward_hook(self._after, with_kwargs=True)

    def _before(self, m, args, kwargs):
        import torch
        self._ev0 = torch.cuda.Event(enable_timing=True) if torch.cuda.is_available() else None
        self._t0 = time.perf_counter()
        if self._ev0 is not None:
            self._ev0.record()

    def _after(self, m, args, kwargs, out):
        import torch
        if self._ev0 is not None:
            ev1 = torch.cuda.Event(enable_timing=True)
            ev1.record()
            torch.cuda.synchronize()
            self.t_ms += self._ev0.elapsed_time(ev1)
        else:
            self.t_ms += (time.perf_counter() - self._t0) * 1000
        self.calls += 1

    def close(self):
        self._pre.remove()
        self._post.remove()


def build_inputs(proc, s, device, image_size=None):
    """① 媒体预处理：固定样例 → processor 输入。image_size 覆盖样例图像边长（单变量入口）。"""
    size = (image_size, image_size) if image_size else s["size"]
    if s["kind"] == "text":
        text = proc.apply_chat_template([{"role": "user", "content": s["prompt"]}],
                                        tokenize=False, add_generation_prompt=True)
        return proc(text=[text], return_tensors="pt").to(device), 0
    if s["kind"] == "image":
        im = draw_shapes(size, s["shapes"], seed=s.get("seed", 0))
        msg = [{"role": "user", "content": [{"type": "image"}, {"type": "text", "text": s["prompt"]}]}]
        text = proc.apply_chat_template(msg, tokenize=False, add_generation_prompt=True)
        return proc(text=[text], images=[im], return_tensors="pt").to(device), 1
    ia = draw_shapes(size, s["shapes_a"], seed=s["seeds"][0])
    ib = draw_shapes(size, s["shapes_b"], seed=s["seeds"][1])
    msg = [{"role": "user", "content": [{"type": "image"}, {"type": "image"},
                                        {"type": "text", "text": s["prompt"]}]}]
    text = proc.apply_chat_template(msg, tokenize=False, add_generation_prompt=True)
    return proc(text=[text], images=[ia, ib], return_tensors="pt").to(device), 2


def one_pass(model, proc, s, device, args, vis_timer):
    """单个样例一次完整测量：返回阶段计时/显存/输出/判分。生成口径：greedy，max_new_tokens 护栏。"""
    import torch

    t0 = time.perf_counter()
    inputs, n_imgs = build_inputs(proc, s, device, args.image_size)
    pre_ms = (time.perf_counter() - t0) * 1000
    n_img_tok = inputs["input_ids"][0].tolist().count(151655)

    if device == "cuda":
        torch.cuda.reset_peak_memory_stats()
        base_mem = torch.cuda.max_memory_allocated()
    vis_timer.t_ms = 0.0
    t0 = time.perf_counter()
    with torch.no_grad():
        out = model(**inputs, use_cache=True)
    if device == "cuda":
        torch.cuda.synchronize()
    prefill_ms = (time.perf_counter() - t0) * 1000
    vision_ms = vis_timer.t_ms
    lang_prefill_ms = prefill_ms - vision_ms   # 近似残差（含注入/hook 同步/主机开销）
    peak_prefill = (torch.cuda.max_memory_allocated() - base_mem) / 1e6 if device == "cuda" else 0.0

    # decode：首 token 取 prefill logits；此后增量喂上一个 token
    eos = proc.tokenizer.eos_token_id
    first_id = int(out.logits[0, -1].argmax())
    generated = []
    past = out.past_key_values
    cur = out.logits[:, -1:].argmax(dim=-1)
    if first_id != eos:
        generated.append(first_id)
    itl_ms = []
    for _ in range(args.max_new_tokens - len(generated)):
        t1 = time.perf_counter()
        with torch.no_grad():
            o2 = model(input_ids=cur, past_key_values=past, use_cache=True)
        if device == "cuda":
            torch.cuda.synchronize()
        itl_ms.append((time.perf_counter() - t1) * 1000)
        past = o2.past_key_values
        cur = o2.logits[:, -1:].argmax(dim=-1)
        nid = int(cur[0, 0])
        if nid == eos:
            break
        generated.append(nid)
    answer = proc.tokenizer.decode(generated, skip_special_tokens=True)
    sc = score(answer, s["judge"], require_all=s.get("require_all", False),
               min_groups=s.get("min_groups"))
    return dict(images=n_imgs, visual_tokens=n_img_tok, input_len=int(inputs["input_ids"].shape[1]),
                stage_ms=dict(preprocess=pre_ms, vision=vision_ms,
                              lang_prefill_residual=lang_prefill_ms,
                              prefill_total=prefill_ms,
                              decode_n=len(itl_ms),
                              itl_mean_ms=(sum(itl_ms) / len(itl_ms)) if itl_ms else None,
                              itl_max_ms=max(itl_ms) if itl_ms else None,
                              itl_samples=[round(x, 2) for x in itl_ms]),
                peak_prefill_delta_mb=peak_prefill, answer=answer, quality=sc)


def run(args) -> int:
    import torch
    from transformers import AutoProcessor, Qwen3VLForConditionalGeneration

    device = "cuda" if torch.cuda.is_available() else "cpu"
    proc = AutoProcessor.from_pretrained(args.model)
    model = Qwen3VLForConditionalGeneration.from_pretrained(
        args.model, dtype=torch.bfloat16 if device == "cuda" else torch.float32,
    ).to(device).eval()
    vis_timer = StageTimer(model.model.visual)

    results = []
    for s in SAMPLES:
        # 预热 1 次（5.1：首跑含编译/缓存效应，弃置），随后 --repeats 次测量
        if args.repeats > 1:
            one_pass(model, proc, s, device, args, vis_timer)
        passes = [one_pass(model, proc, s, device, args, vis_timer) for _ in range(args.repeats)]
        p = passes[0]
        if args.repeats > 1:
            for key in ("vision", "lang_prefill_residual", "prefill_total"):
                vals = [q["stage_ms"][key] for q in passes]
                p["stage_ms"][key + "_mean"] = statistics.mean(vals)
                p["stage_ms"][key + "_std"] = statistics.pstdev(vals)
        results.append(dict(id=s["id"], kind=s["kind"], note=s["note"], **p))
        itl = p["stage_ms"]["itl_mean_ms"]
        print(f"[{s['id']}] imgs={p['images']} vtok={p['visual_tokens']} "
              f"pre={p['stage_ms']['preprocess']:.0f}ms vis={p['stage_ms']['vision']:.0f}ms "
              f"lang≈{p['stage_ms']['lang_prefill_residual']:.0f}ms decode {p['stage_ms']['decode_n']} tok"
              f" (mean {itl:.1f}ms)" if itl is not None else f"[{s['id']}] decode 0 tok")
    vis_timer.close()
    OUT.write_text(json.dumps(
        dict(model=args.model, device=device, repeats=args.repeats,
             image_size_override=args.image_size,
             stage_notes="lang_prefill 为近似残差（总墙钟−预处理−视觉 hook），含特征注入与 hook 开销；"
                         "单变量入口 --image-size（同任务只改分辨率）；生成口径 greedy + max_new_tokens",
             results=results), ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"OK: {OUT}")
    return 0


def _utf8_stdout():
    """Windows 默认 GBK 控制台下非 GBK 字符无法编码——统一按 UTF-8 输出（幂等，静默失败安全）。"""
    import sys as _s
    for _st in (_s.stdout, _s.stderr):
        try:
            _st.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


def main() -> int:
    _utf8_stdout()
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="Qwen/Qwen3-VL-4B-Instruct")
    ap.add_argument("--max-new-tokens", type=int, default=32)
    ap.add_argument("--repeats", type=int, default=1, help=">1 时预热 1 次后取均值±std（5.1 口径）")
    ap.add_argument("--image-size", type=int, default=None,
                    help="覆盖样例图像边长（单变量对照入口：同任务只改分辨率）")
    ap.add_argument("--self-check", action="store_true")
    args = ap.parse_args()
    if args.self_check:
        return self_check()
    return run(args)


if __name__ == "__main__":
    sys.exit(main())
