# exp_ch13 VLM 视觉 token 账与阶段对照 · 实验记录

复跑基准：git 51ff4b1 → 修订后复跑（评审 P1 修复：视觉塔按 merge 前 patch 计、KV 区分整段/仅图像）；环境：Python 3.12.10 / torch 2.15.0+cpu / transformers 5.22.1 / pillow+torchvision 0.29.2+cpu（本实验新增，登记入 versions.md 漂移）/ Windows CPU（处理器型号见 raw.json environment；无 GPU，driver 不适用）。模型对象：Qwen/Qwen3-VL-4B-Instruct，revision `ebb281ec`（S31，2026-11-03 锁定；只加载 processor 配置与 meta-device 结构，不加载权重、不用 GPU）。

| 项 | 结果 | 判据 |
|---|---|---|
| 图像 token 律（10 档尺寸） | 处理器实测与手算公式**全部一致**：token = (W'/32)×(H'/32)，W'/H' 为 round 到 32 倍数后的像素；面积下限 65,536 px（64 token，64×64 被升采样到 256×256）、上限 16,777,216 px（6000×6000 → 4096×4096 → 16,384 token） | 双算一致（断言） |
| 多图线性 | 1/2/4 张 896×896 → 视觉 token 784/1568/3136，严格线性；模板与文本 token 增量 8/14 | 线性断言 |
| 视频帧采样律（N=2..240，704×1280） | 采样帧数 = clamp(int(N/24×2), 4, 768, N)；grid_t = round(采样/2)；token = grid_t×⌈W/32⌉×⌈H/32⌉。10 点全一致（N=48→采样 4→1,760；N=240→采样 20→8,800）。60s→52,800 为**公式外推**（超出实测范围，已标注） | 双算一致（断言） |
| 参数账（meta-device 精确计数） | 总参 **4,437,815,808**（与 S31 登记的模型卡 safetensors 计数逐位闭合）；视觉侧 415,347,712（blocks 302,309,376 + merger 27,271,680 + deepstack_merger_list 81,833,472 + patch/pos embed 3,933,184）；语言侧 4,022,468,096（36 层×100,930,816 + embed 388,956,160）；lm_head 与 embed 共享 | 公式双算：attn/层 26,214,656 = 公式+q/k-norm **精确**；mlp/层 74,711,040 = 3×2560×9728 **精确**；embed = 151,936×2,560 **精确**；vision blocks 公式（不含 bias/norm）差 <0.01% |
| 固定样例阶段成本账（修订口径） | **视觉塔按 merge 前 patch 计**（token×4）：single_img（784 tok/3,136 patch）视觉 1.90+0.97（二次项）=2.87 T vs 语言 6.63+0.40=7.03 T（≈1:2.5）；multi_img2 视觉 3.79+3.87=7.66 T vs 语言 12.95+1.53=14.5 T（≈1:1.9，二次项随 patch 平方增长）。KV：整段输入 824 tok=121.5 MB，**仅图像 784 tok=115.6 MB**；双图 231.2 MB（仅图像） | 账本推演口径（bf16；语言线性项按 2×language_params×L 整段近似，embed/lm_head 各计一次；二次项公式 4·d_mat·N²×层数，视觉按整段全注意力近似） |
| 阶段计时对照（run_stage_comparison.py） | **未测**（无 GPU/权重）。`--self-check` 已验证：样例构造（24px 小目标合成图）与判分器（小目标多组命中、否定陷阱正确答案过 + 错误断言必拒）全过；hook 计时/decode 循环修复后（with_kwargs、首 token 取 prefill logits）代码审读通过但设备行为未测 | 脚本逻辑签收；推理实测待复现条件 |

- 生成口径：token/参数账不适用（无生成任务）；阶段对照脚本为 greedy + max_new_tokens 护栏（复现时生成口径随脚本固定）。
- 固定输入：合成图（固定种子，24px 小图形 + 象限 ground truth）+ 固定样例集（SAMPLES 4 条：文本/小目标清点/否定陷阱/多图比较）；尺寸档与帧数档在脚本顶部常量。
- KV 公式：2(K,V)×36 层×8 KV 头×128 head_dim×2B(bf16) = 147,456 B/token（全注意力层；视觉塔无 KV）。
- baseline/candidate：本记录只有固定样例的阶段账（无优化对照）；优化对照入口为脚本 `--image-size`（同任务只改分辨率），复现时按 5.1 另记。
- 降级说明（5.3）：本机无 NVIDIA GPU、无 VLM 运行环境——视觉编码/语言 prefill/decode 的执行时间与显存**未测**，交付 `run_stage_comparison.py` + 运行说明（README）+ 预期输出结构；processor 实测 + meta-device 参数计数部分不依赖上述环境，如实签收。
