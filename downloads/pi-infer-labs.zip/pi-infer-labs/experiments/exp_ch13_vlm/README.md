# exp_ch13_vlm · 第 13 章 VLM：视觉 token 账与阶段对照

## 组成

| 文件 | 内容 | 本机状态 |
|---|---|---|
| `run_vlm_token_account.py` | processor 实测（token 律）+ meta-device 参数计数 + 固定样例阶段成本表 | **已实测（CPU，无需权重/GPU）** |
| `run_stage_comparison.py` | 固定样例集阶段诊断（预处理/视觉编码 hook 计时/语言 prefill 近似残差/decode ITL）+ 显存峰值 + 判分框架（小目标清点、否定陷阱）；`--image-size` 单变量入口、`--repeats` 预热+重复 | **未测**（需 GPU + 模型权重；`--self-check` 只验证样例构造与判分器逻辑，不含 hook/decode 与推理） |
| `raw.json` | token/参数/成本账产物 | 已实测产物 |
| `record.md` | 5.1 实验记录 | — |

## 运行

```bash
# 本机可跑（约 1–2 分钟；首次自动下载 processor/tokenizer 配置，约数 MB）
python experiments/exp_ch13_vlm/run_vlm_token_account.py

# 本机自检（不加载模型）
python experiments/exp_ch13_vlm/run_stage_comparison.py --self-check

# GPU 环境完整对照（未测项的复现命令）
python experiments/exp_ch13_vlm/run_stage_comparison.py \
    --model Qwen/Qwen3-VL-4B-Instruct --max-new-tokens 32
```

## 复现条件（未测项）

- **环境**：Linux/CUDA，transformers ≥ 4.57（或 5.x，本仓锁定 5.22.1）、torch（CUDA 版）、PIL/torchvision；
- **资源**：bf16 4B 模型权重（约 8.9GB）+ KV；≥12GB 显存（`--max-new-tokens` 与输入长度加大时显存相应增加）；
- **预期输出**：每个样例一行 `[id] imgs=N vtok=K pre=…ms vis=…ms lang≈…ms decode N tok (mean …ms)`；
  阶段量级预期（由 token/成本账推演，供核对）：单图 896×896 样例 `vtok=784`（merge 前 3,136 patch），视觉编码约
  为语言 prefill 的 1/3~1/2（FLOPs 1:2.5、二次项随 patch 数平方增长，见 record.md 成本账），decode 段 ITL 与文本请求
  同量级（视觉 token 只进 prefill 的 KV，不改变逐步 decode 的计算形状）；`lang≈` 为近似残差口径（总墙钟−预处理−视觉
  hook，含特征注入与 hook 开销）；
- 产物 `stage_comparison_raw.json` 含逐样例 ITL 样本与判分明细（关键词命中为代理判据，全部输出存档供人工复核）。

## 口径注意

- 处理器实测只覆盖**预处理输出、grid/token 数**，参数账来自 AutoConfig + meta-device 结构计数（非 processor 输出）；不覆盖视觉编码器执行、语言 prefill/decode 执行、端到端延迟、显存（后者属 `run_stage_comparison.py`，未测）。
- transformers 5.22.1 的视频处理未实现官方 `qwen-vl-utils` 的每帧像素上限（运行时警告；v5.22 起将默认 cap）——与官方工具的 token 数可能存在口径差异，按登记事实声明。
