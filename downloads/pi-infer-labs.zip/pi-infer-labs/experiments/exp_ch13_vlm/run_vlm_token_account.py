#!/usr/bin/env python3
"""第 13 章实验（本机可实测部分）：Qwen3-VL 视觉 token 账与参数/成本账。

本脚本在纯 CPU 上运行，不需要模型权重与 GPU：
- 只加载 AutoProcessor（tokenizer/processor 配置）与 meta-device 实例化（不加载权重）；
- 实测内容 = 预处理输出（grid、视觉 token 数）与据此的参数账（逐组件 numel）。

三段实测 + 一段账本：
  A. 图像 token 律：多档分辨率 × 边界（最小 64 / 最大 16384）——处理器实测 vs 手算公式双算一致；
  B. 多图线性：1/2/4 张同图——token 数线性叠加；
  C. 视频帧采样律：N 帧扫描——采样帧数 = clamp(int(N/fps_in × 2), 4, 768, N)、grid_t = round(采样/2)，
     像素侧与图像同律（取整到 32 倍数）；
  D. 参数与成本账（meta-device 精确计数 + 公式双算）：逐组件参数；固定样例（文本/单图/多图）的
     prefill FLOPs（线性项 + 注意力二次项分开报；视觉塔按 merge 前的 patch token 计）与语言 KV。

边界声明：本实测只覆盖预处理输出、grid/token 数与参数账；不覆盖视觉编码器执行、
语言 prefill/decode 执行、端到端延迟、显存或服务性能（设备项见 run_stage_comparison.py，标未测）。
口径注意（处理器实现直查，transformers 5.22.1）：视频处理未实现官方 qwen-vl-utils 的每帧像素上限
（cap_pixels_per_frame 警告），与官方工具存在口径差异，正文按此声明。

运行：python experiments/exp_ch13_vlm/run_vlm_token_account.py [--model Qwen/Qwen3-VL-4B-Instruct]
产物：experiments/exp_ch13_vlm/raw.json
"""

from __future__ import annotations

import argparse
import json
import platform
import random
import sys
import time
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")

IMG_TOKEN_ID = 151655   # S31：image_token_id（config 直查）
OUT = Path(__file__).resolve().parent / "raw.json"

# 固定样例的图像档（与 run_stage_comparison.py 同一套）：896×896 单图/双图
SAMPLE_IMG = (896, 896)


# ---------------------------------------------------------------- 合成输入（固定种子，可复现）
def make_image(w: int, h: int, seed: int = 0) -> "Image.Image":
    """确定性合成图：16×16 色块网格。小图降采样生成再放大，控制构造耗时。"""
    from PIL import Image

    rng = random.Random(seed)
    small = Image.new("RGB", (max(1, w // 16), max(1, h // 16)))
    px = small.load()
    for x in range(small.width):
        for y in range(small.height):
            px[x, y] = (rng.randrange(256), rng.randrange(256), rng.randrange(256))
    return small.resize((w, h), Image.Resampling.NEAREST)


# ---------------------------------------------------------------- 手算公式（与处理器实现逐条对齐）
def smart_resize_hw(w: int, h: int, factor: int = 32, min_px: int = 65_536, max_px: int = 16_777_216) -> tuple[int, int]:
    """图像 smart_resize（实现直查后的公式化）：round 到 32 倍数，面积越界先按比例缩再取整。"""
    import math

    w_bar = round(w / factor) * factor
    h_bar = round(h / factor) * factor
    if w_bar * h_bar > max_px:
        beta = math.sqrt((w * h) / max_px)
        w_bar = max(factor, math.floor(w / beta / factor) * factor)
        h_bar = max(factor, math.floor(h / beta / factor) * factor)
    elif w_bar * h_bar < min_px:
        beta = math.sqrt(min_px / (w * h))
        w_bar = math.ceil(w * beta / factor) * factor
        h_bar = math.ceil(h * beta / factor) * factor
    return w_bar, h_bar


def image_tokens_formula(w: int, h: int) -> tuple[int, tuple[int, int]]:
    """merge 后视觉 token 数 = (W'/32)×(H'/32)；merge 前 patch 数为其 4 倍（spatial_merge_size=2）。"""
    wb, hb = smart_resize_hw(w, h)
    return (wb // 32) * (hb // 32), (wb, hb)


def video_sampled_frames(n: int, fps_in: float = 24.0, fps: int = 2,
                          min_frames: int = 4, max_frames: int = 768) -> int:
    """视频采样帧数（实现直查）：clamp(int(N/fps_in × fps), min, max, N)。"""
    k = int(n / fps_in * fps)
    return min(max(k, min_frames), max_frames, n)


def video_grid_t_formula(n: int, fps_in: float = 24.0) -> int:
    """grid_t = round(采样帧数/2)（temporal_patch_size=2，t_bar 取偶后再除回）。"""
    return round(video_sampled_frames(n, fps_in) / 2)


# ---------------------------------------------------------------- 成本账常量（S31 config 直查；数值来源逐项标注）
CFG = dict(
    # 视觉塔（vision config）
    vis_depth=24, vis_hidden=1024, vis_inter=4096, vis_heads=16, patch=16, merge=2, t_patch=2,
    vis_out_hidden=2560, deepstack_indexes=[5, 11, 17],
    # text 主干（text_config）
    L=36, d=2560, h_q=32, h_kv=8, d_h=128, inter=9728, vocab=151_936,
)


def param_account_formula() -> dict:
    """参数账的公式侧（与 meta-device 实测双算）。"""
    vis_attn = 4 * CFG["vis_hidden"] ** 2               # q/k/v/o 四投影
    vis_mlp = 2 * CFG["vis_hidden"] * CFG["vis_inter"]  # linear_fc1/fc2（实现直查：两矩阵）
    vis_blocks = CFG["vis_depth"] * (vis_attn + vis_mlp)
    txt_attn = (CFG["d"] * CFG["h_q"] * CFG["d_h"] + 2 * CFG["d"] * CFG["h_kv"] * CFG["d_h"]
                + CFG["h_q"] * CFG["d_h"] * CFG["d"])           # q + k + v + o
    txt_attn += 2 * CFG["d_h"]                                  # q_norm/k_norm
    txt_mlp = 3 * CFG["d"] * CFG["inter"]                       # gate/up/down
    txt_layers = CFG["L"] * (txt_attn + txt_mlp)
    embed = CFG["vocab"] * CFG["d"]
    return dict(vis_blocks_formula=vis_blocks, vis_attn_per_layer=vis_attn, vis_mlp_per_layer=vis_mlp,
                txt_attn_per_layer=txt_attn, txt_mlp_per_layer=txt_mlp, txt_layers_formula=txt_layers,
                embed_formula=embed)


def attn_quad_flops(n_tokens: int, *, vision: bool) -> int:
    """注意力二次项 FLOPs（QK^T 与 PV 两个 N²·d_matmul）：4·d_mat·N²·层数。

    视觉塔：d_mat=vis_hidden（全注意力按整段近似，24 层）；语言侧：d_mat=h_q·d_h=4096（32 头），
    但 GQA 只对 K/V 复制不改变 matmul 输出规模，36 层。"""
    if vision:
        return 4 * CFG["vis_hidden"] * n_tokens ** 2 * CFG["vis_depth"]
    return 4 * (CFG["h_q"] * CFG["d_h"]) * n_tokens ** 2 * CFG["L"]


def _utf8_stdout():
    """Windows 默认 GBK 控制台下非 GBK 字符无法编码——统一按 UTF-8 输出（幂等，静默失败安全）。"""
    import sys as _s
    for _st in (_s.stdout, _s.stderr):
        try:
            _st.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


def main() -> int:
    _utf8_stdout()
    import torch
    import transformers
    from transformers import AutoConfig, AutoProcessor, Qwen3VLForConditionalGeneration

    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="Qwen/Qwen3-VL-4B-Instruct")
    args = ap.parse_args()

    t0 = time.perf_counter()
    proc = AutoProcessor.from_pretrained(args.model)
    ip = proc.image_processor
    raw: dict = {
        "experiment": "exp_ch13_vlm token & param account (CPU; processor measured + meta-device param count)",
        "model": args.model,
        "model_revision_note": "revision 锁定见 references.csv S31（ebb281ec，登记日 main）",
        "environment": {
            "python": platform.python_version(), "torch": torch.__version__,
            "transformers": transformers.__version__,
            "platform": platform.platform(), "processor": platform.processor() or "n/a",
            "driver": "n/a（纯 CPU，无 GPU/驱动项）",
        },
        "processor_facts": {   # 登记时直查（S30/S31）
            "image_processor": type(ip).__name__,
            "patch_size": getattr(ip, "patch_size", None),
            "merge_size": getattr(ip, "merge_size", None),
            "temporal_patch_size": getattr(ip, "temporal_patch_size", None),
            "size": str(getattr(ip, "size", None)),
            "video_fps": getattr(getattr(proc, "video_processor", None), "fps", None),
            "video_min_frames": getattr(getattr(proc, "video_processor", None), "min_frames", None),
            "video_max_frames": getattr(getattr(proc, "video_processor", None), "max_frames", None),
            "note_cap_pixels": "transformers 5.22.1 视频处理未实现 qwen-vl-utils 每帧像素上限（警告原文见 stderr），口径与官方工具有差异",
        },
    }

    # ---------- A. 图像 token 律（实测 vs 公式） ----------
    sizes = [(64, 64), (256, 256), (448, 448), (896, 896), (1280, 704), (704, 1280),
             (1920, 1080), (1000, 333), (2048, 2048), (6000, 6000)]
    tpl = "<|vision_start|><|image_pad|><|vision_end|>描述图片。"
    img_rows = []
    for (w, h) in sizes:
        out = proc(text=[tpl], images=[make_image(w, h)], return_tensors="pt")
        ids = out["input_ids"][0].tolist()
        grid = out["image_grid_thw"][0].tolist()
        measured = ids.count(IMG_TOKEN_ID)
        formula, (wb, hb) = image_tokens_formula(w, h)
        ok = measured == formula and (grid[1] * 16, grid[2] * 16) == (hb, wb)
        img_rows.append(dict(w=w, h=h, resized_px=[wb, hb], grid_thw=grid,
                             patches_pre_merge=grid[1] * grid[2], tokens_measured=measured,
                             tokens_formula=formula, match=ok))
        print(f"[A] {w}x{h} -> resize {wb}x{hb} grid {grid} patches {grid[1]*grid[2]} "
              f"tokens {measured} (formula {formula}) {'OK' if ok else 'MISMATCH'}")
    assert all(r["match"] for r in img_rows), "图像 token 公式与处理器实测不一致"

    # ---------- B. 多图线性 ----------
    ims = [make_image(*SAMPLE_IMG, seed=i) for i in range(4)]
    multi_rows = []
    for k in (1, 2, 4):
        txt = "<|vision_start|><|image_pad|><|vision_end|>" * k + "按顺序描述这些图。"
        out = proc(text=[txt], images=ims[:k], return_tensors="pt")
        ids = out["input_ids"][0].tolist()
        n_img = ids.count(IMG_TOKEN_ID)
        multi_rows.append(dict(images=k, img_tokens=n_img, total_len=len(ids),
                               text_and_markers=len(ids) - n_img))
        print(f"[B] {k} 张 896x896: img_tokens={n_img} total={len(ids)}")
    one = multi_rows[0]["img_tokens"]
    assert multi_rows[1]["img_tokens"] == 2 * one and multi_rows[2]["img_tokens"] == 4 * one, "多图 token 不线性"

    # ---------- C. 视频帧采样律 ----------
    import numpy as np

    vid_rows = []
    for n in (2, 3, 4, 8, 12, 24, 48, 96, 120, 240):
        frames = [np.asarray(make_image(704, 1280, seed=i)) for i in range(n)]
        out = proc(text=["<|vision_start|><|video_pad|><|vision_end|>描述视频。"],
                   videos=[frames], return_tensors="pt")
        ids = out["input_ids"][0].tolist()
        t, gh, gw = out["video_grid_thw"][0].tolist()
        measured = ids.count(151656)
        t_formula = video_grid_t_formula(n)
        sampled = video_sampled_frames(n)
        formula = t_formula * (gh * gw) // 4
        ok = (t == t_formula) and (measured == formula)
        vid_rows.append(dict(frames=n, sampled_frames=sampled, grid_thw=[t, gh, gw],
                             tokens_measured=measured, tokens_formula=formula, match=ok))
        print(f"[C] N={n:3d} -> 采样 {sampled} 帧, grid {t}x{gh}x{gw}, tokens {measured} (formula {formula}) {'OK' if ok else 'MISMATCH'}")
    assert all(r["match"] for r in vid_rows), "视频采样公式与处理器实测不一致"

    # ---------- D. 参数与成本账（meta-device 精确计数 + 公式双算） ----------
    cfg = AutoConfig.from_pretrained(args.model)
    with torch.device("meta"):
        model = Qwen3VLForConditionalGeneration._from_config(cfg)

    def cnt(m):
        return sum(p.numel() for p in m.parameters())

    inner = model.model
    lm = inner.language_model
    vis = inner.visual
    params = dict(
        total_measured=cnt(model),
        visual=dict(total=cnt(vis), patch_embed=cnt(vis.patch_embed), pos_embed=cnt(vis.pos_embed),
                    blocks=cnt(vis.blocks), merger=cnt(vis.merger),
                    deepstack_merger_list=cnt(vis.deepstack_merger_list)),
        language=dict(total=cnt(lm), embed_tokens=cnt(lm.embed_tokens),
                      layers=cnt(lm.layers), per_layer=cnt(lm.layers[0]),
                      per_layer_attn=cnt(lm.layers[0].self_attn), per_layer_mlp=cnt(lm.layers[0].mlp)),
        lm_head=cnt(model.lm_head),
        tied_note="total = visual + language（lm_head 与 embed_tokens 共享，total 只计一次）",
    )
    f = param_account_formula()
    closure = dict(
        txt_attn=dict(measured=params["language"]["per_layer_attn"], formula=f["txt_attn_per_layer"]),
        txt_mlp=dict(measured=params["language"]["per_layer_mlp"], formula=f["txt_mlp_per_layer"]),
        embed=dict(measured=params["language"]["embed_tokens"], formula=f["embed_formula"]),
        vis_blocks=dict(measured=params["visual"]["blocks"], formula=f["vis_blocks_formula"],
                        note="公式不含 bias/norm（实测含），差值 <0.01%"),
    )
    print(f"[D] total params = {params['total_measured']:,}（模型卡口径 4,437,815,808 闭合，S31 登记事实）")
    print(f"[D] visual={params['visual']['total']:,}  language={params['language']['total']:,}")

    # 阶段成本表（固定样例；语言侧 bf16）
    # 视觉塔按 merge 前 patch token 计（spatial_merge_size=2：patch 数 = merge 后 token ×4）
    KV_PER_TOKEN = 2 * CFG["L"] * CFG["h_kv"] * CFG["d_h"] * 2          # 147,456 B（bf16）
    LANG_PARAMS = params["language"]["total"]                            # 每 token 过全部 language 参数（整段近似口径）
    one_img_tokens = multi_rows[0]["img_tokens"]
    two_img_tokens = multi_rows[1]["img_tokens"]
    text_len = 32  # 固定文本样例的输入长度（token，含模板）
    samples = []
    for name, vis_tok, txt_tok in (("text_only", 0, text_len),
                                   ("single_img", one_img_tokens, text_len + multi_rows[0]["text_and_markers"]),
                                   ("multi_img2", two_img_tokens, text_len + multi_rows[1]["text_and_markers"])):
        l_in = vis_tok + txt_tok
        patches = vis_tok * 4                                   # merge 前 patch 数
        vis_lin = 2 * params["visual"]["blocks"] * patches
        vis_quad = attn_quad_flops(patches, vision=True)
        lang_lin = 2 * LANG_PARAMS * l_in
        lang_quad = attn_quad_flops(l_in, vision=False)
        samples.append(dict(sample=name, visual_tokens=vis_tok, vision_patches=patches,
                            text_tokens=txt_tok, input_len=l_in,
                            vision_flops_linear=vis_lin, vision_flops_attn_quad=vis_quad,
                            lang_prefill_flops_linear=lang_lin, lang_prefill_flops_attn_quad=lang_quad,
                            vision_vs_lang_total=(round((vis_lin + vis_quad) / (lang_lin + lang_quad), 4)
                                                  if vis_tok else 0.0),
                            lang_kv_bytes_total_input=KV_PER_TOKEN * l_in,
                            lang_kv_bytes_image_only=KV_PER_TOKEN * vis_tok))
        print(f"[D] {name}: L_in={l_in} (vis {vis_tok} tok / {patches} patches), "
              f"vision {vis_lin/1e12:.2f}+{vis_quad/1e12:.2f} T, lang {lang_lin/1e12:.2f}+{lang_quad/1e12:.2f} T, "
              f"KV total {KV_PER_TOKEN*l_in/1e6:.1f} MB (image-only {KV_PER_TOKEN*vis_tok/1e6:.1f} MB)")

    raw.update(dict(
        image_law=img_rows, multi_image=multi_rows, video_law=vid_rows,
        param_account=params, formula_side=f, closure=closure,
        cost=dict(kv_bytes_per_lang_token=KV_PER_TOKEN, samples=samples,
                  kv_formula="2(K,V)×36层×8 KV头×128 head_dim×2B(bf16)",
                  flops_formula=("线性项：视觉 2×blocks参数×patch数（merge 前，=token×4）；语言 2×language参数×L_in。"
                                 "注意力二次项：4·d_mat·N²×层数（视觉 d_mat=1024/24 层按整段全注意力近似；语言 d_mat=4096/36 层）。"
                                 "语言线性项近似：embed 只在输入端、lm_head 只在输出端，整段按 2×total×L 计"),
                  assumptions=["bf16", "只算语言侧 KV（视觉塔无 KV）",
                               "视频外推（如 60s→52,800 token）为公式外推，实测点到 N=240 截止"]),
        elapsed_s=round(time.perf_counter() - t0, 2),
    ))
    OUT.write_text(json.dumps(raw, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"OK: {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
