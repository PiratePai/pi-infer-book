#!/usr/bin/env python3
"""第 7 章样章实验（CPU 部分）：投机解码的验证、接受、拒绝修正与回滚。

S1 小词表精确投机采样：手算接受概率 + 大样本分布保持检验（vocab=32）
S2 验证/回滚边界：全接受 / 位置0拒绝 / 中间拒绝+修正后继续 / eos 边界 / 回滚后输出
S3 端到端一致性：oracle 草稿下投机生成 = 纯贪心
S4 接受长度分布：随机草稿 N 轮（接受长度、接受率与墙钟收益是三个不同指标）

MTP 实跑（Qwen3.5-0.8B）见 run_mtp_experiment.py，按资源条件单独执行。

复跑：python experiments/exp_ch7_speculative/run_spec_experiment.py
"""

from __future__ import annotations

import json
import math
import platform
import subprocess
import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from pi_infer import build_tiny_model, greedy_decode  # noqa: E402
from pi_infer.model import SimpleKVCache  # noqa: E402
from pi_infer.speculative import (  # noqa: E402
    DraftResult, SamplingSpec, speculative_generate, verify_and_accept,
)

OUT_DIR = Path(__file__).resolve().parent
PROMPT = [2, 4, 6, 8]
VOCAB = 32
N_SAMPLES = 2000


def _utf8_stdout():
    """Windows 默认 GBK 控制台下 ✓/✗ 无法编码——统一按 UTF-8 输出（幂等，无 reconfigure 环境静默跳过）。"""
    import sys as _s
    for _st in (_s.stdout, _s.stderr):
        try:
            _st.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


def git_hash() -> str:
    try:
        return subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
    except Exception:
        return "unavailable"


def main() -> None:
    _utf8_stdout()
    record: dict = {"env": {
        "git": git_hash(), "python": platform.python_version(), "torch": torch.__version__,
        "device": "cpu", "prompt": PROMPT,
        "generation_spec": {"greedy": "argmax（S2/S3）", "sampling": "temperature=1.0 无 top_k（S1/S4）",
                            "stop": "max_tokens / eos 按子实验固定"},
    }}
    print("=" * 64)
    print("exp_ch7 投机验证/接受/拒绝修正/回滚（小模型 CPU）")
    checks: dict[str, bool] = {}

    # ---- S1 精确投机采样：手算 + 统计检验 ----
    print("\n[S1] 小词表（V=32）精确投机采样")
    # 可控分布：目标 p 双峰(0,16)，草稿 q 双峰(0,24)（在 0 处部分重叠）
    p_logits = torch.zeros(VOCAB); p_logits[0] = 3.0; p_logits[16] = 3.0
    q_logits = torch.zeros(VOCAB); q_logits[0] = 3.0; q_logits[24] = 3.0
    p = torch.softmax(p_logits, -1); q = torch.softmax(q_logits, -1)
    # 期望接受率 = E_{y~q}[min(1, p(y)/q(y))] = Σ_y q(y)·min(1, p(y)/q(y)) = Σ_y min(p(y), q(y))
    accept_prob_hand = float(torch.minimum(p, q).sum())
    # 残差分布（拒绝后的修正分布）
    residual = (p - q).clamp_min(0); residual = residual / residual.sum()
    record["s1_hand"] = {
        "p_support": [0, 16], "q_support": [0, 24],
        "accept_prob_per_token": accept_prob_hand,
        "residual_mass_on_16": float(residual[16]),
        "note": "支撑集部分重叠：重叠处按 min(p,q)/q 接受；拒绝后修正集中于 p 独有的 16",
    }
    print(f"  手算: 每 token 接受概率 = {accept_prob_hand:.4f}（重叠位 {float(p[0]):.4f}/{float(q[0]):.4f}）")
    print(f"  手算: 拒绝时修正 token 落在 16 的概率 = {float(residual[16]):.4f}")
    # 单步统计：草稿 token 从 q 采样（真实投机场景），按 min(1,p/q) 接受，残差修正
    model = build_tiny_model(seed=0)
    from pi_infer.speculative import _distribution
    accepts, corrected = 0, []
    gen = torch.Generator().manual_seed(7)
    spec = SamplingSpec(rng=gen)
    for _ in range(N_SAMPLES):
        pv, qv = _distribution(p_logits, spec), _distribution(q_logits, spec)
        y = int(torch.multinomial(qv, 1, generator=spec.rng))          # 草稿 y ~ q
        u = torch.rand((), generator=spec.rng)
        if u < min(1.0, float(pv[y] / qv[y])):
            accepts += 1
        else:
            r = (pv - qv).clamp_min(0); r = r / r.sum()
            corrected.append(int(torch.multinomial(r, 1, generator=spec.rng)))
    emp_acc = accepts / N_SAMPLES
    emp_16 = sum(1 for t in corrected if t == 16) / max(1, len(corrected))
    sigma_acc = math.sqrt(accept_prob_hand * (1 - accept_prob_hand) / N_SAMPLES)
    ok_acc = abs(emp_acc - accept_prob_hand) < 5 * sigma_acc
    print(f"  实测: 接受率 {emp_acc:.4f} vs 手算 {accept_prob_hand:.4f}（|Δ|<{5:.0f}σ={5*sigma_acc:.4f}）{'✓' if ok_acc else '✗'}")
    print(f"  实测: 拒绝后修正落在 16 的比例 {emp_16:.4f} vs 手算 {float(residual[16]):.4f}")
    checks["S1_accept_rate"] = ok_acc
    checks["S1_correction_mass"] = abs(emp_16 - float(residual[16])) < 0.05
    record["s1_stats"] = {"empirical_accept": emp_acc, "hand_accept": accept_prob_hand,
                          "empirical_p16_given_reject": emp_16, "hand_p16": float(residual[16]),
                          "n_samples": N_SAMPLES}

    # ---- S2 验证/回滚边界（greedy + 对抗草稿）----
    print("\n[S2] 验证/回滚边界（greedy，对抗草稿强制触发各位置拒绝）")
    greedy_spec = lambda: SamplingSpec(greedy=True, rng=torch.Generator().manual_seed(0))  # noqa: E731
    with torch.no_grad():
        ref = greedy_decode(model, PROMPT, 8)
        truth = ref.token_ids[len(PROMPT):]  # 贪心真值
    cases = {}
    # a) 全接受：草稿=真值前 4 个
    d = DraftResult(tokens=list(truth[:4]),
                    draft_logits=[torch.full((256,), -10.0) for _ in range(4)])
    r = verify_and_accept(model, PROMPT, d, SimpleKVCache(), greedy_spec())
    cases["全接受"] = (r.rejected_at is None and r.accepted_tokens == list(truth[:4]))
    print(f"  全接受: accepted={r.accepted_tokens} rejected_at={r.rejected_at} {'✓' if cases['全接受'] else '✗'}")
    # b) 位置 0 拒绝
    d = DraftResult(tokens=[(truth[0] + 1) % 256], draft_logits=[torch.zeros(256)])
    r = verify_and_accept(model, PROMPT, d, SimpleKVCache(), greedy_spec())
    cases["位置0拒绝"] = (r.rejected_at == 0 and r.corrected_token == truth[0]
                       and r.accepted_tokens == [])
    print(f"  位置0拒绝: rejected_at={r.rejected_at} corrected={r.corrected_token}(==truth[0] {'✓' if cases['位置0拒绝'] else '✗'})")
    # c) 中间拒绝（位置2）+修正后继续，最终输出=贪心
    def adversarial(model_, ids, n):
        t = []
        with torch.no_grad():
            cur = list(ids)
            for i in range(n):
                nxt = int(model(torch.tensor([cur]))[0, -1].argmax())
                t.append((nxt + 1) % 256 if i == 2 else nxt)  # 位置 2 故意给错
                cur.append(t[-1])
            return DraftResult(tokens=t, draft_logits=[torch.zeros(256)] * n)
    out = speculative_generate(model, adversarial, PROMPT, 8, greedy_spec(), max_draft_len=4)
    ok_c = out.token_ids == ref.token_ids
    cases["中间拒绝+修正后继续=贪心"] = ok_c
    print(f"  中间拒绝(强制位置2)+修正后继续: 输出==贪心 {ok_c} {'✓' if ok_c else '✗'}")
    # d) eos 边界：草稿中间命中 eos
    eos = truth[2]
    def eos_draft(model_, ids, n):
        return DraftResult(tokens=[truth[0], truth[1], eos, truth[3]],
                           draft_logits=[torch.zeros(256)] * 4)
    out = speculative_generate(model, eos_draft, PROMPT, 8, greedy_spec(), eos_id=eos, max_draft_len=4)
    cases["eos边界(草稿中间)"] = (out.token_ids[-1] == eos and len(out.token_ids) == len(PROMPT) + 3)
    print(f"  eos 在草稿第3位: 停止于 eos，输出长度 {len(out.token_ids)}（prompt4+3）{'✓' if cases['eos边界(草稿中间)'] else '✗'}")
    # e) 回滚后 KV 长度正确 + 回滚后继续生成输出正确
    cache = SimpleKVCache()
    d = DraftResult(tokens=[truth[0], (truth[1] + 1) % 256, truth[2]],
                    draft_logits=[torch.zeros(256)] * 3)
    r = verify_and_accept(model, PROMPT, d, cache, greedy_spec())
    kv_len = cache.get(0)[0].shape[2]
    expect_len = len(PROMPT) + 2  # 接受1个+修正1个
    cont = greedy_decode(model, PROMPT + [truth[0], truth[1]], 4, SimpleKVCache())
    cases["回滚后KV与输出"] = (r.rollback_to == expect_len and kv_len == expect_len)
    print(f"  拒绝后回滚: rollback_to={r.rollback_to} KV长度={kv_len}（期望 {expect_len}）{'✓' if cases['回滚后KV与输出'] else '✗'}")
    checks.update({f"S2_{k}": v for k, v in cases.items()})
    record["s2_boundary"] = cases

    # ---- S3 端到端：oracle 草稿 = 贪心 ----
    print("\n[S3] 端到端：oracle 草稿（每步给真贪心 token）")
    def oracle(model_, ids, n):
        toks = []
        with torch.no_grad():
            cur = list(ids)
            for _ in range(n):
                nxt = int(model(torch.tensor([cur]))[0, -1].argmax())
                toks.append(nxt); cur.append(nxt)
        return DraftResult(tokens=toks, draft_logits=[torch.zeros(256)] * len(toks))
    out = speculative_generate(model, oracle, PROMPT, 12, greedy_spec(), max_draft_len=4)
    ref12 = greedy_decode(model, PROMPT, 12)
    ok3 = out.token_ids == ref12.token_ids
    checks["S3_oracle_equals_greedy"] = ok3
    print(f"  投机(oracle,草稿4)输出 == 贪心输出: {ok3} {'✓' if ok3 else '✗'}")

    # ---- S4 接受长度分布（随机草稿）----
    print("\n[S4] 随机草稿多轮：接受长度分布（接受长度≠接受率≠墙钟收益）")
    def random_draft(model_, ids, n):
        g = torch.Generator().manual_seed(len(ids) * 131 + n)
        toks = [int(torch.randint(0, 256, (1,), generator=g)) for _ in range(n)]
        return DraftResult(tokens=toks, draft_logits=[torch.zeros(256)] * n)
    lengths = []
    with torch.no_grad():
        cur = list(PROMPT)
        while len(cur) + 5 < model.config.max_seq_len:  # 上下文上限内的轮数
            d = random_draft(model, cur, 4)
            r = verify_and_accept(model, cur, d, SimpleKVCache(), greedy_spec())
            lengths.append(len(r.accepted_tokens))
            cur = cur + r.accepted_tokens + ([r.corrected_token] if r.corrected_token is not None else [])
    avg = sum(lengths) / len(lengths)
    dist = {k: lengths.count(k) for k in sorted(set(lengths))}
    print(f"  {len(lengths)} 轮，每轮接受草稿数分布 {dist}，均值 {avg:.3f}（草稿=4，随机草稿接受率≈{avg/4:.3f}）")
    record["s4_accept_length"] = {"rounds": len(lengths), "distribution": dist, "mean": avg,
                                 "note": "随机草稿与模型分布无关，接受率低是预期；真实草稿(MTP)的收益取决于草稿与目标的分布匹配度"}
    checks["S4_done"] = True

    record["all_pass"] = all(checks.values()); record["checks"] = checks
    record["degradation_note"] = "CPU 正确性与统计验收；无墙钟性能结论（5.3）。MTP 实跑另见 run_mtp_experiment.py"
    (OUT_DIR / "raw.json").write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    print("\n结论：", "全部通过" if record["all_pass"] else "存在失败项", "（raw.json）")
    sys.exit(0 if record["all_pass"] else 1)


if __name__ == "__main__":
    main()
