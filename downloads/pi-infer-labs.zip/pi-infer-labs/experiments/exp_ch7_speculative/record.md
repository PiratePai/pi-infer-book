# exp_ch7 投机解码验证骨架与 MTP 实跑 · 实验记录

## 小词表实验（S1–S4，run_spec_experiment.py）

| 项 | 结果 | 判据 |
|---|---|---|
| S1 手算精确采样 | PASS | 接受概率手算 0.728 vs 2000 样本实测 0.732；拒绝后修正落在 token 16 的频率 1.0（残差唯一正项） |
| S2 验证边界 | PASS | 全接受 / 位置 0 拒绝 / 中间拒绝+修正后继续=贪心 / 草稿中间 eos / 拒绝回滚后 KV 长度与输出对照 |
| S3 oracle 草稿 | PASS | oracle（用目标自身分布起草）输出与贪心严格一致 |
| S4 随机草稿接受长度 | 记录 | 119 轮接受长度全 0——与目标分布无关的草稿，接受率低是预期；真实收益取决于分布匹配度 |

- 环境：3.12.10 / torch 2.15.0+cpu / CPU / git 700994b9；prompt=[2,4,6,8]，词表 32
- 生成口径：S2/S3 greedy argmax；S1/S4 temperature=1.0 无 top_k、固定种子 RNG

## MTP 实跑（run_mtp_experiment.py，Qwen3.5-0.8B）

| 项 | 结果 | 判据 |
|---|---|---|
| 关/开投机对照 | PASS | 输出 token 序列逐位一致（greedy 一致性） |
| 接受率 | 8/12 轮（66.7%） | 每轮 k=1 草稿（主干 argmax a1 + MTP 草稿 a2） |
| 墙钟（同机相对） | baseline 38.4 s vs spec 30.5 s（24 token） | CPU fp32 全量重算口径（两臂同口径）；GDN 走 transformers 参考实现 |

MTP 头对齐过程（checkpoint 逆向，无官方 MTP 前向文档；8 组合扫描数据见开发记录，最终结构锁定如下）：

1. fc 输入顺序 `concat(norm_e(emb(t_{j+1})), norm_h(h_j))`——embedding 路在前，与 DeepSeek-V3 技术报告书写顺序相反；换序教师一致率 9/18→0/18；
2. hidden 取主干 final norm 之后输出（hidden_states[-1]）；取层原始输出（[-2]）一致率降至 2/18；
3. MTP 层为全注意力（Qwen3_5Attention 输出门控变体，q_proj 输出 = Q⊕gate 拼接），必须整段因果前向携带历史；单 token 前向（丢历史）接受率 0/12；
4. 开发中真实案例：拒绝路径以 corrected 换入 a2 后未重算前向，缓存 logits 污染后续 a1，输出自第 5 token 起崩坏——修复（拒绝后强制重算）后逐位一致。7.5"回滚后检查后续输出"的实证。

- 环境：3.12.10 / torch 2.15.0+cpu / transformers 5.22.1 / CPU / 模型本地 models/qwen3.5-0.8b（revision 2fc06364，见 versions.md）
- 生成口径：Qwen3.5 默认 chat template、模型默认 thinking 设置、greedy argmax、eos 或 24 token 上限；prompt "用一句话介绍你自己。"（token 字面量在 mtp_raw.json）
- 复跑：`python experiments/exp_ch7_speculative/run_spec_experiment.py`；`python experiments/exp_ch7_speculative/run_mtp_experiment.py`
- 降级说明：CPU 正确性/统计验收 + 同机相对对照；无 GPU 性能结论；峰值内存未采样（无 psutil）（5.3）

## 正式章补充：候选长度×草稿质量×并发扫描（run_spec_scan.py，2026-11-03）

复跑基准：git eed7a4d；tiny 模型固定种子、3 条固定 prompt、greedy 口径（SamplingSpec(greedy=True)）。

| 项 | 结果 | 判据 |
|---|---|---|
| 关/开投机逐 token 一致 | 全组合 PASS（15 候选组合 + 45 并发组合） | 与参考 greedy_decode 逐 token 对照 |
| oracle 草稿（目标自身贪心前瞻） | α=1.000；每轮提交=γ（截尾略低，如 k=3 提交 2.667 vs 公式 3.000）；墙钟比 1.0–1.5× | 调整公式 (1−α^(γ+1))/(1−α)−α^γ（≡Σ_{i<γ}α^i）的 α=1 极限 |
| 噪声草稿 ε=0.5 | α≈0.22–0.23；提交 1.231 vs 公式 1.289；墙钟比 4.6× | 实测与公式同报，偏差（i.i.d. 假设）如实入 raw |
| 噪声草稿 ε=2.0 | α≈0.016–0.062；k=8 墙钟比 9.0× | 坏草稿端到端更慢的实证 |
| 并发 B∈{1,2,4} | 逐位接受率与顺序执行差 **0.0** | CPU 串行交错口径；生产引擎验证成本随 batch 变化（S20），不外推 |

- 计时：预热 1 轮 + 交错重复 ≥3，均值±std；全量数据在 spec_scan_raw.json（含 per-position α）。
- MTP 段：复用 mtp_raw.json（k=1 实跑不重复），脚本 `--skip-mtp` 可跳过。
- 复跑：`python experiments/exp_ch7_speculative/run_spec_scan.py`（~45 s）。
- 降级说明：CPU 相对对照；生产引擎的候选长度/并发扫描未测（5.3）；DSpark/DFlash 无本机匹配 checkpoint（DeepSpec 草稿器目标 Qwen3-4B 起），原理与工程数字按 S18–S23 引用。
