#!/usr/bin/env python3
"""第 7 章样章 MTP 实跑：Qwen3.5-0.8B 关/开投机贪心对照（CPU）。

MTP 头随 checkpoint 发布（mtp.* 权重，mtp_num_hidden_layers=1），transformers
不暴露其前向，本脚本手动组装：
  concat(RMSNorm_h(h_t), RMSNorm_emb(emb(a1))) → fc → 1 层 full-attention
  decoder → norm → 共享 lm_head，预测 t+2。
投机循环（k=1 草稿）：每轮一次主干前向 + 一次 MTP 前向，最多提交 2 token；
贪心验证与修正：草稿 token 与主干全量前向的 argmax 比对，不一致则替换。
验收：开/关投机输出 token 序列逐位一致（greedy 一致性）；接受率与墙钟如实记录
（CPU 相对对照，5.3：无 GPU 性能结论）。

前置：models/qwen3.5-0.8b/ 已下载（revision 2fc06364，versions.md 锚定）。
复跑：python experiments/exp_ch7_speculative/run_mtp_experiment.py
"""

from __future__ import annotations

import copy
import json
import platform
import subprocess
import sys
import time
from pathlib import Path

import torch
from torch import Tensor, nn

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

MODEL_DIR = ROOT / "models" / "qwen3.5-0.8b"
OUT_DIR = Path(__file__).resolve().parent
MAX_NEW_TOKENS = 24
PROMPT_TEXT = "用一句话介绍你自己。"

from transformers import AutoModelForCausalLM, AutoTokenizer  # noqa: E402
from transformers.models.qwen3_5.modeling_qwen3_5 import (  # noqa: E402
    Qwen3_5DecoderLayer,
    Qwen3_5RMSNorm,
)


def git_hash() -> str:
    try:
        return subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
    except Exception:
        return "unavailable"


class MTPHead(nn.Module):
    """单层 MTP 预测模块：双路归一化拼接、fc 投影、一层 decoder、终归一化。"""

    def __init__(self, text_cfg, lm_head: nn.Linear, embed: nn.Embedding) -> None:
        super().__init__()
        d = text_cfg.hidden_size
        mtp_cfg = copy.deepcopy(text_cfg)
        mtp_cfg.layer_types = ["full_attention"]  # MTP 层为全注意力（q_norm/k_norm 权重在场）
        self.norm_h = Qwen3_5RMSNorm(d, eps=text_cfg.rms_norm_eps)
        self.norm_e = Qwen3_5RMSNorm(d, eps=text_cfg.rms_norm_eps)
        self.fc = nn.Linear(2 * d, d, bias=False)
        self.layer = Qwen3_5DecoderLayer(mtp_cfg, 0)
        self.norm = Qwen3_5RMSNorm(d, eps=text_cfg.rms_norm_eps)
        self.lm_head = lm_head
        self.embed = embed

    def load(self, tensors: dict[str, Tensor]) -> None:
        """把 checkpoint 的 mtp.* 权重映射进本模块。"""
        with torch.no_grad():
            self.norm_h.weight.copy_(tensors["mtp.pre_fc_norm_hidden.weight"].float())
            self.norm_e.weight.copy_(tensors["mtp.pre_fc_norm_embedding.weight"].float())
            self.fc.weight.copy_(tensors["mtp.fc.weight"].float())
            src = "mtp.layers.0."
            self.layer.input_layernorm.weight.copy_(tensors[src + "input_layernorm.weight"].float())
            self.layer.post_attention_layernorm.weight.copy_(tensors[src + "post_attention_layernorm.weight"].float())
            for name in ("q_proj", "k_proj", "v_proj", "o_proj", "q_norm", "k_norm"):
                getattr(self.layer.self_attn, name).weight.copy_(tensors[src + f"self_attn.{name}.weight"].float())
            for name in ("gate_proj", "up_proj", "down_proj"):
                getattr(self.layer.mlp, name).weight.copy_(tensors[src + f"mlp.{name}.weight"].float())
            self.norm.weight.copy_(tensors["mtp.norm.weight"].float())

    def forward_seq(self, hidden_all: Tensor, next_tokens: Tensor, rotary) -> Tensor:
        """整段因果前向；返回最后位置对下一 token 的预测 logits。

        对齐记录（checkpoint 逆向，无官方 MTP 前向文档，mtp_raw.json 有扫描）：
        1) fc 输入顺序是 concat(norm_e(emb(t_{j+1})), norm_h(h_j))——embedding 路
           在前，与 DeepSeek-V3 技术报告的书写顺序相反；顺序换反教师一致率 9/18→0/18。
        2) hidden 取主干 final norm 之后的输出（hidden_states[-1]），层原始输出
           ([-2]) 一致率显著更低。
        3) MTP 层是全注意力（含输出门控 q_proj=Q⊕gate 的 Qwen3_5Attention 变体），
           必须整段因果前向携带历史；单 token 前向接受率为 0。
        位置 j 的输入是 (h_j, emb(t_{j+1}))，站位 j+1。
        """
        e = self.embed(next_tokens)
        x = self.fc(torch.cat((self.norm_e(e), self.norm_h(hidden_all)), dim=-1))
        length = x.shape[0]
        pos_ids = torch.arange(1, length + 1).view(1, 1, -1)  # 文本路径：mrope 三路同 id
        position_embeddings = rotary(x.unsqueeze(0), pos_ids)
        out = self.layer(
            x.unsqueeze(0),
            position_embeddings=position_embeddings,
            position_ids=pos_ids,
            attention_mask=None,
        )
        return self.lm_head(self.norm(out))[0, -1]


def load_mtp_tensors() -> dict[str, Tensor]:
    from safetensors.torch import load_file

    index = json.loads((MODEL_DIR / "model.safetensors.index.json").read_text(encoding="utf-8"))
    tensors: dict[str, Tensor] = {}
    for shard in sorted(set(index["weight_map"].values())):
        tensors.update(load_file(MODEL_DIR / shard, device="cpu"))
    return {k: v for k, v in tensors.items() if k.startswith("mtp.")}


@torch.no_grad()
def forward_all(model, ids: list[int]):
    """全量前向整段序列；返回 (全部 logits [T,V], 全部位置隐藏态 [T,d])。"""
    out = model(input_ids=torch.tensor([ids]), output_hidden_states=True)
    return out.logits[0], out.hidden_states[-1][0]


@torch.no_grad()
def greedy_baseline(model, ids: list[int], n_new: int, eos: list[int]):
    """关投机：每步全量重算取 argmax（与投机同口径，公平对照）。"""
    tokens = list(ids)
    t0 = time.perf_counter()
    for _ in range(n_new):
        logits, _ = forward_all(model, tokens)
        nxt = int(logits[-1].argmax())
        tokens.append(nxt)
        if nxt in eos:
            break
    return tokens, time.perf_counter() - t0


@torch.no_grad()
def speculative_mtp(model, mtp: MTPHead, ids: list[int], n_new: int, eos: list[int]):
    """开投机：每轮主干前向选 a1，MTP 整段因果起草 a2，下一轮前向验证 a2。"""
    tokens = list(ids)
    rotary = model.model.rotary_emb
    rounds: list[dict] = []
    accepted_mtp = 0
    t0 = time.perf_counter()
    logits, hidden = forward_all(model, tokens)
    while len(tokens) - len(ids) < n_new:
        a1 = int(logits[-1].argmax())  # 主干自己的预测：无需验证
        mtp_t0 = time.perf_counter()
        next_tokens = torch.tensor(tokens[1:] + [a1])  # 位置 j 配对 t_{j+1}；最后配草稿 a1
        mtp_logits = mtp.forward_seq(hidden, next_tokens, rotary)
        mtp_time = time.perf_counter() - mtp_t0
        a2 = int(mtp_logits.argmax())  # 草稿：需要验证
        # 验证前向：喂入 [.. a1 a2]，一次得到 a1 之后位置的真值分布
        logits, hidden = forward_all(model, tokens + [a1, a2])
        truth = int(logits[len(tokens)].argmax())  # 位置 len(tokens) 的真值即对 a2 的裁决
        corrected = None if truth == a2 else truth
        if corrected is None:
            tokens += [a1, a2]
            accepted_mtp += 1
            # 已缓存的 logits/hidden 与新 tokens 一致，下一轮直接复用
        else:
            tokens += [a1, corrected]
            # 裁决前向基于被拒的 a2；corrected 换入后序列已变，必须重算再进下一轮
            logits, hidden = forward_all(model, tokens)
        rounds.append({
            "draft": [a1, a2], "accepted_mtp": corrected is None,
            "corrected": corrected, "mtp_forward_s": mtp_time,
            "committed": 2,
        })
        if tokens[-1] in eos or tokens[-2] in eos:
            break
    return tokens, time.perf_counter() - t0, rounds, accepted_mtp


def main() -> None:
    t0 = time.perf_counter()
    tok = AutoTokenizer.from_pretrained(MODEL_DIR)
    model = AutoModelForCausalLM.from_pretrained(MODEL_DIR, dtype=torch.float32)
    model.eval()
    text_cfg = model.config.get_text_config()  # AutoModelForCausalLM 返回的 config 即 text 配置
    mtp = MTPHead(text_cfg, model.lm_head, model.model.embed_tokens)
    mtp.load(load_mtp_tensors())
    mtp.eval()

    messages = [{"role": "user", "content": PROMPT_TEXT}]
    prompt_ids = tok.apply_chat_template(messages, add_generation_prompt=True, tokenize=True)["input_ids"]
    eos_ids = {tok.eos_token_id}
    for name in ("im_end", "endoftext"):
        extra = getattr(tok, f"{name}_id", None)
        if isinstance(extra, int):
            eos_ids.add(extra)
    print("=" * 64)
    print("exp_ch7 MTP 实跑：Qwen3.5-0.8B 关/开投机贪心对照（CPU）")
    print(f"prompt_ids({len(prompt_ids)}): {prompt_ids}")

    base_tokens, base_s = greedy_baseline(model, prompt_ids, MAX_NEW_TOKENS, eos_ids)
    print(f"[baseline] {len(base_tokens)-len(prompt_ids)} tokens in {base_s:.1f}s")
    print("  输出:", tok.decode(base_tokens[len(prompt_ids):]))

    spec_tokens, spec_s, rounds, accepted = speculative_mtp(model, mtp, prompt_ids, MAX_NEW_TOKENS, eos_ids)
    n_rounds = len(rounds)
    print(f"[spec] {len(spec_tokens)-len(prompt_ids)} tokens in {spec_s:.1f}s, "
          f"{n_rounds} 轮, MTP 接受 {accepted}/{n_rounds}")
    print("  输出:", tok.decode(spec_tokens[len(prompt_ids):]))

    identical = spec_tokens == base_tokens
    accept_rate = accepted / n_rounds if n_rounds else 0.0
    ok = identical
    print(f"[check] 开/关投机输出逐 token 一致 = {identical} ({'PASS' if ok else 'FAIL'})")

    record = {
        "env": {
            "git": git_hash(), "python": platform.python_version(),
            "torch": torch.__version__, "device": "cpu",
            "model": "Qwen/Qwen3.5-0.8B 本地 models/qwen3.5-0.8b（revision 2fc06364，见 versions.md）",
            "dtype": "fp32 装载（bf16 checkpoint）",
            "gdn_backend": "transformers 参考 PyTorch 实现（causal_conv1d/flash-linear-attention 未装，慢但正确）",
        },
        "generation_spec": {
            "chat_template": "Qwen3.5 默认 chat template", "thinking": "模型默认（未传 enable_thinking）",
            "sampling": "greedy argmax（无采样）", "stop": f"eos∈{sorted(eos_ids)} 或 {MAX_NEW_TOKENS} 上限",
            "prompt_text": PROMPT_TEXT, "prompt_ids": prompt_ids,
        },
        "baseline": {"new_tokens": len(base_tokens) - len(prompt_ids), "wall_s": base_s,
                     "forward_calls": len(base_tokens) - len(prompt_ids)},
        "speculative": {
            "new_tokens": len(spec_tokens) - len(prompt_ids), "wall_s": spec_s,
            "rounds": n_rounds, "mtp_accepted": accepted, "accept_rate": accept_rate,
            "per_round": rounds,
        },
        "checks": {"greedy_identical_output": identical, "pass": ok},
        "wall_seconds_total": round(time.perf_counter() - t0, 1),
        "degradation_note": ("CPU fp32 全量重算路径（投机与 baseline 同口径）；GDN 走参考实现，"
                             "墙钟仅作同机相对对照，无 GPU 性能结论（5.3）。峰值内存未采样（无 psutil）"),
    }
    (OUT_DIR / "mtp_raw.json").write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"结论：{'PASS' if ok else 'FAIL'}（mtp_raw.json）")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
