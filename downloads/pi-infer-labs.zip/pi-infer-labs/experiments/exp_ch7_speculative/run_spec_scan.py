#!/usr/bin/env python3
"""第 7 章：tiny CPU 投机候选长度、草稿质量及逐轮并发扫描。

关投机使用 greedy_decode 无缓存全量重算；开投机复用 speculative_generate，
其验证器也全量重算，拒绝后另作一次增量修正。oracle 与噪声草稿均真实调用
目标模型逐步前瞻，草稿成本全部计入墙钟，不能解释为廉价草稿模型的加速比。
每点预热一次，交错重复三次，报告原始秒数、均值和样本标准差。

并发采用外层轮次循环，每轮各请求推进一次 verify_and_accept，等价于现有
speculative_generate 的一轮；各请求有独立缓存、采样 RNG 和草稿 RNG。
这是 CPU 串行交错，并非张量 batch 或并行服务性能测试。

复跑：python experiments/exp_ch7_speculative/run_spec_scan.py
单点：python experiments/exp_ch7_speculative/run_spec_scan.py --k 4 --eps 2 --batch 4
扫描集可用空格覆盖，例如 --k 1 8 --eps 0.5 2 --batch 1 4；oracle 始终保留。
输出 spec_scan_raw.json；逐 token 不一致或自检失败退出 1，非法参数退出 2。
"""

from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import asdict, dataclass, field
import json
import math
from pathlib import Path
import platform
import statistics
import subprocess
import sys
import time

import torch

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from pi_infer.generate import greedy_decode  # noqa: E402
from pi_infer.model import SimpleKVCache, build_tiny_model  # noqa: E402
from pi_infer.speculative import (  # noqa: E402
    DraftResult, SamplingSpec, speculative_generate, verify_and_accept,
)

OUT_DIR = Path(__file__).resolve().parent
PROMPTS = [[2, 4, 6, 8], [1, 7, 13], [9, 3, 5, 11, 17], [21, 22, 23, 24, 25, 26]]
MAX_TOKENS = 16
REPEATS = 3
MODEL_SEED = 0
NOISE_SEED = 1729


def _sampling():
    """返回请求独立的 greedy SamplingSpec；贪心不消耗此 RNG。"""
    return SamplingSpec(greedy=True, rng=torch.Generator().manual_seed(0))


class _Draft:
    """输入非空 list[int] 前缀及 n，输出 n 个 token 和 float32 [V] logits。

    eps=None 表示 oracle；否则逐步对目标 logits 加 eps*N(0,1) 再 argmax。
    噪声 RNG 与采样 RNG 分离，每次完整请求重置；前瞻沿草稿自己的前缀推进。
    """

    def __init__(self, eps, prompt_index):
        self.eps = eps
        self.rng = torch.Generator().manual_seed(NOISE_SEED + prompt_index)
        self.busy = False
        self.pending = None
        self.forward_calls = 0

    @torch.no_grad()
    def __call__(self, model, ids, n):
        current, tokens, logits_list = list(ids), [], []
        self.busy = True
        try:
            for _ in range(n):
                logits = model(torch.tensor([current], dtype=torch.long))[0, -1]
                self.forward_calls += 1
                if self.eps is not None:
                    logits = logits + self.eps * torch.randn(logits.shape, generator=self.rng)
                token = int(logits.argmax())
                tokens.append(token)
                logits_list.append(logits.detach().clone())
                current.append(token)
        finally:
            self.busy = False
        self.pending = (len(ids), tokens)
        return DraftResult(tokens, logits_list)


def _round_row(proposed, accepted, corrected):
    """记录单轮实际检查位；首次拒绝后的草稿后缀不进入接受率分母。"""
    return {"draft_len": proposed, "accepted": accepted,
            "tested": accepted + int(corrected), "corrected": bool(corrected),
            "committed": accepted + int(corrected)}


def _trace_spec(model, prompt_index, k, eps):
    """只读 forward hook 观察真实 speculative_generate；详细采集不用于计时。"""
    draft = _Draft(eps, prompt_index)
    rows, calls = [], {"draft": 0, "verify": 0, "correction": 0}

    def observe(module, args, kwargs, output):
        if draft.busy:
            calls["draft"] += 1
        elif kwargs.get("start_pos", 0):
            calls["correction"] += 1
        else:
            calls["verify"] += 1
            prefix_len, tokens = draft.pending
            truth = output[0, prefix_len - 1:prefix_len + len(tokens) - 1].argmax(-1).tolist()
            accepted = next((i for i, (a, b) in enumerate(zip(tokens, truth)) if a != b), len(tokens))
            rows.append(_round_row(len(tokens), accepted, accepted < len(tokens)))

    handle = model.register_forward_hook(observe, with_kwargs=True)
    try:
        out = speculative_generate(model, draft, PROMPTS[prompt_index], MAX_TOKENS,
                                   _sampling(), max_draft_len=k)
    finally:
        handle.remove()
    return out, rows, calls


def _expected(alpha, gamma):
    """调整公式的稳定等价式 sum(alpha**i, i=0..gamma-1)，含 alpha=1 极限。"""
    return sum(alpha ** i for i in range(gamma))


def _summarize(rows, k):
    """汇总实际轮次，给出逐位条件接受率与名义/尾轮调整后的公式偏差。"""
    accepted = sum(r["accepted"] for r in rows)
    tested = sum(r["tested"] for r in rows)
    proposed = sum(r["draft_len"] for r in rows)
    alpha = accepted / tested
    measured = statistics.mean(r["committed"] for r in rows)
    expected = _expected(alpha, k)
    per_position = []
    for i in range(k):
        a = sum(r["accepted"] > i for r in rows)
        t = sum(r["tested"] > i for r in rows)
        per_position.append({"position": i, "accepted": a, "tested": t,
                             "alpha": a / t if t else None})
    corrections = sum(r["corrected"] for r in rows)
    tail_expected = statistics.mean(_expected(alpha, r["draft_len"]) for r in rows)
    return {
        "rounds": len(rows), "accepted_draft_tokens": accepted,
        "tested_draft_positions": tested, "proposed_draft_tokens": proposed,
        "alpha": alpha, "alpha_by_position": per_position,
        "accepted_over_proposed": accepted / proposed,
        "accepted_per_round_mean": accepted / len(rows),
        "accepted_per_round_histogram": dict(sorted(Counter(r["accepted"] for r in rows).items())),
        "committed_per_round_mean": measured,
        "committed_per_round_histogram": dict(sorted(Counter(r["committed"] for r in rows).items())),
        "forward_calls": {"draft": proposed, "verify": len(rows), "correction": corrections,
                          "target_including_correction": len(rows) + corrections,
                          "total_including_draft": proposed + len(rows) + corrections},
        "formula": {"gamma": k, "alpha": alpha, "expected": expected,
                    "measured": measured, "deviation": measured - expected,
                    "relative_deviation": measured / expected - 1,
                    "tail_length_weighted_expected": tail_expected,
                    "tail_length_weighted_deviation": measured - tail_expected},
    }


@dataclass
class _Request:
    """单请求状态，缓存覆盖全部已提交 token（遵循投机验证器契约）。"""

    prompt_index: int
    eps: float | None
    tokens: list[int] = field(init=False)
    cache: SimpleKVCache = field(default_factory=SimpleKVCache)
    sampling: SamplingSpec = field(default_factory=_sampling)
    rows: list[dict] = field(default_factory=list)
    service_s: float = 0.0

    def __post_init__(self):
        self.tokens = list(PROMPTS[self.prompt_index])
        self.draft = _Draft(self.eps, self.prompt_index)

    @property
    def generated(self):
        return len(self.tokens) - len(PROMPTS[self.prompt_index])


@torch.no_grad()
def _scheduled(model, batch, k, eps, interleaved, trace=False):
    """推进 B 条请求：交错每轮一步，或逐请求运行至完成；返回独立请求状态。

    每步直接复用 verify_and_accept，实现与 speculative_generate 相同的提交规则；
    无 EOS，最多 16 个新 token。service_s 是请求实际占用 CPU 的累计时间，
    排除等待其他请求的时间，不能当作端到端请求延迟。
    """
    requests = [_Request(i % len(PROMPTS), eps) for i in range(batch)]
    while any(r.generated < MAX_TOKENS for r in requests):
        for request in requests:
            while request.generated < MAX_TOKENS:
                start = time.perf_counter()
                n = min(k, MAX_TOKENS - request.generated)
                draft = request.draft(model, request.tokens, n)
                result = verify_and_accept(model, request.tokens, draft, request.cache, request.sampling)
                request.tokens.extend(result.accepted_tokens)
                if result.corrected_token is not None:
                    request.tokens.append(result.corrected_token)
                request.service_s += time.perf_counter() - start
                if trace:
                    request.rows.append(_round_row(n, len(result.accepted_tokens),
                                                  result.corrected_token is not None))
                if interleaved:
                    break
    return requests


def _stats(samples):
    """保留原始秒数/比值及均值、n-1 样本标准差。"""
    return {"samples": samples, "mean": statistics.mean(samples), "std": statistics.stdev(samples)}


def _paired_bench(left, right, validate):
    """两种完整工作负载各预热一次，AB/BA/AB 交错重复；校验在计时区间外。"""
    valid = True
    for fn in (left, right):
        valid = bool(validate(fn())) and valid
    samples, outputs = [[], []], [[], []]
    for repeat in range(REPEATS):
        for side in ((0, 1) if repeat % 2 == 0 else (1, 0)):
            start = time.perf_counter()
            out = (left, right)[side]()
            elapsed = time.perf_counter() - start
            samples[side].append(elapsed)
            outputs[side].append(out)
            valid = bool(validate(out)) and valid
    ratios = [b / a for a, b in zip(*samples)]
    return {"sequential_or_greedy_wall_s": _stats(samples[0]),
            "speculative_or_interleaved_wall_s": _stats(samples[1]),
            "relative_wall_ratio": _stats(ratios),
            "ratio_of_wall_means": statistics.mean(samples[1]) / statistics.mean(samples[0]),
            "all_outputs_identical": valid}, outputs


def _parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--k", nargs="+", type=int, default=[1, 2, 3, 4, 8], help="候选长度扫描集")
    parser.add_argument("--eps", nargs="+", type=float, default=[0.5, 2.0], help="噪声强度扫描集（另含 oracle）")
    parser.add_argument("--batch", nargs="+", type=int, default=[1, 2, 4], help="同时推进的请求数扫描集")
    parser.add_argument("--skip-mtp", action="store_true", help="不读取既有 mtp_raw.json；始终不重跑 MTP")
    args = parser.parse_args(argv)
    if any(k < 1 for k in args.k):
        parser.error("k 必须 >= 1")
    if any(not math.isfinite(eps) or eps < 0 for eps in args.eps):
        parser.error("eps 必须为有限非负数")
    if any(batch < 1 for batch in args.batch):
        parser.error("batch 必须 >= 1")
    # 保序去重，避免同一点被误当作不同测量条件。
    args.k, args.eps, args.batch = (list(dict.fromkeys(values)) for values in (args.k, args.eps, args.batch))
    return args


def _mtp_record(skip):
    """仅引用既有 MTP 实跑结果，不下载/加载模型，不重复实跑。"""
    path = OUT_DIR / "mtp_raw.json"
    if skip or not path.exists():
        return {"status": "SKIPPED", "reason": "--skip-mtp" if skip else "mtp_raw.json 不存在"}
    try:
        record = json.loads(path.read_text(encoding="utf-8"))
        passed = record["checks"]["pass"] is True and record["checks"]["greedy_identical_output"] is True
        return {"status": "PASS" if passed else "FAIL", "source": str(path.relative_to(ROOT)),
                "rerun": False, "record": record}
    except (OSError, ValueError, KeyError, TypeError) as error:
        return {"status": "FAIL", "source": str(path), "error": str(error)}


@torch.no_grad()
def main(argv=None):
    """运行扫描及自检，写 raw JSON 后以 PASS=0、FAIL=1 返回。"""
    args = _parse_args(argv)
    started = time.perf_counter()
    # tiny 张量固定单线程，避免默认线程池开销主导测量，记录实际线程配置。
    torch.set_num_threads(1)
    model = build_tiny_model(seed=MODEL_SEED).cpu().eval()
    references = [greedy_decode(model, p, MAX_TOKENS).token_ids for p in PROMPTS]
    try:
        git = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
    except (OSError, subprocess.SubprocessError):
        git = "unavailable"
    checks = {"formula_endpoints": _expected(0, 8) == 1 and _expected(1, 8) == 8}
    record = {
        "env": {"git": git, "python": platform.python_version(), "torch": torch.__version__,
                "platform": platform.platform(), "device": "cpu", "dtype": "float32",
                "threads": torch.get_num_threads(), "interop_threads": torch.get_num_interop_threads(),
                "model_config": asdict(model.config)},
        "generation_spec": {"prompt_ids": PROMPTS, "reference_token_ids": references,
                            "max_tokens": MAX_TOKENS, "eos_id": None, "model_seed": MODEL_SEED,
                            "sampling": "SamplingSpec(greedy=True, rng=torch.Generator().manual_seed(0))",
                            "noise_seed": "1729 + prompt_index，每次请求重置，与 B/k 无关",
                            "baseline": "greedy_decode，无缓存全量重算",
                            "speculative": "speculative_generate，整段全量验证，拒绝后增量修正，全接受不加 bonus",
                            "draft": "目标模型全量逐步前瞻；oracle=argmax，noise=argmax(logits+eps*N(0,1))"},
        "timing_spec": {"clock": "perf_counter，CPU 同步执行", "warmup": 1, "repeats": REPEATS,
                        "order": "AB/BA/AB；每个点均成对交错重复", "std": "样本标准差 n-1",
                        "included": "全部起草、验证、修正、缓存分配/复制及生成 bookkeeping",
                        "excluded": "模型构造、详细 hook/轮次采集、输出校验、JSON/打印",
                        "relative_ratio": "开投机/关投机，或逐轮交错/同批请求逐条 B=1 顺序运行；<1 较快",
                        "concurrency": "外层逐轮推进 B 个独立请求；CPU 串行交错，无张量合批",
                        "per_request_time": "累计 CPU service time/token，非含排队的端到端延迟"},
        "formula_spec": {"expression": "(1-alpha**(gamma+1))/(1-alpha) - alpha**gamma",
                         "alpha_one_limit": "gamma", "alpha": "接受数/实际检查位数，拒绝后后缀不计分母",
                         "note": "常数独立同分布接受率近似；位置相关、有限样本及末轮 n<gamma 均可造成偏差；不作吻合验收"},
        "scan_sets": {"k": args.k, "eps": args.eps, "batch": args.batch},
        "mtp": _mtp_record(args.skip_mtp), "candidate_scan": [], "concurrency_scan": [],
        "degradation_note": "CPU 同机相对对照，无 GPU 性能结论；生产引擎扫描未测。oracle 起草也计费，不能外推生产加速。",
    }
    checks["mtp_existing_result"] = record["mtp"]["status"] != "FAIL"
    qualities = [("oracle", None)] + [("noise", eps) for eps in args.eps]
    for k in args.k:
        quality_alpha = {}
        for quality, eps in qualities:
            label = f"k={k}/{quality}/eps={eps}"
            per_prompt, all_rows = [], []
            for i in range(len(PROMPTS)):
                out, rows, calls = _trace_spec(model, i, k, eps)
                summary = _summarize(rows, k)
                checks[f"{label}/prompt={i}"] = (
                    out.token_ids == references[i] and out.steps == MAX_TOKENS
                    and sum(r["committed"] for r in rows) == MAX_TOKENS
                    and calls == {name: summary["forward_calls"][name] for name in calls})
                per_prompt.append({"prompt_index": i, "token_ids": out.token_ids,
                                   "identical": out.token_ids == references[i], "per_round": rows, **summary})
                all_rows.extend(rows)
            summary = _summarize(all_rows, k)
            quality_alpha[(quality, eps)] = summary["alpha"]

            def baseline():
                return [greedy_decode(model, p, MAX_TOKENS) for p in PROMPTS]

            def speculative():
                return [speculative_generate(model, _Draft(eps, i), p, MAX_TOKENS,
                                             _sampling(), max_draft_len=k) for i, p in enumerate(PROMPTS)]

            timing, _ = _paired_bench(baseline, speculative,
                                      lambda results: [r.token_ids for r in results] == references)
            checks[f"{label}/timed_outputs"] = timing["all_outputs_identical"]
            record["candidate_scan"].append({"k": k, "quality": quality, "eps": eps,
                                              **summary, "per_prompt": per_prompt, "timing": timing})
            print(f"[候选] {label}: alpha={summary['alpha']:.3f}, "
                  f"提交={summary['committed_per_round_mean']:.3f}, "
                  f"公式={summary['formula']['expected']:.3f}, "
                  f"墙钟比={timing['relative_wall_ratio']['mean']:.3f}"
                  f" +/- {timing['relative_wall_ratio']['std']:.3f}", flush=True)

            for batch in args.batch:
                sequential = _scheduled(model, batch, k, eps, False, trace=True)
                interleaved = _scheduled(model, batch, k, eps, True, trace=True)
                expected_ids = [references[i % len(PROMPTS)] for i in range(batch)]
                timing, timed_outputs = _paired_bench(
                    lambda: _scheduled(model, batch, k, eps, False),
                    lambda: _scheduled(model, batch, k, eps, True),
                    lambda results: [r.tokens for r in results] == expected_ids)
                requests = []
                for i, (seq, inter) in enumerate(zip(sequential, interleaved)):
                    seq_summary, inter_summary = _summarize(seq.rows, k), _summarize(inter.rows, k)
                    service_samples = [[runs[i].service_s / MAX_TOKENS for runs in side] for side in timed_outputs]
                    requests.append({"request_index": i, "prompt_index": inter.prompt_index,
                                     "token_ids": inter.tokens, "per_round": inter.rows,
                                     "sequential": seq_summary, "interleaved": inter_summary,
                                     "alpha_delta_vs_sequential": inter_summary["alpha"] - seq_summary["alpha"],
                                     "sequential_service_s_per_token": _stats(service_samples[0]),
                                     "interleaved_service_s_per_token": _stats(service_samples[1]),
                                     "relative_service_time_per_token": _stats([b / a for a, b in zip(*service_samples)])})
                    cache_ok = all(inter.cache.get(layer)[0].shape[2] == len(inter.tokens)
                                   for layer in range(model.config.n_layers))
                    checks[f"{label}/B={batch}/request={i}"] = (
                        seq.tokens == inter.tokens == expected_ids[i]
                        and seq.rows == inter.rows == per_prompt[inter.prompt_index]["per_round"]
                        and cache_ok)
                checks[f"{label}/B={batch}/timed_outputs"] = timing["all_outputs_identical"]
                token_count = batch * MAX_TOKENS
                timing["sequential_s_per_token"] = _stats([s / token_count for s in timing["sequential_or_greedy_wall_s"]["samples"]])
                timing["interleaved_s_per_token"] = _stats([s / token_count for s in timing["speculative_or_interleaved_wall_s"]["samples"]])
                record["concurrency_scan"].append({"k": k, "quality": quality, "eps": eps,
                                                  "batch": batch, "requests": requests, "timing": timing})
            print(f"[并发] {label}: B={args.batch} 已完成逐请求对照", flush=True)
        checks[f"k={k}/oracle_alpha_one"] = quality_alpha[("oracle", None)] == 1.0
        # eps=0 合法且等价 oracle；用户单点覆盖可能没有噪声拒绝，不强迫出现差异。
        record.setdefault("quality_comparison", []).append({
            "k": k, "oracle_alpha": quality_alpha[("oracle", None)],
            "noise": [{"eps": eps, "alpha": quality_alpha[("noise", eps)],
                       "oracle_minus_noise": 1.0 - quality_alpha[("noise", eps)]} for eps in args.eps]})
    record["checks"] = checks
    record["all_pass"] = all(checks.values())
    record["verdict"] = "PASS" if record["all_pass"] else "FAIL"
    record["wall_seconds_total"] = time.perf_counter() - started
    path = OUT_DIR / "spec_scan_raw.json"
    path.write_text(json.dumps(record, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    print(f"结论：{record['verdict']}，耗时 {record['wall_seconds_total']:.1f}s；{path}")
    return 0 if record["all_pass"] else 1


if __name__ == "__main__":
    sys.exit(main())
