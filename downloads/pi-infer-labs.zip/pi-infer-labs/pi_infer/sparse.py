"""True 表示保留的因果 mask，以及确实跳过空块 matmul 的教学注意力。"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Callable

import torch
from torch import Tensor


def _positive_int(value: int, name: str) -> None:
    if type(value) is not int or value <= 0:
        raise ValueError(f"{name} 必须是正整数")


def _validate_attention(q: Tensor, k: Tensor, v: Tensor) -> None:
    for name, tensor in (("q", q), ("k", k), ("v", v)):
        if not isinstance(tensor, Tensor):
            raise TypeError(f"{name} 必须是 Tensor")
        if tensor.ndim != 4 or any(size == 0 for size in tensor.shape):
            raise ValueError(f"{name} 必须是非空四维张量")
        if tensor.dtype != torch.float32 or tensor.device.type != "cpu":
            raise ValueError(f"{name} 仅支持 fp32 CPU")
        # 标量归约避免验证过程分配与完整序列等大的 bool 张量。
        if not math.isfinite(tensor.amin().item()) or not math.isfinite(tensor.amax().item()):
            raise ValueError(f"{name} 必须仅包含有限值")
    if k.shape != v.shape or q.shape[0] != k.shape[0] or q.shape[-1] != k.shape[-1]:
        raise ValueError("q/k/v 的 batch、head_dim 或 K/V 形状不匹配")
    if q.shape[1] % k.shape[1]:
        raise ValueError("Hq 必须能被 Hkv 整除")


def _validate_mask(mask: Tensor, q: Tensor, k: Tensor) -> None:
    if not isinstance(mask, Tensor):
        raise TypeError("mask 必须是 Tensor")
    if mask.dtype != torch.bool or mask.device.type != "cpu":
        raise ValueError("mask 必须是 CPU bool 张量")
    if mask.shape != (q.shape[-2], k.shape[-2]):
        raise ValueError("mask 必须具有 [Tq,Tk] 形状")


def _qk_into(q: Tensor, k: Tensor, out: Tensor) -> None:
    """按 KV head 分组广播，与 repeat_interleave 语义一致但不物化副本。"""
    repeats = q.shape[1] // k.shape[1]
    for head in range(k.shape[1]):
        group = slice(head * repeats, (head + 1) * repeats)
        torch.matmul(q[:, group], k[:, head:head + 1].transpose(-2, -1), out=out[:, group])


def _pv_into(p: Tensor, v: Tensor, out: Tensor) -> None:
    repeats = p.shape[1] // v.shape[1]
    for head in range(v.shape[1]):
        group = slice(head * repeats, (head + 1) * repeats)
        torch.matmul(p[:, group], v[:, head:head + 1], out=out[:, group])


def sliding_window_causal_mask(T: int, window: int) -> Tensor:
    """正整数 T/window -> CPU bool [T,T]；True 当且仅当 i-window < j <= i。"""
    _positive_int(T, "T")
    _positive_int(window, "window")
    positions = torch.arange(T)
    return (positions[None, :] <= positions[:, None]) & (positions[None, :] > positions[:, None] - window)


def block_sparse_mask(T: int, block_size: int, pattern: str | Callable[[int, int], bool]) -> Tensor:
    """返回 CPU bool [T,T]，块级 pattern 与 token 级因果性取交集。

    T/block_size 为正整数且须整除；callable 接受从 0 开始的块行列号并返回 bool。
    'band' 保留主对角及相邻块（因果交集后仅主对角及前一块）。
    """
    _positive_int(T, "T")
    _positive_int(block_size, "block_size")
    if T % block_size:
        raise ValueError("T 必须按 block_size 块对齐")
    if not callable(pattern) and pattern != "band":
        raise ValueError("pattern 必须是 'band' 或 callable")
    mask = torch.zeros(T, T, dtype=torch.bool)
    for row in range(T // block_size):
        for col in range(T // block_size):
            keep = abs(row - col) <= 1 if pattern == "band" else pattern(row, col)
            if type(keep) is not bool:
                raise TypeError("pattern 必须返回 bool")
            if keep:
                mask[row * block_size:(row + 1) * block_size, col * block_size:(col + 1) * block_size] = True
    return mask.tril_()


@dataclass
class SparseStats:
    """空间块数不乘 B/H；FLOPs 含 B*Hq，QK 与 PV 各计每元素 2*D。"""

    kept_blocks: int
    skipped_blocks: int
    flops_dense: int
    flops_actual: int


def _probabilities(scores: Tensor) -> Tensor:
    """全遮罩行返回零；其余行减 max 后归一化。"""
    maximum = scores.amax(dim=-1, keepdim=True)
    maximum.masked_fill_(maximum == -torch.inf, 0)
    weights = (scores - maximum).exp()
    return weights / weights.sum(dim=-1, keepdim=True).clamp_min(torch.finfo(scores.dtype).tiny)


@torch.no_grad()
def masked_dense_attention(q: Tensor, k: Tensor, v: Tensor, mask: Tensor) -> Tensor:
    """fp32 CPU q [B,Hq,Tq,D]、k/v [B,Hkv,Tk,D] -> out [B,Hq,Tq,D]。

    Hq 必须能被 Hkv 整除；GQA 连续 query 组共享 KV。先物化完整 scores 再应用
    CPU bool [Tq,Tk] mask（True=保留）；全遮罩行输出零。仅供推理，不构建梯度图。
    """
    _validate_attention(q, k, v)
    _validate_mask(mask, q, k)
    scores = torch.empty((*q.shape[:3], k.shape[-2]), dtype=q.dtype, device=q.device)
    _qk_into(q, k, scores)
    scores.div_(math.sqrt(q.shape[-1])).masked_fill_(~mask, -torch.inf)
    weights = _probabilities(scores)
    out = torch.empty_like(q)
    _pv_into(weights, v, out)
    return out


@torch.no_grad()
def blocked_sparse_attention(
    q: Tensor, k: Tensor, v: Tensor, mask: Tensor, *, block_size: int,
) -> tuple[Tensor, SparseStats]:
    """fp32 CPU GQA 输入同 masked_dense_attention，返回同形输出及 SparseStats。

    CPU bool mask [Tq,Tk] 中全 False 的空间块跳过 QK/PV；部分保留块仍按整块计
    FLOPs。Tq/Tk 须按正整数 block_size 对齐。全遮罩行输出零；仅供推理。
    """
    _validate_attention(q, k, v)
    _validate_mask(mask, q, k)
    _positive_int(block_size, "block_size")
    tq, tk, dim = q.shape[-2], k.shape[-2], q.shape[-1]
    if tq % block_size or tk % block_size:
        raise ValueError("Tq/Tk 必须按 block_size 块对齐")
    out = torch.zeros_like(q)
    kept = skipped = 0
    for row in range(0, tq, block_size):
        qs = slice(row, row + block_size)
        scores = torch.full((*q.shape[:2], block_size, tk), -torch.inf, dtype=q.dtype)
        columns = []
        for col in range(0, tk, block_size):
            ks = slice(col, col + block_size)
            block_mask = mask[qs, ks]
            if not block_mask.any():
                skipped += 1
                continue
            kept += 1
            columns.append(ks)
            _qk_into(q[:, :, qs], k[:, :, ks], scores[..., ks])
            scores[..., ks].div_(math.sqrt(dim)).masked_fill_(~block_mask, -torch.inf)
        weights = _probabilities(scores)
        for ks in columns:
            contribution = torch.empty_like(out[:, :, qs])
            _pv_into(weights[..., ks], v[:, :, ks], contribution)
            out[:, :, qs].add_(contribution)
    per_block = q.shape[0] * q.shape[1] * block_size**2 * 2 * dim * 2
    return out, SparseStats(kept, skipped, (kept + skipped) * per_block, kept * per_block)
