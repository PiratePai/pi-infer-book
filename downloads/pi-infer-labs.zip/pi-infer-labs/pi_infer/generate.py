"""并排提供全量重算与 KV 增量两种贪心解码路径。"""

from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import Tensor

from .model import KVCache, TinyTransformer


@dataclass
class GenerateResult:
    """token_ids 含原始 prompt；每个生成 token 对应一个 [V] logits。

    steps 是实际生成 token 数，包含命中的 EOS。kv_stats 统计本次调用
    每层读写的 KV token 槽位数（B*T，K/V 合为一对），包含 prompt；
    无缓存时 reads/writes 均为零，不计注意力内部的重复访存或复制。
    """

    token_ids: list[int]
    per_step_logits: list[Tensor]
    steps: int
    kv_stats: dict[str, int]


class _CountingCache:
    """以协议包装任意缓存，计数不依赖 SimpleKVCache 的存储细节。"""

    def __init__(self, cache: KVCache, stats: dict[str, int]) -> None:
        self.cache = cache
        self.stats = stats

    def get(self, layer_idx: int) -> tuple[Tensor | None, Tensor | None]:
        """空缓存不计读取；历史 KV 按实际返回的槽位数计数。"""
        k, v = self.cache.get(layer_idx)
        if k is not None:
            self.stats["reads"] += k.shape[0] * k.shape[2]
        return k, v

    def append(self, layer_idx: int, k: Tensor, v: Tensor) -> None:
        """只统计模型请求的追加量，不计缓存实现内部的拼接拷贝。"""
        self.cache.append(layer_idx, k, v)
        self.stats["writes"] += k.shape[0] * k.shape[2]

    def record_tokens(self, token_ids: list[int], start_pos: int) -> None:
        """透传可选 token 登记钩子，不计入 KV 读写量。"""
        record = getattr(self.cache, "record_tokens", None)
        if record is not None:
            record(token_ids, start_pos)


@torch.no_grad()
def greedy_decode(
    model: TinyTransformer,
    prompt_ids: list[int],
    max_new_tokens: int,
    kv_cache: KVCache | None = None,
    eos_id: int | None = None,
) -> GenerateResult:
    """从非空 prompt 贪心生成；缓存为空或为本次请求已匹配的分页前缀。

    无缓存时每次送入全部已知 token；有缓存时仅 prefill 未命中部分，
    此后每次只送入上次生成的 token。最后生成的 token 尚未做前向，
    因而不在缓存内。EOS 仅检查新生成的 token，prompt 中的 EOS 不停止生成。
    max_new_tokens=0 时不调用模型，也不读写缓存。
    """
    if not prompt_ids:
        raise ValueError("prompt_ids 不能为空")
    if not isinstance(max_new_tokens, int) or max_new_tokens < 0:
        raise ValueError("max_new_tokens 必须是非负整数")
    token_ids = list(prompt_ids)
    logits_history: list[Tensor] = []
    stats = {"reads": 0, "writes": 0}
    cache = None if kv_cache is None else _CountingCache(kv_cache, stats)
    device = model.embedding.weight.device
    prefill_start = 0 if kv_cache is None else getattr(kv_cache, "prefill_start_pos", 0)
    if prefill_start > len(prompt_ids):
        raise ValueError("缓存前缀长于 prompt")
    if max_new_tokens and prefill_start == len(prompt_ids):
        # KV 不存 logits：重算最后一个 prompt token，以获得首步分布。
        kv_cache.truncate_to(prefill_start - 1)
        prefill_start -= 1
    for step in range(max_new_tokens):
        if cache is None:
            input_ids, start_pos = token_ids, 0
        elif step == 0:
            input_ids, start_pos = token_ids[prefill_start:], prefill_start
        else:
            input_ids, start_pos = token_ids[-1:], len(token_ids) - 1
        inputs = torch.tensor([input_ids], dtype=torch.long, device=device)
        logits = model(inputs, start_pos=start_pos, kv_cache=cache)[0, -1].detach().clone()
        next_id = int(logits.argmax().item())
        logits_history.append(logits)
        token_ids.append(next_id)
        if next_id == eos_id:
            break
    return GenerateResult(token_ids, logits_history, len(logits_history), stats)
