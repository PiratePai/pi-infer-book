"""执行实验的 CPU 状态校验、异常转发与成对计时回归。"""

import json
import runpy
import sys
from contextlib import nullcontext
from pathlib import Path
from types import SimpleNamespace

import pytest
import torch


EXPERIMENTS = Path(__file__).resolve().parents[2] / "experiments"


@pytest.fixture
def execution():
    return runpy.run_path(str(EXPERIMENTS / "exp_ch8_exec/run_exec_experiment.py"))


def test_cpu_graph_rejected_shape_change_preserves_original_fallback(execution):
    runner = execution["CudaGraphRunner"](lambda x: x + 1, torch.zeros(2, 3))
    assert runner._signature[-1] == "cpu"
    runner.call(torch.ones(2, 3))
    with pytest.raises(ValueError, match="签名变化"):
        runner.call(torch.ones(4, 3))
    assert torch.equal(runner.call(torch.ones(2, 3)), torch.full((2, 3), 2.))
    assert runner.status.eager_fallbacks == 2
    assert runner.status.captures == runner.status.replays == runner.status.recaptures_shape_change == 0


def test_graph_capture_failure_preserves_graph_buffers_signature_and_device_index(execution, monkeypatch):
    runner = execution["CudaGraphRunner"](lambda x: x + 1, torch.zeros(2, 3))
    monkeypatch.setattr(torch.cuda, "is_available", lambda: True)
    monkeypatch.setattr(runner, "_warmup_on_side_stream", lambda x: None)
    monkeypatch.setattr(torch.cuda, "CUDAGraph", object)
    monkeypatch.setattr(torch.cuda, "graph", lambda graph: nullcontext())

    def fake_input(index):
        return SimpleNamespace(shape=(2, 3), dtype=torch.float32, device=torch.device(f"cuda:{index}"),
                               is_cuda=True, clone=lambda: torch.zeros(2, 3))

    runner._capture(fake_input(0))
    assert runner._signature[-1] == "cuda:0"
    original = (runner._signature, runner._graph, runner._static_input, runner._static_output)
    status = vars(runner.status).copy()

    def fail(x):
        raise RuntimeError("捕获失败")

    runner.fn = fail
    with pytest.raises(RuntimeError, match="捕获失败"):
        runner.call(fake_input(1))
    assert runner._signature == original[0]
    assert runner._graph is original[1]
    assert runner._static_input is original[2] and runner._static_output is original[3]
    assert vars(runner.status) == status


@pytest.mark.parametrize("side", ["producer", "consumer"])
def test_pipeline_worker_exception_reaches_caller_without_queue_deadlock(execution, monkeypatch, side):
    pipeline = execution["_run_pipeline"]

    def fail(*args):
        raise RuntimeError(f"{side} 故障")

    monkeypatch.setitem(pipeline.__globals__, "_consume", fail if side == "consumer" else lambda x: x)
    with pytest.raises(RuntimeError, match=f"{side} 故障"):
        pipeline(fail if side == "producer" else lambda: 1, depth=1, batches=20)


def test_timed_pair_warms_both_and_retains_interleaved_samples(execution):
    calls = []
    rows = execution["timed"](lambda: calls.append("A"), interleave=lambda: calls.append("B"),
                               warmup=2, repeats=3)
    assert calls == ["A", "B"] * 5
    assert all(len(row["samples"]) == 3 for row in rows)


def test_pipeline_normal_path_consumes_all_batches(execution, monkeypatch):
    received = []
    pipeline = execution["_run_pipeline"]
    monkeypatch.setitem(pipeline.__globals__, "_consume", received.append)
    items = iter(range(9))
    assert pipeline(lambda: next(items), batches=9, depth=1) >= 0
    assert received == list(range(9))


def test_x5_failure_cleans_unique_temporary_files(execution, monkeypatch):
    x5 = execution["x5_pipeline"]
    paths = []

    def fail_io(path):
        paths.append(path)
        path.write_bytes(b"partial payload")
        raise OSError("磁盘故障")

    monkeypatch.setitem(x5.__globals__, "_produce_compute", lambda: 1)
    monkeypatch.setitem(x5.__globals__, "_consume", lambda x: x)
    monkeypatch.setitem(x5.__globals__, "_produce_io", fail_io)
    for _ in range(2):
        with pytest.raises(OSError, match="磁盘故障"):
            x5()
    assert paths[0] != paths[1]
    assert all(not path.parent.exists() for path in paths)


def test_x5_pairs_both_variants_and_preserves_samples(execution, monkeypatch):
    x5 = execution["x5_pipeline"]
    calls = []
    monkeypatch.setitem(x5.__globals__, "_run_serial", lambda produce: calls.append("serial"))
    monkeypatch.setitem(x5.__globals__, "_run_pipeline", lambda produce: calls.append("prefetch"))
    result = x5()
    assert calls == ["serial", "prefetch"] * (2 * (execution["WARMUP"] + execution["REPEATS"]))
    for row in result["variants"].values():
        assert len(row["serial_samples"]) == len(row["prefetch_samples"]) == execution["REPEATS"]


def test_compile_probe_calls_without_arguments_and_compares_output(execution, monkeypatch):
    calls = []

    def compile_fn(fn):
        def compiled():
            calls.append("compiled")
            return fn()
        return compiled

    monkeypatch.setattr(torch, "compile", compile_fn)
    assert execution["_probe_compile"](lambda: torch.ones(2))["status"] == "available"
    assert calls == ["compiled"]
    monkeypatch.setattr(torch, "compile", lambda fn: lambda: torch.zeros(2))
    with pytest.raises(RuntimeError, match="探测代码/执行错误"):
        execution["_probe_compile"](lambda: torch.ones(2))


def test_compile_probe_only_degrades_known_environment_failures(execution, monkeypatch):
    class InvalidCxxCompiler(RuntimeError):
        pass

    def unavailable(fn):
        raise InvalidCxxCompiler("找不到编译器")

    monkeypatch.setattr(torch, "compile", unavailable)
    result = execution["_probe_compile"](lambda: torch.ones(2))
    assert result == {"status": "unavailable", "error": "InvalidCxxCompiler: 找不到编译器"}

    def invalid(fn):
        raise TypeError("错误的探测参数")

    monkeypatch.setattr(torch, "compile", invalid)
    with pytest.raises(RuntimeError, match="TypeError: 错误的探测参数"):
        execution["_probe_compile"](lambda: torch.ones(2))


def test_exec_main_failure_persists_false_and_returns_nonzero(execution, monkeypatch, tmp_path):
    main = execution["main"]

    def fail(record):
        raise RuntimeError("流水线故障")

    monkeypatch.setitem(main.__globals__, "_run_experiment", fail)
    monkeypatch.setitem(main.__globals__, "OUT_DIR", tmp_path)
    assert main() == 1
    raw = json.loads((tmp_path / "raw.json").read_text(encoding="utf-8"))
    assert raw["pass"] is False and raw["checks"]["pass"] is False
    assert "流水线故障" in raw["error"]


@pytest.mark.parametrize("allowed", [False, True])
def test_pd_experiment_gloo_failure_requires_explicit_fallback(monkeypatch, tmp_path, allowed):
    experiment = runpy.run_path(str(EXPERIMENTS / "exp_ch11_pd/run_pd_experiment.py"))
    main = experiment["main"]

    def fail():
        raise RuntimeError("gloo 故障")

    monkeypatch.setitem(main.__globals__, "_run_gloo", fail)
    monkeypatch.setitem(main.__globals__, "_run_inprocess", lambda: {"pass": True, "scan": []})
    monkeypatch.setitem(main.__globals__, "_write_curve", lambda *args: None)
    output = tmp_path / "pd.json"
    monkeypatch.setattr(sys, "argv", ["run_pd_experiment.py", "--output", str(output)]
                        + (["--allow-fallback"] if allowed else []))
    assert main() == (0 if allowed else 1)
    raw = json.loads(output.read_text(encoding="utf-8"))
    assert raw["fallback"]["used"] and "gloo 故障" in raw["fallback"]["reason"]
    assert raw["pass"] is allowed and not raw["gloo_two_process_pass"]
