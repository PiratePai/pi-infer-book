"""CPU MoE：独立数值参考、整 token 原子溢出、负载与三笔资源账。"""

from dataclasses import replace
import json
from pathlib import Path
import runpy

import pytest
import torch

from pi_infer.moe import MoEConfig, MoEFFN, Router, controlled_router_probs, controlled_routing


@pytest.fixture(scope="module", autouse=True)
def one_thread():
    previous = torch.get_num_threads()
    torch.set_num_threads(1)
    yield
    torch.set_num_threads(previous)


def test_router_seeded_fixed_logits_and_softmax_gates():
    torch.manual_seed(12)
    router = Router(3, 4, k=2)
    assert torch.equal(router(torch.eye(3))[0], torch.tensor([[3, 2], [1, 2], [2, 3]]))
    # 固定种子输入后钉住 logits，期望专家独立手算。
    x = torch.eye(3)
    with torch.no_grad():
        router.linear.weight.copy_(torch.tensor([[1., 0., 2.], [3., 1., 0.],
                                                 [2., 4., 1.], [0., 2., 3.]]))
    indices, gates = router(x)
    assert torch.equal(indices, torch.tensor([[1, 2], [2, 3], [3, 0]]))
    expected = torch.tensor([[3., 2.], [4., 2.], [3., 2.]]).exp()
    denominator = torch.tensor([[1., 3., 2., 0.], [0., 1., 4., 2.], [2., 0., 1., 3.]]).exp().sum(1)
    torch.testing.assert_close(gates, expected / denominator[:, None])
    assert torch.equal(router(x)[0], indices)
    assert torch.equal(router(x)[1], gates)
    assert router(x, k=4)[0].shape == (3, 4)
    # softmax top-k 不再归一化；k=1 的 gate 也不是恒为 1。
    assert (gates.sum(1) < 1).all()
    with torch.no_grad():
        router.linear.weight.zero_()
    assert torch.equal(router(x)[0], torch.tensor([[0, 1]] * 3))


def test_experts_independent_reproducible_and_rng_isolated():
    cfg = MoEConfig(d_model=4, d_ff=7, num_experts=3, seed=17)
    before = torch.random.get_rng_state().clone()
    first = MoEFFN(cfg)
    assert torch.equal(before, torch.random.get_rng_state())
    torch.randn(20)
    second = MoEFFN(cfg)
    for name, weight in first.state_dict().items():
        assert torch.equal(weight, second.state_dict()[name])
    a, b = (module.gate_proj.weight for module in first.experts[:2])
    assert a.data_ptr() != b.data_ptr() and not torch.equal(a, b)


def test_single_token_k1_activates_one_expert_and_counts_parameters():
    model = MoEFFN(MoEConfig(d_model=4, d_ff=7, num_experts=4))
    _, stats = model(torch.ones(1, 4))
    assert stats.activated_params == 3 * 4 * 7 == stats.expert_params
    assert stats.activated_param_ratio == 1 / 4
    assert stats.total_params == sum(p.numel() for p in model.parameters())
    assert stats.total_params == 4 * 84 + 4 * 4
    assert stats.executed_flops == 2 * 84
    assert stats.flops_ratio_vs_dense == 1 / 4


@pytest.mark.parametrize("k,cf", [(1, 1.0), (1, 1.25), (2, 2.0)])
def test_balanced_uniform_no_overflow_when_capacity_sufficient(k, cf):
    cfg = MoEConfig(d_model=4, d_ff=7, k=k, capacity_factor=cf)
    _, stats = MoEFFN(cfg)(torch.ones(64, 4), controlled_routing(8, k, "uniform"))
    assert stats.overflow_tokens == 0
    assert stats.expert_token_counts == [8 * k] * 8
    assert stats.activated_params == stats.expert_total_params


def test_k2_capacity_is_not_silently_multiplied_by_k():
    _, stats = MoEFFN(MoEConfig(d_model=4, d_ff=7, k=2))(
        torch.ones(64, 4), controlled_routing(8, 2, "uniform"))
    assert stats.capacity_limit == stats.capacity == 8
    assert stats.processed_tokens == 32 and stats.overflow_tokens == 32
    assert stats.expert_token_assignments == 64


def test_peak_overflow_decreases_with_more_capacity():
    routing = controlled_routing(8, 1, "peak", tokens=64, p=0.8, seed=12)
    base = MoEConfig(d_model=4, d_ff=7)
    rates = [MoEFFN(replace(base, capacity_factor=cf))(torch.ones(64, 4), routing)[1].overflow_rate
             for cf in (1., 1.25, 2.)]
    assert rates[0] >= rates[1] >= rates[2]
    assert rates[0] > rates[-1] > 0


def test_token_atomic_overflow_weighted_output_and_hand_byte_ledger():
    # T=4,N=3: ceil(4/3)*1 = 2 槽。逐 token 独立枚举：
    # t0:[0,1] 接纳→[1,1,0]；t1:[0,2] 接纳→[2,1,1]；
    # t2:[0,1] 整体拒绝→[2,1,1]（专家1不能偷占位）；
    # t3:[1,2] 接纳→[2,2,2]。单程 6*4*4=96B，两程 192B。
    model = MoEFFN(MoEConfig(d_model=4, d_ff=7, num_experts=3, k=2))
    x = torch.arange(16, dtype=torch.float32).view(4, 4) / 16
    indices = torch.tensor([[0, 1], [0, 2], [0, 1], [1, 2]])
    gates = torch.tensor([[.6, .4], [.7, .2], [.5, .5], [.8, .1]])
    output, stats = model(x, (indices, gates))
    for token in (0, 1, 3):
        expected = sum(gates[token, slot] * model.experts[expert](x[token])
                       for slot, expert in enumerate(indices[token].tolist()))
        torch.testing.assert_close(output[token], expected)
    assert torch.equal(output[2], x[2])
    assert stats.expert_token_counts == [2, 2, 2]
    assert stats.requested_token_counts == [3, 3, 2]
    assert stats.overflow_tokens == 1 and stats.processed_tokens == 3
    assert stats.ep_dispatch_bytes == stats.ep_return_bytes == 96
    assert stats.ep_total_bytes == 192 and stats.ep_bytes_per_token == 48
    assert stats.executed_flops == 2 * 84 * 6
    assert stats.dense_flops == 2 * (3 * 84) * 4
    assert stats.flops_ratio_vs_dense == .5
    assert stats.flops_ratio_vs_single_expert_dense == 1.5


def test_fractional_capacity_floors_and_zero_capacity_is_residual():
    model = MoEFFN(MoEConfig(d_model=4, d_ff=7, capacity_factor=.5))
    x = torch.randn(1, 4)
    output, stats = model(x)
    assert stats.capacity_limit == .5 and stats.capacity == 0
    assert torch.equal(output, x)
    assert stats.activated_params == stats.executed_flops == stats.ep_total_bytes == 0


def test_external_and_internal_routing_match_and_stats_reset_each_forward():
    model = MoEFFN(MoEConfig(d_model=4, d_ff=7, k=2, capacity_factor=2))
    x = torch.randn(16, 4)
    expected, expected_stats = model(x)
    actual, stats = model(x, model.router(x))
    assert torch.equal(actual, expected) and stats == expected_stats
    _, smaller = model(x[:1])
    assert smaller.tokens == 1 and smaller.expert_token_assignments == 2


def test_gradients_reach_router_and_used_experts():
    model = MoEFFN(MoEConfig(d_model=4, d_ff=7))
    x = torch.randn(8, 4, requires_grad=True)
    output, _ = model(x)
    output.square().sum().backward()
    assert x.grad is not None and torch.isfinite(x.grad).all()
    assert model.router.linear.weight.grad is not None
    assert any(expert.down_proj.weight.grad is not None for expert in model.experts)


@pytest.mark.parametrize("dist", ["uniform", "peak", "temperature"])
@pytest.mark.parametrize("k", [1, 2, 8])
def test_controlled_routing_seed_shape_uniqueness_normalization(dist, k):
    kwargs = dict(tokens=64, seed=17, p=.8, temperature=.5)
    before = torch.random.get_rng_state().clone()
    indices, gates = controlled_routing(8, k, dist, **kwargs)
    other_indices, other_gates = controlled_routing(8, k, dist, **kwargs)
    assert torch.equal(before, torch.random.get_rng_state())
    assert torch.equal(indices, other_indices) and torch.equal(gates, other_gates)
    assert indices.dtype == torch.int64 and gates.dtype == torch.float32
    assert indices.shape == gates.shape == (64, k)
    assert (gates[:, :-1] >= gates[:, 1:]).all()
    assert all(len(set(row)) == k for row in indices.tolist())
    probabilities = controlled_router_probs(8, dist, p=.8, temperature=.5)
    expected = probabilities[indices]
    torch.testing.assert_close(gates, expected / expected.sum(1, keepdim=True))
    torch.testing.assert_close(gates.sum(1), torch.ones(64))


def test_temperature_probabilities_and_low_temperature_full_k():
    logits = torch.tensor([0., 1., 3.])
    torch.testing.assert_close(controlled_router_probs(3, "temperature", temperature=2, logits=logits),
                               (logits / 2).softmax(0))
    cold = controlled_router_probs(3, "temperature", temperature=.1, logits=logits)
    assert cold[-1] > .99
    _, gates = controlled_routing(3, 3, "temperature", temperature=1e-300, logits=logits)
    assert torch.isfinite(gates).all()


@pytest.mark.parametrize("dist", ["uniform", "peak", "temperature"])
def test_controlled_routing_stays_float32_under_float64_default(dist):
    previous = torch.get_default_dtype()
    try:
        torch.set_default_dtype(torch.float64)
        assert controlled_router_probs(8, dist).dtype == torch.float32
        assert controlled_routing(8, 2, dist)[1].dtype == torch.float32
    finally:
        torch.set_default_dtype(previous)


@pytest.mark.parametrize("dtype,extra", [(torch.float16, 1 / 1024), (torch.bfloat16, 1 / 16)])
def test_low_precision_gates_reject_excess_mass(dtype, extra):
    model = MoEFFN(MoEConfig(d_model=4, d_ff=7, num_experts=2, k=2)).to(dtype)
    with pytest.raises(ValueError, match="gates"):
        model(torch.ones(1, 4, dtype=dtype),
              (torch.tensor([[0, 1]]), torch.tensor([[.5, .5 + extra]], dtype=dtype)))


def test_gates_sum_uses_high_precision_and_small_absolute_tolerance():
    model = MoEFFN(MoEConfig(d_model=4, d_ff=7, num_experts=2, k=2))
    x = torch.ones(1, 4)
    indices = torch.tensor([[0, 1]])
    model(x, (indices, torch.tensor([[.5, .500005]])))
    with pytest.raises(ValueError, match="gates"):
        model(x, (indices, torch.tensor([[.5, .50002]])))


@pytest.mark.parametrize("k", [0, -1, 9, True, 1.5])
def test_illegal_k(k):
    with pytest.raises(ValueError, match="k"):
        Router(4, 8, k)
    with pytest.raises(ValueError, match="k"):
        Router(4, 8)(torch.ones(1, 4), k)
    with pytest.raises(ValueError, match="k"):
        MoEConfig(k=k)
    with pytest.raises(ValueError, match="k"):
        controlled_routing(8, k, "uniform")


@pytest.mark.parametrize("cf", [0, -1, float("nan"), float("inf"), True, "1"])
def test_illegal_capacity_factor(cf):
    with pytest.raises(ValueError, match="capacity_factor"):
        MoEConfig(capacity_factor=cf)


@pytest.mark.parametrize("kwargs", [dict(dist="missing"), dict(p=1), dict(p=0),
    dict(p=float("nan")), dict(temperature=0), dict(temperature=float("inf")),
    dict(tokens=0), dict(seed=-1), dict(num_experts=0), dict(num_experts=True)])
def test_illegal_controlled_distribution(kwargs):
    options = dict(num_experts=8, k=1, dist="uniform")
    options.update(kwargs)
    with pytest.raises(ValueError):
        controlled_routing(**options)


@pytest.mark.parametrize("kwargs", [dict(d_model=0), dict(d_ff=True), dict(num_experts=-1), dict(seed=1.5)])
def test_illegal_config(kwargs):
    with pytest.raises(ValueError):
        MoEConfig(**kwargs)


def test_invalid_routing_and_input_contracts():
    model = MoEFFN(MoEConfig(d_model=4, d_ff=7, num_experts=3, k=2))
    x = torch.ones(1, 4)
    cases = [((torch.tensor([[0, 0]]), torch.ones(1, 2) / 2), ValueError),
             ((torch.tensor([[0, 3]]), torch.ones(1, 2) / 2), ValueError),
             ((torch.tensor([[0, 1]]), torch.ones(1, 2)), ValueError),
             ((torch.tensor([[0, 1]]), torch.tensor([[float("nan"), .5]])), ValueError),
             ((torch.tensor([[0, 1]]), torch.tensor([[-.1, .5]])), ValueError),
             ((torch.tensor([[0, 1]]), torch.zeros(1, 2)), ValueError),
             ((torch.tensor([[0, 1]]).float(), torch.ones(1, 2) / 2), TypeError),
             ((torch.tensor([[0, 1]]), torch.ones(1, 2, dtype=torch.float64) / 2), TypeError),
             ((torch.tensor([[0]]), torch.ones(1, 1)), ValueError),
             ([torch.tensor([[0, 1]]), torch.ones(1, 2) / 2], TypeError)]
    for routing, error in cases:
        with pytest.raises(error):
            model(x, routing)
    for bad, error in ((torch.ones(0, 4), ValueError), (torch.ones(1, 5), ValueError),
                       (torch.ones(1, 1, 4), ValueError), (x.long(), TypeError),
                       (x * float("inf"), ValueError), ([1], TypeError)):
        with pytest.raises(error):
            model(bad)


@pytest.fixture(scope="module")
def experiment():
    return runpy.run_path(str(Path(__file__).resolve().parents[2]
                             / "experiments/exp_ch12_moe/run_moe_experiment.py"))


def test_deepseek_ledger_hand_counts_and_bound_direction(experiment):
    ledger = experiment["deepseek_v3_ledger"]([50, 200, 900])
    assert ledger["pass"]
    assert ledger["total_params"] == 671026404352
    assert ledger["active_params_per_token"] == 36625610752
    single = ledger["single_token"]
    assert single["routed_weight_read_bytes_per_layer"] == 672 * 1024**2
    assert single["ep_total_bytes_per_layer"] == 224 * 1024
    assert single["routed_weight_read_bytes_all_58_layers"] == 40869298176
    assert single["ep_total_bytes_all_58_layers"] == 13303808
    scenarios = ledger["bandwidth_scenarios"]
    assert scenarios[0]["routed_all_58_layers_min_seconds_per_token"] == pytest.approx(.81738596352)
    assert scenarios[1]["routed_all_58_layers_max_tokens_per_second"] == pytest.approx(4.89364899633749)
    assert scenarios[0]["routed_all_58_layers_max_tokens_per_second"] < scenarios[-1]["routed_all_58_layers_max_tokens_per_second"]
    assert all(row["ep_total_bytes_per_layer_per_token"] == 229376 for row in ledger["batch"])


def test_experiment_failure_persists_partial_raw_and_returns_nonzero(experiment, monkeypatch, tmp_path):
    output = tmp_path / "failed.json"

    def fail_after_one_row(record):
        record["distribution_scan"].append({"case": "failure fixture", "pass": False})
        raise RuntimeError("故意触发实验失败")

    main = experiment["main"]
    monkeypatch.setitem(main.__globals__, "distribution_scan", fail_after_one_row)
    monkeypatch.setattr("sys.argv", ["run_moe_experiment.py", "--output", str(output)])
    assert main() == 1
    raw = json.loads(output.read_text(encoding="utf-8"))
    assert raw["pass"] is False
    assert raw["distribution_scan"] == [{"case": "failure fixture", "pass": False}]
    assert "故意触发实验失败" in raw["error"]


def test_experiment_rejects_corrupted_accepted_output(experiment, monkeypatch, tmp_path):
    original = MoEFFN.forward

    def corrupted(self, *args, **kwargs):
        output, stats = original(self, *args, **kwargs)
        return output + .01, stats

    monkeypatch.setattr(MoEFFN, "forward", corrupted)
    output = tmp_path / "corrupted.json"
    monkeypatch.setattr("sys.argv", ["run_moe_experiment.py", "--output", str(output)])
    assert experiment["main"]() == 1
    raw = json.loads(output.read_text(encoding="utf-8"))
    assert not raw["pass"]
    assert not raw["distribution_scan"][0]["accepted_output_matches"]
    assert raw["distribution_scan"][0]["accepted_output_max_abs_error"] > .009
