"""调度正确性、确定性模拟账本、容量等待与状态回收。"""

import pytest
import torch

from pi_infer.generate import greedy_decode
from pi_infer.model import SimpleKVCache, build_tiny_model
from pi_infer.scheduler import CostTable, Request, Scheduler, SchedulerConfig


@pytest.fixture(scope="module", autouse=True)
def single_thread():
    previous = torch.get_num_threads()
    torch.set_num_threads(1)
    yield
    torch.set_num_threads(previous)


@pytest.fixture
def model():
    return build_tiny_model(seed=9).eval()


def costs(decode=1.0):
    return CostTable({b: decode for b in (1, 2, 4, 8)}, {c: c / 8 for c in (8, 16, 32, 64)})


@pytest.mark.parametrize("policy", ["static", "continuous", "chunked"])
def test_same_trace_matches_independent_greedy(model, policy):
    scheduler = Scheduler(model, SchedulerConfig(policy=policy, max_batch=3, token_budget=6,
                                                 chunk_size=3, max_wait_s=.5), costs())
    requests = [Request(str(i), i * .7, [i + 1] * (2 + i), 1 + i) for i in range(6)]
    references = {r.request_id: greedy_decode(model, r.prompt_ids, r.max_new_tokens,
                                             SimpleKVCache()).token_ids for r in requests}
    for r in requests:
        scheduler.submit(r)
    metrics = scheduler.run()
    assert metrics.finished == len(requests)
    assert metrics.failed == metrics.cancelled == metrics.running == metrics.waiting == 0
    for r in requests:
        assert r.token_ids == references[r.request_id]
        assert len(r.token_timestamps) == r.max_new_tokens
        assert r.token_timestamps == sorted(r.token_timestamps)
        assert r.queue_depth_samples
        assert r._cache is None
    assert scheduler.kv_used_tokens == 0
    assert scheduler.iterate() is None
    for row in scheduler.iterations:
        assert row["input_tokens"] <= 6
        assert len(row["active_ids"]) <= 3
        if policy == "chunked":
            assert sum(c["tokens"] for c in row["prefill_chunks"]) <= 3


def test_static_completion_table_shows_stranded_slots(model):
    tables = {}
    for policy in ("static", "continuous"):
        s = Scheduler(model, SchedulerConfig(policy=policy, max_batch=2, max_wait_s=0), costs())
        for name, new in (("short", 1), ("long", 4), ("next", 1)):
            s.submit(Request(name, 0, [1], new))
        metrics = s.run()
        tables[policy] = {r["request_id"]: r["模拟完成时刻_s"] for r in metrics.completion_table}
        if policy == "static":
            assert metrics.static_stranded_slot_seconds == 3
    assert tables["static"] == {"short": 1, "long": 5, "next": 6}
    assert tables["continuous"] == {"short": 1, "long": 6, "next": 3}


@pytest.mark.parametrize("zero_first", [False, True])
def test_static_zero_generation_does_not_occupy_batch_slots(model, zero_first):
    scheduler = Scheduler(model, SchedulerConfig(policy="static", max_batch=2, max_wait_s=0), costs())
    zero = [Request(f"zero-{i}", 0, [1], 0) for i in range(10)]
    normal = [Request("normal", 0, [1], 4)]
    for req in zero + normal if zero_first else normal + zero:
        scheduler.submit(req)
    while not scheduler.done:
        row = scheduler.iterate()
        assert len(scheduler._static_batch) <= 2
        assert not any(rid.startswith("zero-") for rid in scheduler._static_batch)
        if row:
            assert 0 <= row["static_closed_slots"] <= 2
            assert row["static_closed_slots"] == 0
    assert scheduler.metrics().finished == 11
    assert scheduler.metrics().static_stranded_slot_seconds == 0


def test_static_zero_generation_completes_independently_of_batch_wait(model):
    scheduler = Scheduler(model, SchedulerConfig(policy="static", max_batch=2, max_wait_s=5), costs())
    empty = Request("zero", 0, [1], 0)
    normal = Request("normal", 0, [1], 1)
    scheduler.submit(empty)
    scheduler.submit(normal)
    scheduler.run()
    assert empty.completed_at == 0
    assert normal.started_at == 5


def test_static_waits_for_batch_or_timeout(model):
    s = Scheduler(model, SchedulerConfig(policy="static", max_batch=2, max_wait_s=5), costs())
    s.submit(Request("a", 0, [1], 1))
    s.submit(Request("b", 2, [1], 1))
    assert s.iterate()["模拟起始时刻_s"] == 2  # 满批提前唤醒。
    s.submit(Request("c", s.now, [1], 1))
    arrival = s.now
    assert s.iterate()["模拟起始时刻_s"] == arrival + 5


def test_chunk_size_trades_decode_ttft_against_throughput(model):
    # 长 prefill 到达已有 decode 期间；小块减小 decode 阻塞，但多付调用成本。
    results = []
    table = CostTable({b: 1.0 for b in (1, 2, 4, 8)},
                      {8: 1.5, 16: 2.0, 32: 3.0, 64: 5.0})
    for chunk in (8, 16, 32):
        s = Scheduler(model, SchedulerConfig(policy="chunked", chunk_size=chunk), table)
        long = Request("long", 0, [1] * 64, 2)
        short = Request("short", 0, [2] * 8, 8)
        # 短 prompt 先入批，下一步会与长 prompt 的 prefill 混合。
        s.submit(short)
        s.submit(long)
        metrics = s.run()
        results.append((short.token_timestamps[1] - short.token_timestamps[0],
                        long.token_timestamps[0], metrics.throughput_tokens_per_sim_s))
    # 更小块保护已有请求的下一 token；更大块让长 prompt 更早获得首 token。
    assert results[0][0] < results[1][0] < results[2][0]
    assert results[0][1] > results[1][1] > results[2][1]
    assert results[0][2] < results[1][2] < results[2][2]


def test_mixed_serial_charge_and_cost_lookup(model):
    table = CostTable({1: 2., 2: 3., 4: 5., 8: 9.}, {8: 7., 16: 11., 32: 13., 64: 17.})
    assert table.decode_cost(3) == 5
    assert table.prefill_cost(9) == 11
    s = Scheduler(model, SchedulerConfig(max_batch=4), table)
    for i in range(3):
        s.submit(Request(str(i), 0, [i], 3))
    s.iterate()
    s.submit(Request("new", s.now, [1] * 9, 2))
    row = s.iterate()
    assert row["decode_cost_s"] == 5
    assert row["prefill_cost_s"] == 11
    assert row["模拟完成时刻_s"] - row["模拟起始时刻_s"] == 16
    assert all(s.requests[str(i)].token_timestamps[-1] == s.now for i in range(3))


def test_prefill_over_measured_limit_splits_without_extrapolation(model):
    s = Scheduler(model, SchedulerConfig(token_budget=128), costs())
    r = Request("long", 0, [1] * 70, 2)
    s.submit(r)
    first = s.iterate()
    assert [c["tokens"] for c in first["prefill_chunks"]] == [64, 6]
    assert first["prefill_cost_s"] == 9
    s.run()
    assert r.token_ids == greedy_decode(model, r.prompt_ids, 2, SimpleKVCache()).token_ids


@pytest.mark.parametrize("operation", ["cancel", "fail", "release"])
@pytest.mark.parametrize("running", [False, True])
def test_terminal_operations_recycle_capacity_and_reject_duplicates(model, operation, running):
    s = Scheduler(model, SchedulerConfig(kv_num_blocks=1, block_size=6), costs())
    r = Request("a", 0, [1] * 4, 3)  # 精确预留 4+3-1=6。
    queued = Request("b", 0, [2] * 4, 3)
    s.submit(r)
    s.submit(queued)
    if running:
        s.iterate()
        assert r.status == "running" and queued.status == "waiting"
        assert s.kv_used_tokens == 6
    getattr(s, operation)("a")
    assert s.kv_used_tokens == 0 and r._cache is None
    for repeated in (s.cancel, s.fail, s.release):
        with pytest.raises(ValueError, match="已经结束"):
            repeated("a")
    metrics = s.run()
    assert queued.status == "finished"
    assert metrics.finished == 1
    assert metrics.failed == (operation == "fail")
    assert metrics.cancelled == (operation != "fail")
    assert s.kv_used_tokens == 0


def test_forward_failure_is_visible_and_releases_partial_cache(model, monkeypatch):
    s = Scheduler(model, SchedulerConfig(), costs())
    r = Request("broken", 0, [1], 3)
    s.submit(r)
    def broken(*args, **kwargs):
        raise RuntimeError("injected failure")
    monkeypatch.setattr(model, "forward", broken)
    m = s.run()
    assert m.failed == 1 and m.finished == 0
    assert r.status == "failed" and "injected failure" in r.error
    assert s.kv_used_tokens == 0 and r._cache is None
    assert s.now == 1  # 失败的已调度操作仍计费。


@pytest.mark.parametrize("policy", ["static", "continuous", "chunked"])
def test_budget_and_kv_wait_without_losing_requests(model, policy):
    s = Scheduler(model, SchedulerConfig(policy=policy, token_budget=1, chunk_size=1,
                                         max_batch=8, kv_num_blocks=1, block_size=7,
                                         max_wait_s=0), costs())
    requests = [Request(str(i), 0, [1, 2, 3, 4], 4) for i in range(10)]
    for r in requests:
        s.submit(r)
    first = s.iterate()
    assert first["input_tokens"] == 1
    assert requests[0].output_ids == []  # prefill 未完成，不错误生成/丢 token。
    assert requests[1].status == "waiting"
    assert s.kv_used_tokens == 7
    reference = greedy_decode(model, requests[0].prompt_ids, 4, SimpleKVCache()).token_ids
    assert s.run().finished == 10
    assert all(r.token_ids == reference for r in requests)
    assert all(row["input_tokens"] <= 1 for row in s.iterations)
    assert max(len(row["active_ids"]) for row in s.iterations) == 1


def test_active_batch_never_exceeds_eight(model):
    s = Scheduler(model, SchedulerConfig(), costs())
    for i in range(12):
        s.submit(Request(str(i), 0, [1], 2))
    s.iterate()
    assert len(s._running()) == 8
    assert len(s._waiting()) == 4
    assert s.run().finished == 12


def test_decode_budget_smaller_than_active_batch_keeps_unscheduled_state(model):
    s = Scheduler(model, SchedulerConfig(token_budget=2, max_batch=4), costs())
    requests = [Request(str(i), 0, [i + 1], 4) for i in range(4)]
    for r in requests:
        s.submit(r)
    s.iterate()
    assert all(r.status == "running" for r in requests)
    assert [len(r.output_ids) for r in requests] == [1, 1, 0, 0]
    assert s.run().finished == 4
    for r in requests:
        assert r.token_ids == greedy_decode(model, r.prompt_ids, 4, SimpleKVCache()).token_ids
    assert all(row["input_tokens"] <= 2 for row in s.iterations)


def test_zero_only_batch_and_empty_scheduler(model):
    s = Scheduler(model, SchedulerConfig(), costs())
    assert s.done and s.iterate() is None
    assert s.run().throughput_tokens_per_sim_s == 0
    s.submit(Request("zero", 3, [1], 0))
    assert s.run().finished == 1
    assert s.now == 3 and s.kv_used_tokens == 0
    assert s.requests["zero"].output_ids == []
    with pytest.raises(ValueError):
        s.release("zero", "finished")


def test_metrics_issue_target_separation_zero_and_partial_requests(model):
    s = Scheduler(model, SchedulerConfig(), costs())
    s.submit(Request("zero", 5, [1], 0, target_arrival_time=2))
    s.submit(Request("one", 5, [1], 1, target_arrival_time=1))
    d = s.run().to_dict()
    zero, one = d["completion_table"]
    assert zero["模拟完成时刻_s"] == 5 and zero["模拟 TTFT_s"] is None
    assert one["target_arrival_time_s"] == 1 and one["actual_issue_time_s"] == 5
    assert one["模拟 TTFT_s"] == 1
    assert d["模拟 TTFT_s"] == {"p50": 1, "p99": 1}
    assert d["模拟 TPOT_s"] == {"p50": None, "p99": None}
    assert sum(d["counts"].values()) == 2


@pytest.mark.parametrize("kwargs", [
    {"policy": "other"}, {"max_batch": 9}, {"max_batch": True}, {"token_budget": 0},
    {"chunk_size": -1}, {"kv_num_blocks": 0}, {"block_size": 1.5},
    {"max_wait_s": -1}, {"max_wait_s": float("nan")},
])
def test_invalid_config(kwargs):
    with pytest.raises(ValueError):
        SchedulerConfig(**kwargs)


@pytest.mark.parametrize("args", [
    ("", 0, [1], 1), ("a", -1, [1], 1), ("a", float("inf"), [1], 1),
    ("a", 0, [], 1), ("a", 0, [-1], 1), ("a", 0, [True], 1), ("a", 0, [1], -1),
])
def test_invalid_request(args):
    with pytest.raises(ValueError):
        Request(*args)


def test_invalid_cost_tables_and_ranges():
    with pytest.raises(ValueError):
        CostTable({1: 1}, {8: 1})
    for value in (0, -1, float("nan")):
        with pytest.raises(ValueError):
            CostTable({b: value for b in (1, 2, 4, 8)}, costs().prefill_s)
    for batch in (0, 9):
        with pytest.raises(ValueError):
            costs().decode_cost(batch)
    with pytest.raises(ValueError):
        costs().prefill_cost(65)


def test_invalid_submissions_and_operations(model):
    s = Scheduler(model, SchedulerConfig(kv_num_blocks=1, block_size=4), costs())
    for r in (Request("vocab", 0, [256], 1), Request("capacity", 0, [1] * 5, 1),
              Request("position", 0, [1] * 128, 2)):
        with pytest.raises(ValueError):
            s.submit(r)
    s.submit(Request("a", 0, [1], 2))
    with pytest.raises(ValueError):
        s.submit(Request("a", 0, [1], 1))
    with pytest.raises(ValueError):
        s.release("a", "finished")
    with pytest.raises(ValueError):
        s.cancel("unknown")
    with pytest.raises(ValueError):
        s.release("a", "invalid")
    s.iterate()
    with pytest.raises(ValueError):
        s.submit(Request("past", 0, [1], 1))
    with pytest.raises(TypeError):
        Request("type", 0, (1,), 1)
    with pytest.raises(TypeError):
        s.submit(None)
    with pytest.raises(TypeError):
        Scheduler(None, SchedulerConfig(), costs())
