"""固定种子、手算注意力和增量前向的正确性测试。"""

import math

import pytest
import torch

from pi_infer import TinyConfig, TinyTransformer, build_tiny_model
from pi_infer.model import RMSNorm, RotaryEmbedding, SimpleKVCache, causal_attention


def test_same_seed_rebuilds_identical_weights_and_logits() -> None:
    first = build_tiny_model(seed=17)
    torch.randn(100)  # 中间的随机操作不应影响重新构建。
    second = build_tiny_model(seed=17, preset="tiny")
    assert first.config == second.config == TinyConfig(seed=17)
    for name, weight in first.state_dict().items():
        assert torch.equal(weight, second.state_dict()[name]), name
    tokens = torch.tensor([[1, 7, 11]])
    assert torch.equal(first(tokens), second(tokens))
    assert not torch.equal(first.embedding.weight, build_tiny_model(seed=18).embedding.weight)
    assert first.embedding.weight.data_ptr() != first.lm_head.weight.data_ptr()


def test_forward_returns_batch_sequence_vocab_logits() -> None:
    model = build_tiny_model()
    logits = model(torch.tensor([[1, 2, 3], [4, 5, 6]]))
    assert logits.shape == (2, 3, 256)
    assert torch.isfinite(logits).all()
    assert all(module.bias is None for module in model.modules() if isinstance(module, torch.nn.Linear))


def test_seed_zero_logits_match_recorded_cpu_reference() -> None:
    # 初版 CPU float32 存档（torch 2.15.0，默认 tiny，seed=0）。
    # 这是后续改动的回归锚点；独立数学正确性由手算注意力测试验证。
    reference = torch.tensor([
        [-0.433235884, 0.482292354, 0.310008675, 0.116080061, -0.260784328, -0.213458151],
        [0.298161030, -0.495017290, -0.272267252, -0.412694871, 0.896487474, -0.432440937],
        [0.726913631, -0.284058332, -0.426585585, -0.171945751, 1.258289099, 0.503898025],
    ])
    logits = build_tiny_model()(torch.tensor([[1, 7, 11]]))
    torch.testing.assert_close(logits[0, :, :6], reference, atol=1e-5, rtol=0)


@pytest.mark.parametrize("chunk_sizes", [(3, 1, 1, 2), (1, 2, 4), (7,)])
@torch.no_grad()
def test_incremental_chunks_match_full_recomputation(chunk_sizes: tuple[int, ...]) -> None:
    model = build_tiny_model(seed=5)
    tokens = torch.tensor([[2, 5, 8, 11, 13, 17, 19], [3, 7, 9, 12, 14, 18, 20]])
    expected = model(tokens)
    cache = SimpleKVCache()
    start_pos = 0
    chunks = []
    for size in chunk_sizes:
        chunks.append(model(tokens[:, start_pos:start_pos + size], start_pos, cache))
        start_pos += size
        for layer_idx in range(model.config.n_layers):
            k, v = cache.get(layer_idx)
            assert k.shape == v.shape == (2, 2, start_pos, 16)
    torch.testing.assert_close(torch.cat(chunks, dim=1), expected, atol=1e-5, rtol=0)


def test_hand_calculated_two_head_three_token_causal_gqa() -> None:
    # 2 个 query head 共享 1 个 KV head，且两个 query head 的分数不同。
    q_values = [[[1.0, 0.0], [0.0, 2.0], [1.0, 1.0]],
                [[0.0, 1.0], [2.0, 0.0], [-1.0, 1.0]]]
    k_values = [[1.0, 0.0], [0.0, 1.0], [1.0, -1.0]]
    v_values = [[2.0, 3.0], [5.0, 7.0], [11.0, 13.0]]
    # 纯 Python 枚举可见位置，直接按 exp(dot/sqrt(2))/sum(exp) 手算。
    # 不调用被测函数的 mask、repeat、softmax 或其他内部路径。
    expected = []
    for head in q_values:
        rows = []
        for position, query in enumerate(head):
            exps = [math.exp(sum(a * b for a, b in zip(query, key)) / math.sqrt(2))
                    for key in k_values[:position + 1]]
            rows.append([sum(weight * value[channel]
                             for weight, value in zip(exps, v_values)) / sum(exps)
                         for channel in range(2)])
        expected.append(rows)
    q = torch.tensor([q_values], dtype=torch.float64)
    k = torch.tensor([[k_values]], dtype=torch.float64)
    v = torch.tensor([[v_values]], dtype=torch.float64)
    expected_tensor = torch.tensor([expected], dtype=torch.float64)
    torch.testing.assert_close(causal_attention(q, k, v), expected_tensor, atol=1e-12, rtol=0)
    # 带历史的两 token 增量使用同一份独立期望值。
    torch.testing.assert_close(
        causal_attention(q[:, :, 1:], k, v, start_pos=1),
        expected_tensor[:, :, 1:], atol=1e-12, rtol=0,
    )
    assert torch.equal(expected_tensor[:, :, 0], v[:, :, 0].expand(1, 2, 2))


def test_softmax_stays_finite_for_large_attention_scores() -> None:
    q = torch.tensor([[[[1000.0, 0.0], [1000.0, 0.0]],
                       [[1000.0, 0.0], [1000.0, 0.0]]]])
    k = torch.tensor([[[[1000.0, 0.0], [999.0, 0.0]]]])
    v = torch.tensor([[[[2.0, 3.0], [5.0, 7.0]]]])
    actual = causal_attention(q, k, v)
    assert torch.isfinite(actual).all()
    torch.testing.assert_close(actual, torch.tensor([[[[2.0, 3.0], [2.0, 3.0]],
                                                       [[2.0, 3.0], [2.0, 3.0]]]]))


def test_gqa_repeats_each_kv_head_within_its_query_group() -> None:
    q = torch.zeros(1, 4, 1, 2)
    k = torch.zeros(1, 2, 1, 2)
    v = torch.tensor([[[[2.0, 3.0]], [[5.0, 7.0]]]])
    expected = torch.tensor([[[[2.0, 3.0]], [[2.0, 3.0]], [[5.0, 7.0]], [[5.0, 7.0]]]])
    torch.testing.assert_close(causal_attention(q, k, v), expected, atol=0, rtol=0)


def test_equal_query_and_kv_head_counts_support_standard_mha() -> None:
    torch.manual_seed(3)
    model = TinyTransformer(TinyConfig(n_kv_heads=4))
    tokens = torch.tensor([[1, 2, 3, 4]])
    full = model(tokens)
    cache = SimpleKVCache()
    model(tokens[:, :2], kv_cache=cache)
    actual = model(tokens[:, 2:], start_pos=2, kv_cache=cache)
    torch.testing.assert_close(actual, full[:, 2:], atol=1e-5, rtol=0)


def test_rope_rotation_depends_only_on_absolute_position() -> None:
    rope = RotaryEmbedding(head_dim=4, max_seq_len=16, theta=10000.0)
    x = torch.tensor([[[[1.0, 2.0, 3.0, 4.0]]]])
    in_full_sequence = rope(x.expand(1, 2, 8, 4), start_pos=0)[:, :, 5:6]
    isolated = rope(x, start_pos=5)
    torch.testing.assert_close(in_full_sequence, isolated.expand(1, 2, 1, 4), atol=0, rtol=0)
    torch.testing.assert_close(rope(x.expand(1, 1, 3, 4), 4)[:, :, 1:2], isolated, atol=0, rtol=0)
    # 第 5 个绝对位置的两个旋转角分别是 5 和 5/100。
    expected = torch.tensor([[[[
        math.cos(5) - 2 * math.sin(5), math.sin(5) + 2 * math.cos(5),
        3 * math.cos(0.05) - 4 * math.sin(0.05),
        3 * math.sin(0.05) + 4 * math.cos(0.05),
    ]]]])
    torch.testing.assert_close(isolated, expected, atol=1e-6, rtol=0)
    assert not torch.allclose(isolated, rope(x, 0))


def test_causal_prefix_logits_do_not_depend_on_future_tokens() -> None:
    model = build_tiny_model()
    first = model(torch.tensor([[1, 2, 3, 4]]))
    changed_future = model(torch.tensor([[1, 2, 200, 201]]))
    torch.testing.assert_close(first[:, :2], changed_future[:, :2], atol=0, rtol=0)


def test_rms_norm_matches_scalar_formula_without_bias() -> None:
    norm = RMSNorm(2, eps=1e-6)
    x = torch.tensor([[3.0, 4.0]])
    expected = x / math.sqrt((9 + 16) / 2 + 1e-6)
    torch.testing.assert_close(norm(x), expected)
    assert list(dict(norm.named_parameters())) == ["weight"]


def test_simple_cache_appends_segments_independently_per_layer() -> None:
    cache = SimpleKVCache()
    assert cache.get(0) == (None, None)
    k = torch.arange(8.0).reshape(1, 1, 2, 4)
    v = k + 10
    cache.append(0, k, v)
    cache.append(1, k + 20, v + 20)
    cache.append(0, k[:, :, :1] + 30, v[:, :, :1] + 30)
    actual_k, actual_v = cache.get(0)
    assert torch.equal(actual_k, torch.cat([k, k[:, :, :1] + 30], dim=2))
    assert torch.equal(actual_v, torch.cat([v, v[:, :, :1] + 30], dim=2))
    assert torch.equal(cache.get(1)[0], k + 20)


def test_invalid_cache_history_fails_before_any_layer_is_modified() -> None:
    model = build_tiny_model()
    cache = SimpleKVCache()
    k = torch.zeros(1, 2, 2, 16)
    cache.append(0, k, k)  # 故意遗漏第 1 层。
    before = cache.get(0)[0].clone()
    with pytest.raises(ValueError, match="start_pos"):
        model(torch.tensor([[3]]), start_pos=2, kv_cache=cache)
    assert torch.equal(cache.get(0)[0], before)
    assert cache.get(1) == (None, None)


def test_forward_rejects_positions_outside_context_window() -> None:
    model = TinyTransformer(TinyConfig(max_seq_len=3))
    assert model(torch.tensor([[1]]), start_pos=2).shape == (1, 1, 256)
    with pytest.raises(ValueError, match="max_seq_len"):
        model(torch.tensor([[1, 2]]), start_pos=2)
    with pytest.raises(ValueError, match="非负整数"):
        model(torch.tensor([[1]]), start_pos=-1)


@pytest.mark.parametrize("config", [dict(d_model=63), dict(n_kv_heads=3), dict(d_model=12), dict(n_heads=0)])
def test_invalid_head_dimensions_are_rejected(config: dict[str, int]) -> None:
    with pytest.raises(ValueError):
        TinyConfig(**config)


def test_unknown_model_preset_is_rejected() -> None:
    with pytest.raises(ValueError, match="preset"):
        build_tiny_model(preset="unknown")
