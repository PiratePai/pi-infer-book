"""Online softmax 数值、合并中间量与按实际生命周期计量的内存账本。"""

import math

import pytest
import torch

from pi_infer.flash import (
    _LiveTensors, _merge_block, flash_attention_reference, online_softmax_attention,
)
from pi_infer.model import causal_attention


@pytest.mark.parametrize("causal", [True, False])
@pytest.mark.parametrize("heads,kv_heads", [(1, 1), (4, 2), (4, 1), (4, 4)])
@pytest.mark.parametrize("block_size", [1, 2, 7, 12])
def test_online_matches_reference_including_tails_and_extremes(causal, heads, kv_heads, block_size) -> None:
    generator = torch.Generator().manual_seed(23)
    q = torch.randn(2, heads, 7, 5, generator=generator)
    k = torch.randn(2, kv_heads, 7, 5, generator=generator)
    v = torch.randn(2, kv_heads, 7, 5, generator=generator)
    expected, _ = flash_attention_reference(q, k, v, causal=causal)
    actual, _ = online_softmax_attention(q, k, v, block_size=block_size, causal=causal)
    # seed=23、以上 32 组 fp32 CPU 实测最大误差 2.3842e-7；取 atol=1e-6、rtol=0。
    torch.testing.assert_close(actual, expected, atol=1e-6, rtol=0)
    if causal:
        torch.testing.assert_close(expected, causal_attention(q, k, v), atol=1e-6, rtol=0)


@torch.no_grad()
def test_two_block_merge_running_max_denominator_and_numerator_by_hand() -> None:
    # 块一 scores=[0,log(2)]，块二=[log(4),log(8)]；两块 max 不同。
    # 第一块 m=log2,l=1.5,O=1/2*1+1*3=3.5；合并时 alpha=1/4,beta=1。
    live = _LiveTensors()
    maximum = live.add(torch.full((1, 1, 1, 1), -torch.inf))
    denominator = live.add(torch.zeros(1, 1, 1, 1))
    accumulator = live.add(torch.zeros(1, 1, 1, 1))
    first = live.add(torch.tensor([[[[0., math.log(2)]]]]))
    _merge_block(first, torch.tensor([[[[1.], [3.]]]]), maximum, denominator, accumulator, live)
    assert maximum.item() == pytest.approx(math.log(2), abs=1e-7)
    assert denominator.item() == 1.5
    assert accumulator.item() == 3.5
    live.release(first)
    del first
    second = live.add(torch.tensor([[[[math.log(4), math.log(8)]]]]))
    _merge_block(second, torch.tensor([[[[5.], [7.]]]]), maximum, denominator, accumulator, live)
    assert maximum.item() == pytest.approx(math.log(8), abs=1e-7)
    assert denominator.item() == pytest.approx(1.5 / 4 + 1.5, abs=1e-7)
    assert accumulator.item() == pytest.approx(3.5 / 4 + 0.5 * 5 + 7, abs=1e-7)
    assert (accumulator / denominator).item() == pytest.approx(83 / 15, abs=1e-6)


@pytest.mark.parametrize("dimension", [1, 3])
def test_peak_bytes_and_writes_match_hand_calculated_live_numel(dimension: int) -> None:
    # 非因果：Q 有 2 行，KV 有 4 行，block=2。float32 每元素 4 bytes。
    q = torch.ones(1, 1, 2, dimension)
    k = v = torch.ones(1, 1, 4, dimension)
    _, reference = flash_attention_reference(q, k, v, causal=False)
    # 峰值时 S(8)、P(8)、max(2) 同时存活，之后 S/max 释放才分配 denom。
    assert reference.peak_bytes == (8 + 8 + 2) * 4
    # 首次写 S/P/max/denom + 输出。
    assert reference.hbm_writes_approx == (8 + 8 + 2 + 2 + 2 * dimension) * 4
    _, online = online_softmax_attention(q, k, v, block_size=2, causal=False)
    # 常驻 m/l/O = 2+2+2D；单块 scores=4；临时峰值为 max+alpha(4) 或 PV(2D)。
    assert online.peak_bytes == (2 + 2 + 2 * dimension + 4 + max(4, 2 * dimension)) * 4
    # 常驻首次写；每块写 scores/max/alpha/sum/PV；最终输出写一次。
    assert online.hbm_writes_approx == (4 + 2 * dimension + 2 * (4 + 2 + 2 + 2 + 2 * dimension) + 2 * dimension) * 4


def test_peak_independent_of_sequence_length_at_fixed_block_size() -> None:
    peaks = []
    for length in (4, 8, 16):
        q = torch.ones(2, 4, length, 3)
        k = v = torch.ones(2, 2, length, 3)
        _, stats = online_softmax_attention(q, k, v, block_size=2)
        peaks.append(stats.peak_bytes)
        # B*Hq*Br * (Bc + D + 2 + max(2,D)) 个 fp32 元素，无 GQA repeat 副本。
        assert stats.peak_bytes == 2 * 4 * 2 * (2 + 3 + 2 + 3) * 4
    assert len(set(peaks)) == 1


@pytest.mark.parametrize("tq,tk", [(3, 7), (7, 3), (1, 1)])
@pytest.mark.parametrize("causal", [True, False])
def test_rectangular_sequences_use_zero_based_positions(tq: int, tk: int, causal: bool) -> None:
    generator = torch.Generator().manual_seed(6)
    q = torch.randn(1, 4, tq, 3, generator=generator)
    k = torch.randn(1, 2, tk, 3, generator=generator)
    v = torch.randn(1, 2, tk, 3, generator=generator)
    expected, _ = flash_attention_reference(q, k, v, causal=causal)
    for size in (1, 2, tk):
        actual, _ = online_softmax_attention(q, k, v, block_size=size, causal=causal)
        torch.testing.assert_close(actual, expected, atol=1e-6, rtol=0)
    if causal:
        torch.testing.assert_close(expected, causal_attention(q, k, v), atol=1e-6, rtol=0)


def test_causal_block_skipping_and_diagonal_mask_prevent_future_leak(monkeypatch: pytest.MonkeyPatch) -> None:
    import pi_infer.flash as flash

    q = k = torch.zeros(1, 1, 4, 1)
    v = torch.tensor([[[[1.], [3.], [100.], [200.]]]])
    calls = []
    original = flash._qk_into

    def record(q, k, out):
        calls.append((q.shape[-2], k.shape[-2]))
        original(q, k, out)

    monkeypatch.setattr(flash, "_qk_into", record)
    out, _ = online_softmax_attention(q, k, v, block_size=2)
    expected = torch.tensor([[[[1.], [2.], [104 / 3], [76.]]]])
    torch.testing.assert_close(out, expected, atol=4e-6, rtol=0)
    assert len(calls) == 3  # 两个 query 块仅访问 1+2 个 key 块。


def test_large_scores_use_stable_softmax_and_noncontiguous_inputs() -> None:
    q = torch.tensor([[[[1., -1.], [-1., 1.]]]]).transpose(-1, -2) * 1000
    k = q.clone()
    v = torch.tensor([[[[2., 3.], [5., 7.]]]]).transpose(-1, -2)
    expected, _ = flash_attention_reference(q, k, v, causal=False)
    actual, _ = online_softmax_attention(q, k, v, block_size=1, causal=False)
    assert torch.isfinite(actual).all()
    torch.testing.assert_close(actual, expected, atol=0, rtol=0)


@pytest.mark.parametrize("size", [0, -1, 1.5, True])
def test_invalid_block_size(size) -> None:
    q = torch.ones(1, 1, 2, 2)
    with pytest.raises(ValueError, match="block_size"):
        online_softmax_attention(q, q, q, block_size=size)


@pytest.mark.parametrize("function", [flash_attention_reference,
    lambda q, k, v, **kwargs: online_softmax_attention(q, k, v, block_size=2, **kwargs)])
def test_invalid_attention_inputs_fail_explicitly(function) -> None:
    q = torch.ones(1, 4, 2, 2)
    kv = torch.ones(1, 2, 2, 2)
    bad_args = [(q.double(), kv, kv), (q[0], kv, kv), (q[:, :, :0], kv, kv),
                (q, kv, kv[..., :1]), (q, kv[:0], kv[:0]), (q[:, :3], kv, kv),
                (q * float("nan"), kv, kv), (q.to("meta"), kv, kv)]
    for args in bad_args:
        with pytest.raises(ValueError):
            function(*args)
    with pytest.raises(TypeError):
        function([], kv, kv)
    with pytest.raises(TypeError, match="causal"):
        function(q, kv, kv, causal=1)


def test_online_accumulator_overflow_is_rejected() -> None:
    """回归（段末评审 P1-2）：未归一化累加器会溢出的输入必须显式报错，不得返回 Inf。"""
    q = torch.zeros(1, 1, 4, 8)
    k = torch.zeros(1, 1, 4, 8)
    v = torch.full((1, 1, 4, 8), 1e38)
    out, _ = flash_attention_reference(q, k, v, causal=False)  # 参考实现输出 ~1e38，有限
    assert torch.isfinite(out).all()
    with pytest.raises(ValueError, match="溢出"):
        online_softmax_attention(q, k, v, block_size=2, causal=False)
