"""因果窗口/块语义、稠密对照、跳块操作与手算 FLOPs。"""

import math

import pytest
import torch

from pi_infer.model import causal_attention
from pi_infer.sparse import (
    block_sparse_mask, blocked_sparse_attention, masked_dense_attention,
    sliding_window_causal_mask,
)


def test_sliding_window_hand_calculated_boundary() -> None:
    expected = torch.tensor([[1, 0, 0, 0], [1, 1, 0, 0],
                             [0, 1, 1, 0], [0, 0, 1, 1]], dtype=torch.bool)
    mask = sliding_window_causal_mask(4, 2)
    assert mask.device.type == "cpu" and mask.dtype == torch.bool
    assert torch.equal(mask, expected)
    assert not mask.triu(1).any()


@pytest.mark.parametrize("window", [4, 5, 100])
def test_large_window_degenerates_to_full_causal(window: int) -> None:
    assert torch.equal(sliding_window_causal_mask(4, window), torch.ones(4, 4, dtype=torch.bool).tril())


def test_one_token_window_and_single_token_sequence() -> None:
    assert torch.equal(sliding_window_causal_mask(4, 1), torch.eye(4, dtype=torch.bool))
    assert torch.equal(sliding_window_causal_mask(1, 10), torch.tensor([[True]]))


def test_block_band_boundaries_and_callable_intersection() -> None:
    band = block_sparse_mask(6, 2, "band")
    expected = torch.tensor([
        [1, 0, 0, 0, 0, 0], [1, 1, 0, 0, 0, 0],
        [1, 1, 1, 0, 0, 0], [1, 1, 1, 1, 0, 0],
        [0, 0, 1, 1, 1, 0], [0, 0, 1, 1, 1, 1],
    ], dtype=torch.bool)
    assert torch.equal(band, expected)
    diagonal = block_sparse_mask(6, 2, lambda row, col: row == col)
    assert diagonal[2, 2] and not diagonal[2, 1] and not diagonal[2, 3]
    full = block_sparse_mask(6, 2, lambda row, col: True)
    assert torch.equal(full, torch.ones(6, 6, dtype=torch.bool).tril())
    assert not band.triu(1).any() and not diagonal.triu(1).any()
    assert torch.equal(block_sparse_mask(3, 1, "band"), sliding_window_causal_mask(3, 2))


def test_hand_calculated_masked_gqa_values() -> None:
    q = torch.zeros(1, 4, 2, 1)
    k = torch.zeros(1, 2, 2, 1)
    v = torch.tensor([[[[2.], [6.]], [[10.], [20.]]]])
    mask = sliding_window_causal_mask(2, 2)
    expected = torch.tensor([[[[2.], [4.]], [[2.], [4.]], [[10.], [15.]], [[10.], [15.]]]])
    torch.testing.assert_close(masked_dense_attention(q, k, v, mask), expected, atol=0, rtol=0)
    actual, _ = blocked_sparse_attention(q, k, v, mask, block_size=1)
    torch.testing.assert_close(actual, expected, atol=0, rtol=0)


@pytest.mark.parametrize("heads,kv_heads", [(1, 1), (4, 2), (4, 1), (4, 4)])
@pytest.mark.parametrize("kind", ["window", "band", "full", "empty"])
def test_sparse_matches_dense_with_recorded_tolerance(heads: int, kv_heads: int, kind: str) -> None:
    generator = torch.Generator().manual_seed(19)
    q = torch.randn(2, heads, 8, 3, generator=generator)
    k = torch.randn(2, kv_heads, 8, 3, generator=generator)
    v = torch.randn(2, kv_heads, 8, 3, generator=generator)
    masks = dict(window=sliding_window_causal_mask(8, 3), band=block_sparse_mask(8, 2, "band"),
                 full=torch.ones(8, 8, dtype=torch.bool), empty=torch.zeros(8, 8, dtype=torch.bool))
    dense = masked_dense_attention(q, k, v, masks[kind])
    actual, _ = blocked_sparse_attention(q, k, v, masks[kind], block_size=2)
    # seed=19、以上 16 组 fp32 CPU 实测最大差异 1.1921e-7；取 atol=1e-6。
    torch.testing.assert_close(actual, dense, atol=1e-6, rtol=0)
    assert torch.isfinite(actual).all()


def test_full_causal_matches_model_and_future_values_do_not_leak() -> None:
    generator = torch.Generator().manual_seed(5)
    q = torch.randn(1, 4, 6, 2, generator=generator)
    k = torch.randn(1, 2, 6, 2, generator=generator)
    v = torch.randn(1, 2, 6, 2, generator=generator)
    mask = sliding_window_causal_mask(6, 6)
    expected = causal_attention(q, k, v)
    actual = masked_dense_attention(q, k, v, mask)
    torch.testing.assert_close(actual, expected, atol=1e-6, rtol=0)
    changed = v.clone()
    changed[:, :, 3:] += 1000
    for function in (masked_dense_attention, lambda q, k, v, m: blocked_sparse_attention(q, k, v, m, block_size=2)[0]):
        torch.testing.assert_close(function(q, k, changed, mask)[:, :, :3], actual[:, :, :3], atol=1e-6, rtol=0)


def test_sparse_stats_and_matmul_calls_match_hand_count(monkeypatch: pytest.MonkeyPatch) -> None:
    # 2x2 个空间块中因果保留 3 块；每块 QK/PV 各 2*2*2*D FLOPs。
    q = torch.ones(2, 4, 4, 3)
    k = v = torch.ones(2, 2, 4, 3)
    calls = []
    original = torch.matmul

    def record(*args, **kwargs):
        calls.append(args[0].shape)
        return original(*args, **kwargs)

    monkeypatch.setattr(torch, "matmul", record)
    _, stats = blocked_sparse_attention(q, k, v, sliding_window_causal_mask(4, 4), block_size=2)
    assert (stats.kept_blocks, stats.skipped_blocks) == (3, 1)
    assert stats.flops_dense == 2 * 4 * 4 * 4 * 2 * 3 * 2 == 1536
    assert stats.flops_actual == 3 * 2 * 4 * 2 * 2 * 2 * 3 * 2 == 1152
    assert len(calls) == 3 * 2 * 2  # 3 块 × QK/PV × 2 KV groups，空块无调用。
    calls.clear()
    out, stats = blocked_sparse_attention(q, k, v, torch.zeros(4, 4, dtype=torch.bool), block_size=2)
    assert stats.kept_blocks == 0 and stats.skipped_blocks == 4 and stats.flops_actual == 0
    assert not calls and not out.any()


def test_rectangular_attention_and_single_retained_key() -> None:
    q = torch.ones(1, 1, 2, 1)
    k = torch.ones(1, 1, 4, 1)
    v = torch.tensor([[[[2.], [3.], [5.], [7.]]]])
    mask = torch.tensor([[0, 0, 1, 0], [0, 0, 0, 0]], dtype=torch.bool)
    expected = torch.tensor([[[[5.], [0.]]]])
    torch.testing.assert_close(masked_dense_attention(q, k, v, mask), expected, atol=0, rtol=0)
    actual, stats = blocked_sparse_attention(q, k, v, mask, block_size=2)
    torch.testing.assert_close(actual, expected, atol=0, rtol=0)
    assert (stats.kept_blocks, stats.skipped_blocks) == (1, 1)


@pytest.mark.parametrize("T,window", [(0, 1), (3, 0), (-1, 2), (2, 1.5), (True, 1)])
def test_invalid_window_parameters(T: int, window: int) -> None:
    with pytest.raises(ValueError):
        sliding_window_causal_mask(T, window)


@pytest.mark.parametrize("T,block,pattern,error", [(5, 2, "band", ValueError), (4, 0, "band", ValueError),
    (0, 2, "band", ValueError), (4, 2, "bad", ValueError), (4, 2, lambda i, j: 1, TypeError)])
def test_invalid_block_mask(T, block, pattern, error) -> None:
    with pytest.raises(error):
        block_sparse_mask(T, block, pattern)


@pytest.mark.parametrize("tq,tk", [(3, 4), (4, 3)])
def test_non_aligned_attention_lengths_rejected(tq: int, tk: int) -> None:
    with pytest.raises(ValueError, match="对齐"):
        blocked_sparse_attention(torch.ones(1, 1, tq, 2), torch.ones(1, 1, tk, 2),
                                 torch.ones(1, 1, tk, 2), torch.ones(tq, tk, dtype=torch.bool), block_size=2)


@pytest.mark.parametrize("function", [masked_dense_attention,
    lambda q, k, v, m: blocked_sparse_attention(q, k, v, m, block_size=1)])
def test_invalid_attention_inputs(function) -> None:
    q = torch.ones(1, 2, 2, 2)
    k = v = torch.ones(1, 1, 2, 2)
    mask = torch.ones(2, 2, dtype=torch.bool)
    cases = [(q.double(), k, v, mask), (q, k, v, mask.float()), (q, k, v, mask[:1]),
             (q[0], k, v, mask), (q[:, :, :0], k, v, mask), (q, k, v[..., :1], mask),
             (q, k.expand(2, -1, -1, -1), v, mask), (q, k.expand(-1, 3, -1, -1), v.expand(-1, 3, -1, -1), mask),
             (q * math.inf, k, v, mask), (q.to("meta"), k, v, mask)]
    for args in cases:
        with pytest.raises(ValueError):
            function(*args)
    with pytest.raises(TypeError):
        function([], k, v, mask)
    with pytest.raises(TypeError):
        function(q, k, v, [])


@pytest.mark.parametrize("size", [0, -1, 1.5, True])
def test_invalid_attention_block_size(size) -> None:
    q = torch.ones(1, 1, 2, 2)
    with pytest.raises(ValueError, match="block_size"):
        blocked_sparse_attention(q, q, q, torch.ones(2, 2, dtype=torch.bool), block_size=size)
