"""bench 统一测量入口的调用顺序、统计口径与非法参数回归（段末评审 P2-3）。"""

from __future__ import annotations

import statistics

import pytest

from pi_infer.bench import sweep, sync_device
from pi_infer.model import build_tiny_model


def _builder():
    return build_tiny_model(seed=0).eval()


def test_sweep_returns_mean_std_samples() -> None:
    """每点返回均值/样本标准差(n-1)/原始样本，样本数=重复数。"""
    rows = sweep(_builder, variable="input_len", values=[8, 16],
                 new_tokens=4, batch=1, warmup=2, repeats=5)
    assert [row["value"] for row in rows] == [8, 16]
    for row in rows:
        assert len(row["samples"]) == 5
        assert row["mean_s"] == pytest.approx(statistics.mean(row["samples"]))
        assert row["std_s"] == pytest.approx(statistics.stdev(row["samples"]))
        assert row["mean_s"] > 0


def test_sweep_calls_decode_per_batch() -> None:
    """batch=N 意味着每样本 N 次独立解码请求；用计数器验证调用次数。"""
    calls = {"n": 0}

    def counting_decode(model, prompt_ids, new_tokens):
        calls["n"] += 1
        return None

    sweep(_builder, variable="batch", values=[1, 2], decode_fn=counting_decode,
          input_len=8, new_tokens=4, warmup=2, repeats=5)
    # (1+2) × (预热2+重复5) = 21 次调用
    assert calls["n"] == (1 + 2) * (2 + 5)


def test_sweep_invalid_arguments() -> None:
    with pytest.raises(TypeError):
        sweep("not-a-builder", variable="input_len", values=[8])
    with pytest.raises(TypeError):
        sweep(_builder, variable="input_len", values=8)
    with pytest.raises(ValueError, match="variable"):
        sweep(_builder, variable="prompt_len", values=[8])
    with pytest.raises(ValueError, match="不能为空"):
        sweep(_builder, variable="input_len", values=[])
    with pytest.raises(ValueError, match="fixed"):
        sweep(_builder, variable="input_len", values=[8], input_len=8)
    with pytest.raises(ValueError, match="warmup"):
        sweep(_builder, variable="input_len", values=[8], warmup=1)


def test_sync_device_cpu_is_noop() -> None:
    """CPU 上同步为空操作且不抛错；CUDA 分支语义见 docstring（本机无卡未测）。"""
    sync_device()
