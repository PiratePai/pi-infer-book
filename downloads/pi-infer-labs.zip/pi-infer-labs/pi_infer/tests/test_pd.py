"""P/D 四阶段协议：逐 token 参考、故障注入、取消回收与 epoch 隔离。"""

from __future__ import annotations

import pickle
import threading
import time
from contextlib import contextmanager
from dataclasses import replace

import pytest
import torch

from pi_infer.generate import greedy_decode
from pi_infer.kv import CapacityError, DoubleFreeError
from pi_infer.model import SimpleKVCache, build_tiny_model
from pi_infer.pd import (
    ACK_TOPIC, PD_TOPIC, Ack, Cancel, Channel, Commit, Data, DecodeWorker,
    GlooChannel, InProcessChannel, PdCancelled, PdChannelClosed, PdRequest,
    PdStaleMessage, PrefillWorker, Prepare, Release, message_bytes,
)


@pytest.fixture(scope="module", autouse=True)
def one_cpu_thread():
    """避免小矩阵的线程池开销，模块结束后恢复配置。"""
    previous = torch.get_num_threads()
    torch.set_num_threads(1)
    yield
    torch.set_num_threads(previous)


def wait_for(predicate, timeout=2.):
    deadline = time.monotonic() + timeout
    while not predicate():
        if time.monotonic() >= deadline:
            raise AssertionError("等待协议条件超时")
        time.sleep(0.001)


def request(model, rid="r", prompt=None, prefill_tokens=2):
    cache = SimpleKVCache()
    result = greedy_decode(model, prompt or [1, 5, 9, 11], prefill_tokens, cache)
    return PdRequest.from_cache(rid, result.token_ids, cache)


@contextmanager
def receiver(worker):
    stop = threading.Event()
    errors = []

    def receive():
        try:
            worker.run(stop)
        except Exception as error:
            errors.append(error)

    thread = threading.Thread(target=receive)
    thread.start()
    try:
        yield
    finally:
        stop.set()
        thread.join(2)
        assert not thread.is_alive()
        assert not errors


def assert_empty(p, d, channel):
    wait_for(lambda: d.state_count == 0 and channel.pending_count == 0)
    assert not p.held and not p.transferred
    assert not d.pending and not d.states


@pytest.mark.parametrize("seed", [0, 7])
def test_handoff_continues_greedy_token_for_token(seed):
    model = build_tiny_model(seed)
    channel = InProcessChannel()
    p, d = PrefillWorker(channel), DecodeWorker(build_tiny_model(seed), channel)
    req = request(model)
    p.hold(req)
    with receiver(d):
        assert p.handoff("r") == 0
        wait_for(lambda: d.states["r"].committed)
        assert p.owned_count == 0
        assert d.states["r"].cache.get(0)[0].shape[2] == len(req.token_ids) - 1
        actual = d.decode("r", 5)
        assert actual == greedy_decode(model, [1, 5, 9, 11], 7).token_ids
        assert d.states["r"].cache.get(0)[0].shape[2] == len(actual) - 1
        p.release("r", "complete")
        assert_empty(p, d, channel)
    channel.close()


def test_cancel_before_prepare_releases_only_p():
    model = build_tiny_model()
    channel = InProcessChannel()
    p, d = PrefillWorker(channel), DecodeWorker(model, channel)
    p.hold(request(model))
    p.cancel("r")
    assert_empty(p, d, channel)
    with pytest.raises(DoubleFreeError):
        p.release("r")


class PausedDataChannel(InProcessChannel):
    """阻塞 Data，允许取消消息先到达 D；随后可丢弃或延迟投递 Data。"""

    def __init__(self, deliver=False):
        super().__init__()
        self.entered = threading.Event()
        self.resume = threading.Event()
        self.deliver = deliver

    def send(self, topic, message):
        if isinstance(message, Data):
            self.entered.set()
            if not self.resume.wait(2):
                raise TimeoutError("测试未恢复 Data")
            if not self.deliver:
                return
        super().send(topic, message)


@pytest.mark.parametrize("deliver_late", [False, True])
def test_cancel_during_data_cannot_resurrect_state(deliver_late):
    channel = PausedDataChannel(deliver=deliver_late)
    model = build_tiny_model()
    p, d = PrefillWorker(channel), DecodeWorker(model, channel, data_timeout=0.03)
    p.hold(request(model))
    failures = []

    def handoff():
        try:
            p.handoff("r")
        except Exception as error:
            failures.append(error)

    with receiver(d):
        thread = threading.Thread(target=handoff)
        thread.start()
        try:
            assert channel.entered.wait(2)
            wait_for(lambda: "r" in d.pending)
            p.cancel("r")
            wait_for(lambda: d.state_count == 0)
        finally:
            channel.resume.set()
            thread.join(2)
        assert not thread.is_alive()
        assert len(failures) == 1 and isinstance(failures[0], PdCancelled)
        assert_empty(p, d, channel)
        if deliver_late:
            wait_for(lambda: any(isinstance(error, PdStaleMessage) for error in d.errors))


def test_prepare_without_data_expires_even_when_cancel_is_lost():
    channel = InProcessChannel()
    model = build_tiny_model()
    p, d = PrefillWorker(channel), DecodeWorker(model, channel, data_timeout=0.01)
    req = request(model)
    epoch = p.hold(req)
    with receiver(d):
        channel.send(PD_TOPIC, Data(req.request_id, epoch, req.token_ids, req.kv).prepare())
        wait_for(lambda: "r" in d.pending)
        p.cancel("r")  # P 尚未 handoff，因此只做本地回收；D 依靠超时。
        wait_for(lambda: d.expired_prepares == 1)
        assert_empty(p, d, channel)


def test_cancel_after_ack_releases_d_and_p_route():
    channel = InProcessChannel()
    model = build_tiny_model()
    p, d = PrefillWorker(channel), DecodeWorker(model, channel)
    p.hold(request(model))
    with receiver(d):
        p.handoff("r")
        wait_for(lambda: d.states["r"].committed)
        d.decode("r", 1)
        p.cancel("r")
        assert_empty(p, d, channel)


class DropAckChannel(InProcessChannel):
    """丢第一次 Ack，让 D 已暂存而 P 超时；重试应走同 epoch 去重路径。"""

    def __init__(self):
        super().__init__()
        self.ack_count = 0
        self.data_epochs = []

    def send(self, topic, message):
        if type(message) is Ack:
            self.ack_count += 1
            if self.ack_count == 1:
                return
        if isinstance(message, Data):
            self.data_epochs.append(message.epoch)
        super().send(topic, message)


def test_ack_timeout_retry_preserves_epoch_and_transfers_once():
    channel = DropAckChannel()
    model = build_tiny_model()
    p, d = PrefillWorker(channel, ack_timeout=0.05), DecodeWorker(model, channel)
    req = request(model)
    epoch = p.hold(req)
    with receiver(d):
        with pytest.raises(TimeoutError, match="P 保留所有权"):
            p.handoff("r")
        assert p.owned_count == 1 and d.state_count == 1
        state = d.states["r"]
        assert not state.committed
        with pytest.raises(ValueError, match="Commit"):
            d.decode("r", 1)
        assert p.handoff("r") == epoch
        wait_for(lambda: state.committed)
        assert d.states["r"] is state
        assert channel.data_epochs == [epoch, epoch]
        assert p.sent_bytes == 2 * message_bytes(req)
        assert d.decode("r", 3) == greedy_decode(model, [1, 5, 9, 11], 5).token_ids
        p.release("r")
        assert_empty(p, d, channel)


def test_duplicate_data_reacks_without_reset_or_decode():
    channel = InProcessChannel()
    model = build_tiny_model()
    d = DecodeWorker(model, channel)
    req = request(model)
    data = Data("r", 0, req.token_ids, req.kv)
    d.process(data.prepare())
    d.process(data)
    assert channel.recv(ACK_TOPIC) == Ack("r", 0)
    d.process(Commit("r", 0))
    actual = d.decode("r", 2)
    state, cache = d.states["r"], d.states["r"].cache.get(0)[0]
    d.process(data.prepare())
    d.process(data)
    d.process(Commit("r", 0))
    assert channel.recv(ACK_TOPIC) == Ack("r", 0)
    assert d.states["r"] is state and state.steps == 2
    assert state.cache.get(0)[0] is cache and state.token_ids == actual
    d.release("r")
    with pytest.raises(DoubleFreeError):
        d.release("r")
    assert d.state_count == channel.pending_count == 0


def test_stale_epoch_after_reuse_does_not_damage_new_or_other_request():
    channel = InProcessChannel()
    model = build_tiny_model()
    p, d = PrefillWorker(channel), DecodeWorker(model, channel)
    req = request(model)
    old = Data("r", p.hold(req), req.token_ids, req.kv)
    with receiver(d):
        p.handoff("r")
        p.release("r")
        wait_for(lambda: d.state_count == 0)
        assert p.hold(req) == 1
        p.handoff("r")
        wait_for(lambda: d.states["r"].committed)
        current = d.states["r"]
        stale = [old.prepare(), old, Commit("r", 0), Release("r", 0), Cancel("r", 0)]
        for message in stale:
            channel.send(PD_TOPIC, message)
        p.hold(request(model, "other"))
        p.handoff("other")
        wait_for(lambda: d.states["other"].committed and len(d.errors) == len(stale))
        assert all(isinstance(error, PdStaleMessage) for error in d.errors)
        assert all(error.__traceback__ is None for error in d.errors)
        assert d.states["r"] is current
        for rid in ("r", "other"):
            assert d.decode(rid, 2) == greedy_decode(model, [1, 5, 9, 11], 4).token_ids
            p.release(rid)
        assert_empty(p, d, channel)
    with pytest.raises(PdStaleMessage):
        d.process(Data("r", 1, req.token_ids, req.kv))


@pytest.mark.parametrize("failed_type", [Prepare, Data, Commit])
def test_send_exception_ownership_and_retry(failed_type):
    class FailOnce(InProcessChannel):
        failed = False

        def send(self, topic, message):
            if type(message) is failed_type and not self.failed:
                self.failed = True
                raise OSError("injected send failure")
            super().send(topic, message)

    channel = FailOnce()
    model = build_tiny_model()
    p, d = PrefillWorker(channel), DecodeWorker(model, channel)
    p.hold(request(model))
    with receiver(d):
        with pytest.raises(OSError):
            p.handoff("r")
        assert p.owned_count == (0 if failed_type is Commit else 1)
        p.handoff("r")
        wait_for(lambda: d.states["r"].committed)
        assert d.decode("r", 1) == greedy_decode(model, [1, 5, 9, 11], 3).token_ids
        p.release("r")
        assert_empty(p, d, channel)


def test_kv_length_shape_dtype_fields_and_bytes():
    model = build_tiny_model()
    req = request(model)
    data = Data("r", 0, req.token_ids, req.kv)
    prepare = data.prepare()
    assert message_bytes(data) == len(req.token_ids) * 8 + 2 * 2 * 1 * 2 * 5 * 16 * 4
    assert message_bytes(data) == message_bytes(req)
    for message in (prepare, data, Ack("r", 0), Commit("r", 0), Release("r", 0), Cancel("r", 0)):
        assert type(pickle.loads(pickle.dumps(message))) is type(message)
    with pytest.raises(ValueError, match="kv_len"):
        replace(data, token_ids=data.token_ids + [1])
    with pytest.raises(ValueError, match="kv_len"):
        replace(prepare, kv_len=prepare.kv_len + 1)
    with pytest.raises(ValueError, match="shape"):
        replace(data, kv={0: (torch.zeros(1, 2, 5, 16), torch.zeros(1, 2, 4, 16))})
    with pytest.raises(TypeError):
        Prepare("r", 0, 3, 2)  # 缺少 kv_shape
    with pytest.raises(TypeError):
        message_bytes(prepare)
    d = DecodeWorker(model, InProcessChannel())
    with pytest.raises(TypeError):
        d.process({"request_id": "r"})
    with pytest.raises(ValueError, match="模型"):
        d.process(replace(prepare, kv_shape={0: (1, 2, 5, 16)}))
    with pytest.raises(ValueError, match="Prepare"):
        d.process(data)
    d.process(prepare)
    with pytest.raises(ValueError, match="dtype"):
        d.process(replace(data, kv={layer: (k.double(), v.double()) for layer, (k, v) in data.kv.items()}))
    assert not d.states and len(d.pending) == 1
    d.release("r")


def test_constructor_capacity_snapshot_and_close_contracts():
    model = build_tiny_model()
    channel = InProcessChannel()
    for timeout in (0, -1, float("inf"), float("nan")):
        with pytest.raises(ValueError):
            PrefillWorker(channel, ack_timeout=timeout)
        with pytest.raises(ValueError):
            DecodeWorker(model, channel, data_timeout=timeout)
    with pytest.raises(TypeError):
        PrefillWorker(object())
    with pytest.raises(TypeError):
        Channel()
    with pytest.raises(ValueError):
        GlooChannel(1)
    p = PrefillWorker(channel, max_requests=1)
    req = request(model)
    p.hold(req)
    snapshot = p.held["r"].data.kv[0][0].clone()
    req.kv[0][0].zero_()
    torch.testing.assert_close(p.held["r"].data.kv[0][0], snapshot)
    with pytest.raises(ValueError):
        p.hold(req)
    with pytest.raises(CapacityError):
        p.hold(request(model, "other"))
    p.release("r")
    with pytest.raises(DoubleFreeError):
        p.handoff("r")
    with pytest.raises(TimeoutError):
        channel.recv("empty", timeout=0)
    channel.send("topic", Ack("r", 0))
    assert channel.pending_count == 1
    channel.close()
    channel.close()
    assert channel.pending_count == 0
    for operation in (lambda: channel.send("topic", None), lambda: channel.recv("topic")):
        with pytest.raises(PdChannelClosed):
            operation()


@pytest.mark.parametrize("phase", ["rebuild", "decode"])
def test_second_layer_failure_discards_request_cache_and_isolates_others(monkeypatch, phase):
    model = build_tiny_model()
    channel = InProcessChannel()
    d = DecodeWorker(model, channel)
    req = request(model)
    data = Data("r", 0, req.token_ids, req.kv)
    d.process(data.prepare())
    state = None
    if phase == "decode":
        d.process(data)
        channel.recv(ACK_TOPIC)
        d.process(Commit("r", 0))
        state = d.states["r"]
        original_ids = list(state.token_ids)

    with monkeypatch.context() as patch:
        if phase == "rebuild":
            append = SimpleKVCache.append

            def fail(cache, layer, k, v):
                if layer == 1:
                    raise RuntimeError("第二层故障")
                return append(cache, layer, k, v)

            patch.setattr(SimpleKVCache, "append", fail)
            operation = lambda: d.process(data)
        else:
            def fail(*args, **kwargs):
                raise RuntimeError("第二层故障")

            patch.setattr(model.layers[1], "forward", fail)
            operation = lambda: d.decode("r", 1)
        with pytest.raises(RuntimeError, match="第二层故障"):
            operation()
    assert d.failed == {"r": 0}
    assert "r" not in d.states and "r" not in d.pending
    if state:
        assert not state.cache.k_cache and not state.cache.v_cache
        assert state.token_ids == original_ids and state.steps == 0
    with pytest.raises(ValueError, match="Commit"):
        d.decode("r", 1)
    with pytest.raises(PdStaleMessage):
        d.process(data.prepare())
    # 故障不污染其他请求，也不妨碍同 id 的新 epoch。
    for rid, epoch in (("other", 0), ("r", 1)):
        next_data = Data(rid, epoch, req.token_ids, req.kv)
        d.process(next_data.prepare())
        d.process(next_data)
        assert channel.recv(ACK_TOPIC) == Ack(rid, epoch)
        d.process(Commit(rid, epoch))
        assert d.decode(rid, 2) == greedy_decode(model, [1, 5, 9, 11], 4).token_ids
        d.release(rid)


def test_network_release_cancel_replay_is_idempotent_but_local_release_is_strict():
    model = build_tiny_model()
    channel = InProcessChannel()
    p, d = PrefillWorker(channel), DecodeWorker(model, channel)
    req = request(model)
    with receiver(d):
        for epoch in (0, 1):
            assert p.hold(req) == epoch
            p.handoff("r")
            wait_for(lambda: d.states.get("r") is not None and d.states["r"].committed)
            p.release("r")
            wait_for(lambda: "r" not in d.states)
            for message in (Release("r", epoch), Cancel("r", epoch), Release("r", epoch)):
                channel.send(PD_TOPIC, message)
            wait_for(lambda: channel.pending_count == 0)
            assert not d.errors
            for worker in (p, d):
                with pytest.raises(DoubleFreeError):
                    worker.release("r")
        for message in (Release("r", 0), Cancel("r", 0)):
            with pytest.raises(PdStaleMessage):
                d.process(message)


def test_gloo_close_bounds_both_sender_and_receiver_and_clears_queue(monkeypatch):
    channel = GlooChannel.__new__(GlooChannel)
    InProcessChannel.__init__(channel)
    channel.close_timeout = .01
    channel.close_errors = []
    InProcessChannel.send(channel, "pending", Ack("r", 0))
    resume = threading.Event()
    monkeypatch.setattr(channel, "_wire_send", lambda *args: resume.wait(2))
    channel._receiver = threading.Thread(target=lambda: resume.wait(2), daemon=True)
    channel._receiver.start()
    try:
        start = time.monotonic()
        with pytest.raises(TimeoutError, match="发送超时"):
            channel.close()
        assert time.monotonic() - start < 1
        assert len(channel.close_errors) == 2
        assert channel._closed and channel.pending_count == 0
        channel.close()
    finally:
        resume.set()
        channel._receiver.join(2)
