"""Windows spawn + gloo CPU：数值参考、应用层载荷与进程回收。"""

from __future__ import annotations

import os
import statistics

import pytest
import torch
import torch.distributed as dist
import torch.multiprocessing as mp

from pi_infer.comm import (
    ByteLog, aggregate_bytes, all_gather, all_reduce, broadcast, p2p_recv, p2p_send,
    pp2_tiny_forward, reduce_scatter, register_workload, run_world, spawn_workers,
    time_op, tp2_matmul, verify_primitives,
)


@register_workload
def _suite(world):
    rank = dist.get_rank()
    checked = {
        "primitives": verify_primitives(world),
        "tp2": tp2_matmul(world),
        "pp2": pp2_tiny_forward(world),
    }
    errors = []
    cases = [
        lambda: reduce_scatter(torch.ones(3)),
        lambda: all_gather(torch.ones(2), total_numel=3),
        lambda: all_gather(torch.ones(2), total_numel=6),
        lambda: reduce_scatter(torch.ones(4 + 2 * rank)),
        lambda: all_gather(torch.ones(2 + rank)),
        lambda: broadcast(torch.ones(4), src=world),
        lambda: all_reduce(torch.ones(4, dtype=torch.float64)),
        lambda: all_reduce(torch.ones(4) if rank == 0 else torch.ones(2, 2)),
        lambda: p2p_send(torch.ones(4), rank),
        lambda: broadcast(torch.ones(4), src=1 if rank == 0 else True),
        lambda: all_gather(torch.ones(1), total_numel=2 if rank == 0 else 2.0),
    ]
    for fn in cases:
        try:
            fn()
        except ValueError as error:
            errors.append(str(error))
        else:
            raise AssertionError("非法输入应在所有 rank 抛出 ValueError")
    # all_gather 的本地 K 无需整除 P；完整 N 必须整除。
    odd, _ = all_gather(torch.full((3,), float(rank)), total_numel=6)
    assert torch.equal(odd, torch.tensor([0., 0., 0., 1., 1., 1.]))
    # 非零广播源，同时校验仅源记发送字节。
    value, log = broadcast(torch.full((4,), float(rank)), src=1)
    assert torch.equal(value, torch.ones(4))
    assert log.bytes == (16 if rank == 1 else 0)
    checked.update(errors=errors, rank=rank, env={key: os.environ[key] for key in
                   ("MASTER_ADDR", "MASTER_PORT", "RANK", "WORLD_SIZE")},
                   returned_tensor=odd)
    return checked


def _failing_worker(world):
    raise ValueError("故意触发工作负载失败")


@pytest.fixture(scope="module")
def results():
    """合并小负载仅启动一次，避免 Windows 重复导入 torch 的固定成本。"""
    before = {p.pid for p in mp.active_children()}
    env = {key: os.environ.get(key) for key in ("MASTER_ADDR", "MASTER_PORT", "RANK", "WORLD_SIZE")}
    rows = run_world("_suite", 2)
    assert {p.pid for p in mp.active_children()} == before
    assert not dist.is_initialized()
    assert {key: os.environ.get(key) for key in env} == env
    return rows


def test_primitives_match_hand_reference_and_bytes(results):
    expected_per_rank = {"p2p": [64, 64], "broadcast": [64, 0],
                         "all_reduce": [64, 64], "reduce_scatter": [64, 64],
                         "all_gather": [32, 32]}
    for op, expected in expected_per_rank.items():
        logs = []
        for rank, row in enumerate(results):
            passed, log, delta = row["primitives"][op]
            assert passed and delta <= 1e-6
            assert log.rank == rank and log.op == op
            assert log.bytes == expected[rank] == log.numel * log.element_size
            logs.append(log)
        assert aggregate_bytes(logs) == {"per_rank": dict(enumerate(expected)),
                                         "total_bytes": sum(expected)}


def test_tp2_pp2_match_full_forward_and_payload(results):
    for key, expected in (("tp2", [128, 128]), ("pp2", [1024, 0])):
        for rank, row in enumerate(results):
            passed, log, delta = row[key]
            assert passed and delta <= 1e-6
            assert log.bytes == expected[rank]
        assert aggregate_bytes(row[key][1] for row in results)["total_bytes"] == sum(expected)


def test_rank_environment_results_and_invalid_shapes(results):
    for rank, row in enumerate(results):
        assert row["rank"] == rank
        assert len(row["errors"]) == 11
        assert "整除" in row["errors"][0] and "整除" in row["errors"][1]
        assert row["env"]["RANK"] == str(rank)
        assert row["env"]["WORLD_SIZE"] == "2"
        assert row["env"]["MASTER_ADDR"] == "127.0.0.1"
        assert 0 < int(row["env"]["MASTER_PORT"]) < 65536
        assert torch.equal(row["returned_tensor"], torch.tensor([0., 0., 0., 1., 1., 1.]))


def test_collective_rejects_equal_values_with_different_types_on_all_ranks(results):
    for row in results:
        assert all("集合参数必须为 int" in error for error in row["errors"][-2:])


def test_spawn_deadline_terminates_and_joins_children(monkeypatch):
    from types import SimpleNamespace
    from pi_infer import comm

    class Child:
        alive = True
        joined = False

        def is_alive(self):
            return self.alive

        def terminate(self):
            self.alive = False

        def join(self, timeout=None):
            self.joined = True

    child = Child()
    context = SimpleNamespace(processes=[child], join=lambda timeout: False)
    monkeypatch.setattr(comm.mp, "spawn", lambda *args, **kwargs: context)
    with pytest.raises(TimeoutError, match="总等待超时"):
        spawn_workers(_failing_worker, 1, deadline=.01)
    assert child.joined and not child.alive


@pytest.mark.parametrize("fn", [lambda: p2p_send(torch.ones(4), 1),
                                  lambda: p2p_recv(torch.ones(4), 1),
                                  lambda: broadcast(torch.ones(4)),
                                  lambda: all_reduce(torch.ones(4)),
                                  lambda: reduce_scatter(torch.ones(4)),
                                  lambda: all_gather(torch.ones(4))])
def test_uninitialized_group_raises(fn):
    with pytest.raises(RuntimeError, match="初始化"):
        fn()


def test_worker_failure_is_propagated_and_reaped():
    before = {p.pid for p in mp.active_children()}
    with pytest.raises(mp.ProcessRaisedException, match="故意触发"):
        spawn_workers(_failing_worker, 2)
    assert {p.pid for p in mp.active_children()} == before
    assert not dist.is_initialized()


def test_spawn_and_bytelog_validation():
    for world in (0, -1, True, 1.5):
        with pytest.raises(ValueError, match="world_size"):
            spawn_workers(verify_primitives, world)
    with pytest.raises(ValueError, match="未注册"):
        spawn_workers("missing", 2)
    with pytest.raises(TypeError):
        spawn_workers(None, 2)
    with pytest.raises(ValueError, match="顶层"):
        spawn_workers(lambda world: world, 2)
    with pytest.raises(ValueError, match="bytes"):
        ByteLog("all_reduce", "all", "all", 4, 4, 15, 0)
    with pytest.raises(ValueError, match="rank"):
        ByteLog("all_reduce", "all", "all", 4, 4, 16, -1)
    with pytest.raises(TypeError):
        aggregate_bytes([16])


def test_time_op_interleaves_and_reports_sample_std():
    calls = []
    rows = time_op({"a": lambda: calls.append("a"), "b": lambda: calls.append("b")})
    assert calls == ["a", "b"] * 7
    for row in rows.values():
        assert len(row["samples"]) == 5
        assert row["mean_s"] == pytest.approx(statistics.mean(row["samples"]))
        assert row["std_s"] == pytest.approx(statistics.stdev(row["samples"]))
    assert len(time_op(lambda: None)["samples"]) == 5
    for kwargs in ({"warmup": 1}, {"repeats": 4}):
        with pytest.raises(ValueError):
            time_op(lambda: None, **kwargs)
    with pytest.raises(TypeError):
        time_op({})
