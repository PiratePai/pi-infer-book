"""贪心严格一致、回滚边界及精确采样分布保持的独立验收。"""

from types import SimpleNamespace

import pytest
import torch
from torch import Tensor, nn

from pi_infer import build_tiny_model, greedy_decode
from pi_infer.kv import PagedKVCache
from pi_infer.model import SimpleKVCache, TinyTransformer
from pi_infer.speculative import DraftResult, SamplingSpec, sample_from_logits, speculative_generate, verify_and_accept


def spec(seed: int = 0, greedy: bool = True, **kwargs) -> SamplingSpec:
    """每次显式创建调用方拥有的 RNG。"""
    return SamplingSpec(greedy=greedy, rng=torch.Generator().manual_seed(seed), **kwargs)


def oracle(model: TinyTransformer, ids: list[int], n: int) -> DraftResult:
    """以独立全量贪心路径产生真草稿及各步 logits。"""
    generated = greedy_decode(model, ids, n)
    return DraftResult(generated.token_ids[len(ids):], generated.per_step_logits)


def adversary(k: int):
    """草稿第 k 个位置强制给错，后续位置仍返回占位草稿。"""
    def draft(model: TinyTransformer, ids: list[int], n: int) -> DraftResult:
        result = oracle(model, ids, n)
        position = min(k, n - 1)
        result.tokens[position] = (result.tokens[position] + 1) % model.config.vocab_size
        return result
    return draft


def assert_cache_matches(model: TinyTransformer, cache, ids: list[int]) -> None:
    """核对每层长度及完整 KV 内容，防止仅修正了表面长度。"""
    reference = SimpleKVCache()
    with torch.no_grad():
        model(torch.tensor([ids]), kv_cache=reference)
    for layer in range(model.config.n_layers):
        assert cache.get(layer)[0].shape[2] == len(ids)
        for actual, expected in zip(cache.get(layer), reference.get(layer), strict=True):
            torch.testing.assert_close(actual, expected, atol=1e-5, rtol=0)


def test_greedy_all_accepted_and_verify_logits_align_with_next_token() -> None:
    model = build_tiny_model()
    ids = [1, 2, 3]
    draft = oracle(model, ids, 4)
    cache = SimpleKVCache()
    result = verify_and_accept(model, ids, draft, cache, spec())
    assert result.accepted_tokens == draft.tokens
    assert result.rejected_at is None and result.corrected_token is None
    assert not result.hit_eos and not result.model_was_rolled_back
    assert result.rollback_to == len(ids) + 4
    for actual, expected in zip(result.verify_logits, draft.draft_logits, strict=True):
        torch.testing.assert_close(actual, expected, atol=1e-5, rtol=0)
    assert_cache_matches(model, cache, ids + draft.tokens)


@pytest.mark.parametrize("k", [0, 1, 2, 3])
@pytest.mark.parametrize("prefilled", [False, True])
def test_greedy_rejects_at_forced_position_then_continues_from_correct_kv(k: int, prefilled: bool) -> None:
    model = build_tiny_model(seed=7)
    prompt = [3, 5, 7]
    draft = adversary(k)(model, prompt, 4)
    expected = greedy_decode(model, prompt, 8)
    cache = SimpleKVCache()
    if prefilled:
        with torch.no_grad():
            model(torch.tensor([prompt]), kv_cache=cache)
    result = verify_and_accept(model, prompt, draft, cache, spec())
    assert result.rejected_at == k
    assert result.accepted_tokens == expected.token_ids[len(prompt):len(prompt) + k]
    assert result.corrected_token == expected.token_ids[len(prompt) + k]
    assert result.rollback_to == len(prompt) + k + 1
    assert result.model_was_rolled_back
    current = prompt + result.accepted_tokens + [result.corrected_token]
    assert_cache_matches(model, cache, current)
    # 从同一个回滚后的缓存继续，逐步输出与独立纯贪心一致。
    with torch.no_grad():
        logits = model(torch.tensor([current]), kv_cache=None)[0, -1]
        for _ in range(8 - k - 1):
            token = int(logits.argmax())
            current.append(token)
            logits = model(torch.tensor([[token]]), start_pos=len(current) - 1, kv_cache=cache)[0, -1]
    assert current == expected.token_ids


@pytest.mark.parametrize("draft_fn", [oracle, adversary(0), adversary(1), adversary(3)])
@pytest.mark.parametrize("max_tokens", [0, 1, 7, 10])
def test_greedy_end_to_end_equals_greedy_decode(draft_fn, max_tokens: int) -> None:
    model = build_tiny_model(seed=42)
    prompt = [2, 4, 6]
    expected = greedy_decode(model, prompt, max_tokens)
    actual = speculative_generate(model, draft_fn, prompt, max_tokens, spec(), max_draft_len=4)
    assert actual.token_ids == expected.token_ids
    assert actual.steps == expected.steps == max_tokens
    for got, want in zip(actual.per_step_logits, expected.per_step_logits, strict=True):
        torch.testing.assert_close(got, want, atol=1e-5, rtol=0)


def test_random_drafts_still_produce_exact_greedy_output() -> None:
    model = build_tiny_model()
    rng = torch.Generator().manual_seed(123)

    def random_draft(model, ids, n):
        return DraftResult(torch.randint(model.config.vocab_size, (n,), generator=rng).tolist(), [torch.zeros(model.config.vocab_size)] * n)

    actual = speculative_generate(model, random_draft, [1, 3], 7, spec())
    assert actual.token_ids == greedy_decode(model, [1, 3], 7).token_ids


@pytest.mark.parametrize("position", [1, 3])
def test_greedy_eos_in_accepted_middle_or_final_token(position: int) -> None:
    model = build_tiny_model()
    prompt = [1, 2, 3]
    draft = oracle(model, prompt, 4)
    eos = draft.tokens[position]
    assert eos not in draft.tokens[:position]
    cache = SimpleKVCache()
    result = verify_and_accept(model, prompt, draft, cache, spec(), eos)
    assert result.accepted_tokens == draft.tokens[:position + 1]
    assert result.hit_eos and result.corrected_token is None and result.rejected_at is None
    assert result.rollback_to == len(prompt) + position + 1
    assert_cache_matches(model, cache, prompt + result.accepted_tokens)
    actual = speculative_generate(model, oracle, prompt, 10, spec(), eos_id=eos)
    expected = greedy_decode(model, prompt, 10, eos_id=eos)
    assert actual.token_ids == expected.token_ids


def test_corrected_eos_stops_and_prompt_eos_does_not_stop() -> None:
    model = build_tiny_model()
    prompt = [3, 5, 7]
    eos = oracle(model, prompt, 1).tokens[0]
    result = speculative_generate(model, adversary(0), prompt, 8, spec(), eos_id=eos)
    assert result.token_ids == prompt + [eos]
    prompt_eos = speculative_generate(model, oracle, prompt, 1, spec(), eos_id=prompt[-1])
    assert prompt_eos.steps == 1


def test_paged_cache_rollback_preserves_shared_request() -> None:
    model = build_tiny_model()
    c = model.config
    pool = PagedKVCache(16, (c.n_kv_heads, 2, c.d_model // c.n_heads), n_layers=c.n_layers)
    prompt = [1, 2, 3, 4]
    a = pool.request("m", "a", prompt)
    with torch.no_grad():
        model(torch.tensor([prompt]), kv_cache=a)
    b = pool.request("m", "b", prompt)
    result = verify_and_accept(model, prompt, adversary(1)(model, prompt, 4), b, spec())
    assert result.rollback_to == 6
    assert_cache_matches(model, b, prompt + result.accepted_tokens + [result.corrected_token])
    assert_cache_matches(model, a, prompt)
    a.release()
    b.release()
    assert pool.allocator.used_blocks == 0


class DistributionModel(nn.Module):
    """固定目标分布及可观测前向次数，用于隔离采样算法。"""

    def __init__(self, probabilities: Tensor) -> None:
        super().__init__()
        self.embedding = nn.Embedding(len(probabilities), 2)
        self.config = SimpleNamespace(n_layers=1, vocab_size=len(probabilities))
        self.register_buffer("logits", probabilities.log())
        self.calls = 0

    def forward(self, token_ids, start_pos=0, kv_cache=None):
        self.calls += 1
        if kv_cache is not None:
            zeros = torch.zeros(1, 1, token_ids.shape[1], 2)
            kv_cache.append(0, zeros, zeros)
        return self.logits.view(1, 1, -1).expand(1, token_ids.shape[1], -1)


@pytest.mark.parametrize("temperature,top_k", [(1.0, None), (0.7, None), (0.7, 2)])
def test_sampling_distribution_preservation_vocab32_n2000(temperature: float, top_k: int | None) -> None:
    # 两个峰的权重反转，其余 30 桶均为正概率；草稿确实从 q 抽取。
    p = torch.tensor([0.31, 0.19] + [0.5 / 30] * 30, dtype=torch.float64)
    q = torch.tensor([0.05, 0.50] + [0.45 / 30] * 30, dtype=torch.float64)
    model = DistributionModel(p)
    sampling = spec(seed=20261102, greedy=False, temperature=temperature, top_k=top_k)
    expected_logits = p.log() / temperature
    if top_k is not None:
        top_values, top_indices = expected_logits.topk(top_k)
        expected_logits = torch.full_like(expected_logits, -torch.inf).scatter(0, top_indices, top_values)
    expected = expected_logits.softmax(0)
    counts = torch.zeros(32, dtype=torch.int64)
    accepted = rejected = 0
    n = 2000
    for _ in range(n):
        token = sample_from_logits(q.log(), sampling)
        result = verify_and_accept(model, [2], DraftResult([token], [q.log()]), SimpleKVCache(), sampling)
        if result.corrected_token is None:
            output = result.accepted_tokens[0]
            accepted += 1
        else:
            output = result.corrected_token
            rejected += 1
        counts[output] += 1
        assert result.rollback_to == 2
    assert accepted > 0 and rejected > 0
    sigma = torch.sqrt(n * expected * (1 - expected))
    assert torch.all((counts - n * expected).abs() <= 5 * sigma), (counts, n * expected)


@pytest.mark.parametrize("branch", ["accept", "reject"])
def test_sampling_branch_rng_reproducibility(branch: str) -> None:
    p = torch.tensor([0.01, 0.39, 0.60], dtype=torch.float64)
    q = p if branch == "accept" else torch.tensor([0.8, 0.1, 0.1], dtype=torch.float64)
    results = []
    states = []
    for _ in range(2):
        sampling = spec(seed=17, greedy=False)
        cache = SimpleKVCache()
        model = DistributionModel(p)
        result = verify_and_accept(model, [2], DraftResult([0], [q.log()]), cache, sampling)
        assert (result.rejected_at is None) == (branch == "accept")
        assert model.calls == (1 if branch == "accept" else 2)
        assert cache.get(0)[0].shape[2] == result.rollback_to == 2
        results.append((result.accepted_tokens, result.corrected_token, result.rejected_at))
        states.append(sampling.rng.get_state())
    assert results[0] == results[1]
    assert torch.equal(states[0], states[1])


def test_sampling_temperature_topk_and_greedy_rng_behavior() -> None:
    logits = torch.tensor([0.0, 1.0, 2.0, 3.0])
    sampling = spec(seed=99, greedy=False, temperature=0.5, top_k=2)
    other = torch.Generator().manual_seed(99)
    expected = torch.tensor([-torch.inf, -torch.inf, 4.0, 6.0], dtype=torch.float64).softmax(0)
    for _ in range(50):
        assert sample_from_logits(logits, sampling) == int(torch.multinomial(expected, 1, generator=other))
    greedy = spec()
    state = greedy.rng.get_state().clone()
    assert sample_from_logits(logits, greedy) == 3
    assert torch.equal(state, greedy.rng.get_state())


@pytest.mark.parametrize("kwargs", [{"temperature": 0}, {"temperature": float("nan")}, {"top_k": 0}])
def test_invalid_sampling_parameters(kwargs) -> None:
    with pytest.raises(ValueError):
        spec(**kwargs)


def test_invalid_inputs_fail_before_mutating_caller_cache() -> None:
    model = build_tiny_model()
    with pytest.raises(ValueError, match="长度"):
        verify_and_accept(model, [1], DraftResult([2], []), SimpleKVCache(), spec())
    with pytest.raises(TypeError, match="truncate_to"):
        verify_and_accept(model, [1], DraftResult([2], [torch.zeros(256)]), object(), spec())
    with pytest.raises(ValueError, match="1..n"):
        speculative_generate(model, lambda *args: DraftResult([], []), [1], 2, spec())
