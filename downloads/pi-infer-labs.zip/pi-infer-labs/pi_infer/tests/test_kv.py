"""块分配、前缀生命周期、分页输出一致性与容量字节账。"""

import pytest
import torch

from pi_infer import build_tiny_model, greedy_decode
from pi_infer.kv import BlockAllocator, CapacityError, DoubleFreeError, PagedKVCache
from pi_infer.model import SimpleKVCache, TinyTransformer


def pool_for(model: TinyTransformer, block_size: int = 2, num_blocks: int = 32) -> PagedKVCache:
    """根据模型配置创建跨层块池。"""
    c = model.config
    return PagedKVCache(num_blocks, (c.n_kv_heads, block_size, c.d_model // c.n_heads), n_layers=c.n_layers)


@torch.no_grad()
def prefill(model: TinyTransformer, request, ids: list[int]) -> None:
    """只计算未命中的 prompt 部分。"""
    start = request.prefill_start_pos
    if start < len(ids):
        model(torch.tensor([ids[start:]]), start_pos=start, kv_cache=request)


def test_allocator_capacity_and_atomic_double_free() -> None:
    allocator = BlockAllocator(3, (2, 4, 8))
    assert allocator.allocate(0) == []
    assert allocator.allocate(2) == [0, 1]
    with pytest.raises(CapacityError):
        allocator.allocate(2)
    assert allocator.used_blocks == 2
    for ids in ([0, 0], [0, 2], [10]):
        with pytest.raises(DoubleFreeError):
            allocator.free(ids)
        assert allocator.used_blocks == 2
    allocator.free([0, 1])
    with pytest.raises(DoubleFreeError):
        allocator.free([0])
    assert allocator.allocate(3) == [0, 1, 2]


@pytest.mark.parametrize("reason", ["finished", "cancelled", "failed"])
def test_release_restores_pool_and_reuses_same_blocks(reason: str) -> None:
    model = build_tiny_model()
    pool = pool_for(model)
    request = pool.request("model", "a", [1, 2, 3, 4, 5])
    prefill(model, request, request.token_ids)
    ids = request.table.block_ids.copy()
    assert request.table.valid_tokens == [2, 2, 1]
    pool.prefix_cache.release("model", "a", reason)
    assert pool.allocator.free_blocks == pool.allocator.total_blocks
    assert not pool.prefix_cache._requests
    assert not pool.prefix_cache.ref_counts
    assert pool.allocator.allocate(len(ids)) == ids
    with pytest.raises(DoubleFreeError):
        request.release(reason)
    with pytest.raises(DoubleFreeError):
        request.get(0)


def test_exact_hit_miss_partial_tail_and_model_namespace() -> None:
    model = build_tiny_model()
    pool = pool_for(model)
    ids = [1, 2, 3, 4, 5]
    a = pool.request("m", "a", ids)
    prefill(model, a, ids)
    exact = pool.prefix_cache.match("m", ids)
    assert exact.num_matched == 4 and exact.tail_block_partial
    assert exact.block_ids == a.table.block_ids[:2]
    partial = pool.prefix_cache.match("m", [1, 2, 3])
    assert partial.num_matched == 2 and partial.tail_block_partial
    assert pool.prefix_cache.match("m", [9, 2, 3]).num_matched == 0
    assert pool.prefix_cache.match("other", ids).num_matched == 0
    b = pool.request("other", "a", ids)
    prefill(model, b, ids)
    assert set(a.table.block_ids).isdisjoint(b.table.block_ids)
    assert pool.prefix_cache.match("other", ids).num_matched == 4
    a.release()
    diverged = pool.prefix_cache.match("m", [1, 2, 3, 9])
    assert diverged.num_matched == 2 and diverged.tail_block_partial


@torch.no_grad()
def test_shared_references_survive_owner_release_and_tail_is_private() -> None:
    model = build_tiny_model()
    pool = pool_for(model)
    a = pool.request("m", "a", [1, 2, 3, 4, 5])
    prefill(model, a, a.token_ids)
    b = pool.request("m", "b", [1, 2, 3, 4, 9, 8])
    shared = b.table.block_ids.copy()
    assert b.num_matched == 4
    assert all(pool.prefix_cache.ref_counts[i] == 2 for i in shared)
    before = [tensor.clone() for tensor in b.get(0)]
    a.release("cancelled")
    assert all(pool.prefix_cache.ref_counts[i] == 1 for i in shared)
    for actual, expected in zip(b.get(0), before, strict=True):
        torch.testing.assert_close(actual, expected, atol=0, rtol=0)
    prefill(model, b, b.token_ids)
    reference = SimpleKVCache()
    model(torch.tensor([[1, 2, 3, 4, 9, 8]]), kv_cache=reference)
    for layer in range(model.config.n_layers):
        for actual, expected in zip(b.get(layer), reference.get(layer), strict=True):
            torch.testing.assert_close(actual, expected, atol=1e-6, rtol=0)
    b.release("failed")
    assert pool.allocator.used_blocks == 0


@torch.no_grad()
def test_partial_tail_is_recomputed_without_modifying_original() -> None:
    model = build_tiny_model()
    pool = pool_for(model, block_size=4)
    a = pool.request("m", "a", [1, 2, 3, 4, 5, 6])
    prefill(model, a, a.token_ids)
    old_k = a.get(0)[0].clone()
    b = pool.request("m", "b", [1, 2, 3, 4, 5, 9])
    assert b.num_matched == 4
    prefill(model, b, b.token_ids)
    assert b.table.block_ids[1] != a.table.block_ids[1]
    torch.testing.assert_close(a.get(0)[0], old_k, atol=0, rtol=0)


def test_weak_prefix_invalidated_on_reallocation() -> None:
    model = build_tiny_model()
    pool = pool_for(model, num_blocks=2)
    a = pool.request("m", "a", [1, 2, 3, 4])
    prefill(model, a, a.token_ids)
    a.release()
    assert pool.prefix_cache.match("m", [1, 2, 3, 4]).num_matched == 4
    pool.allocator.allocate(1)
    assert pool.prefix_cache.match("m", [1, 2, 3, 4]).num_matched == 0


@pytest.mark.parametrize("seed", [0, 7])
@pytest.mark.parametrize("suffix", [[7], [7, 8, 9]])
def test_four_generation_paths_match_tokens_and_each_step_logits(seed: int, suffix: list[int]) -> None:
    model = build_tiny_model(seed=seed)
    prefix = [1, 11, 21, 31]
    prompt = prefix + suffix
    pool = pool_for(model)
    baseline = greedy_decode(model, prompt, 6)
    simple = greedy_decode(model, prompt, 6, SimpleKVCache())
    independent = pool.request("m", "independent", prompt)
    paged = greedy_decode(model, prompt, 6, independent)
    independent.release()
    # 使用另一空池单独建立 P，确保复用完全来自已释放的预填充请求。
    pool = pool_for(model)
    warmup = pool.request("m", "warmup", prefix)
    prefill(model, warmup, prefix)
    warmup.release()
    reused = pool.request("m", "reuse", prompt)
    assert reused.num_matched == len(prefix)
    assert reused.prefill_start_pos == reused.num_matched
    reused_result = greedy_decode(model, prompt, 6, reused)
    for actual in (simple, paged, reused_result):
        assert actual.token_ids == baseline.token_ids
        assert actual.steps == baseline.steps == 6
        for got, expected in zip(actual.per_step_logits, baseline.per_step_logits, strict=True):
            torch.testing.assert_close(got, expected, atol=1e-5, rtol=0)


def test_generated_tokens_are_registered_and_full_prompt_hit_can_decode() -> None:
    model = build_tiny_model()
    pool = pool_for(model)
    request = pool.request("m", "a", [1, 2, 3])
    generated = greedy_decode(model, [1, 2, 3], 4, request)
    known = generated.token_ids[:-1]
    request.release()
    b = pool.request("m", "b", known)
    assert b.num_matched == len(known) == 6
    actual = greedy_decode(model, known, 4, b)
    expected = greedy_decode(model, known, 4)
    assert actual.token_ids == expected.token_ids
    for got, want in zip(actual.per_step_logits, expected.per_step_logits, strict=True):
        torch.testing.assert_close(got, want, atol=1e-5, rtol=0)


@torch.no_grad()
def test_truncate_shared_block_copies_tail_and_preserves_other_request() -> None:
    model = build_tiny_model()
    pool = pool_for(model, block_size=4)
    a = pool.request("m", "a", [1, 2, 3, 4])
    prefill(model, a, a.token_ids)
    b = pool.request("m", "b", [1, 2, 3, 4])
    old = a.get(0)[0].clone()
    b.truncate_to(2)
    assert a.table.block_ids[0] != b.table.block_ids[0]
    model(torch.tensor([[9]]), start_pos=2, kv_cache=b)
    torch.testing.assert_close(a.get(0)[0], old, atol=0, rtol=0)
    assert b.table.valid_tokens == [3]


def test_full_pool_can_recompute_last_token_of_exclusively_owned_hit() -> None:
    model = build_tiny_model()
    pool = pool_for(model, block_size=4, num_blocks=1)
    prompt = [1, 2, 3, 4]
    a = pool.request("m", "a", prompt)
    prefill(model, a, prompt)
    a.release()
    b = pool.request("m", "b", prompt)
    assert b.num_matched == 4 and pool.allocator.free_blocks == 0
    assert greedy_decode(model, prompt, 1, b).token_ids == greedy_decode(model, prompt, 1).token_ids


def test_shared_tail_truncate_capacity_failure_is_atomic() -> None:
    model = build_tiny_model()
    pool = pool_for(model, num_blocks=1)
    a = pool.request("m", "a", [1, 2])
    prefill(model, a, a.token_ids)
    b = pool.request("m", "b", [1, 2])
    with pytest.raises(CapacityError):
        b.truncate_to(1)
    assert b.num_tokens == 2 and b.table.block_ids == a.table.block_ids
    assert pool.prefix_cache.ref_counts[a.table.block_ids[0]] == 2


def test_shared_tail_truncate_can_reclaim_its_own_suffix_first() -> None:
    model = build_tiny_model()
    pool = pool_for(model, num_blocks=4)
    a = pool.request("m", "a", [1, 2, 3, 4])
    prefill(model, a, a.token_ids)
    b = pool.request("m", "b", [1, 2, 3, 4, 5, 6, 7, 8])
    prefill(model, b, b.token_ids)
    assert pool.allocator.free_blocks == 0
    b.truncate_to(3)
    assert b.num_tokens == 3
    assert b.table.block_ids[1] != a.table.block_ids[1]
    assert pool.allocator.free_blocks == 1
    assert a.get(0)[0].shape[2] == 4


@pytest.mark.parametrize("dtype", [torch.float32, torch.float64, torch.float16])
@pytest.mark.parametrize("dims", [(2, 2, 16, 4, 7), (3, 1, 8, 5, 3)])
def test_token_capacity_and_actual_tensor_bytes(dtype: torch.dtype, dims: tuple[int, ...]) -> None:
    layers, heads, dim, block_size, blocks = dims
    pool = PagedKVCache(blocks, (heads, block_size, dim), n_layers=layers, dtype=dtype)
    tensor = pool.allocator.storage
    capacity = blocks * block_size
    bytes_per_token = 2 * layers * heads * dim * tensor.element_size()
    assert pool.token_capacity == capacity
    assert pool.allocated_bytes == capacity * bytes_per_token == tensor.numel() * tensor.element_size()
    pool.allocator.allocate(1)
    assert pool.allocated_bytes == tensor.numel() * tensor.element_size()


def test_request_capacity_error_and_identity_checks() -> None:
    model = build_tiny_model()
    pool = pool_for(model, num_blocks=1)
    request = pool.request("m", "a", [1, 2, 3])
    with pytest.raises(ValueError, match="已登记"):
        pool.request("m", "a", [1])
    with pytest.raises(CapacityError):
        prefill(model, request, request.token_ids)
    assert request.get(0) == (None, None)
    assert pool.allocator.used_blocks == 0
    request.release("failed")
