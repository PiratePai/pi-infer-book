"""逐行量化的手算值、误差报告、整数存储与非法输入测试。"""

import pytest
import torch
from torch import nn

from pi_infer.quant import (
    QuantErrorReport, QuantReport, QuantizedTensor, fake_quantize, quantize_linear,
    quantize_tensor,
)


def test_symmetric_hand_calculated_round_even_and_outlier_scales() -> None:
    # 两行 scale 分别为 1 和 10；正负 .5 均向偶数取整。
    w = torch.tensor([[-127., -2.5, -1.5, 0.5, 1.5, 127.],
                      [-1270., -25., -15., 5., 15., 1270.]])
    qt = quantize_tensor(w, scheme="symmetric", axis=0)
    assert isinstance(qt, QuantizedTensor)
    assert qt.q_int8.dtype == torch.int8
    assert qt.zero_point.dtype == torch.int32
    assert qt.shape == (2, 6) and qt.dtype == torch.float32
    torch.testing.assert_close(qt.scale, torch.tensor([[1.], [10.]]), atol=0, rtol=0)
    assert torch.equal(qt.zero_point, torch.zeros(2, 1, dtype=torch.int32))
    expected_q = torch.tensor([[-127, -2, -2, 0, 2, 127]] * 2, dtype=torch.int8)
    assert torch.equal(qt.q_int8, expected_q)
    restored = fake_quantize(qt)
    torch.testing.assert_close(restored, expected_q.float() * qt.scale, atol=0, rtol=0)
    assert qt.report.max_abs == 5
    assert qt.report.mean_abs == pytest.approx(22 / 12)
    assert QuantReport is QuantErrorReport
    torch.testing.assert_close(qt.report.scale, torch.tensor([1., 10.]), atol=0, rtol=0)


def test_asymmetric_hand_calculated_zero_point_and_clamping() -> None:
    # 范围 [-2,3] -> scale=1/51，zero_point=-26；3 映射到 127 并截断。
    w = torch.tensor([[-2., -1., 0., 3.]], dtype=torch.float64)
    qt = quantize_tensor(w, scheme="asymmetric")
    torch.testing.assert_close(qt.scale, torch.tensor([[1 / 51]], dtype=w.dtype), atol=0, rtol=0)
    assert qt.zero_point.item() == -26
    assert torch.equal(qt.q_int8, torch.tensor([[-128, -77, -26, 127]], dtype=torch.int8))
    torch.testing.assert_close(fake_quantize(qt), w, atol=1e-15, rtol=0)


def test_asymmetric_round_even_precedes_zero_point_and_saturates() -> None:
    # scale=1、zero_point=-127（奇数）；先对缩放值取偶数，再加零点。
    qt = quantize_tensor(torch.tensor([[-1., -0.5, 0.5, 1., 254.]]), scheme="asymmetric")
    assert qt.scale.item() == 1 and qt.zero_point.item() == -127
    assert torch.equal(qt.q_int8, torch.tensor([[-128, -127, -127, -126, 127]], dtype=torch.int8))
    # [-1,1] -> scale=2/255、zero_point=0；+1 取整为 128，必须截断成 127。
    saturated = quantize_tensor(torch.tensor([[-1., 1.]], dtype=torch.float64), scheme="asymmetric")
    assert saturated.zero_point.item() == 0
    assert torch.equal(saturated.q_int8, torch.tensor([[-128, 127]], dtype=torch.int8))
    expected = torch.tensor([[-256 / 255, 254 / 255]], dtype=torch.float64)
    torch.testing.assert_close(fake_quantize(saturated), expected, atol=0, rtol=0)


@pytest.mark.parametrize("scheme", ["symmetric", "asymmetric"])
def test_zero_and_one_sided_constant_channels(scheme: str) -> None:
    w = torch.tensor([[0., 0.], [2., 2.], [-3., -3.]])
    qt = quantize_tensor(w, scheme=scheme)
    assert qt.scale[0].item() == 1
    assert (qt.scale > 0).all()
    # 实测零/常数行的 fp32 最大还原误差为 0。
    torch.testing.assert_close(fake_quantize(qt), w, atol=0, rtol=0)


@pytest.mark.parametrize("scheme", ["symmetric", "asymmetric"])
def test_fake_quantize_recorded_float_error_and_report(scheme: str) -> None:
    w = torch.tensor([[-1.2, -0.3, 0., 0.7, 1.8], [-12., -3., 0., 7., 18.]])
    qt = quantize_tensor(w, scheme=scheme)
    restored = fake_quantize(qt)
    # 该固定矩阵实测最大误差：对称 0.05511761，非对称 0.05882359；取 atol=0.06。
    torch.testing.assert_close(restored, w, atol=0.06, rtol=0)
    error = (restored - w).abs()
    assert qt.report.max_abs == error.max().item()
    assert qt.report.mean_abs == error.mean().item()
    assert qt.scale[1].item() == pytest.approx(10 * qt.scale[0].item())


@pytest.mark.parametrize("dtype", [torch.float16, torch.bfloat16, torch.float32, torch.float64])
def test_original_dtype_is_restored_without_aliasing(dtype: torch.dtype) -> None:
    w = torch.tensor([[-1., 0., 1.]], dtype=dtype)
    qt = quantize_tensor(w, scheme="symmetric")
    w.zero_()
    assert fake_quantize(qt).dtype == dtype
    torch.testing.assert_close(fake_quantize(qt), torch.tensor([[-1., 0., 1.]], dtype=dtype))


@pytest.mark.parametrize("scheme", ["symmetric", "asymmetric"])
@pytest.mark.parametrize("bias", [True, False])
def test_quantized_linear_stores_only_integer_weight_and_keeps_bias(scheme: str, bias: bool) -> None:
    module = nn.Linear(3, 2, bias=bias)
    with torch.no_grad():
        module.weight.copy_(torch.tensor([[-1.2, 0.3, 1.8], [-12., 3., 18.]]))
        if bias:
            module.bias.copy_(torch.tensor([0.25, -0.75]))
    before = module.weight.detach().clone()
    quantized = quantize_linear(module, scheme=scheme)
    x = torch.tensor([[[0.5, -1., 2.], [-0.2, 0.3, -0.1]]])
    # 固定输入实测最大输出误差：对称 0.00236249，非对称 0.05882263；取 atol=0.06。
    torch.testing.assert_close(quantized(x), module(x), atol=0.06, rtol=0)
    assert quantized.q_int8.dtype == torch.int8
    assert "weight" not in quantized.state_dict()
    assert not list(quantized.parameters())
    assert torch.equal(module.weight, before)
    assert isinstance(quantized.report, QuantErrorReport)
    if bias:
        assert torch.equal(quantized.bias, module.bias)
        assert quantized.bias.data_ptr() != module.bias.data_ptr()
    else:
        assert quantized.bias is None
    # 缓冲区可以经 state_dict 恢复，前向只反量化并使用原 bias。
    clone = quantize_linear(module, scheme=scheme)
    clone.load_state_dict(quantized.state_dict())
    torch.testing.assert_close(clone(x), quantized(x), atol=0, rtol=0)


@pytest.mark.parametrize("kwargs", [dict(scheme="bad"), dict(scheme="symmetric", axis=1),
                                        dict(scheme="symmetric", axis=-1), dict(scheme="symmetric", axis=True)])
def test_invalid_scheme_or_axis(kwargs: dict) -> None:
    with pytest.raises(ValueError):
        quantize_tensor(torch.ones(2, 3), **kwargs)


@pytest.mark.parametrize("w", [torch.ones(3), torch.ones(1, 2, 3), torch.empty(0, 3),
                                   torch.empty(2, 0), torch.ones(2, 3, dtype=torch.int64),
                                   torch.tensor([[float("nan")]]), torch.tensor([[float("inf")]]),
                                   torch.ones(2, 3, device="meta")])
def test_invalid_weight(w: torch.Tensor) -> None:
    with pytest.raises(ValueError):
        quantize_tensor(w, scheme="symmetric")


def test_invalid_object_types_and_forward_shapes() -> None:
    with pytest.raises(TypeError):
        quantize_tensor([[1.]], scheme="symmetric")
    with pytest.raises(TypeError):
        fake_quantize(torch.ones(1))
    with pytest.raises(TypeError):
        quantize_linear(nn.ReLU(), scheme="symmetric")
    layer = quantize_linear(nn.Linear(2, 3), scheme="symmetric")
    with pytest.raises(ValueError, match="in_features"):
        layer(torch.ones(1, 4))
    with pytest.raises(ValueError, match="dtype"):
        layer(torch.ones(1, 2, dtype=torch.float64))
    with pytest.raises(TypeError):
        layer([1., 2.])


def test_restoration_overflow_is_rejected() -> None:
    """回归（段末评审 P1-1）：fp16/fp32 极值权重反量化溢出必须显式报错，不得静默 Inf。"""
    fp16_edge = torch.tensor([[65504.0, -65504.0]], dtype=torch.float16)
    with pytest.raises(ValueError, match="溢出"):
        quantize_tensor(fp16_edge, scheme="asymmetric")
    fp32_edge = torch.tensor([[torch.finfo(torch.float32).max, -torch.finfo(torch.float32).max]])
    with pytest.raises(ValueError, match="溢出"):
        quantize_tensor(fp32_edge, scheme="symmetric")
