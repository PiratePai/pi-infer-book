"""贪心生成与逐步 argmax 参考的对照，以及 KV 统计边界。"""

import pytest
import torch

from pi_infer import GenerateResult, build_tiny_model, greedy_decode
from pi_infer.model import SimpleKVCache


@pytest.mark.parametrize("seed", [0, 7])
def test_cached_and_uncached_generation_return_identical_tokens(seed: int) -> None:
    model = build_tiny_model(seed=seed)
    prompt = [1, 11, 21, 31]
    uncached = greedy_decode(model, prompt, 6)
    cache = SimpleKVCache()
    cached = greedy_decode(model, prompt, 6, kv_cache=cache)
    assert isinstance(cached, GenerateResult)
    assert cached.token_ids == uncached.token_ids
    assert cached.steps == uncached.steps == 6
    assert prompt == [1, 11, 21, 31]
    assert cached.token_ids[:len(prompt)] == prompt
    for actual, expected in zip(cached.per_step_logits, uncached.per_step_logits, strict=True):
        assert actual.shape == (256,)
        assert not actual.requires_grad
        torch.testing.assert_close(actual, expected, atol=1e-5, rtol=0)
    # 最后一个生成 token 尚未参与下一次前向。
    assert cache.get(0)[0].shape[2] == len(cached.token_ids) - 1
    assert uncached.kv_stats == {"reads": 0, "writes": 0}


@pytest.mark.parametrize("use_cache", [False, True])
@torch.no_grad()
def test_generation_equals_stepwise_full_argmax_reference(use_cache: bool) -> None:
    model = build_tiny_model(seed=42)
    reference = [2, 4, 6]
    reference_logits = []
    for _ in range(5):
        logits = model(torch.tensor([reference]))[0, -1]
        reference_logits.append(logits)
        reference.append(int(torch.argmax(logits)))
    result = greedy_decode(model, [2, 4, 6], 5, SimpleKVCache() if use_cache else None)
    assert result.token_ids == reference
    assert result.steps == len(result.per_step_logits) == 5
    for actual, expected in zip(result.per_step_logits, reference_logits, strict=True):
        torch.testing.assert_close(actual, expected, atol=1e-5, rtol=0)


@pytest.mark.parametrize("use_cache", [False, True])
def test_generated_eos_is_included_and_stops_immediately(use_cache: bool) -> None:
    model = build_tiny_model()
    prompt = [3, 5, 7]
    eos_id = int(model(torch.tensor([prompt]))[0, -1].argmax())
    result = greedy_decode(model, prompt, 10, SimpleKVCache() if use_cache else None, eos_id)
    assert result.token_ids == prompt + [eos_id]
    assert result.steps == len(result.per_step_logits) == 1
    assert result.kv_stats == {"reads": 0, "writes": 2 * len(prompt) if use_cache else 0}


def test_eos_in_prompt_does_not_stop_generation() -> None:
    model = build_tiny_model()
    prompt = [1, 2, 3]
    result = greedy_decode(model, prompt, 1, eos_id=3)
    assert result.steps == 1
    assert len(result.token_ids) == 4


@pytest.mark.parametrize("limit", [0, 1, 4])
@pytest.mark.parametrize("use_cache", [False, True])
def test_max_new_tokens_bounds_generated_count(limit: int, use_cache: bool) -> None:
    result = greedy_decode(build_tiny_model(), [9, 10], limit, SimpleKVCache() if use_cache else None)
    assert result.steps == len(result.per_step_logits) == limit
    assert len(result.token_ids) == 2 + limit
    if limit == 0:
        assert result.kv_stats == {"reads": 0, "writes": 0}


def test_kv_stats_count_original_prompt_and_each_layer_history() -> None:
    model = build_tiny_model()
    prompt = [3, 3, 3, 3, 3]  # 重复 token 仍按原始位置计数，不做去重。
    prefill_only = greedy_decode(model, prompt, 1, SimpleKVCache())
    assert prefill_only.kv_stats == {"reads": 0, "writes": model.config.n_layers * len(prompt)}
    result = greedy_decode(model, prompt, 4, SimpleKVCache())
    # 第 2/3/4 步分别读 5/6/7 个历史位置，写入量为 prompt + 3。
    assert result.kv_stats == {"reads": 2 * (5 + 6 + 7), "writes": 2 * (5 + 3)}


def test_generation_uses_cache_protocol_without_concrete_cache_attributes() -> None:
    class ProtocolOnlyCache:
        """仅实现协议，验证生成不依赖连续缓存的内部字典。"""

        def __init__(self) -> None:
            self.storage = SimpleKVCache()

        def get(self, layer_idx: int) -> tuple[torch.Tensor | None, torch.Tensor | None]:
            return self.storage.get(layer_idx)

        def append(self, layer_idx: int, k: torch.Tensor, v: torch.Tensor) -> None:
            self.storage.append(layer_idx, k, v)

    model = build_tiny_model()
    result = greedy_decode(model, [1, 2], 3, ProtocolOnlyCache())
    reference = greedy_decode(model, [1, 2], 3)
    assert result.token_ids == reference.token_ids
    assert result.kv_stats == {"reads": 2 * (2 + 3), "writes": 2 * (2 + 2)}


def test_empty_prompt_and_negative_limit_are_rejected() -> None:
    model = build_tiny_model()
    with pytest.raises(ValueError, match="不能为空"):
        greedy_decode(model, [], 2)
    with pytest.raises(ValueError, match="非负整数"):
        greedy_decode(model, [1], -1)
