"""第 9 章教学调度器：真实逐请求贪心前向 + 单位成本离散事件模拟。

KV 使用简化 token 容量计数：容量为 kv_num_blocks * block_size，不取整到块。
入批预留 prompt + max_new_tokens - 1 个槽位，覆盖整个生命周期的最大 KV，
实际张量由每请求独立 SimpleKVCache 保存；不模拟分页、共享前缀或换出。
全部时间单位为秒；模拟 TTFT/TPOT/完成时刻不是服务或设备实测延迟。
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Literal

import torch

from .model import SimpleKVCache, TinyTransformer

Status = Literal["waiting", "running", "finished", "cancelled", "failed"]
TERMINAL = {"finished", "cancelled", "failed"}


def _positive_int(name: str, value: object) -> None:
    if type(value) is not int or value <= 0:
        raise ValueError(f"{name} 必须是正整数")


def _nonnegative_time(name: str, value: object) -> None:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
        raise ValueError(f"{name} 必须是有限非负秒数")


@dataclass
class Request:
    """单请求；prompt_ids 为非空 Python int 列表，output_ids 仅含生成 token。

    arrival_time 是服务端实际收到请求的模拟时刻，target_arrival_time 是原始
    目标到达时刻（缺省相同）；token_timestamps/queue_depth_samples 均为模拟时间。
    固定生成 max_new_tokens 个 token，无 EOS；零生成请求不做前向。
    """

    request_id: str
    arrival_time: float
    prompt_ids: list[int]
    max_new_tokens: int
    target_arrival_time: float | None = None
    status: Status = field(default="waiting", init=False)
    output_ids: list[int] = field(default_factory=list, init=False)
    token_timestamps: list[float] = field(default_factory=list, init=False)
    queue_depth_samples: list[dict] = field(default_factory=list, init=False)
    started_at: float | None = field(default=None, init=False)
    completed_at: float | None = field(default=None, init=False)
    error: str | None = field(default=None, init=False)
    _cache: SimpleKVCache | None = field(default=None, init=False, repr=False)
    _prefilled: int = field(default=0, init=False, repr=False)
    _reserved: int = field(default=0, init=False, repr=False)

    def __post_init__(self) -> None:
        if not isinstance(self.request_id, str) or not self.request_id:
            raise ValueError("request_id 必须是非空字符串")
        _nonnegative_time("arrival_time", self.arrival_time)
        if self.target_arrival_time is None:
            self.target_arrival_time = self.arrival_time
        _nonnegative_time("target_arrival_time", self.target_arrival_time)
        if self.target_arrival_time > self.arrival_time:
            raise ValueError("实际发出时刻不能早于目标到达时刻")
        if not isinstance(self.prompt_ids, list):
            raise TypeError("prompt_ids 必须是 list[int]")
        if not self.prompt_ids or any(type(t) is not int or t < 0 for t in self.prompt_ids):
            raise ValueError("prompt_ids 必须包含非负整数 token")
        if type(self.max_new_tokens) is not int or self.max_new_tokens < 0:
            raise ValueError("max_new_tokens 必须是非负整数")
        self.prompt_ids = list(self.prompt_ids)

    @property
    def token_ids(self) -> list[int]:
        """返回含 prompt 的完整 token 列表，口径与 greedy_decode.token_ids 一致。"""
        return self.prompt_ids + self.output_ids


@dataclass(frozen=True)
class SchedulerConfig:
    """构造期校验调度参数；max_batch 上限 8，禁止超出实测范围外推。

    token_budget 是每迭代所有前向输入 token 总数，decode 每请求计 1；
    chunked 的 chunk_size 是全迭代 prefill 总量上限。其余策略仅受总预算限制，
    超长 prompt 也可分多迭代完成。static 等满 max_batch 或最老请求等待
    max_wait_s 后开批，批内所有请求终止前不补槽；到达/取消只在迭代边界处理。
    """

    policy: Literal["static", "continuous", "chunked"] = "continuous"
    chunk_size: int = 32
    token_budget: int = 128
    kv_num_blocks: int = 256
    block_size: int = 16
    max_batch: int = 8
    max_wait_s: float = 0.005

    def __post_init__(self) -> None:
        if self.policy not in ("static", "continuous", "chunked"):
            raise ValueError("policy 必须是 static/continuous/chunked")
        for name in ("chunk_size", "token_budget", "kv_num_blocks", "block_size", "max_batch"):
            _positive_int(name, getattr(self, name))
        if self.max_batch > 8:
            raise ValueError("max_batch 不得超过实测上限 8")
        _nonnegative_time("max_wait_s", self.max_wait_s)


@dataclass(frozen=True)
class CostTable:
    """秒制实测单位成本：decode [B,1]、prefill [1,C]。

    必须提供完整 {1,2,4,8}/{8,16,32,64} 表且值为有限正数。未测尺寸向上
    取最近档（如 B=3 按 4、C=5 按 8），不插值/外推；prefill 超过 64
    拆为多个真实前向，分别查表。测试可注入人工成本，实验必须启动时实测。
    混合迭代按每块 prefill 成本之和 + 一次 decode batch 成本串行计费。
    """

    decode_s: dict[int, float]
    prefill_s: dict[int, float]

    def __post_init__(self) -> None:
        for name, keys in (("decode_s", {1, 2, 4, 8}), ("prefill_s", {8, 16, 32, 64})):
            table = getattr(self, name)
            if not isinstance(table, dict) or set(table) != keys or any(type(k) is not int for k in table):
                raise ValueError(f"{name} 必须恰好包含 {sorted(keys)}")
            for value in table.values():
                _nonnegative_time(name, value)
                if value == 0:
                    raise ValueError(f"{name} 成本必须大于零")
            object.__setattr__(self, name, dict(table))

    def decode_cost(self, batch: int) -> float:
        """返回 batch∈[1,8] 的向上取档模拟 decode 成本，非法范围报错。"""
        _positive_int("batch", batch)
        if batch > 8:
            raise ValueError("decode batch 不得超过 8")
        return self.decode_s[next(k for k in sorted(self.decode_s) if k >= batch)]

    def prefill_cost(self, chunk: int) -> float:
        """返回 chunk∈[1,64] 的向上取档模拟 prefill 成本，禁止外推。"""
        _positive_int("chunk", chunk)
        if chunk > 64:
            raise ValueError("prefill chunk 不得超过 64，须先拆段")
        return self.prefill_s[next(k for k in sorted(self.prefill_s) if k >= chunk)]


def _percentile(values: list[float], q: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    position = (len(ordered) - 1) * q
    left, right = math.floor(position), math.ceil(position)
    return ordered[left] + (ordered[right] - ordered[left]) * (position - left)


@dataclass
class Metrics:
    """全量状态账本；TTFT 从实际发出算，TPOT 为请求内首末 token 间平均间隔。

    分位数跨 finished 请求计算；零生成无 TTFT，少于两 token 无 TPOT。
    吞吐分子包含所有已输出 token（包括取消/失败前的输出），分母从最早实际
    到达至当前模拟时刻；结束原因及未结束数全列。所有延迟均为模拟量。
    """

    finished: int
    cancelled: int
    failed: int
    waiting: int
    running: int
    simulated_end_time: float
    throughput_tokens_per_sim_s: float
    simulated_ttft_s: list[float]
    simulated_tpot_s: list[float]
    completion_table: list[dict]
    static_stranded_slot_seconds: float

    def to_dict(self) -> dict:
        """返回 JSON 兼容字典；模拟 TTFT/TPOT/完成时刻以名称明确标记口径。"""
        return {
            "counts": {s: getattr(self, s) for s in ("finished", "cancelled", "failed", "waiting", "running")},
            "模拟完成时刻_s": self.simulated_end_time,
            "模拟吞吐_token/s": self.throughput_tokens_per_sim_s,
            "模拟 TTFT_s": {"p50": _percentile(self.simulated_ttft_s, .5),
                            "p99": _percentile(self.simulated_ttft_s, .99)},
            "模拟 TPOT_s": {"p50": _percentile(self.simulated_tpot_s, .5),
                            "p99": _percentile(self.simulated_tpot_s, .99)},
            "completion_table": self.completion_table,
            "static_stranded_slot_seconds": self.static_stranded_slot_seconds,
        }


class Scheduler:
    """以 eval TinyTransformer、SchedulerConfig、CostTable 构造的单引擎模拟器。

    模型可由 build_tiny_model(seed) 构造；每次实际前向输入 long [1,T]，
    输出 [1,T,V] 后取 argmax。正确性层逐请求串行执行，不以它的墙钟计费。
    时间层先 prefill、后 decode，二者串行相加；新到达只能下一边界加入。
    FIFO 入批，KV 不足保留 waiting；decode 优先，其余预算按 FIFO 分给 prefill。
    """

    def __init__(self, model: TinyTransformer, config: SchedulerConfig, costs: CostTable) -> None:
        if not isinstance(model, TinyTransformer):
            raise TypeError("model 必须是 TinyTransformer")
        if not isinstance(config, SchedulerConfig) or not isinstance(costs, CostTable):
            raise TypeError("config/costs 类型错误")
        self.model = model.eval()
        self.config, self.costs = config, costs
        self.now = 0.0
        self.requests: dict[str, Request] = {}
        self.iterations: list[dict] = []
        self.queue_depth_samples: list[dict] = []
        self.kv_used_tokens = 0
        self._static_batch: list[str] = []

    @property
    def kv_capacity_tokens(self) -> int:
        """逻辑 token 容量，无块尾取整、无分页张量池。"""
        return self.config.kv_num_blocks * self.config.block_size

    @property
    def done(self) -> bool:
        """全部已提交请求是否终止；尚未到达的已提交请求也计入。"""
        return all(r.status in TERMINAL for r in self.requests.values())

    def submit(self, request: Request) -> None:
        """提交全新请求，可预先提交未来到达；不可容纳的单请求显式报错。

        验证词表、模型位置容量和单请求 KV 需求；总并发 KV 不足通过排队处理。
        不接受过去到达的补交请求，避免追溯改变已执行的模拟时间线。
        """
        if not isinstance(request, Request):
            raise TypeError("request 必须是 Request")
        if request.request_id in self.requests or request.status != "waiting":
            raise ValueError("重复 request_id 或请求已被执行")
        if request.arrival_time < self.now:
            raise ValueError("arrival_time 不能早于当前模拟时刻")
        if max(request.prompt_ids) >= self.model.config.vocab_size:
            raise ValueError("prompt token 超出词表")
        needed = len(request.prompt_ids) + max(request.max_new_tokens - 1, 0)
        if needed > self.model.config.max_seq_len:
            raise ValueError("请求超出模型 max_seq_len")
        if request.max_new_tokens and needed > self.kv_capacity_tokens:
            raise ValueError("单请求 KV 需求超过总容量，永远无法入批")
        self.requests[request.request_id] = request
        self._sample_queue()

    def _waiting(self) -> list[Request]:
        return sorted((r for r in self.requests.values()
                       if r.status == "waiting" and r.arrival_time <= self.now),
                      key=lambda r: r.arrival_time)

    def _running(self) -> list[Request]:
        return [r for r in self.requests.values() if r.status == "running"]

    def _sample_queue(self) -> None:
        waiting = self._waiting()
        sample = {"模拟时刻_s": self.now, "waiting": len(waiting), "running": len(self._running()),
                  "kv_reserved_tokens": self.kv_used_tokens}
        self.queue_depth_samples.append(sample)
        for r in self.requests.values():
            if r.arrival_time <= self.now and r.status not in TERMINAL:
                r.queue_depth_samples.append(dict(sample))

    def _release(self, r: Request, reason: Status, error: str | None = None) -> None:
        if r.status in TERMINAL:
            raise ValueError("请求已经结束，不能重复 cancel/fail/release")
        self.kv_used_tokens -= r._reserved
        r._reserved = 0
        r._cache = None
        r.status, r.completed_at, r.error = reason, self.now, error

    def release(self, request_id: str, reason: str = "cancelled") -> None:
        """统一结束和回收路径；waiting/running 可取消或失败，重复操作报 ValueError。

        finished 只允许已生成全部 token 的请求；未知 id/reason 显式报错。
        """
        if request_id not in self.requests or reason not in TERMINAL:
            raise ValueError("未知 request_id 或结束原因")
        r = self.requests[request_id]
        if reason == "finished" and len(r.output_ids) != r.max_new_tokens:
            raise ValueError("请求尚未完成生成")
        self._release(r, reason)
        self._sample_queue()

    def cancel(self, request_id: str) -> None:
        """取消 waiting/running 请求并归还预留 KV；重复取消报 ValueError。"""
        self.release(request_id, "cancelled")

    def fail(self, request_id: str) -> None:
        """将 waiting/running 请求计为 failed，与取消使用同一回收路径。"""
        self.release(request_id, "failed")

    def _complete_zero_generation(self) -> None:
        """零生成请求独立完成，不参与静态批等待、容量与搁浅槽位记账。"""
        for r in self._waiting():
            if not r.max_new_tokens:
                r.started_at = self.now
                self._release(r, "finished")

    def _admit(self) -> None:
        self._complete_zero_generation()
        running = self._running()
        if self.config.policy == "static":
            if running:
                return
            self._static_batch = []
        for r in self._waiting():
            if len(self._running()) >= self.config.max_batch:
                break
            needed = len(r.prompt_ids) + r.max_new_tokens - 1 if r.max_new_tokens else 0
            if needed + self.kv_used_tokens > self.kv_capacity_tokens:
                break
            r.status, r.started_at = "running", self.now
            r._reserved, r._cache = needed, SimpleKVCache()
            self.kv_used_tokens += needed
            if self.config.policy == "static":
                self._static_batch.append(r.request_id)

    def _advance_idle(self) -> None:
        # 只在无活动请求时跳跃空闲时间；static 可在 deadline 前观察未来到达。
        while not self._running() and not self.done:
            self._complete_zero_generation()
            if self.done:
                return
            waiting = self._waiting()
            future = [r.arrival_time for r in self.requests.values()
                      if r.status == "waiting" and r.arrival_time > self.now]
            if not waiting:
                self.now = min(future)
                self._sample_queue()
                continue
            if self.config.policy != "static" or len(waiting) >= self.config.max_batch:
                break
            deadline = waiting[0].arrival_time + self.config.max_wait_s
            if self.now >= deadline:
                break
            self.now = min([deadline, *future])
            self._sample_queue()

    @torch.inference_mode()
    def _forward(self, r: Request, ids: list[int], start_pos: int, cost: float, emit: bool) -> None:
        # 失败的已调度操作仍计费，且部分写入的缓存整体丢弃并归还容量。
        self.now += cost
        try:
            inputs = torch.tensor([ids], dtype=torch.long, device=self.model.embedding.weight.device)
            logits = self.model(inputs, start_pos=start_pos, kv_cache=r._cache)[0, -1]
            if emit:
                r.output_ids.append(int(logits.argmax().item()))
                r.token_timestamps.append(self.now)
                if len(r.output_ids) == r.max_new_tokens:
                    self._release(r, "finished")
        except Exception as error:
            self._release(r, "failed", f"{type(error).__name__}: {error}")

    def iterate(self) -> dict | None:
        """执行一个模型迭代，返回组成/预算/模拟起止时刻；全结束返回 None。

        先确定全迭代计划，真实执行每个 prefill 块和每个选中的 decode 请求。
        decode B 个独立缓存前向仅计一次 [B,1] 单位成本；prefill 逐块计费。
        总预算过小时未选中的 running 请求保留状态，下步继续；无请求被丢弃。
        返回值只含模拟时间，不能解释为真实批处理的墙钟耗时。
        """
        if self.done:
            return None
        self._advance_idle()
        self._admit()
        self._sample_queue()
        active = self._running()
        if not active:  # 零生成请求可在入批时直接完成。
            return {"模拟起始时刻_s": self.now, "模拟完成时刻_s": self.now,
                    "decode_ids": [], "prefill_chunks": [], "input_tokens": 0,
                    "active_ids": [], "decode_cost_s": 0.0, "prefill_cost_s": 0.0,
                    "static_closed_slots": 0}
        start = self.now
        budget = self.config.token_budget
        decode = [r for r in active if r.output_ids][:budget]
        budget -= len(decode)
        prefill_budget = min(budget, self.config.chunk_size) if self.config.policy == "chunked" else budget
        prefills: list[tuple[Request, int]] = []
        for r in active:
            if r.output_ids:
                continue
            amount = min(len(r.prompt_ids) - r._prefilled, prefill_budget)
            if amount:
                prefills.append((r, amount))
                prefill_budget -= amount
        closed_slots = len(self._static_batch) - len(active) if self.config.policy == "static" else 0
        chunks = []
        for r, amount in prefills:
            remaining = amount
            while remaining and r.status == "running":
                size = min(remaining, 64)
                offset = r._prefilled
                cost = self.costs.prefill_cost(size)
                chunks.append({"request_id": r.request_id, "tokens": size, "cost_s": cost})
                self._forward(r, r.prompt_ids[offset:offset + size], offset, cost,
                              offset + size == len(r.prompt_ids))
                r._prefilled += size
                remaining -= size
        decode_cost = self.costs.decode_cost(len(decode)) if decode else 0.0
        # 所有 decode 请求共享本次 batch 的完成时刻；只有第一条推进模拟钟。
        for i, r in enumerate(decode):
            self._forward(r, r.output_ids[-1:], len(r.token_ids) - 1, decode_cost if i == 0 else 0.0, True)
        row = {"模拟起始时刻_s": start, "模拟完成时刻_s": self.now,
               "active_ids": [r.request_id for r in active],
               "decode_ids": [r.request_id for r in decode], "prefill_chunks": chunks,
               "input_tokens": len(decode) + sum(c["tokens"] for c in chunks),
               "prefill_cost_s": sum(c["cost_s"] for c in chunks), "decode_cost_s": decode_cost,
               "static_closed_slots": closed_slots}
        self.iterations.append(row)
        self._sample_queue()
        return row

    def run(self) -> Metrics:
        """排空所有已提交请求，返回包含所有结束原因的模拟 Metrics。"""
        while not self.done:
            self.iterate()
        return self.metrics()

    def metrics(self) -> Metrics:
        """返回当前快照；完成时刻表逐请求列目标到达/实际发出/模拟延迟及输出。"""
        counts = {s: 0 for s in ("waiting", "running", "finished", "cancelled", "failed")}
        ttfts, tpots, rows = [], [], []
        for r in self.requests.values():
            counts[r.status] += 1
            ttft = r.token_timestamps[0] - r.arrival_time if r.token_timestamps else None
            tpot = ((r.token_timestamps[-1] - r.token_timestamps[0]) / (len(r.output_ids) - 1)
                    if len(r.output_ids) > 1 else None)
            if r.status == "finished":
                if ttft is not None:
                    ttfts.append(ttft)
                if tpot is not None:
                    tpots.append(tpot)
            rows.append({"request_id": r.request_id, "status": r.status,
                         "target_arrival_time_s": r.target_arrival_time,
                         "actual_issue_time_s": r.arrival_time,
                         "模拟开始时刻_s": r.started_at, "模拟完成时刻_s": r.completed_at,
                         "模拟 TTFT_s": ttft, "模拟 TPOT_s": tpot,
                         "output_ids": list(r.output_ids), "token_timestamps_s": list(r.token_timestamps),
                         "queue_depth_samples": list(r.queue_depth_samples), "error": r.error})
        first_arrival = min((r.arrival_time for r in self.requests.values()), default=self.now)
        duration = self.now - first_arrival
        return Metrics(**counts, simulated_end_time=self.now,
                       throughput_tokens_per_sim_s=(sum(len(r.output_ids) for r in self.requests.values()) / duration
                                                    if duration > 0 else 0.0),
                       simulated_ttft_s=ttfts, simulated_tpot_s=tpots, completion_table=rows,
                       static_stranded_slot_seconds=sum(
                           row["static_closed_slots"] * (row["模拟完成时刻_s"] - row["模拟起始时刻_s"])
                           for row in self.iterations))
