"""整段草稿验证、精确投机采样以及拒绝后的 KV 修正。"""

from __future__ import annotations

from dataclasses import dataclass, field
import math
from typing import Callable

import torch
from torch import Tensor

from .generate import GenerateResult
from .model import KVCache, SimpleKVCache, TinyTransformer


@dataclass
class SamplingSpec:
    """调用方持有 RNG；p/q 必须使用完全相同的温度和 top-k 口径。"""

    temperature: float = 1.0
    top_k: int | None = None
    greedy: bool = False
    rng: torch.Generator = field(kw_only=True)

    def __post_init__(self) -> None:
        """提前拒绝无效采样参数。"""
        if not math.isfinite(self.temperature) or self.temperature <= 0:
            raise ValueError("temperature 必须为有限正数")
        if self.top_k is not None and (not isinstance(self.top_k, int) or self.top_k <= 0):
            raise ValueError("top_k 必须为正整数或 None")
        if not isinstance(self.rng, torch.Generator):
            raise TypeError("rng 必须由调用方创建的 torch.Generator 提供")


@dataclass
class DraftResult:
    """每个草稿 token 对应一份生成该 token 时的原始 [V] logits。"""

    tokens: list[int]
    draft_logits: list[Tensor]


@dataclass
class VerifyResult:
    """verify_logits[i] 是预测 draft.tokens[i] 的目标 logits，含已作废后缀。"""

    accepted_tokens: list[int]
    rejected_at: int | None
    corrected_token: int | None
    hit_eos: bool
    rollback_to: int
    verify_logits: list[Tensor]
    model_was_rolled_back: bool


def _distribution(logits: Tensor, spec: SamplingSpec) -> Tensor:
    """先缩放 logits、截断 top-k，再归一化；保留精确的零概率。"""
    if logits.ndim != 1 or not logits.numel():
        raise ValueError("logits 必须为非空 [V]")
    if torch.isnan(logits).any() or torch.isposinf(logits).any() or not torch.isfinite(logits).any():
        raise ValueError("logits 必须定义有效概率分布")
    scaled = logits.double() / spec.temperature
    if spec.top_k is not None and spec.top_k < scaled.numel():
        values, indices = torch.topk(scaled, spec.top_k)
        scaled = torch.full_like(scaled, -torch.inf).scatter(0, indices, values)
    return torch.softmax(scaled, dim=-1)


def sample_from_logits(logits: Tensor, spec: SamplingSpec) -> int:
    """贪心取 argmax，否则用调用方 RNG 按处理后的分布采样。"""
    if spec.greedy:
        return int(logits.argmax())
    return int(torch.multinomial(_distribution(logits, spec), 1, generator=spec.rng))


def _truncate_simple(cache: SimpleKVCache, length: int) -> None:
    """在本模块重建连续缓存，避免修改 SimpleKVCache 的协议。"""
    cache.k_cache = {layer: k[:, :, :length].clone() for layer, k in cache.k_cache.items()} if length else {}
    cache.v_cache = {layer: v[:, :, :length].clone() for layer, v in cache.v_cache.items()} if length else {}


def _commit(cache: KVCache, source: SimpleKVCache, ids: list[int]) -> None:
    """把已验证的最终 KV 提交给原对象，调用方无需替换缓存引用。"""
    if isinstance(cache, SimpleKVCache):
        cache.k_cache = {layer: k.clone() for layer, k in source.k_cache.items()}
        cache.v_cache = {layer: v.clone() for layer, v in source.v_cache.items()}
        return
    cache.truncate_to(0)
    record = getattr(cache, "record_tokens", None)
    if record is not None:
        record(ids, 0)
    for layer, k in source.k_cache.items():
        cache.append(layer, k, source.v_cache[layer])


@torch.no_grad()
def verify_and_accept(
    model: TinyTransformer,
    prompt_ids: list[int],
    draft: DraftResult,
    kv_cache: KVCache,
    sampling: SamplingSpec,
    eos_id: int | None = None,
) -> VerifyResult:
    """一次全量因果前向验证整段草稿，拒绝后截断并前向修正 token。

    采用契约允许的全量重算路径，传入缓存可以为空或已有 prompt。
    SimpleKVCache 在函数内重建；其他实现须额外提供 truncate_to(length)。
    仅 append/get 无法删除历史，因此对不能截断的实现提前报错。
    采样正确性要求草稿 token 确实来自 draft_logits 对应的 q 分布。
    """
    if not prompt_ids or not draft.tokens:
        raise ValueError("prompt_ids 与 draft.tokens 不能为空")
    if len(draft.tokens) != len(draft.draft_logits):
        raise ValueError("draft tokens/logits 长度必须一致")
    if not isinstance(kv_cache, SimpleKVCache) and not callable(getattr(kv_cache, "truncate_to", None)):
        raise TypeError("缓存须为 SimpleKVCache 或提供 truncate_to")
    device = model.embedding.weight.device
    all_ids = list(prompt_ids) + list(draft.tokens)
    temporary = SimpleKVCache()
    logits = model(torch.tensor([all_ids], dtype=torch.long, device=device), kv_cache=temporary)[0]
    verify_logits = [row.detach().clone() for row in logits[len(prompt_ids) - 1:len(all_ids) - 1]]
    if any(q.shape != p.shape for p, q in zip(verify_logits, draft.draft_logits, strict=True)):
        raise ValueError("草稿 logits 必须与目标词表形状一致")
    accepted: list[int] = []
    rejected_at = None
    corrected = None
    hit_eos = False
    for i, token in enumerate(draft.tokens):
        p_logits = verify_logits[i]
        if not 0 <= token < p_logits.numel():
            raise ValueError("草稿 token 超出词表")
        if sampling.greedy:
            candidate = int(p_logits.argmax())
            accept = token == candidate
        else:
            p = _distribution(p_logits, sampling)
            q = _distribution(draft.draft_logits[i].to(device), sampling)
            if q[token] <= 0:
                raise ValueError("草稿 token 在 q 中概率必须为正")
            ratio = torch.minimum(torch.ones_like(p[token]), p[token] / q[token])
            accept = bool(torch.rand((), device=device, generator=sampling.rng) < ratio)
            candidate = None
        if accept:
            accepted.append(token)
            if token == eos_id:
                hit_eos = True
                break
        else:
            rejected_at = i
            if sampling.greedy:
                corrected = candidate
            else:
                residual = (p - q).clamp_min(0)
                corrected = int(torch.multinomial(residual / residual.sum(), 1, generator=sampling.rng))
            hit_eos = corrected == eos_id
            break
    prefix_ids = list(prompt_ids) + accepted
    _truncate_simple(temporary, len(prefix_ids))
    if corrected is not None:
        model(torch.tensor([[corrected]], dtype=torch.long, device=device), start_pos=len(prefix_ids), kv_cache=temporary)
        prefix_ids.append(corrected)
    _commit(kv_cache, temporary, prefix_ids)
    return VerifyResult(
        accepted, rejected_at, corrected, hit_eos, len(prefix_ids), verify_logits,
        rejected_at is not None or len(accepted) < len(draft.tokens),
    )


@torch.no_grad()
def speculative_generate(
    model: TinyTransformer,
    draft_fn: Callable[[TinyTransformer, list[int], int], DraftResult],
    prompt_ids: list[int],
    max_tokens: int,
    sampling: SamplingSpec,
    eos_id: int | None = None,
    max_draft_len: int = 4,
) -> GenerateResult:
    """循环提议与验证；返回含 prompt 的 GenerateResult，全接受时不额外抽 token。"""
    if not prompt_ids:
        raise ValueError("prompt_ids 不能为空")
    if not isinstance(max_tokens, int) or max_tokens < 0:
        raise ValueError("max_tokens 必须为非负整数")
    if not isinstance(max_draft_len, int) or max_draft_len <= 0:
        raise ValueError("max_draft_len 必须为正整数")
    current = list(prompt_ids)
    history: list[Tensor] = []
    cache = SimpleKVCache()
    stats = {"reads": 0, "writes": 0}
    while len(history) < max_tokens:
        n = min(max_draft_len, max_tokens - len(history))
        draft = draft_fn(model, list(current), n)
        if not draft.tokens or len(draft.tokens) > n:
            raise ValueError("draft_fn 必须返回 1..n 个草稿 token")
        result = verify_and_accept(model, current, draft, cache, sampling, eos_id)
        layers = model.config.n_layers
        stats["writes"] += layers * (len(current) + len(draft.tokens))
        if result.corrected_token is not None:
            stats["reads"] += layers * (len(current) + len(result.accepted_tokens))
            stats["writes"] += layers
        count = len(result.accepted_tokens) + int(result.corrected_token is not None)
        history.extend(result.verify_logits[:count])
        current.extend(result.accepted_tokens)
        if result.corrected_token is not None:
            current.append(result.corrected_token)
        if result.hit_eos:
            break
    return GenerateResult(current, history, len(history), stats)
