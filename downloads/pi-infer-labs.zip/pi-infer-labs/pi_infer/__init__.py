"""Pi-Infer：用于逐步理解大模型推理的合成小模型。"""

from .generate import GenerateResult, greedy_decode
from .model import TinyConfig, TinyTransformer, build_tiny_model

__all__ = [
    "build_tiny_model",
    "TinyConfig",
    "TinyTransformer",
    "greedy_decode",
    "GenerateResult",
]

from .kv import (
    BlockAllocator, BlockTable, CapacityError, DoubleFreeError, Hit,
    PagedKVCache, PagedRequestCache, PrefixCache,
)
from .speculative import (
    DraftResult, SamplingSpec, VerifyResult, sample_from_logits,
    speculative_generate, verify_and_accept,
)

__all__ += [
    "BlockAllocator", "BlockTable", "CapacityError", "DoubleFreeError", "Hit",
    "PagedKVCache", "PagedRequestCache", "PrefixCache",
    "DraftResult", "SamplingSpec", "VerifyResult", "sample_from_logits",
    "speculative_generate", "verify_and_accept",
]
