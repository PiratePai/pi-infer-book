"""第 10 章小张量进程验证：Windows spawn、gloo CPU 与应用层发送载荷账。

ByteLog 不测链路流量：不含协议、padding、集合算法内部重复收发及校验元数据。
所有 rank 必须按相同顺序调用集合原语；点对点两端须约定相同 shape。
"""

from __future__ import annotations

import math
import os
import pickle
import queue
import socket
import statistics
import time
from collections.abc import Callable, Iterable, Mapping
from dataclasses import dataclass
from datetime import timedelta

import torch
import torch.distributed as dist
import torch.multiprocessing as mp
from torch import Tensor, nn

from .model import build_tiny_model


@dataclass(frozen=True)
class ByteLog:
    """单次调用的发送账；numel 是发送元素数，recv/非源 broadcast 为零。

    src/dst 为 rank 或 'all'；bytes 恒等于 numel×element_size，rank 为本进程。
    集合输入只计一次，绝不乘内部跳数；接收缓冲区不重复计入发送账。
    """

    op: str
    src: int | str
    dst: int | str
    numel: int
    element_size: int
    bytes: int
    rank: int

    def __post_init__(self) -> None:
        if not isinstance(self.op, str) or not self.op:
            raise ValueError("op 必须是非空字符串")
        for name in ("numel", "bytes", "rank"):
            if type(getattr(self, name)) is not int or getattr(self, name) < 0:
                raise ValueError(f"{name} 必须是非负整数")
        if type(self.element_size) is not int or self.element_size <= 0:
            raise ValueError("element_size 必须是正整数")
        for endpoint in (self.src, self.dst):
            if endpoint != "all" and (type(endpoint) is not int or endpoint < 0):
                raise ValueError("src/dst 必须是非负 rank 或 'all'")
        if self.bytes != self.numel * self.element_size:
            raise ValueError("bytes 必须等于 numel×element_size")


def aggregate_bytes(logs: Iterable[ByteLog]) -> dict:
    """聚合单个或多个操作的发送账，返回 per_rank 与 total_bytes=Σrank。"""
    per_rank: dict[int, int] = {}
    for log in logs:
        if not isinstance(log, ByteLog):
            raise TypeError("logs 只能包含 ByteLog")
        per_rank[log.rank] = per_rank.get(log.rank, 0) + log.bytes
    return {"per_rank": dict(sorted(per_rank.items())), "total_bytes": sum(per_rank.values())}


_WORKLOADS: dict[str, Callable] = {}


def register_workload(fn: Callable) -> Callable:
    """注册可 pickle 的顶层 fn(world_size)，原函数不包装；返回值按 rank 回主进程。

    spawn_workers 可接收该函数或注册名称；自定义函数必须定义在可导入模块顶层。
    """
    if not callable(fn):
        raise TypeError("工作负载必须可调用")
    if "<locals>" in getattr(fn, "__qualname__", "<locals>") or getattr(fn, "__name__", "<lambda>") == "<lambda>":
        raise ValueError("工作负载必须是可 pickle 的顶层函数")
    _WORKLOADS[fn.__name__] = fn
    return fn


def _positive_int(name: str, value: int) -> None:
    if type(value) is not int or value <= 0:
        raise ValueError(f"{name} 必须是正整数")


def _worker(rank: int, world: int, port: int, fn: Callable, results) -> None:
    os.environ.update(MASTER_ADDR="127.0.0.1", MASTER_PORT=str(port),
                      RANK=str(rank), WORLD_SIZE=str(world))
    torch.set_num_threads(1)
    try:
        dist.init_process_group("gloo", init_method="env://", timeout=timedelta(seconds=30))
        # 序列化为值，避免返回 Tensor 的共享存储依赖已经退出的子进程。
        results.put((rank, pickle.dumps(fn(world), protocol=pickle.HIGHEST_PROTOCOL)))
    finally:
        if dist.is_initialized():
            dist.destroy_process_group()


def spawn_workers(entry_fn: Callable | str, world_size: int, *, deadline: float | None = 300.) -> list:
    """spawn gloo CPU 进程，调用各 rank 的 entry_fn(world_size)，返回按 rank 排序的值。

    返回值须可 pickle；使用 env://，端口先以 socket 绑定 0 探测，再传给子进程。
    探测与 rendezvous 间存在通常的端口竞争窗口，冲突会显式失败。成功/异常均 join
    并清理子进程；父进程不修改环境变量。脚本调用须位于 __main__ 入口保护内。
    deadline 为父进程总等待秒数（默认 300，None 禁用），超时终止子进程并抛
    TimeoutError；不替代进程组自己的通信超时。
    """
    _positive_int("world_size", world_size)
    if deadline is not None and (isinstance(deadline, bool) or not isinstance(deadline, (int, float))
                                 or not math.isfinite(deadline) or deadline <= 0):
        raise ValueError("deadline 必须为有限正秒数或 None")
    expires = None if deadline is None else time.monotonic() + deadline

    def remaining() -> float:
        if expires is None:
            return 0.05
        seconds = expires - time.monotonic()
        if seconds <= 0:
            raise TimeoutError("spawn_workers 父进程总等待超时")
        return min(0.05, seconds)

    if isinstance(entry_fn, str):
        if entry_fn not in _WORKLOADS:
            raise ValueError(f"未注册工作负载: {entry_fn}")
        entry_fn = _WORKLOADS[entry_fn]
    if not callable(entry_fn):
        raise TypeError("entry_fn 必须可调用或为注册名称")
    if ("<locals>" in getattr(entry_fn, "__qualname__", "<locals>")
            or getattr(entry_fn, "__name__", "<lambda>") == "<lambda>"):
        raise ValueError("entry_fn 必须是可 pickle 的顶层函数")
    if not dist.is_available() or not dist.is_gloo_available():
        raise RuntimeError("需要可用的 gloo 后端")
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        probe.bind(("127.0.0.1", 0))
        port = probe.getsockname()[1]
    results = mp.get_context("spawn").Queue()
    context = None
    received = {}
    try:
        context = mp.spawn(_worker, args=(world_size, port, entry_fn, results),
                           nprocs=world_size, join=False)
        # 边读返回值边 join，避免大返回值填满管道后子进程无法退出。
        finished = False
        while not finished:
            try:
                rank, payload = results.get(timeout=remaining())
                received[rank] = pickle.loads(payload)
            except queue.Empty:
                pass
            finished = context.join(timeout=remaining())
        while len(received) < world_size:
            try:
                rank, payload = results.get(timeout=remaining())
            except queue.Empty:
                continue
            received[rank] = pickle.loads(payload)
        return [received[rank] for rank in range(world_size)]
    finally:
        if context is not None:
            for process in context.processes:
                if process.is_alive():
                    process.terminate()
            for process in context.processes:
                process.join(timeout=5.)
                if process.is_alive():
                    process.kill()
                    process.join(timeout=5.)
        results.close()
        results.join_thread()


def run_world(workload: Callable | str, world_size: int) -> list:
    """计划文档接口：等价于 spawn_workers，返回按 rank 排序的工作负载结果。"""
    return spawn_workers(workload, world_size)


def _group() -> tuple[int, int]:
    if not dist.is_initialized():
        raise RuntimeError("调用通信原语前必须初始化进程组")
    if dist.get_backend() != "gloo":
        raise ValueError("仅支持 gloo CPU")
    return dist.get_rank(), dist.get_world_size()


def _tensor_error(tensor: Tensor) -> str | None:
    if not isinstance(tensor, Tensor):
        return "输入必须是 Tensor"
    if tensor.device.type != "cpu" or tensor.dtype != torch.float32:
        return "输入必须是 CPU float32"
    if tensor.ndim != 1 or tensor.numel() == 0 or not tensor.is_contiguous():
        return "输入必须是非空连续 [N] 张量"
    return None


def _collective(tensor: Tensor, op: str, option=None) -> tuple[int, int]:
    rank, world = _group()
    error = _tensor_error(tensor)
    if option is not None and type(option) is not int:
        error = "集合参数必须为 int，不能是 bool 或其他类型"
    metadata = [None] * world
    dist.all_gather_object(metadata, (error, None if error else tensor.numel(), op, type(option), option))
    if any(item[0] is not None for item in metadata):
        raise ValueError(f"集合输入错误: {metadata}")
    if any(item != metadata[0] for item in metadata):
        raise ValueError("各 rank 的 shape/op/参数必须相同")
    return rank, world


def _peer(peer: int, rank: int, world: int) -> None:
    if type(peer) is not int or not 0 <= peer < world or peer == rank:
        raise ValueError("点对点 peer 必须是组内另一 rank")


def _log(op: str, tensor: Tensor, rank: int, src, dst, *, sends: bool = True) -> ByteLog:
    numel = tensor.numel() if sends else 0
    size = tensor.element_size()
    return ByteLog(op, src, dst, numel, size, numel * size, rank)


def p2p_send(tensor: Tensor, dst: int) -> ByteLog:
    """阻塞发送非空连续 CPU float32 [N] 给 dst；返回 N×4 字节发送账。"""
    rank, world = _group()
    if error := _tensor_error(tensor):
        raise ValueError(error)
    _peer(dst, rank, world)
    dist.send(tensor, dst=dst)
    return _log("p2p", tensor, rank, rank, dst)


def p2p_recv(tensor: Tensor, src: int) -> ByteLog:
    """阻塞接收到 CPU float32 [N] 缓冲区（原地）；返回零发送字节账。"""
    rank, world = _group()
    if error := _tensor_error(tensor):
        raise ValueError(error)
    _peer(src, rank, world)
    dist.recv(tensor, src=src)
    return _log("p2p", tensor, rank, src, rank, sends=False)


def broadcast(tensor: Tensor, src: int = 0) -> tuple[Tensor, ByteLog]:
    """将 src 的 CPU float32 [N] 原地广播；仅源 rank 记 N×4 字节一次。"""
    rank, world = _collective(tensor, "broadcast", src)
    if type(src) is not int or not 0 <= src < world:
        raise ValueError("src 必须是组内 rank")
    dist.broadcast(tensor, src=src)
    return tensor, _log("broadcast", tensor, rank, src, "all", sends=rank == src)


def all_reduce(tensor: Tensor) -> tuple[Tensor, ByteLog]:
    """CPU float32 [N] 原地 SUM，返回 [N] 与每 rank 输入 N×4 字节账。"""
    rank, _ = _collective(tensor, "all_reduce")
    dist.all_reduce(tensor, op=dist.ReduceOp.SUM)
    return tensor, _log("all_reduce", tensor, rank, "all", "all")


def reduce_scatter(tensor: Tensor) -> tuple[Tensor, ByteLog]:
    """各 rank 输入 CPU float32 [N]，SUM 后返回第 rank 块 [N/P]。

    N 必须被 P 整除，各 rank shape 相同；输入不变，每 rank 记 N×4 字节。
    使用 gloo 的 reduce_scatter_tensor，不以 all_reduce 模拟。
    """
    rank, world = _collective(tensor, "reduce_scatter")
    if tensor.numel() % world:
        raise ValueError("reduce_scatter 输入 N 必须被 world 整除")
    output = torch.empty(tensor.numel() // world, dtype=tensor.dtype)
    dist.reduce_scatter_tensor(output, tensor, op=dist.ReduceOp.SUM)
    return output, _log("reduce_scatter", tensor, rank, "all", "all")


def all_gather(tensor: Tensor, *, total_numel: int | None = None) -> tuple[Tensor, ByteLog]:
    """各 rank 输入等长 CPU float32 分片 [K]，按 rank 拼接输出 [N=P*K]。

    total_numel 可指定预期完整 N，须被 P 整除且 N/P=K；省略时推导 N。
    分片 K 本身无须被 P 整除。每 rank 只记本地分片 K×4 字节。
    """
    rank, world = _collective(tensor, "all_gather", total_numel)
    if total_numel is not None:
        _positive_int("total_numel", total_numel)
        if total_numel % world:
            raise ValueError("all_gather 的 total_numel 必须被 world 整除")
        if total_numel // world != tensor.numel():
            raise ValueError("all_gather 分片 shape 与 total_numel 不匹配")
    pieces = [torch.empty_like(tensor) for _ in range(world)]
    dist.all_gather(pieces, tensor)
    return torch.cat(pieces), _log("all_gather", tensor, rank, "all", "all")


def _world(world: int, *, two: bool = False) -> int:
    _positive_int("world", world)
    rank, actual = _group()
    if world != actual or world < 2 or (two and world != 2):
        raise ValueError("world 必须与进程组一致，且本工作负载要求 world>=2（TP/PP=2）")
    return rank


def _comparison(actual: Tensor, expected: Tensor, log: ByteLog) -> tuple[bool, ByteLog, float]:
    delta = float((actual - expected).abs().max())
    return bool(torch.allclose(actual, expected, atol=1e-6, rtol=1e-6)), log, delta


@register_workload
def verify_primitives(world: int) -> dict[str, tuple[bool, ByteLog, float]]:
    """rank 工作负载：确定性 float32 [8*P] 验证五原语，返回 op→(PASS,账,max|Δ|)。

    用 spawn_workers(verify_primitives, P) 在主进程取得逐 rank 结果；p2p 为环传递。
    参考由 arange 与 rank 手算，SUM 的期望为 P*arange+P(P−1)/2。
    """
    rank = _world(world)
    base = torch.arange(8 * world, dtype=torch.float32)
    own = base + rank
    # 环形 send/recv 按边串行，避免阻塞 send 形成循环等待。
    received = torch.empty_like(own)
    send_log = None
    for src in range(world):
        dst = (src + 1) % world
        if rank == src:
            send_log = p2p_send(own, dst)
        elif rank == dst:
            p2p_recv(received, src)
    result = {"p2p": _comparison(received, base + (rank - 1) % world, send_log)}
    out, log = broadcast(own.clone())
    result["broadcast"] = _comparison(out, base, log)
    expected_sum = base * world + world * (world - 1) / 2
    out, log = all_reduce(own.clone())
    result["all_reduce"] = _comparison(out, expected_sum, log)
    out, log = reduce_scatter(own)
    result["reduce_scatter"] = _comparison(out, expected_sum.chunk(world)[rank], log)
    out, log = all_gather(own.chunk(world)[rank].contiguous(), total_numel=base.numel())
    expected = torch.cat([base.chunk(world)[peer] + peer for peer in range(world)])
    result["all_gather"] = _comparison(out, expected, log)
    return result


@register_workload
@torch.inference_mode()
def tp2_matmul(world: int = 2) -> tuple[bool, ByteLog, float]:
    """TP2：X[1,2,16]，Linear(16,16) 按输出维分权重；结果对照完整 Linear。

    半权重计算局部 8 列，嵌入零填充的 [1,2,16] 再 SUM，载荷每 rank 32 float。
    输出维切分通常用 all_gather；此处按教学任务用零填充+all_reduce 展示等价组合。
    """
    rank = _world(world, two=True)
    torch.manual_seed(10)
    linear = nn.Linear(16, 16, bias=False).eval()
    x = torch.randn(1, 2, 16)
    weight = linear.weight.chunk(2, dim=0)[rank].clone()
    local = x @ weight.T
    padded = torch.zeros(1, 2, 16)
    padded[..., rank * 8:(rank + 1) * 8] = local
    out, log = all_reduce(padded.flatten())
    return _comparison(out.view(1, 2, 16), linear(x), log)


@register_workload
@torch.inference_mode()
def pp2_tiny_forward(world: int = 2) -> tuple[bool, ByteLog, float]:
    """PP2：rank0 embedding+layer0，发送 [1,4,64]；rank1 layer1+norm+head。

    展平 float32 hidden 经 send/recv；logits[1,4,256] 对照完整 tiny(seed=10)。
    rank1 将 PASS/误差诊断广播给 rank0，此控制元数据不计入 hidden 载荷账。
    """
    rank = _world(world, two=True)
    model = build_tiny_model(seed=10).eval()
    tokens = torch.tensor([[1, 7, 11, 13]])
    expected = model(tokens)
    if rank == 0:
        hidden = model.layers[0](model.embedding(tokens), 0, 0, None, (None, None))
        log = p2p_send(hidden.flatten().contiguous(), 1)
        diagnostic = torch.zeros(2, dtype=torch.float64)
    else:
        hidden = torch.empty(1, 4, 64)
        log = p2p_recv(hidden.flatten(), 0)
        hidden = model.layers[1](hidden, 0, 1, None, (None, None))
        passed, _, delta = _comparison(model.lm_head(model.norm(hidden)), expected, log)
        diagnostic = torch.tensor([float(passed), delta], dtype=torch.float64)
    dist.broadcast(diagnostic, src=1)
    return bool(diagnostic[0]), log, float(diagnostic[1])


def time_op(fn: Callable | Mapping[str, Callable], repeats: int = 5, warmup: int = 2) -> dict:
    """gloo CPU 同机相对计时；设备性能未测，不用于 NCCL/GPU 性能推断。

    fn 为无参阻塞函数，或有序 name→函数映射；映射按轮交错各 op（各 rank 顺序须一致）。
    至少预热 2 轮、采样 5 轮；返回 mean_s/std_s（样本 n−1）/samples；映射返回逐 op 表。
    调用方应提前构造输入、启动进程；fn 内部的 shape 校验和分配均计时，不主动插入 barrier。
    """
    for name, value, minimum in (("repeats", repeats, 5), ("warmup", warmup, 2)):
        if type(value) is not int or value < minimum:
            raise ValueError(f"{name} 必须是 >= {minimum} 的整数")
    single = callable(fn)
    cases = {"op": fn} if single else fn
    if not isinstance(cases, Mapping) or not cases or not all(callable(f) for f in cases.values()):
        raise TypeError("fn 必须是无参函数或非空 name→函数映射")
    for _ in range(warmup):
        for operation in cases.values():
            operation()
    samples = {name: [] for name in cases}
    for _ in range(repeats):
        for name, operation in cases.items():
            start = time.perf_counter()
            operation()
            samples[name].append(time.perf_counter() - start)
    rows = {name: {"mean_s": statistics.mean(values), "std_s": statistics.stdev(values),
                   "samples": values} for name, values in samples.items()}
    return rows["op"] if single else rows
