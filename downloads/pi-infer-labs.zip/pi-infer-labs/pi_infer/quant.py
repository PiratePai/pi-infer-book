"""逐输出通道的 int8 教学量化器；前向反量化，不依赖整数计算内核。"""

from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import Tensor, nn
from torch.nn import functional as F


@dataclass
class QuantErrorReport:
    """权重反量化的 max/mean 绝对误差，以及 CPU 浮点 [Out] scale 表。"""

    max_abs: float
    mean_abs: float
    scale: Tensor


# 计划表中的名称；两者表示同一种报告。
QuantReport = QuantErrorReport


@dataclass
class QuantizedTensor:
    """CPU 量化快照：int8 [Out,In]、浮点/int32 [Out,1] scale/zero_point。

    shape/dtype 保存原始元数据，report 保存误差；不保留浮点权重副本。
    """

    q_int8: Tensor
    scale: Tensor
    zero_point: Tensor
    shape: tuple[int, int]
    dtype: torch.dtype
    report: QuantErrorReport


@torch.no_grad()
def quantize_tensor(w: Tensor, *, scheme: str, axis: int = 0) -> QuantizedTensor:
    """量化 CPU 非空有限浮点 [Out,In]，仅支持 axis=0（每行独立统计）。

    scheme 为 'symmetric'（[-127,127]，scale=max(abs(w))/127）或
    'asymmetric'（[-128,127]，统计范围包含 0，scale=(max-min)/255）。
    零通道取 scale=1；q=clamp(round(w/scale)+zero_point)，round 为 nearest-even，
    零点也取整截断。
    fp16/bf16/fp32 用 fp32 scale，fp64 用 fp64；返回快照及其 report。
    """
    if not isinstance(w, Tensor):
        raise TypeError("w 必须是 Tensor")
    if scheme not in ("symmetric", "asymmetric"):
        raise ValueError("scheme 必须是 'symmetric' 或 'asymmetric'")
    if type(axis) is not int or axis != 0:
        raise ValueError("axis 仅支持 0（逐输出通道）")
    if w.ndim != 2 or w.numel() == 0:
        raise ValueError("w 必须是非空二维 [Out,In] 张量")
    if w.device.type != "cpu" or not w.is_floating_point():
        raise ValueError("w 必须是 CPU 浮点张量")
    if not torch.isfinite(w).all():
        raise ValueError("w 必须仅包含有限值")
    work = w.detach().to(torch.float64 if w.dtype == torch.float64 else torch.float32)
    if scheme == "symmetric":
        scale = work.abs().amax(dim=1, keepdim=True) / 127
        zero_point = torch.zeros_like(scale, dtype=torch.int32)
        qmin = -127
    else:
        lo = work.amin(dim=1, keepdim=True).clamp(max=0)
        hi = work.amax(dim=1, keepdim=True).clamp(min=0)
        scale = (hi - lo) / 255
        scale = torch.where(scale == 0, torch.ones_like(scale), scale)
        zero_point = (-128 - lo / scale).round().clamp(-128, 127).to(torch.int32)
        qmin = -128
    scale = torch.where(scale == 0, torch.ones_like(scale), scale)
    if not torch.isfinite(scale).all() or not (scale > 0).all():
        raise ValueError("w 的动态范围无法用有限正 scale 表示")
    q = ((work / scale).round() + zero_point).clamp(qmin, 127).to(torch.int8)
    restored = ((q.to(scale.dtype) - zero_point) * scale).to(w.dtype)
    if not torch.isfinite(restored).all():
        # 反量化在原 dtype 下溢出（如 fp16 极值通道 (q-zp)*scale 超 fp16 上限）。
        raise ValueError("还原值在原 dtype 下溢出；该权重的动态范围超出本量化器可表示范围")
    error = (restored.to(work.dtype) - work).abs()
    report = QuantErrorReport(error.max().item(), error.mean().item(), scale[:, 0].clone())
    return QuantizedTensor(q, scale, zero_point, tuple(w.shape), w.dtype, report)


def fake_quantize(qt: QuantizedTensor) -> Tensor:
    """将量化快照还原为原 shape/dtype 的 CPU Tensor；误差报告见 qt.report。

    输入由 quantize_tensor 生成；计算 (q_int8-zero_point)*scale，不保留梯度。
    """
    if not isinstance(qt, QuantizedTensor):
        raise TypeError("qt 必须是 QuantizedTensor")
    return ((qt.q_int8.to(qt.scale.dtype) - qt.zero_point) * qt.scale).to(qt.dtype).reshape(qt.shape)


class QuantizedLinear(nn.Module):
    """int8 权重和未量化 bias 的 CPU Linear；report 为量化时的权重误差。"""

    def __init__(self, module: nn.Linear, *, scheme: str) -> None:
        super().__init__()
        if not isinstance(module, nn.Linear):
            raise TypeError("module 必须是 nn.Linear")
        qt = quantize_tensor(module.weight, scheme=scheme, axis=0)
        self.in_features = module.in_features
        self.out_features = module.out_features
        self.original_dtype = qt.dtype
        self.report = qt.report
        self.register_buffer("q_int8", qt.q_int8)
        self.register_buffer("scale", qt.scale)
        self.register_buffer("zero_point", qt.zero_point)
        self.register_buffer("bias", None if module.bias is None else module.bias.detach().clone())

    def forward(self, x: Tensor) -> Tensor:
        """CPU 浮点 [...,In] -> [...,Out]，dtype 与原权重一致；推理时反量化。"""
        if not isinstance(x, Tensor):
            raise TypeError("x 必须是 Tensor")
        if x.ndim == 0 or x.shape[-1] != self.in_features:
            raise ValueError("x 的最后一维必须等于 in_features")
        if x.device.type != "cpu" or x.dtype != self.original_dtype:
            raise ValueError("x 必须是 CPU 张量且 dtype 与原权重一致")
        weight = ((self.q_int8.to(self.scale.dtype) - self.zero_point) * self.scale).to(x.dtype)
        return F.linear(x, weight, self.bias)


def quantize_linear(module: nn.Linear, *, scheme: str) -> QuantizedLinear:
    """CPU 浮点 nn.Linear -> int8 存储的 QuantizedLinear，报告在返回值.report。

    权重 [Out,In] 按输出行量化，bias [Out] 原 dtype 原值复制，不修改源模块。
    forward 接受同 dtype 的 CPU [...,In] 并返回 [...,Out]。
    """
    return QuantizedLinear(module, scheme=scheme)
