"""可在 CPU 上逐行阅读的 decoder-only Transformer，无 QK-Norm。"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Protocol

import torch
from torch import Tensor, nn
from torch.nn import functional as F


@dataclass
class TinyConfig:
    """小模型配置；默认值对应 tiny preset，head_dim 必须为偶数。"""

    vocab_size: int = 256
    d_model: int = 64
    n_heads: int = 4
    n_kv_heads: int = 2
    n_layers: int = 2
    d_ff: int = 176
    max_seq_len: int = 128
    rope_theta: float = 10000.0
    rms_norm_eps: float = 1e-6
    seed: int = 0

    def __post_init__(self) -> None:
        """提前检查维度，避免到 reshape 或广播时才报错。"""
        for name in (
            "vocab_size", "d_model", "n_heads", "n_kv_heads", "n_layers",
            "d_ff", "max_seq_len",
        ):
            value = getattr(self, name)
            if not isinstance(value, int) or value <= 0:
                raise ValueError(f"{name} 必须是正整数")
        if self.d_model % self.n_heads:
            raise ValueError("d_model 必须能被 n_heads 整除")
        if self.n_heads % self.n_kv_heads:
            raise ValueError("n_heads 必须能被 n_kv_heads 整除")
        if (self.d_model // self.n_heads) % 2:
            raise ValueError("RoPE 要求 head_dim 为偶数")
        if not math.isfinite(self.rope_theta) or self.rope_theta <= 0:
            raise ValueError("rope_theta 必须为有限正数")
        if not math.isfinite(self.rms_norm_eps) or self.rms_norm_eps <= 0:
            raise ValueError("rms_norm_eps 必须为有限正数")


class KVCache(Protocol):
    """整段 KV 读写协议；空层返回 (None, None)，非空为 [B,Hkv,T,D]。"""

    def append(self, layer_idx: int, k: Tensor, v: Tensor) -> None:
        """在指定层的序列维追加一段 KV。"""
        ...

    def get(self, layer_idx: int) -> tuple[Tensor | None, Tensor | None]:
        """读取指定层的全部历史 KV；不包含尚未追加的新 token。"""
        ...


class SimpleKVCache:
    """教学用连续缓存：每层独立存储 K/V，追加时沿序列维拼接。"""

    def __init__(self) -> None:
        self.k_cache: dict[int, Tensor] = {}
        self.v_cache: dict[int, Tensor] = {}

    def append(self, layer_idx: int, k: Tensor, v: Tensor) -> None:
        """写入未 repeat 的 KV，存储维度始终为 [B,Hkv,T,D]。"""
        if k.ndim != 4 or k.shape != v.shape:
            raise ValueError("K/V 必须具有相同的 [B,Hkv,T,D] 形状")
        old_k, old_v = self.get(layer_idx)
        if old_k is None:
            self.k_cache[layer_idx], self.v_cache[layer_idx] = k, v
        else:
            self.k_cache[layer_idx] = torch.cat((old_k, k), dim=2)
            self.v_cache[layer_idx] = torch.cat((old_v, v), dim=2)

    def get(self, layer_idx: int) -> tuple[Tensor | None, Tensor | None]:
        """返回整段 KV；第一次写入前返回 (None, None)。"""
        return self.k_cache.get(layer_idx), self.v_cache.get(layer_idx)


class RMSNorm(nn.Module):
    """只按均方根缩放的归一化，含可学习的缩放参数，不含 bias。"""

    def __init__(self, d_model: int, eps: float) -> None:
        super().__init__()
        self.weight = nn.Parameter(torch.ones(d_model))
        self.eps = eps

    def forward(self, x: Tensor) -> Tensor:
        """低精度输入时用 float32 累加平方，输出恢复输入精度。"""
        work = x.float() if x.dtype in (torch.float16, torch.bfloat16) else x
        normalized = work * torch.rsqrt(work.square().mean(dim=-1, keepdim=True) + self.eps)
        return normalized.to(x.dtype) * self.weight


class RotaryEmbedding(nn.Module):
    """预计算 RoPE 表；相邻两个通道组成一对，在绝对位置上旋转。"""

    def __init__(self, head_dim: int, max_seq_len: int, theta: float) -> None:
        super().__init__()
        inv_freq = theta ** (-torch.arange(0, head_dim, 2, dtype=torch.float32) / head_dim)
        angles = torch.outer(torch.arange(max_seq_len, dtype=torch.float32), inv_freq)
        self.register_buffer("cos", angles.cos(), persistent=False)
        self.register_buffer("sin", angles.sin(), persistent=False)

    def forward(self, x: Tensor, start_pos: int = 0) -> Tensor:
        """旋转 [B,H,T,D]，位置为 start_pos 到 start_pos+T-1。"""
        end_pos = start_pos + x.shape[-2]
        if start_pos < 0 or end_pos > self.cos.shape[0]:
            raise ValueError("RoPE 位置超出预计算范围")
        cos = self.cos[start_pos:end_pos].to(x.dtype)
        sin = self.sin[start_pos:end_pos].to(x.dtype)
        even, odd = x[..., 0::2], x[..., 1::2]
        return torch.stack((even * cos - odd * sin, even * sin + odd * cos), dim=-1).flatten(-2)


def causal_attention(
    q: Tensor, k: Tensor, v: Tensor, start_pos: int = 0, key_start_pos: int = 0,
) -> Tensor:
    """显式实现 GQA、缩放点积、绝对位置因果 mask 和减 max 的 softmax。

    Q 为 [B,Hq,Tq,D]，K/V 为 [B,Hkv,Tk,D]；同组 query head
    共享一个 KV head。位置偏移使多 token 增量也不能看到未来 token。
    """
    repeats = q.shape[1] // k.shape[1]
    k = k.repeat_interleave(repeats, dim=1)
    v = v.repeat_interleave(repeats, dim=1)
    scores = (q @ k.transpose(-2, -1)) / math.sqrt(q.shape[-1])
    query_pos = torch.arange(start_pos, start_pos + q.shape[-2], device=q.device)
    key_pos = torch.arange(key_start_pos, key_start_pos + k.shape[-2], device=q.device)
    scores = scores.masked_fill(key_pos[None, :] > query_pos[:, None], -torch.inf)
    scores = scores - scores.amax(dim=-1, keepdim=True)
    weights = scores.exp()
    weights = weights / weights.sum(dim=-1, keepdim=True)
    return weights @ v


class CausalSelfAttention(nn.Module):
    """无 bias 的 Q/K/V/O 投影；KV 在缓存中保持较少的 head 数。"""

    def __init__(self, config: TinyConfig) -> None:
        super().__init__()
        self.n_heads = config.n_heads
        self.n_kv_heads = config.n_kv_heads
        self.head_dim = config.d_model // config.n_heads
        self.q_proj = nn.Linear(config.d_model, config.d_model, bias=False)
        self.k_proj = nn.Linear(config.d_model, config.n_kv_heads * self.head_dim, bias=False)
        self.v_proj = nn.Linear(config.d_model, config.n_kv_heads * self.head_dim, bias=False)
        self.o_proj = nn.Linear(config.d_model, config.d_model, bias=False)
        self.rope = RotaryEmbedding(self.head_dim, config.max_seq_len, config.rope_theta)

    def forward(
        self, x: Tensor, start_pos: int, layer_idx: int, kv_cache: KVCache | None,
        past_kv: tuple[Tensor | None, Tensor | None],
    ) -> Tensor:
        """历史 K 已旋转；只对新 Q/K 应用当前绝对位置的 RoPE。"""
        batch, length, _ = x.shape
        q = self.q_proj(x).view(batch, length, self.n_heads, self.head_dim).transpose(1, 2)
        k = self.k_proj(x).view(batch, length, self.n_kv_heads, self.head_dim).transpose(1, 2)
        v = self.v_proj(x).view(batch, length, self.n_kv_heads, self.head_dim).transpose(1, 2)
        q, k = self.rope(q, start_pos), self.rope(k, start_pos)
        if kv_cache is not None:
            kv_cache.append(layer_idx, k, v)
        past_k, past_v = past_kv
        if past_k is not None:
            k, v = torch.cat((past_k, k), dim=2), torch.cat((past_v, v), dim=2)
        key_start = 0 if kv_cache is not None else start_pos
        attended = causal_attention(q, k, v, start_pos, key_start)
        return self.o_proj(attended.transpose(1, 2).contiguous().view(batch, length, -1))


class SwiGLU(nn.Module):
    """前馈网络：down(silu(gate(x)) * up(x))。"""

    def __init__(self, config: TinyConfig) -> None:
        super().__init__()
        self.gate_proj = nn.Linear(config.d_model, config.d_ff, bias=False)
        self.up_proj = nn.Linear(config.d_model, config.d_ff, bias=False)
        self.down_proj = nn.Linear(config.d_ff, config.d_model, bias=False)

    def forward(self, x: Tensor) -> Tensor:
        """门控分支与上投影分支逐元素相乘，再投影回模型维度。"""
        return self.down_proj(F.silu(self.gate_proj(x)) * self.up_proj(x))


class DecoderBlock(nn.Module):
    """两次 pre-norm 和残差连接组成一个标准 decoder block。"""

    def __init__(self, config: TinyConfig) -> None:
        super().__init__()
        self.attn_norm = RMSNorm(config.d_model, config.rms_norm_eps)
        self.attention = CausalSelfAttention(config)
        self.ffn_norm = RMSNorm(config.d_model, config.rms_norm_eps)
        self.ffn = SwiGLU(config)

    def forward(
        self, x: Tensor, start_pos: int, layer_idx: int, kv_cache: KVCache | None,
        past_kv: tuple[Tensor | None, Tensor | None],
    ) -> Tensor:
        """先做注意力残差，再做 SwiGLU 残差。"""
        x = x + self.attention(self.attn_norm(x), start_pos, layer_idx, kv_cache, past_kv)
        return x + self.ffn(self.ffn_norm(x))


class TinyTransformer(nn.Module):
    """合成 decoder-only 模型；embedding 与 lm_head 使用独立权重。"""

    def __init__(self, config: TinyConfig) -> None:
        super().__init__()
        self.config = config
        self.embedding = nn.Embedding(config.vocab_size, config.d_model)
        self.layers = nn.ModuleList(DecoderBlock(config) for _ in range(config.n_layers))
        self.norm = RMSNorm(config.d_model, config.rms_norm_eps)
        self.lm_head = nn.Linear(config.d_model, config.vocab_size, bias=False)

    def forward(
        self, token_ids: Tensor, start_pos: int = 0, kv_cache: KVCache | None = None,
    ) -> Tensor:
        """输入 [B,T]，输出 [B,T,V]，不在此处选择下一个 token。

        无缓存时重算整段输入，start_pos 仅指定它的绝对位置。
        有缓存时，每层必须恰好保存 [0:start_pos] 的 KV，再追加本段。
        在修改任何层前检查全部历史形状，以便位置错误时不污染缓存。
        """
        if token_ids.ndim != 2 or token_ids.shape[0] == 0 or token_ids.shape[1] == 0:
            raise ValueError("token_ids 必须是非空的 [B,T] 张量")
        if token_ids.dtype not in (torch.int32, torch.int64):
            raise ValueError("token_ids 必须是 int32 或 int64")
        if not isinstance(start_pos, int) or start_pos < 0:
            raise ValueError("start_pos 必须是非负整数")
        if start_pos + token_ids.shape[1] > self.config.max_seq_len:
            raise ValueError("输入位置超出 max_seq_len")
        past: list[tuple[Tensor | None, Tensor | None]] = []
        for layer_idx in range(self.config.n_layers):
            k, v = (None, None) if kv_cache is None else kv_cache.get(layer_idx)
            if kv_cache is not None:
                expected = (
                    token_ids.shape[0], self.config.n_kv_heads, start_pos,
                    self.config.d_model // self.config.n_heads,
                )
                if (k is None) != (v is None):
                    raise ValueError("缓存中的 K/V 必须同时存在")
                if k is None:
                    if start_pos != 0:
                        raise ValueError("缓存历史长度必须等于 start_pos")
                elif tuple(k.shape) != expected or tuple(v.shape) != expected:
                    raise ValueError("缓存形状或历史长度与 start_pos 不匹配")
            past.append((k, v))
        record_tokens = getattr(kv_cache, "record_tokens", None)
        if record_tokens is not None:
            if token_ids.shape[0] != 1:
                raise ValueError("前缀缓存仅支持 batch=1")
            record_tokens(token_ids[0].tolist(), start_pos)
        x = self.embedding(token_ids)
        for layer_idx, layer in enumerate(self.layers):
            x = layer(x, start_pos, layer_idx, kv_cache, past[layer_idx])
        return self.lm_head(self.norm(x))


def build_tiny_model(seed: int = 0, preset: str = "tiny") -> TinyTransformer:
    """固定种子后按 embedding、各层、lm_head 顺序使用 PyTorch 默认初始化。"""
    if preset != "tiny":
        raise ValueError(f"未知 preset: {preset!r}，目前仅支持 'tiny'")
    torch.manual_seed(seed)
    return TinyTransformer(TinyConfig(seed=seed))
