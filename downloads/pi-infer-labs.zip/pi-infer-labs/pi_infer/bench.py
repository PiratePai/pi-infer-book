"""统一的完整解码计时入口；batch 表示顺序请求数，不是张量批大小。"""

from __future__ import annotations

import argparse
import json
import platform
import statistics
import time
from collections.abc import Callable
from pathlib import Path

import torch
from torch import nn

from .generate import greedy_decode
from .model import SimpleKVCache, TinyConfig, TinyTransformer


def sync_device(device: torch.device | str | None = None) -> None:
    """读表前同步 CUDA；CPU 上为空操作，保留相同计时调用点。

    device 为 None 时同步当前设备；自定义 decode_fn 在其他 GPU 上异步执行时，
    应传入该设备（段末评审 P2-2），否则计时可能在队列完成前结束。
    """
    if torch.cuda.is_available():
        torch.cuda.synchronize(torch.device(device) if device is not None else None)


def _positive_int(name: str, value: object) -> None:
    if type(value) is not int or value <= 0:
        raise ValueError(f"{name} 必须是正整数")


def _decode(model: nn.Module, prompt_ids: list[int], new_tokens: int) -> object:
    """每次请求新建缓存；默认支持 tiny 接口的 CPU/CUDA 浮点模型。"""
    return greedy_decode(model, prompt_ids, new_tokens, SimpleKVCache())


@torch.inference_mode()
def sweep(
    model_builder: Callable[[], nn.Module],
    *,
    variable: str,
    values: list,
    decode_fn=None,
    warmup: int = 2,
    repeats: int = 5,
    **fixed,
) -> list[dict]:
    """扫描 input_len/new_tokens/batch，返回秒制 {value, mean_s, std_s, samples}。

    每点调用无参 builder 新建 nn.Module 并设为 eval，构造不计时；builder
    应返回独立模型，位置容量须覆盖输入与生成长度。默认参数
    input_len=32、new_tokens=16、batch=1，均为正整数。
    prompt 为 Python int 列表 [7]*input_len。自定义 decode_fn 的契约为
    decode_fn(model, prompt_ids, new_tokens)，负责一次完整请求并隔离缓存等状态；
    返回值不参与统计，可支持任意模型设备/dtype。batch 次调用顺序执行。
    每点至少预热两次，至少重复五次；按轮交错各点，样本标准差用 n-1。
    计时包含全部请求与末尾设备同步，排除 prompt 构造；非法参数显式报错。
    """
    if not callable(model_builder):
        raise TypeError("model_builder 必须可调用")
    if decode_fn is not None and not callable(decode_fn):
        raise TypeError("decode_fn 必须可调用或为 None")
    names = {"input_len", "new_tokens", "batch"}
    if not isinstance(variable, str) or variable not in names:
        raise ValueError("variable 必须是 input_len、new_tokens 或 batch")
    if not isinstance(values, list):
        raise TypeError("values 必须是 list")
    if not values:
        raise ValueError("values 不能为空")
    if set(fixed) - names or variable in fixed:
        raise ValueError("fixed 仅接受未被扫描的 input_len、new_tokens、batch")
    for name, value, minimum in (("warmup", warmup, 2), ("repeats", repeats, 5)):
        if type(value) is not int or value < minimum:
            raise ValueError(f"{name} 必须是 >= {minimum} 的整数")
    configs = []
    for value in values:
        config = {"input_len": 32, "new_tokens": 16, "batch": 1, **fixed, variable: value}
        for name, number in config.items():
            _positive_int(name, number)
        configs.append(config)

    models = []
    for _ in values:
        model = model_builder()
        if not isinstance(model, nn.Module):
            raise TypeError("model_builder 必须返回 nn.Module")
        if any(model is previous for previous in models):
            raise ValueError("model_builder 必须为每个扫描点返回新模型")
        models.append(model.eval())
    decode = _decode if decode_fn is None else decode_fn

    def measure(index: int) -> float:
        config = configs[index]
        prompt = [7] * config["input_len"]
        sync_device()
        start = time.perf_counter()
        for _ in range(config["batch"]):
            decode(models[index], prompt, config["new_tokens"])
        sync_device()
        return time.perf_counter() - start

    for _ in range(warmup):
        for index in range(len(values)):
            measure(index)
    samples: list[list[float]] = [[] for _ in values]
    for _ in range(repeats):
        for index in range(len(values)):
            samples[index].append(measure(index))
    return [
        {"value": value, "mean_s": statistics.mean(times),
         "std_s": statistics.stdev(times), "samples": times}
        for value, times in zip(values, samples)
    ]


def main() -> None:
    """tiny CLI；扩展 RoPE 容量以覆盖扫描点，打印表格并保存原始样本。"""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--variable", choices=("input_len", "new_tokens", "batch"), required=True)
    parser.add_argument("--values", required=True, help="逗号分隔的正整数，例如 8,32,128")
    parser.add_argument("--input-len", type=int, default=32)
    parser.add_argument("--new-tokens", type=int, default=16)
    parser.add_argument("--batch", type=int, default=1)
    parser.add_argument("--warmup", type=int, default=2)
    parser.add_argument("--repeats", type=int, default=5)
    parser.add_argument("--output", type=Path, default=Path("bench_raw.json"))
    args = parser.parse_args()
    try:
        values = [int(value.strip()) for value in args.values.split(",")]
        fixed = {"input_len": args.input_len, "new_tokens": args.new_tokens, "batch": args.batch}
        fixed.pop(args.variable)
        max_input = max(values) if args.variable == "input_len" else args.input_len
        max_new = max(values) if args.variable == "new_tokens" else args.new_tokens

        def builder() -> nn.Module:
            torch.manual_seed(0)
            return TinyTransformer(TinyConfig(max_seq_len=max(128, max_input + max_new)))

        rows = sweep(builder, variable=args.variable, values=values, warmup=args.warmup,
                     repeats=args.repeats, **fixed)
    except (ValueError, TypeError) as error:
        parser.error(str(error))
    record = {"env": {"python": platform.python_version(), "torch": torch.__version__,
                      "device": "cpu", "threads": torch.get_num_threads(), "seed": 0,
                      "warmup": args.warmup, "repeats": args.repeats,
                      "timing_method": "perf_counter + 两端 sync_device；按轮交错重复"},
              "variable": args.variable, "fixed": fixed,
              "generation_spec": {"prompt": "[7]*input_len", "decode": "greedy",
                                  "stop": "固定 new_tokens，无 EOS", "batch": "顺序请求数"},
              "rows": rows}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"{args.variable:>12}  {'mean_ms':>12}  {'std_ms':>12}")
    for row in rows:
        print(f"{row['value']:12d}  {row['mean_s'] * 1000:12.3f}  {row['std_s'] * 1000:12.3f}")
    print(f"原始样本：{args.output}")


if __name__ == "__main__":
    main()
