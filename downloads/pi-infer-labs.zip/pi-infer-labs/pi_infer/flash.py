"""显式 S/P 与 online softmax 对照；逐次登记中间张量存活字节。"""

from __future__ import annotations

import math
from dataclasses import dataclass

import torch
from torch import Tensor

from .sparse import _positive_int, _pv_into, _qk_into, _validate_attention


@dataclass
class FlashStats:
    """内部同时存活张量峰值及近似写入字节数（均为整数 byte）。

    peak_bytes 不含输入/最终输出、view、参数校验、PyTorch 算子内部工作区；包含所有显式
    分配的 scores、概率、running 与临时向量/累加矩阵。不构建 autograd 图。
    hbm_writes_approx 为每个内部张量首次物化字节加最终输出字节；不累计原地
    重写或 CPU cache 行流量，是教学账本而非硬件 HBM 测量。
    """

    peak_bytes: int
    hbm_writes_approx: int


class _LiveTensors:
    """登记显式分配/最后使用后的释放；不持有 Tensor 引用。"""

    def __init__(self) -> None:
        self.current = 0
        self.peak = 0
        self.writes = 0

    def add(self, tensor: Tensor) -> Tensor:
        size = tensor.numel() * tensor.element_size()
        self.current += size
        self.writes += size
        self.peak = max(self.peak, self.current)
        return tensor

    def release(self, tensor: Tensor) -> None:
        self.current -= tensor.numel() * tensor.element_size()

    def finish(self, out: Tensor) -> FlashStats:
        assert self.current == 0
        return FlashStats(self.peak, self.writes + out.numel() * out.element_size())


def _validate(q: Tensor, k: Tensor, v: Tensor, causal: bool) -> None:
    _validate_attention(q, k, v)
    if type(causal) is not bool:
        raise TypeError("causal 必须是 bool")


def _validate_accumulator_range(k: Tensor, v: Tensor) -> None:
    """online 累加器的溢出防护（段末评审 P1-2）。

    未归一化累加满足 |Õ| ≤ ℓ·max|v| ≤ Tk·max|v|（每个 e^{s-m} ≤ 1），
    该上界超出 dtype 最大值时先除分母已无法救回；显式拒绝。
    参考实现先归一化再乘 V，输出是 V 行的凸组合，无此约束。
    """
    bound = k.shape[-2] * float(v.abs().amax())
    if bound > torch.finfo(v.dtype).max:
        raise ValueError("V 幅值×键长会溢出未归一化累加器；请缩放输入或使用参考实现")


def _causal_fill(scores: Tensor, query_start: int, key_start: int) -> None:
    """用 view 原地填充未来位置，不额外分配 mask/位置张量。"""
    for row in range(scores.shape[-2]):
        first_future = max(0, query_start + row + 1 - key_start)
        scores[..., row, first_future:].fill_(-torch.inf)


def _merge_block(
    scores: Tensor, value: Tensor, maximum: Tensor, denominator: Tensor,
    accumulator: Tensor, live: _LiveTensors,
) -> None:
    """原地合并一个非空可见块，更新 running (m,l,O)，scores 的存活由调用者管理。"""
    block_max = live.add(scores.amax(dim=-1, keepdim=True))
    scores.sub_(block_max).exp_()
    # alpha 保存旧 m，更新后成为 exp(m_old-m_new)。
    alpha = live.add(maximum.clone())
    torch.maximum(maximum, block_max, out=maximum)
    alpha.sub_(maximum).exp_()
    denominator.mul_(alpha)
    accumulator.mul_(alpha)
    live.release(alpha)
    del alpha
    # beta=exp(m_block-m_new)，将块内 exp 转到合并后的基准。
    block_max.sub_(maximum).exp_()
    scores.mul_(block_max)
    live.release(block_max)
    del block_max
    block_sum = live.add(scores.sum(dim=-1, keepdim=True))
    denominator.add_(block_sum)
    live.release(block_sum)
    del block_sum
    contribution = live.add(torch.empty_like(accumulator))
    _pv_into(scores, value, contribution)
    accumulator.add_(contribution)
    live.release(contribution)
    del contribution


@torch.no_grad()
def flash_attention_reference(
    q: Tensor, k: Tensor, v: Tensor, *, causal: bool = True,
) -> tuple[Tensor, FlashStats]:
    """fp32 CPU q [B,Hq,Tq,D]、k/v [B,Hkv,Tk,D] -> (同形 out, FlashStats)。

    Hq 必须能被 Hkv 整除，连续 query 组共享 KV；仅推理。先显式分配完整 S=QK/sqrt(D)
    和 P=softmax(S)，再 PV；causal 采用从 0 开始的 j<=i（不隐式右对齐）。
    支持非空矩形序列；内存口径见 FlashStats，包含行 max/denom，GQA 不物化 repeat。
    """
    _validate(q, k, v, causal)
    live = _LiveTensors()
    scores = live.add(torch.empty((*q.shape[:3], k.shape[-2]), dtype=q.dtype))
    _qk_into(q, k, scores)
    scores.div_(math.sqrt(q.shape[-1]))
    if causal:
        _causal_fill(scores, 0, 0)
    maximum = live.add(scores.amax(dim=-1, keepdim=True))
    probabilities = live.add(torch.empty_like(scores))
    torch.sub(scores, maximum, out=probabilities)
    probabilities.exp_()
    live.release(maximum)
    del maximum
    live.release(scores)
    del scores
    denominator = live.add(probabilities.sum(dim=-1, keepdim=True))
    probabilities.div_(denominator)
    live.release(denominator)
    del denominator
    out = torch.empty_like(q)
    _pv_into(probabilities, v, out)
    live.release(probabilities)
    del probabilities
    return out, live.finish(out)


@torch.no_grad()
def online_softmax_attention(
    q: Tensor, k: Tensor, v: Tensor, *, block_size: int, causal: bool = True,
) -> tuple[Tensor, FlashStats]:
    """fp32 CPU GQA 输入同 reference，返回 (同形 out, FlashStats)，仅推理。

    Q/KV 均按正整数 block_size 分块，允许尾块；causal 时只访问 j<=i 的 key 块，
    对角块再按绝对位置遮罩。局部 exp 以块 max 为基准，再缩放合并 running
    (m,l,O)。固定 block_size 时额外存储与序列长度无关；不保存完整 S/P 或 KV repeat。
    输入约束：V 幅值×键序列长度不得超出 dtype 最大值（未归一化累加器会溢出，
    见 _validate_accumulator_range；参考实现无此约束）。
    """
    _validate(q, k, v, causal)
    _validate_accumulator_range(k, v)
    _positive_int(block_size, "block_size")
    live = _LiveTensors()
    out = torch.empty_like(q)
    for query_start in range(0, q.shape[-2], block_size):
        query = q[:, :, query_start:query_start + block_size]
        vector_shape = (*query.shape[:3], 1)
        maximum = live.add(torch.full(vector_shape, -torch.inf, dtype=q.dtype))
        denominator = live.add(torch.zeros(vector_shape, dtype=q.dtype))
        accumulator = live.add(torch.zeros_like(query))
        key_end = min(k.shape[-2], query_start + block_size) if causal else k.shape[-2]
        for key_start in range(0, key_end, block_size):
            key = k[:, :, key_start:key_start + block_size]
            value = v[:, :, key_start:key_start + block_size]
            scores = live.add(torch.empty((*query.shape[:3], key.shape[-2]), dtype=q.dtype))
            _qk_into(query, key, scores)
            scores.div_(math.sqrt(q.shape[-1]))
            if causal and key_start == query_start:
                _causal_fill(scores, query_start, key_start)
            _merge_block(scores, value, maximum, denominator, accumulator, live)
            live.release(scores)
            del scores
        accumulator.div_(denominator)
        out[:, :, query_start:query_start + block_size].copy_(accumulator)
        live.release(maximum)
        live.release(denominator)
        live.release(accumulator)
        del maximum, denominator, accumulator
    return out, live.finish(out)
