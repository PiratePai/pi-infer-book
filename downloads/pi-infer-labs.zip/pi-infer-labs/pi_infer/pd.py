"""第 11 章 Dense 状态交接：prepare/data/ack/commit-release 四阶段协议。

仅支持 CPU、batch=1、逐层 [1,Hkv,T,D] 浮点 KV；token_ids 是 Python int
列表，在线路上使用 int64。KV 恰好覆盖 token_ids[:-1]，最后一个 token
尚未前向。Ack 前 P 持有所有权；D 暂存副本，Commit 后才能执行解码。
超时不会回滚已收 Data：同 epoch 重试只重发 Ack。这里只实现单 P/单 D，
不提供进程崩溃后的持久恢复或不可信来源的 pickle 反序列化。
"""

from __future__ import annotations

import math
import pickle
import queue
import threading
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass

import torch
import torch.distributed as dist
from torch import Tensor

from .kv import CapacityError, DoubleFreeError
from .model import SimpleKVCache, TinyTransformer


PD_TOPIC = "pd"
ACK_TOPIC = "ack"
KV = dict[int, tuple[Tensor, Tensor]]


class PdStaleMessage(ValueError):
    """消息 epoch 已过期或已释放；不能改变任何当前请求。"""


class PdCancelled(RuntimeError):
    """交接或逐步解码期间，请求已被取消。"""


class PdChannelClosed(RuntimeError):
    """通道已关闭或对端已退出。"""


def _integer(name: str, value: int, minimum: int = 0) -> None:
    if type(value) is not int or value < minimum:
        raise ValueError(f"{name} 必须是 >= {minimum} 的整数")


def _seconds(name: str, value: float) -> None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{name} 必须是秒数")
    if not math.isfinite(value) or value <= 0:
        raise ValueError(f"{name} 必须为有限正数")


def _key(request_id: str, epoch: int) -> None:
    if not isinstance(request_id, str) or not request_id:
        raise ValueError("request_id 必须为非空字符串")
    _integer("epoch", epoch)


def _shapes(kv: KV, length: int) -> dict[int, tuple[int, ...]]:
    if not isinstance(kv, dict) or not kv:
        raise ValueError("kv 必须是非空的逐层 K/V 字典")
    shapes = {}
    for layer, pair in kv.items():
        _integer("layer_idx", layer)
        if not isinstance(pair, tuple) or len(pair) != 2:
            raise ValueError("每层必须提供 (k,v)")
        k, v = pair
        if not isinstance(k, Tensor) or not isinstance(v, Tensor):
            raise TypeError("K/V 必须为张量")
        if (k.device.type != "cpu" or v.device.type != "cpu"
                or not k.is_floating_point() or k.dtype != v.dtype):
            raise ValueError("K/V 必须是相同 dtype 的 CPU 浮点张量")
        if k.ndim != 4 or k.shape != v.shape or k.shape[0] != 1:
            raise ValueError("K/V 必须具有相同的 [1,Hkv,T,D] shape")
        if k.shape[2] != length:
            raise ValueError("kv_len 必须等于 len(token_ids)-1")
        if k.shape[1] <= 0 or k.shape[3] <= 0:
            raise ValueError("Hkv/D 必须为正数")
        shapes[layer] = tuple(k.shape)
    return shapes


@dataclass(frozen=True)
class Prepare:
    """预告层号到 [1,Hkv,kv_len,D] 的 shape；kv_len=num_tokens-1。"""

    request_id: str
    epoch: int
    num_tokens: int
    kv_len: int
    kv_shape: dict[int, tuple[int, ...]]

    def __post_init__(self) -> None:
        _key(self.request_id, self.epoch)
        _integer("num_tokens", self.num_tokens, 1)
        _integer("kv_len", self.kv_len)
        if self.kv_len != self.num_tokens - 1:
            raise ValueError("kv_len 必须等于 len(token_ids)-1 (num_tokens-1)")
        if not isinstance(self.kv_shape, dict) or not self.kv_shape:
            raise ValueError("kv_shape 必须为非空字典")
        for layer, shape in self.kv_shape.items():
            _integer("layer_idx", layer)
            if (not isinstance(shape, tuple) or len(shape) != 4
                    or any(type(n) is not int for n in shape)
                    or shape[0] != 1 or shape[1] <= 0 or shape[2] != self.kv_len
                    or shape[3] <= 0):
                raise ValueError("kv_shape 必须为 [1,Hkv,kv_len,D]")


@dataclass(frozen=True)
class Data:
    """token_ids: 非空 int 列表；kv: 各层 CPU 浮点 (K,V)，T=len(ids)-1。"""

    request_id: str
    epoch: int
    token_ids: list[int]
    kv: KV

    def __post_init__(self) -> None:
        _key(self.request_id, self.epoch)
        if (not isinstance(self.token_ids, list) or not self.token_ids
                or any(type(t) is not int or t < 0 for t in self.token_ids)):
            raise ValueError("token_ids 必须是非空的非负 int 列表")
        _shapes(self.kv, len(self.token_ids) - 1)

    def prepare(self) -> Prepare:
        """生成与本载荷一致的形状预告。"""
        self.__post_init__()
        length = len(self.token_ids) - 1
        return Prepare(self.request_id, self.epoch, len(self.token_ids), length,
                       _shapes(self.kv, length))


@dataclass(frozen=True)
class Ack:
    """D 已验证并重建暂存缓存；使用 (request_id,epoch) 匹配。"""

    request_id: str
    epoch: int

    def __post_init__(self) -> None:
        _key(self.request_id, self.epoch)


@dataclass(frozen=True)
class Commit(Ack):
    """P 已收到 Ack 并清理所有权；D 可以开始解码。"""

    reason: str = "handoff"

    def __post_init__(self) -> None:
        super().__post_init__()
        if not isinstance(self.reason, str) or not self.reason:
            raise ValueError("reason 必须为非空字符串")


@dataclass(frozen=True)
class Release(Commit):
    """释放该 epoch；同 epoch 网络重放成功且无操作，旧 epoch 仍拒绝。"""

    reason: str = "released"


@dataclass(frozen=True)
class Cancel(Release):
    """取消等价于带原因的 Release；可在交接的任一阶段使用。"""

    reason: str = "cancelled"


@dataclass(frozen=True)
class PdRequest:
    """P 接收的缓存快照；hold 时再次复制，调用方后续改动不会影响交接。"""

    request_id: str
    token_ids: list[int]
    kv: KV

    def __post_init__(self) -> None:
        Data(self.request_id, 0, self.token_ids, self.kv)

    @classmethod
    def from_cache(cls, request_id: str, token_ids: list[int], cache: SimpleKVCache) -> PdRequest:
        """从 greedy_decode 的缓存提取各层张量；返回独立 CPU 快照。"""
        if not isinstance(cache, SimpleKVCache):
            raise TypeError("cache 必须是 SimpleKVCache")
        return cls(request_id, list(token_ids), {
            layer: (k.detach().clone(), cache.v_cache[layer].detach().clone())
            for layer, k in cache.k_cache.items()})


def message_bytes(payload: Data | PdRequest) -> int:
    """返回逻辑载荷字节：int64 token_ids + 各层 K/V numel×element_size。

    不含 Prepare/Ack/Commit/Release、pickle、shape、协议头与链路重复传输；
    每次重发 Data 都应单独计一次。结果是整数，非链路抓包字节数。
    """
    if not isinstance(payload, (Data, PdRequest)):
        raise TypeError("payload 必须为 Data 或 PdRequest")
    payload.__post_init__()
    return len(payload.token_ids) * 8 + sum(
        t.numel() * t.element_size() for pair in payload.kv.values() for t in pair)


class Channel(ABC):
    """按 topic 收发可 pickle 消息；recv 的可选 timeout 单位为秒。

    超时抛 TimeoutError，关闭抛 PdChannelClosed；close 幂等并清空本地队列。
    应用使用 pd/ack 两个 topic，不能同时有多个接收者消费同一个 topic。
    """

    @abstractmethod
    def send(self, topic: str, message: object) -> None:
        """发送一条消息，失败显式抛异常。"""

    @abstractmethod
    def recv(self, topic: str, timeout: float | None = None) -> object:
        """取下一条消息；timeout=None 持续等待。"""

    @abstractmethod
    def close(self) -> None:
        """关闭通道。"""


class InProcessChannel(Channel):
    """共享 queue.Queue 的进程内通道；P/D 使用同一个实例，线程安全。"""

    def __init__(self) -> None:
        self._queues: dict[str, queue.Queue] = {}
        self._lock = threading.RLock()
        self._closed = False
        self._error: Exception | None = None

    def _queue(self, topic: str) -> queue.Queue:
        if not isinstance(topic, str) or not topic:
            raise ValueError("topic 必须为非空字符串")
        with self._lock:
            if self._closed:
                raise PdChannelClosed("通道已关闭")
            if self._error is not None:
                raise PdChannelClosed(str(self._error)) from self._error
            return self._queues.setdefault(topic, queue.Queue())

    def send(self, topic: str, message: object) -> None:
        """以 pickle 值拷贝入队，避免发送后修改张量污染对端。"""
        payload = pickle.dumps(message, protocol=pickle.HIGHEST_PROTOCOL)
        with self._lock:
            self._queue(topic).put(payload)

    def recv(self, topic: str, timeout: float | None = None) -> object:
        if timeout is not None:
            if timeout != 0:
                _seconds("timeout", timeout)
        deadline = None if timeout is None else time.monotonic() + timeout
        while True:
            inbox = self._queue(topic)
            remaining = 0.02 if deadline is None else max(0., min(0.02, deadline - time.monotonic()))
            try:
                return pickle.loads(inbox.get(timeout=remaining))
            except queue.Empty:
                if deadline is not None and time.monotonic() >= deadline:
                    raise TimeoutError(f"等待 topic={topic} 超时") from None

    @property
    def pending_count(self) -> int:
        """本端尚未消费的消息数量，便于验证回收。"""
        with self._lock:
            return sum(inbox.qsize() for inbox in self._queues.values())

    def close(self) -> None:
        with self._lock:
            self._closed = True
            self._queues.clear()


class GlooChannel(InProcessChannel):
    """两 rank gloo CPU 端点；须由 spawn 子进程初始化进程组后构造。

    控制头 pickle 化为 uint8 张量，Data 的 token_ids/K/V 独立 send/recv；
    后台接收线程解帧并按 topic 入队，使应用层超时不破坏 gloo 连接。
    同一进程组不能再有其他点对点接收者。双方必须最终调用 close，
    close 后再 destroy_process_group；进程组由调用方管理（参见实验）。
    close 对关闭帧发送线程及接收线程分别限时 join，超时记入 close_errors
    并抛 TimeoutError，仍清空本地队列。Python 无法强制中断阻塞的 gloo
    调用；残留守护线程须由调用方销毁进程组或通信自身超时来解除。
    """

    def __init__(self, peer: int, *, close_timeout: float = 5.) -> None:
        super().__init__()
        _seconds("close_timeout", close_timeout)
        if not dist.is_initialized() or dist.get_backend() != "gloo":
            raise ValueError("需要已初始化的 gloo 进程组")
        if (dist.get_world_size() != 2 or type(peer) is not int
                or peer not in (0, 1) or peer == dist.get_rank()):
            raise ValueError("GlooChannel 仅支持两个 rank 的对端")
        self.peer = peer
        self.close_timeout = close_timeout
        self.close_errors: list[Exception] = []
        self._send_lock = threading.Lock()
        self._peer_closed = threading.Event()
        self._receiver = threading.Thread(target=self._receive_loop, daemon=True, name="pd-gloo-recv")
        self._receiver.start()

    def _wire_send(self, header: object, tensors: list[Tensor]) -> None:
        encoded = pickle.dumps(header, protocol=pickle.HIGHEST_PROTOCOL)
        control = torch.tensor(list(encoded), dtype=torch.uint8)
        with self._send_lock:
            dist.send(torch.tensor([control.numel()], dtype=torch.int64), self.peer)
            dist.send(control, self.peer)
            for tensor in tensors:
                if tensor.numel():
                    dist.send(tensor.detach().contiguous(), self.peer)

    def send(self, topic: str, message: object) -> None:
        self._queue(topic)  # 相同 topic/关闭校验
        tensors = []
        if isinstance(message, Data):
            message.__post_init__()
            tensors = [torch.tensor(message.token_ids, dtype=torch.int64)]
            layers = sorted(message.kv)
            for layer in layers:
                tensors.extend(message.kv[layer])
            body = (message.request_id, message.epoch, layers)
        else:
            body = message
        specs = [(tuple(t.shape), t.dtype) for t in tensors]
        self._wire_send((topic, body, specs), tensors)

    def _receive_loop(self) -> None:
        try:
            while True:
                size = torch.empty(1, dtype=torch.int64)
                dist.recv(size, self.peer)
                control = torch.empty(int(size.item()), dtype=torch.uint8)
                dist.recv(control, self.peer)
                header = pickle.loads(bytes(control.tolist()))
                if header is None:
                    self._peer_closed.set()
                    return
                topic, body, specs = header
                tensors = []
                for shape, dtype in specs:
                    tensor = torch.empty(shape, dtype=dtype)
                    if tensor.numel():
                        dist.recv(tensor, self.peer)
                    tensors.append(tensor)
                if specs:
                    request_id, epoch, layers = body
                    body = Data(request_id, epoch, tensors[0].tolist(), {
                        layer: (tensors[1 + i * 2], tensors[2 + i * 2])
                        for i, layer in enumerate(layers)})
                InProcessChannel.send(self, topic, body)
        except Exception as error:
            self._error = error
            self._peer_closed.set()

    def recv(self, topic: str, timeout: float | None = None) -> object:
        # 正常 close 帧之后仍允许消费此前已入队的消息。
        if self._peer_closed.is_set() and self.pending_count == 0:
            raise PdChannelClosed("gloo 对端已关闭")
        return super().recv(topic, timeout)

    def _queue(self, topic: str) -> queue.Queue:
        inbox = super()._queue(topic)
        if hasattr(self, "_peer_closed") and self._peer_closed.is_set() and inbox.empty():
            raise PdChannelClosed("gloo 对端已关闭")
        return inbox

    def close(self) -> None:
        if self._closed:
            return

        def send_close() -> None:
            try:
                self._wire_send(None, [])
            except Exception as error:
                self.close_errors.append(error)

        try:
            sender = None
            if self._error is None:
                sender = threading.Thread(target=send_close, daemon=True, name="pd-gloo-close")
                sender.start()
                sender.join(self.close_timeout)
                if sender.is_alive():
                    self.close_errors.append(TimeoutError("gloo 关闭帧发送超时"))
            self._receiver.join(self.close_timeout)
            if self._receiver.is_alive():
                self.close_errors.append(TimeoutError("gloo 对端未关闭接收线程"))
            if self.close_errors:
                self._error = self.close_errors[0]
                raise self._error
        finally:
            super().close()


@dataclass
class _Held:
    data: Data
    prepared: bool = False


class PrefillWorker:
    """P 所有权登记与交接；handoff 串行，release/cancel 可由其他线程调用。

    held 仅含 P 拥有的载荷；transferred 仅含取消路由所需 epoch，无 KV。
    Ack 前异常保留 held；Ack 后即转移，Commit 发送失败可再次 handoff 补发。
    """

    def __init__(self, channel: Channel, *, ack_timeout: float = 1., max_requests: int = 1024) -> None:
        if not isinstance(channel, Channel):
            raise TypeError("channel 必须实现 Channel")
        _seconds("ack_timeout", ack_timeout)
        _integer("max_requests", max_requests, 1)
        self.channel = channel
        self.ack_timeout = ack_timeout
        self.max_requests = max_requests
        self.held: dict[str, _Held] = {}
        self.transferred: dict[str, int] = {}
        self._epochs: dict[str, int] = {}
        self._lock = threading.RLock()
        self._handoff_lock = threading.Lock()
        self.sent_bytes = 0

    @property
    def owned_count(self) -> int:
        """P 当前实际持有的请求数，不含转移后的路由元数据。"""
        return len(self.held)

    def hold(self, request: PdRequest) -> int:
        """登记并复制 CPU 请求，返回从 0 起按 request_id 递增的 epoch。"""
        if not isinstance(request, PdRequest):
            raise TypeError("request 必须为 PdRequest")
        request.__post_init__()
        with self._lock:
            rid = request.request_id
            if rid in self.held or rid in self.transferred:
                raise ValueError("request_id 尚未释放")
            if len(self.held) >= self.max_requests:
                raise CapacityError("P 请求容量不足")
            epoch = self._epochs.get(rid, -1) + 1
            data = Data(rid, epoch, list(request.token_ids), {
                layer: (k.detach().clone(), v.detach().clone()) for layer, (k, v) in request.kv.items()})
            self.held[rid] = _Held(data)
            self._epochs[rid] = epoch
            return epoch

    def handoff(self, request_id: str) -> int:
        """prepare→data→等待 Ack→清理 P→Commit，返回 epoch；超时可原 epoch 重试。"""
        with self._handoff_lock:
            with self._lock:
                if request_id in self.transferred:
                    epoch = self.transferred[request_id]
                    self.channel.send(PD_TOPIC, Commit(request_id, epoch))
                    return epoch
                if request_id not in self.held:
                    raise DoubleFreeError("P 未持有该请求")
                held = self.held[request_id]
                data = held.data
                # 先标记，保证 send 抛错或与取消交错时也能发送回收消息。
                held.prepared = True
            self.channel.send(PD_TOPIC, data.prepare())
            with self._lock:
                if self.held.get(request_id) is not held:
                    raise PdCancelled(request_id)
            self.channel.send(PD_TOPIC, data)
            self.sent_bytes += message_bytes(data)
            deadline = time.monotonic() + self.ack_timeout
            while True:
                with self._lock:
                    if self.held.get(request_id) is not held:
                        raise PdCancelled(request_id)
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise TimeoutError(f"Ack 超时: {(request_id, data.epoch)}，P 保留所有权")
                try:
                    ack = self.channel.recv(ACK_TOPIC, timeout=min(remaining, 0.02))
                except TimeoutError:
                    continue
                if type(ack) is not Ack:
                    raise TypeError("ack topic 只能包含 Ack")
                if (ack.request_id, ack.epoch) != (request_id, data.epoch):
                    continue  # 丢弃前次交接延迟到达的 Ack，不改变本次超时截止点。
                with self._lock:
                    if self.held.get(request_id) is not held:
                        raise PdCancelled(request_id)
                    del self.held[request_id]
                    self.transferred[request_id] = data.epoch
                self.channel.send(PD_TOPIC, Commit(request_id, data.epoch))
                return data.epoch

    def _release(self, request_id: str, reason: str, message_type: type[Release]) -> None:
        with self._lock:
            held = self.held.get(request_id)
            epoch = held.data.epoch if held is not None else self.transferred.get(request_id)
            if epoch is None:
                raise DoubleFreeError("请求已经释放或从未登记")
            message = message_type(request_id, epoch, reason)
            # 发送异常时保留登记，可重试；发送成功后统一删除载荷与路由。
            if held is None or held.prepared:
                self.channel.send(PD_TOPIC, message)
            self.held.pop(request_id, None)
            self.transferred.pop(request_id, None)

    def release(self, request_id: str, reason: str = "released") -> None:
        """统一回收 P 载荷或通知 D 回收；重复调用抛 DoubleFreeError。"""
        self._release(request_id, reason, Release)

    def cancel(self, request_id: str, reason: str = "cancelled") -> None:
        """交接前直接释放，传输中/交接后发送 Cancel 并清理 P 登记。"""
        self._release(request_id, reason, Cancel)


@dataclass
class _Decoded:
    prepare: Prepare
    token_ids: list[int]
    cache: SimpleKVCache
    committed: bool = False
    steps: int = 0


class DecodeWorker:
    """D 接收状态机；暂存缓存不具有执行权，Commit 后 decode 才可续生成。

    pending 是未收到 Data 的预告；states 是 Ack 后的暂存/已提交缓存。
    latest/released 只保存 epoch tombstone，不保存张量。run 在非法/过期消息后
    继续服务，并把异常记录到 errors；直接 process/serve_once 则显式抛错。
    failed 保存前向/重建失败的 epoch；失败请求清空缓存且不可再次解码。
    """

    def __init__(self, model: TinyTransformer, channel: Channel, *, data_timeout: float = 1.) -> None:
        if not isinstance(model, TinyTransformer):
            raise TypeError("model 必须为 TinyTransformer")
        if model.embedding.weight.device.type != "cpu":
            raise ValueError("仅支持 CPU 模型")
        if not isinstance(channel, Channel):
            raise TypeError("channel 必须实现 Channel")
        _seconds("data_timeout", data_timeout)
        self.model, self.channel, self.data_timeout = model, channel, data_timeout
        self.pending: dict[str, tuple[Prepare, float]] = {}
        self.states: dict[str, _Decoded] = {}
        self.latest: dict[str, int] = {}
        self.released: dict[str, int] = {}
        self.failed: dict[str, int] = {}
        self.errors: list[Exception] = []
        self.expired_prepares = 0
        self._lock = threading.RLock()

    @property
    def state_count(self) -> int:
        """D 的预告与缓存登记总数（含未提交副本）。"""
        return len(self.pending) + len(self.states)

    def expire_pending(self) -> int:
        """清理 Prepare 后缺失 Data 的超时预告；仍允许原 epoch 重新 Prepare。"""
        with self._lock:
            expired = [rid for rid, (_, deadline) in self.pending.items() if time.monotonic() >= deadline]
            for rid in expired:
                del self.pending[rid]
            self.expired_prepares += len(expired)
            return len(expired)

    def _check_epoch(self, message: Ack | Prepare | Data) -> None:
        rid, epoch = message.request_id, message.epoch
        if (epoch < self.latest.get(rid, -1) or epoch <= self.released.get(rid, -1)
                or epoch <= self.failed.get(rid, -1)):
            raise PdStaleMessage(f"过期/已释放: {(rid, epoch)}")

    def _fail(self, request_id: str, epoch: int) -> None:
        """回收失败请求的全部缓存与预告，仅保留失败 epoch 墓碑。"""
        state = self.states.pop(request_id, None)
        if state is not None:
            state.cache.k_cache.clear()
            state.cache.v_cache.clear()
        self.pending.pop(request_id, None)
        self.latest[request_id] = epoch
        self.failed[request_id] = epoch

    def _check_prepare(self, message: Prepare) -> None:
        message.__post_init__()
        config = self.model.config
        expected = (1, config.n_kv_heads, message.kv_len, config.d_model // config.n_heads)
        if (set(message.kv_shape) != set(range(config.n_layers))
                or any(shape != expected for shape in message.kv_shape.values())):
            raise ValueError("预告的层数/shape 与 D 模型不匹配")
        if message.kv_len > config.max_seq_len:
            raise ValueError("kv_len 超出 D 模型 max_seq_len")

    def process(self, message: object) -> None:
        """处理单条协议消息；校验先于修改，异常加入 errors 并原样抛出。"""
        with self._lock:
            try:
                self._process(message)
            except Exception as error:
                # 只记录异常值；原 traceback 会引用 Data/KV 与当前缓存，妨碍回收。
                self.errors.append(type(error)(*error.args))
                raise

    def _process(self, message: object) -> None:
        if not isinstance(message, (Prepare, Data, Ack)):
            raise TypeError("缺少协议消息字段或消息类型非法")
        message.__post_init__()  # pickle 不调用构造器；接收时再次校验。
        rid, epoch = message.request_id, message.epoch
        if (isinstance(message, Release) and epoch == self.released.get(rid)
                and epoch == self.latest.get(rid)):
            return
        self._check_epoch(message)
        if isinstance(message, Release):
            self.latest[rid] = epoch
            self.released[rid] = epoch
            self.pending.pop(rid, None)
            self.states.pop(rid, None)
        elif isinstance(message, Prepare):
            self._check_prepare(message)
            state = self.states.get(rid)
            pending = self.pending.get(rid)
            prior = state.prepare if state else pending[0] if pending else None
            if prior and prior.epoch == epoch:
                if prior != message:
                    raise ValueError("同 epoch Prepare 的元数据不一致")
                if pending:
                    self.pending[rid] = (message, time.monotonic() + self.data_timeout)
                return
            self.states.pop(rid, None)
            self.latest[rid] = epoch
            self.failed.pop(rid, None)
            self.pending[rid] = (message, time.monotonic() + self.data_timeout)
        elif isinstance(message, Data):
            prepare = message.prepare()
            self._check_prepare(prepare)
            if any(t.dtype != self.model.embedding.weight.dtype for pair in message.kv.values() for t in pair):
                raise ValueError("KV dtype 与 D 模型不匹配")
            if any(t >= self.model.config.vocab_size for t in message.token_ids):
                raise ValueError("token_ids 超出词表")
            state = self.states.get(rid)
            if state and state.prepare.epoch == epoch:
                if state.prepare != prepare:
                    raise ValueError("重复 Data shape 与原预告不符")
                self.channel.send(ACK_TOPIC, Ack(rid, epoch))
                return
            pending = self.pending.get(rid)
            if not pending or pending[0] != prepare:
                raise ValueError("Data 缺少匹配的 Prepare 或 shape 不符")
            cache = SimpleKVCache()
            try:
                for layer, (k, v) in message.kv.items():
                    cache.append(layer, k.detach().clone(), v.detach().clone())
            except Exception:
                cache.k_cache.clear()
                cache.v_cache.clear()
                self._fail(rid, epoch)
                raise
            self.states[rid] = _Decoded(prepare, list(message.token_ids), cache)
            del self.pending[rid]
            self.channel.send(ACK_TOPIC, Ack(rid, epoch))
        elif isinstance(message, Commit):
            state = self.states.get(rid)
            if state is None or state.prepare.epoch != epoch:
                raise ValueError("Commit 缺少匹配的 Data")
            state.committed = True
        else:
            raise TypeError("D 不接收 Ack")

    def serve_once(self, timeout: float = 0.02) -> None:
        """收取一条 pd 消息并处理；即使空闲也执行 Prepare 超时回收。"""
        self.expire_pending()
        message = self.channel.recv(PD_TOPIC, timeout=timeout)
        self.expire_pending()
        self.process(message)

    def run(self, stop: threading.Event) -> None:
        """接收循环，stop 置位后返回；不隐式解码，以便独立控制生成预算。"""
        while not stop.is_set():
            try:
                self.serve_once()
            except PdChannelClosed:
                return
            except Exception:
                continue

    @torch.no_grad()
    def decode(self, request_id: str, max_tokens: int) -> list[int]:
        """Commit 后额外贪心生成 max_tokens 个 token，返回含原前缀的 int 列表。

        首步重喂最后 token，start_pos=len(ids)-1；每步后仍维持 T=len(ids)-1。
        不检测 EOS；逐 token 锁允许接收线程在步间处理取消，取消抛 PdCancelled。
        每步在独立缓存上完成所有层后整体提交；失败标记 failed、丢弃全部缓存
        并原样抛错，已成功生成的其他请求不受影响。
        """
        _integer("max_tokens", max_tokens)
        with self._lock:
            state = self.states.get(request_id)
            if state is None or not state.committed:
                raise ValueError("请求尚未 Commit")
            if len(state.token_ids) - 1 + max_tokens > self.model.config.max_seq_len:
                raise ValueError("解码位置超出 max_seq_len")
        for _ in range(max_tokens):
            with self._lock:
                if self.states.get(request_id) is not state:
                    raise PdCancelled(request_id)
                cache = SimpleKVCache()
                try:
                    for layer, k in state.cache.k_cache.items():
                        cache.append(layer, k.detach().clone(), state.cache.v_cache[layer].detach().clone())
                    logits = self.model(torch.tensor([state.token_ids[-1:]], dtype=torch.int64),
                                        start_pos=len(state.token_ids) - 1, kv_cache=cache)[0, -1]
                    token = int(logits.argmax().item())
                except Exception as error:
                    cache.k_cache.clear()
                    cache.v_cache.clear()
                    self._fail(request_id, state.prepare.epoch)
                    self.errors.append(type(error)(*error.args))
                    raise
                state.cache = cache
                state.token_ids.append(token)
                state.steps += 1
        with self._lock:
            if self.states.get(request_id) is not state:
                raise PdCancelled(request_id)
            return list(state.token_ids)

    def release(self, request_id: str, reason: str = "released") -> None:
        """D 本地统一回收，重复 release 抛 DoubleFreeError；网络 Release 可重放。"""
        with self._lock:
            state = self.states.get(request_id)
            pending = self.pending.get(request_id)
            if state is None and pending is None:
                raise DoubleFreeError("D 未持有该请求")
            epoch = state.prepare.epoch if state else pending[0].epoch
            self.process(Release(request_id, epoch, reason))
