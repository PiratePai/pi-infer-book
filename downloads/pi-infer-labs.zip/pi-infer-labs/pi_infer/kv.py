"""固定 KV 块池、整块前缀树与实现整段读写协议的请求视图。"""

from __future__ import annotations

from dataclasses import dataclass, field
import heapq
from typing import Literal, Sequence

import torch
from torch import Tensor


class CapacityError(RuntimeError):
    """块池剩余容量不足。"""


class DoubleFreeError(RuntimeError):
    """释放了未持有的块或请求。"""


class BlockAllocator:
    """每块存储所有层的 KV；布局为 [块,2,层,Hkv,槽位,D]。

    num_blocks 是跨层逻辑块数量，理论 token 容量为 num_blocks*block_size。
    allocated_bytes 统计固定池实际张量字节数，与当前占用率无关。
    """

    def __init__(
        self, num_blocks: int, block_shape: Sequence[int], *, n_layers: int = 1,
        dtype: torch.dtype = torch.float32, device: torch.device | str = "cpu",
    ) -> None:
        if len(block_shape) != 3 or any(not isinstance(x, int) or x <= 0 for x in block_shape):
            raise ValueError("block_shape 必须是正整数 [Hkv,block_size,D]")
        if not isinstance(num_blocks, int) or num_blocks <= 0 or not isinstance(n_layers, int) or n_layers <= 0:
            raise ValueError("num_blocks 与 n_layers 必须为正整数")
        self.block_shape = tuple(block_shape)
        self.n_layers = n_layers
        self.storage = torch.empty((num_blocks, 2, n_layers, *block_shape), dtype=dtype, device=device)
        self._free = list(range(num_blocks))
        self._allocated: set[int] = set()
        self.versions = [0] * num_blocks

    @property
    def total_blocks(self) -> int:
        """固定块总数。"""
        return self.storage.shape[0]

    @property
    def used_blocks(self) -> int:
        """正在被请求持有的物理块数。"""
        return len(self._allocated)

    @property
    def free_blocks(self) -> int:
        """可分配块数。"""
        return len(self._free)

    @property
    def allocated_bytes(self) -> int:
        """固定张量池的实际字节数。"""
        return self.storage.numel() * self.storage.element_size()

    def allocate(self, n: int) -> list[int]:
        """原子分配 n 块；容量不足不改变状态。"""
        if not isinstance(n, int) or n < 0:
            raise ValueError("n 必须为非负整数")
        if n > self.free_blocks:
            raise CapacityError(f"需要 {n} 块，仅余 {self.free_blocks} 块")
        ids = [heapq.heappop(self._free) for _ in range(n)]
        for block_id in ids:
            self._allocated.add(block_id)
            self.versions[block_id] += 1
        return ids

    def free(self, ids: Sequence[int]) -> None:
        """整批校验后释放，重复 id 也视为重复释放。"""
        if len(set(ids)) != len(ids) or any(i not in self._allocated for i in ids):
            raise DoubleFreeError("块未分配或重复释放")
        for block_id in ids:
            self._allocated.remove(block_id)
            heapq.heappush(self._free, block_id)

    def _claim(self, block_id: int) -> None:
        """重新持有未被覆盖的弱缓存块，保持版本与数据。"""
        if block_id not in self._allocated:
            self._free.remove(block_id)
            heapq.heapify(self._free)
            self._allocated.add(block_id)


@dataclass
class BlockTable:
    """逻辑块序号对应 block_ids 下标；valid_tokens 记录各块有效槽位。"""

    block_ids: list[int] = field(default_factory=list)
    valid_tokens: list[int] = field(default_factory=list)


@dataclass
class Hit:
    """只返回可共享的完整块；部分匹配尾块必须由请求重新计算。"""

    block_ids: list[int]
    num_matched: int
    tail_block_partial: bool


@dataclass
class _Node:
    """版本号防止已回收并重写的物理块被错误命中。"""

    children: dict[tuple[int, ...], _Node] = field(default_factory=dict)
    block_id: int = -1
    version: int = -1


class PrefixCache:
    """按模型隔离的整块前缀树；引用属于请求，树仅保留弱索引。

    最后一个请求释放后立即归还块池；尚未重新分配的内容仍可重新持有。
    普通 allocate 会递增版本，旧前缀因此安全失效。match 本身不获取引用。
    """

    def __init__(self, allocator: BlockAllocator) -> None:
        self.allocator = allocator
        self.block_size = allocator.block_shape[1]
        self._roots: dict[str, _Node] = {}
        self._requests: dict[tuple[str, str], PagedRequestCache] = {}
        self.ref_counts: dict[int, int] = {}

    def _valid(self, node: _Node) -> bool:
        return node.block_id >= 0 and self.allocator.versions[node.block_id] == node.version

    def match(self, model_id: str, token_ids: Sequence[int]) -> Hit:
        """逐块精确匹配；部分尾块仅报告命中，不共享物理存储。"""
        node = self._roots.get(model_id)
        ids: list[int] = []
        size = self.block_size
        offset = 0
        while node is not None and offset + size <= len(token_ids):
            child = node.children.get(tuple(token_ids[offset:offset + size]))
            if child is None or not self._valid(child):
                break
            ids.append(child.block_id)
            offset += size
            node = child
        partial = False
        tail = tuple(token_ids[offset:offset + size])
        if node is not None and tail:
            for key, child in node.children.items():
                if not self._valid(child):
                    continue
                common = 0
                while common < len(tail) and key[common] == tail[common]:
                    common += 1
                partial |= 0 < common < size
        for (namespace, _), request in self._requests.items():
            if namespace != model_id:
                continue
            common = 0
            limit = min(len(token_ids), request.num_tokens, len(request.token_ids))
            while common < limit and token_ids[common] == request.token_ids[common]:
                common += 1
            partial |= common > offset and common % size != 0
        return Hit(ids, offset, partial)

    def _retain(self, ids: Sequence[int]) -> None:
        for block_id in ids:
            self.allocator._claim(block_id)
            self.ref_counts[block_id] = self.ref_counts.get(block_id, 0) + 1

    def _drop(self, ids: Sequence[int]) -> None:
        for block_id in ids:
            count = self.ref_counts[block_id] - 1
            if count:
                self.ref_counts[block_id] = count
            else:
                del self.ref_counts[block_id]
                self.allocator.free([block_id])

    def extend(self, model_id: str, request_id: str, token_ids: Sequence[int]) -> None:
        """登记所有层均已写完且已知 token 身份的稳定完整块。"""
        request = self._requests[(model_id, request_id)]
        limit = min(request.num_tokens, len(token_ids))
        node = self._roots.setdefault(model_id, _Node())
        for offset in range(0, limit - self.block_size + 1, self.block_size):
            key = tuple(token_ids[offset:offset + self.block_size])
            block_id = request.table.block_ids[offset // self.block_size]
            child = node.children.setdefault(key, _Node())
            if not self._valid(child):
                child.children.clear()
                child.block_id = block_id
                child.version = self.allocator.versions[block_id]
            node = child

    def release(
        self, model_id: str, request_id: str,
        reason: Literal["finished", "cancelled", "failed"],
    ) -> None:
        """所有结束原因使用相同回收路径，移除请求私有登记。"""
        if reason not in {"finished", "cancelled", "failed"}:
            raise ValueError("未知 release reason")
        request = self._requests.pop((model_id, request_id), None)
        if request is None:
            raise DoubleFreeError("请求未登记或已经释放")
        self._drop(request.table.block_ids)
        request._released = True


class PagedKVCache:
    """组合固定池与前缀树；每个请求视图支持 batch=1 的 KVCache 协议。"""

    def __init__(
        self, num_blocks: int, block_shape: Sequence[int], *, n_layers: int = 1,
        dtype: torch.dtype = torch.float32, device: torch.device | str = "cpu",
    ) -> None:
        self.allocator = BlockAllocator(num_blocks, block_shape, n_layers=n_layers, dtype=dtype, device=device)
        self.prefix_cache = PrefixCache(self.allocator)

    @property
    def token_capacity(self) -> int:
        """全部层可容纳的完整 token 数。"""
        return self.allocator.total_blocks * self.allocator.block_shape[1]

    @property
    def allocated_bytes(self) -> int:
        """池张量实际字节数。"""
        return self.allocator.allocated_bytes

    def request(self, model_id: str, request_id: str, prompt_ids: Sequence[int]) -> PagedRequestCache:
        """获取前缀引用并建立独立请求状态。"""
        key = (model_id, request_id)
        if key in self.prefix_cache._requests:
            raise ValueError("request_id 已登记")
        hit = self.prefix_cache.match(model_id, prompt_ids)
        self.prefix_cache._retain(hit.block_ids)
        request = PagedRequestCache(self, model_id, request_id, list(prompt_ids), hit)
        self.prefix_cache._requests[key] = request
        return request

    def release(self, model_id: str, request_id: str, reason: Literal["finished", "cancelled", "failed"]) -> None:
        """转发统一请求回收接口。"""
        self.prefix_cache.release(model_id, request_id, reason)


class PagedRequestCache:
    """请求级整段 KV 视图；整块共享，部分尾块永远私有。"""

    def __init__(self, owner: PagedKVCache, model_id: str, request_id: str, token_ids: list[int], hit: Hit) -> None:
        self.owner, self.model_id, self.request_id = owner, model_id, request_id
        self.token_ids = token_ids
        self.num_matched = hit.num_matched
        self.table = BlockTable(list(hit.block_ids), [self.block_size] * len(hit.block_ids))
        self._lengths = [hit.num_matched] * self.allocator.n_layers
        self._released = False

    @property
    def allocator(self) -> BlockAllocator:
        """所属固定块池。"""
        return self.owner.allocator

    @property
    def block_size(self) -> int:
        """每块槽位数。"""
        return self.allocator.block_shape[1]

    @property
    def num_tokens(self) -> int:
        """所有层均已完成的 token 数。"""
        return min(self._lengths)

    @property
    def prefill_start_pos(self) -> int:
        """下一次 prefill 应使用的绝对起点。"""
        return self.num_tokens

    def _check(self, layer_idx: int | None = None) -> None:
        if self._released:
            raise DoubleFreeError("请求已释放")
        if layer_idx is not None and not 0 <= layer_idx < self.allocator.n_layers:
            raise ValueError("layer_idx 越界")

    def record_tokens(self, token_ids: Sequence[int], start_pos: int) -> None:
        """可选模型钩子：KV 协议本身不携带 token 身份。"""
        self._check()
        if start_pos > len(self.token_ids):
            raise ValueError("token 身份不能有空洞")
        self.token_ids[start_pos:] = list(token_ids)

    def append(self, layer_idx: int, k: Tensor, v: Tensor) -> None:
        """按层写入尾块和新块；全部层完成后登记稳定前缀。"""
        self._check(layer_idx)
        heads, _, dim = self.allocator.block_shape
        if k.ndim != 4 or k.shape != v.shape or k.shape[0:2] != (1, heads) or k.shape[3] != dim:
            raise ValueError("K/V 必须为相同的 [1,Hkv,T,D] 形状")
        if any(x.dtype != self.allocator.storage.dtype or x.device != self.allocator.storage.device for x in (k, v)):
            raise ValueError("K/V 的 dtype/device 必须与块池一致")
        start = self._lengths[layer_idx]
        end = start + k.shape[2]
        needed = (end + self.block_size - 1) // self.block_size - len(self.table.block_ids)
        ids = self.allocator.allocate(max(0, needed))
        self.owner.prefix_cache._retain(ids)
        self.table.block_ids.extend(ids)
        for pos in range(start, end):
            block_id = self.table.block_ids[pos // self.block_size]
            slot = pos % self.block_size
            self.allocator.storage[block_id, 0, layer_idx, :, slot].copy_(k[0, :, pos - start].detach())
            self.allocator.storage[block_id, 1, layer_idx, :, slot].copy_(v[0, :, pos - start].detach())
        self._lengths[layer_idx] = end
        length = self.num_tokens
        self.table.valid_tokens = [max(0, min(self.block_size, length - i * self.block_size)) for i in range(len(self.table.block_ids))]
        self.owner.prefix_cache.extend(self.model_id, self.request_id, self.token_ids)

    def get(self, layer_idx: int) -> tuple[Tensor | None, Tensor | None]:
        """跨块 gather，只返回本层已经写入的 [1,Hkv,T,D]。"""
        self._check(layer_idx)
        length = self._lengths[layer_idx]
        if not length:
            return None, None
        parts = []
        for i in range((length + self.block_size - 1) // self.block_size):
            block = self.allocator.storage[self.table.block_ids[i], :, layer_idx]
            parts.append(block[:, :, :min(self.block_size, length - i * self.block_size)])
        kv = torch.cat(parts, dim=2)
        return kv[0].unsqueeze(0), kv[1].unsqueeze(0)

    def truncate_to(self, length: int) -> None:
        """回滚所有层；切入稳定块时复制尾块，保留其他请求的完整前缀。"""
        self._check()
        if not 0 <= length <= self.num_tokens:
            raise ValueError("截断长度越界")
        if all(value == length for value in self._lengths):
            return
        keep = (length + self.block_size - 1) // self.block_size
        old_id = self.table.block_ids[keep - 1] if length % self.block_size else None
        shared_tail = old_id is not None and self.owner.prefix_cache.ref_counts[old_id] > 1
        dropped = self.table.block_ids[keep:]
        reclaimable = sum(self.owner.prefix_cache.ref_counts[i] == 1 for i in dropped)
        if shared_tail and self.allocator.free_blocks + reclaimable == 0:
            raise CapacityError("共享尾块写时复制需要一块可用空间")
        self.owner.prefix_cache._drop(dropped)
        del self.table.block_ids[keep:]
        if length % self.block_size:
            if shared_tail:
                new_id = self.allocator.allocate(1)[0]
                self.allocator.storage[new_id].copy_(self.allocator.storage[old_id])
                self.owner.prefix_cache._retain([new_id])
                self.owner.prefix_cache._drop([old_id])
                self.table.block_ids[keep - 1] = new_id
            else:
                # 独占块可原地截断；更换版本，使树中原完整块索引失效。
                self.allocator.versions[old_id] += 1
        self._lengths = [length] * self.allocator.n_layers
        self.table.valid_tokens = [min(self.block_size, length - i * self.block_size) for i in range(keep)]
        del self.token_ids[length:]

    def release(self, reason: Literal["finished", "cancelled", "failed"] = "finished") -> None:
        """释放请求拥有的全部引用。"""
        self.owner.release(self.model_id, self.request_id, reason)
