"""CPU 教学 MoE：整 token 溢出、专家执行账与 EP 逻辑载荷公式。

任一 top-k 专家满位时，整 token 残差直通且不占用任何专家槽位。这是
简化语义；文献还有按专家粒度丢弃的变体，不冒充 Switch 原文语义。
EP 仅公式推演：本项目 gloo 路径无 all-to-all，不执行或实测通信。
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import torch
from torch import Tensor, nn

from .model import SwiGLU


def _positive_int(name: str, value: object) -> None:
    if type(value) is not int or value < 1:
        raise ValueError(f"{name} 必须是正整数")


def _positive_real(name: str, value: object) -> None:
    if (isinstance(value, bool) or not isinstance(value, (int, float))
            or not math.isfinite(value) or value <= 0):
        raise ValueError(f"{name} 必须是有限正数")


def _check_k(k: int, num_experts: int) -> None:
    if type(k) is not int or not 1 <= k <= num_experts:
        raise ValueError("k 必须是 1..num_experts 的整数")


def _check_seed(seed: int) -> None:
    if type(seed) is not int or not 0 <= seed < 2**63:
        raise ValueError("seed 必须是 [0, 2**63) 的整数")


@dataclass(frozen=True)
class MoEConfig:
    """独立 MoE 配置；不受注意力 head 维约束，容量不额外乘 k。"""

    d_model: int = 64
    d_ff: int = 176
    num_experts: int = 8
    k: int = 1
    capacity_factor: float = 1.0
    seed: int = 0

    def __post_init__(self) -> None:
        for name in ("d_model", "d_ff", "num_experts"):
            _positive_int(name, getattr(self, name))
        _check_k(self.k, self.num_experts)
        _positive_real("capacity_factor", self.capacity_factor)
        _check_seed(self.seed)


class Router(nn.Module):
    """无 bias 线性 logits → softmax → top-k；支持 CPU 浮点张量。"""

    def __init__(self, d_model: int, num_experts: int, k: int = 1) -> None:
        super().__init__()
        _positive_int("d_model", d_model)
        _positive_int("num_experts", num_experts)
        _check_k(k, num_experts)
        self.d_model, self.num_experts, self.k = d_model, num_experts, k
        self.linear = nn.Linear(d_model, num_experts, bias=False)

    def forward(self, x: Tensor, k: int | None = None) -> tuple[Tensor, Tensor]:
        """[T,d] → (int64 [T,k], 同输入浮点 dtype [T,k])，按 gate 降序。

        返回原 softmax 概率，不对 top-k 再归一化；平分时以专家 id 升序破平。
        输入须非空、有限、CPU，dtype 与权重相同；非法 shape/dtype 抛错。
        """
        k = self.k if k is None else k
        _check_k(k, self.num_experts)
        _check_x(x, self.d_model, self.linear.weight)
        logits = self.linear(x)
        if not torch.isfinite(logits).all():
            raise ValueError("logits 必须有限")
        probabilities = logits.softmax(dim=-1)
        indices = probabilities.argsort(dim=-1, descending=True, stable=True)[:, :k]
        return indices, probabilities.gather(1, indices)


def _check_x(x: Tensor, d_model: int, weight: Tensor) -> None:
    if not isinstance(x, Tensor):
        raise TypeError("x 必须是 Tensor")
    if x.ndim != 2 or x.shape[0] == 0 or x.shape[1] != d_model:
        raise ValueError("x 必须是非空 [T,d_model]")
    if x.device.type != "cpu" or weight.device.type != "cpu":
        raise ValueError("仅支持 CPU")
    if not x.is_floating_point() or x.dtype != weight.dtype:
        raise TypeError("x 必须为与权重相同 dtype 的浮点张量")
    if not torch.isfinite(x).all():
        raise ValueError("x 必须有限")


@dataclass(frozen=True)
class MoEStats:
    """一次前向账本，计数为接纳后的专家 token 数，另记原始请求数。

    activated_params = 专家并集大小 × P，P=3*d*d_ff；不含 router。
    total_params 含 router，expert_total_params 单列，激活比例只比较专家。
    executed_flops = 2*P*sum(expert_token_counts)，即逐专家 2*参数*处理数；
    不能把并集参数直接乘 T（各专家处理数不同）。只估三次线性矩阵乘，
    不含 router、SiLU、门控合并、残差与内存访问；FMA 计两次 FLOP。
    等价 dense 是 d_ff_dense=N*d_ff、相同专家总参数的 SwiGLU，每 token
    全执行一次；另列单专家宽度 dense 参考，避免比较基准歧义。
    EP 为两次 all-to-all，每次 sum(sent_e)*d*4B，固定 float32 逻辑载荷
    假设（即使模型转成其他 dtype）；不含 metadata/本地放置优化/协议开销。
    项目 gloo 路径无 all-to-all；这些值是公式推演，非实测链路字节。
    """

    tokens: int
    k: int
    capacity: int
    capacity_limit: float
    requested_token_counts: list[int]
    expert_token_counts: list[int]
    overflow_tokens: int
    overflow_rate: float
    active_experts: int
    expert_params: int
    activated_params: int
    expert_total_params: int
    router_params: int
    total_params: int
    activated_param_ratio: float
    processed_tokens: int
    expert_token_assignments: int
    executed_flops: int
    dense_flops: int
    flops_ratio_vs_dense: float
    single_expert_dense_flops: int
    flops_ratio_vs_single_expert_dense: float
    ep_dispatch_bytes: int
    ep_return_bytes: int
    ep_total_bytes: int
    ep_bytes_per_token: float


class MoEFFN(nn.Module):
    """固定种子、独立 SwiGLU 权重的 CPU MoE；forward 返回 (输出, stats)。

    容量 limit=ceil(T/N)*capacity_factor，不乘 k；整数槽位取 floor(limit)。
    按 token 输入顺序接纳，任一所选专家满位则该 token 整体残差直通，
    不预占其他专家槽位。未溢出输出为 sum(gate_j*Expert_j(x))，不加 x。
    此整 token 规则是简化语义；另有按专家粒度丢弃的文献变体，不等同于
    Switch 原文语义。初始化隔离 RNG，连续构造不依赖全局随机数状态。
    """

    def __init__(self, config: MoEConfig) -> None:
        super().__init__()
        if not isinstance(config, MoEConfig):
            raise TypeError("config 必须是 MoEConfig")
        self.config = config
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(config.seed)
            self.router = Router(config.d_model, config.num_experts, config.k)
            self.experts = nn.ModuleList(SwiGLU(config) for _ in range(config.num_experts))

    def forward(
        self, x: Tensor, routing: tuple[Tensor, Tensor] | None = None,
    ) -> tuple[Tensor, MoEStats]:
        """CPU 浮点 [T,d] → (同 shape/dtype 输出, MoEStats)。

        routing 可注入 (int64 indices [T,k], 浮点 gates [T,k])，CPU 且同
        x dtype；每行专家唯一、gate 有限非负、和在 (0,1]，无需再归一化。
        行和用 float64 累加，仅允许上界额外 1e-5 的绝对舍入误差。
        gates 按所给权重使用，外部路由无需排序；非法输入显式抛错。
        """
        cfg = self.config
        _check_x(x, cfg.d_model, self.router.linear.weight)
        indices, gates = self.router(x) if routing is None else self._routing(x, routing)
        limit = math.ceil(x.shape[0] / cfg.num_experts) * cfg.capacity_factor
        if not math.isfinite(limit):
            raise ValueError("capacity_factor 导致容量超出有限范围")
        capacity = math.floor(limit)
        counts = [0] * cfg.num_experts
        accepted = []
        # 原子接纳：拒绝的 token 在所有专家上均不占位。
        for chosen in indices.tolist():
            fits = all(counts[e] < capacity for e in chosen)
            accepted.append(fits)
            if fits:
                for expert in chosen:
                    counts[expert] += 1
        mask = torch.tensor(accepted, dtype=torch.bool)
        output = torch.where(mask[:, None], torch.zeros_like(x), x)
        for expert, module in enumerate(self.experts):
            tokens, slots = torch.where((indices == expert) & mask[:, None])
            if tokens.numel():
                weighted = module(x[tokens]) * gates[tokens, slots, None]
                output = output.index_add(0, tokens, weighted)
        requested = torch.bincount(indices.flatten(), minlength=cfg.num_experts).tolist()
        processed = sum(accepted)
        assignments = sum(counts)
        p = sum(parameter.numel() for parameter in self.experts[0].parameters())
        router_p = sum(parameter.numel() for parameter in self.router.parameters())
        active = sum(count > 0 for count in counts)
        dense = 2 * p * cfg.num_experts * len(accepted)
        flops = 2 * p * assignments
        ep = assignments * cfg.d_model * 4
        stats = MoEStats(
            tokens=len(accepted), k=cfg.k, capacity=capacity, capacity_limit=limit,
            requested_token_counts=requested, expert_token_counts=counts,
            overflow_tokens=len(accepted) - processed,
            overflow_rate=1 - processed / len(accepted), active_experts=active,
            expert_params=p, activated_params=active * p,
            expert_total_params=cfg.num_experts * p, router_params=router_p,
            total_params=cfg.num_experts * p + router_p,
            activated_param_ratio=active / cfg.num_experts,
            processed_tokens=processed, expert_token_assignments=assignments,
            executed_flops=flops, dense_flops=dense, flops_ratio_vs_dense=flops / dense,
            single_expert_dense_flops=dense // cfg.num_experts,
            flops_ratio_vs_single_expert_dense=flops / (dense // cfg.num_experts),
            ep_dispatch_bytes=ep, ep_return_bytes=ep, ep_total_bytes=2 * ep,
            ep_bytes_per_token=2 * ep / len(accepted),
        )
        return output, stats

    def _routing(self, x: Tensor, routing: tuple[Tensor, Tensor]) -> tuple[Tensor, Tensor]:
        if not isinstance(routing, tuple) or len(routing) != 2:
            raise TypeError("routing 必须是 (indices, gates) 元组")
        indices, gates = routing
        if not isinstance(indices, Tensor) or not isinstance(gates, Tensor):
            raise TypeError("indices/gates 必须是 Tensor")
        shape = (x.shape[0], self.config.k)
        if tuple(indices.shape) != shape or tuple(gates.shape) != shape:
            raise ValueError("routing shape 必须为 [T,k]")
        if indices.device.type != "cpu" or gates.device.type != "cpu":
            raise ValueError("routing 仅支持 CPU")
        if indices.dtype != torch.int64 or gates.dtype != x.dtype:
            raise TypeError("indices 必须 int64，gates dtype 必须与 x 相同")
        if (indices < 0).any() or (indices >= self.config.num_experts).any():
            raise ValueError("专家 id 越界")
        ordered = indices.sort(dim=-1).values
        if (ordered[:, 1:] == ordered[:, :-1]).any():
            raise ValueError("每 token 所选专家必须唯一")
        sums = gates.sum(dim=-1, dtype=torch.float64)
        tolerance = 1e-5
        if (not torch.isfinite(gates).all() or (gates < 0).any()
                or (sums <= 0).any() or (sums > 1 + tolerance).any()):
            raise ValueError("gates 必须有限非负且每行之和在 (0,1]")
        return indices, gates


def controlled_router_probs(
    num_experts: int, dist: str, *, p: float = 0.8, temperature: float = 1.0,
    logits: Tensor | None = None,
) -> Tensor:
    """返回 float32 CPU [N] 概率，支持 uniform/peak/temperature。

    peak 的专家 0 概率 p，其余均分（N>=2，0<p<1）；temperature 默认
    logits=linspace(1,-1,N)，也可提供有限浮点 CPU [N]，按 logits/温度
    softmax。非法分布、p、温度或 logits 抛 ValueError/TypeError。
    """
    _positive_int("num_experts", num_experts)
    if not isinstance(dist, str) or dist not in ("uniform", "peak", "temperature"):
        raise ValueError("dist 必须为 uniform、peak 或 temperature")
    _positive_real("temperature", temperature)
    if isinstance(p, bool) or not isinstance(p, (int, float)) or not 0 < p < 1:
        raise ValueError("p 必须在 (0,1)")
    if dist == "uniform":
        return torch.full((num_experts,), 1 / num_experts, dtype=torch.float32)
    if dist == "peak":
        if num_experts < 2:
            raise ValueError("peak 要求 num_experts >= 2")
        probabilities = torch.full((num_experts,), (1 - p) / (num_experts - 1), dtype=torch.float32)
        probabilities[0] = p
        return probabilities
    if logits is None:
        logits = torch.linspace(1, -1, num_experts, dtype=torch.float32)
    if not isinstance(logits, Tensor):
        raise TypeError("logits 必须是 Tensor")
    if (logits.shape != (num_experts,) or logits.device.type != "cpu"
            or not logits.is_floating_point() or not torch.isfinite(logits).all()):
        raise ValueError("logits 必须是有限 CPU 浮点 [N]")
    # double 中除温度并减 max，避免低温时 float32 除法溢出。
    scaled = (logits.double() - logits.double().max()) / temperature
    return scaled.softmax(dim=-1).float()


def controlled_routing(
    num_experts: int, k: int, dist: str, *, tokens: int = 64, p: float = 0.8,
    temperature: float = 1.0, seed: int = 0, logits: Tensor | None = None,
) -> tuple[Tensor, Tensor]:
    """生成 (int64 [T,k], float32 [T,k])，固定 seed，不改变全局 RNG。

    uniform 使用随机排列循环的分层均匀路由，各专家边际等概率，完整周期
    负载精确均衡（并非 iid 抽样）；peak/temperature 每 token 按概率无放回
    采样 k 个专家。p 是抽样底分布概率，k>1 时不是最终命中率。
    gates 为所选底分布概率归一化，再按 gate 降序；极低温零概率采用
    float32 tiny 下限以支持 k=N。非法 k/T/seed/分布参数均显式报错。
    """
    _positive_int("num_experts", num_experts)
    _check_k(k, num_experts)
    _positive_int("tokens", tokens)
    _check_seed(seed)
    probabilities = controlled_router_probs(
        num_experts, dist, p=p, temperature=temperature, logits=logits,
    )
    generator = torch.Generator().manual_seed(seed)
    if dist == "uniform":
        permutation = torch.randperm(num_experts, generator=generator)
        positions = (torch.arange(tokens)[:, None] * k + torch.arange(k)) % num_experts
        indices = permutation[positions]
    else:
        probabilities = probabilities.clamp_min(torch.finfo(torch.float32).tiny)
        # 逐 token 抽样使相同 seed 的不同 T 具有相同路由前缀。
        indices = torch.stack([torch.multinomial(probabilities, k, replacement=False,
                                               generator=generator) for _ in range(tokens)])
    selected = probabilities[indices]
    gates = selected / selected.sum(dim=-1, keepdim=True)
    order = gates.argsort(dim=-1, descending=True, stable=True)
    return indices.gather(1, order), gates.gather(1, order)
